package SStoRM;

import java.awt.Color;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleInsets;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.net.URL;

/** 
 * This class creates a chart that graphs the time evolution of an SPE.
 * Only "your SPE" can be drawn in the graph. But other lines are
 * shown in the graph by using an image of other historical time evolution
 * curves. This means that the most tricky part of this graph is syncing 
 * the background to an 
 * outside image of time evolutions. This image is TimeEvolutionBackdrop.jpg
 * and was obtained from Ron Turner.
 * <p>
 * The graph ranges on the X axis from -1 to 10 days and on the Y
 * axis from 10^-2 to 10^4 in particle flux.
 * <p>
 * <b>Usage</b>
 * <p>
 * Before you use this class, you must have the image TimeEvolutionBackdrop.jpg
 * in a current folder as the .class file.
 * <pre>
 * // You must first create "your SPE"
 * SolarParticleEvent yourSPE = new SolarParticleEvent();
 * // or
 * DoubleEvent yourSPE = new SolarParticleEvent();
 * // Followed by more initializing of the events.
 * 
 * // Now, create the chart
 * TimeEvolutionGraph graphObject = new TimeEvolutionGraph(yourSPE);
 * // Now, get the actual chart panel to place in a swing object
 * ChartPanel chartPanel = graphObject.getChartPanel;
 * // Now, you can say something line
 * jContentPane.add(ChartPanel); // or whatever else you want to do with the time evolution graph
 * @author Joshua Lande
 */
public class TimeEvolutionGraph { 
	/**
	 * Holds that data series that takes points from "your SPE". This is useful
	 * because it can be modified later.
	 */
    
	private XYSeries yourSPESeries=null;
    
	/**
     * The data set that holds your SPE.
     */
    private XYSeriesCollection dataset;
    
    /**
     * That chart that holds your SPE as well as the image of the other historical SPEs.
     */
    private JFreeChart chart;

    /** 
     * The lower bound of the range.
     */
    private static final double MINIMUM_FLUX = 1e-2;
    
    /**
     * The upper bound of the range.
     */
    private static final double MAXIMUM_FLUX = 1e4;
   
    /**
     * The first point in time in which to get a time evolution flux for and graph.
     */
    private static final Time MINIMUM_TIME=Time.inDays(-1);
    
    /**
     * The last point in time in which to get a time evolution flux for and graph. 
     */
    private static final Time MAXIMUM_TIME=Time.inDays(5);
    
    /**
     * The step size used to find time evolution flux values.
     */
    private static final Time timeStep=Time.inDays(.05);
    
    /**
     * This constructor takes in an SPE and initializes the chart 
     * with that SPE in it. 
     * <p>
     * The code to get an image gets in as an imageURL. The image
     * must currentally be in the same folder as the .class file.
     * I'm not actually entirely sure how this works because
     * once it is all bundled in the eclipse fat jar, I'm not
     * entirely sure what the structure of everything is. But
     * in eclipse, if you put the picture in the same folder
     * as the .java and .class file, this class will be able 
     * to open the picture both running inside of eclipse and
     * outside as a fat jar.
     * <p>
     * The code example I used to figure out how to get the image
     * from inside a fat jar was found at 
     * http://forum.java.sun.com/thread.jspa?threadID=588857&tstart=240
     * I'm not entirely sure how this works, but it does.
     * @param inputEvent The SPE to put in the time evolution graph.
     * @throws IllegalArgumentException If the object passed does not implement SolarParticleEventInterface.
     */
    public TimeEvolutionGraph(Object inputEvent) throws IllegalArgumentException{
    	SolarParticleEventInterface yourSPE = (SolarParticleEventInterface)inputEvent;
        dataset = new XYSeriesCollection();
        chart = createChart(dataset);
        XYPlot plot = (XYPlot) chart.getPlot();  
        addYourSPE(yourSPE);
        
        try {
        	// load the image into the plot's background
        	URL imageURL = Thread.currentThread().getContextClassLoader() 
				.getResource("SStoRM/TimeEvolutionBackdrop.jpg");
	 
        	ImageIcon icon = new ImageIcon(imageURL); // get the icon from the URL.
        	Image image = icon.getImage(); // get the image from the icon
        	plot.setBackgroundImage(image); // set the background of the plot to the image
        } catch (Exception exception) { // image failed to load, do nothing.
        }
    }
    
    /**
     * This method puts the time evolution graph into a chart panel, 
     * disables zooming the graph, disables the right
     * click pop up menu of the graph, and returns the panel for use.
     * @return A ChartPanel 
     */
    public ChartPanel getChartPanel() {
    	ChartPanel panel= new ChartPanel(chart);
    	panel.setDomainZoomable(false);
    	panel.setRangeZoomable(false);
    	panel.setPopupMenu(null); 
        return panel;
    }   
    
    /**
     * Adds your SPE to the chart. It gets time evolution values for
     * the SPE for times from {@link #MINIMUM_TIME} to {@link #MAXIMUM_TIME}.
     * @param inputEvent The solar particle event to put in the graph.
     * @throws IllegalArgumentException If the object passed does not implement SolarParticleEventInterface.
     */
    private void addYourSPE(Object inputEvent) throws IllegalArgumentException {
    	SolarParticleEventInterface yourSPE = (SolarParticleEventInterface)inputEvent;
    	if (yourSPE==null) throw new IllegalArgumentException("SPEs sent to the time evolution graph must be defined");
    	yourSPESeries = new XYSeries(yourSPE.getName()); // store the series for safe keeping.
        try {
        	for (Time time =(Time)MINIMUM_TIME.clone();time.getDays()<=MAXIMUM_TIME.getDays();time.add(timeStep))            
        		yourSPESeries.add(time.getDays(),yourSPE.getTimeEvolutionFluxWithCWithGCR(time));
        } catch (IllegalArgumentException exception) { 
        }
        dataset.addSeries(yourSPESeries); // add the series to the data set  
        XYPlot plot = (XYPlot) chart.getPlot(); 
        plot.setDataset(dataset); // add the dataset to the plot
    }
    
    /**
     * Changes your SPE by clearing all flux points and replacing them with points from the newly passed
     * solar particle event. This graph is only updated with a new
     * SPE if the spe passed is changed.
     * @param inputEvent The updated solar particle event.
     * @throws IllegalArgumentException If the object passed does not implement SolarParticleEventInterface.
     */
    public void changeYourSPE(Object inputEvent) {
    	SolarParticleEventInterface yourSPE = (SolarParticleEventInterface)inputEvent;
    	if (yourSPE==null) throw new IllegalArgumentException("SPEs sent to the time evolution graph must be defined");
    	yourSPESeries.clear(); // reset series
        try {
        	for (Time time =(Time)MINIMUM_TIME.clone();time.getDays()<=MAXIMUM_TIME.getDays();time.add(timeStep))      
        		yourSPESeries.add(time.getDays(),yourSPE.getTimeEvolutionFluxWithCWithGCR(time));
        } catch (IllegalArgumentException exception) { // do nothing
        }
    }

    /**
     * Creates a chart when given an XYDataset. It is given the proper title, x axis, y axis, 
     * and set to the correct domain and range.
     * @param dataset The data for the chart.
     * @return A chart.
     */
    private static JFreeChart createChart(XYDataset dataset) { 
        JFreeChart chart = ChartFactory.createXYLineChart(
            "Time Evolution of your SPE",      		// chart title
            "Time (days)", 							// x-axis label
            "Particle Flux (protons/cm^2-sec-sr)",  // y-axis label
            dataset,                  				// data
            PlotOrientation.VERTICAL,
            true,                     				// include legend
            true,                     				// tooltips
            false                     				// urls
        );
        chart.setBackgroundPaint(Color.white);
        XYPlot plot = (XYPlot) chart.getPlot();
        plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
        
        // remove gridlines (the dotted lines in the background of the graph)
        plot.setDomainGridlinesVisible(false);
        plot.setRangeGridlinesVisible(false);

        // set log axis for the domain
        LogarithmicAxis rangeAxis=new LogarithmicAxis("Particle Flux (protons/cm^2-sec-sr)"); 
        rangeAxis.setLog10TickLabelsFlag(true);
        rangeAxis.setTickMarksVisible(false);
        rangeAxis.setRange(MINIMUM_FLUX,MAXIMUM_FLUX);
        plot.setRangeAxis(rangeAxis);
                 
        NumberAxis domainAxis=new NumberAxis("Time (days)"); 
	    domainAxis.setRange(MINIMUM_TIME.getDays(),MAXIMUM_TIME.getDays());    
        plot.setDomainAxis(domainAxis); 
        return chart;  
    }
    
}
