package SStoRM;

import java.awt.Color;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.LogarithmicAxis;

import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleInsets;

/**
 * This class creates a chart that graphs energy spectrum as a function of energy.
 * This chart holds "your SPE" and a variable number of other SPEs. 
 * This object allows for "your SPE" to be changed after it is created with a 
 * call to {@link #changeYourSPE}. your SPE is distinguished from
 * the other SPEs by having series shapes. 
 * This chart is a double log scale with the X axis varying from 10 to 1000 MeV and
 * the Y axis varying from 1 up to the first order of magnitude larger then biggest 
 * fluence value 
 * in the chart. This means that the largest point must be stored
 * and rounded up to the next largest order of magnitude to find the range. 
 * To accomplish this,
 * the maximum point on your SPE is stored in {@link #maxYourSPEFluenceValue} and the maximum
 * for the points of any other SPE is stored in {@link #maxOtherSPEFluenceValue}. The maximum 
 * value is then the larger of these points. We need to hold 2 values because your SPE can
 * change. If we only held one maximum and yourSPE changed, we would not know if the previous
 * maximum was from your SPE or another one. So it is easier to simply hold 2 maximums.
 * <p>
 * <b>To use this object:</b>
 * <p>
 * first you must create yourSPE (and a bunch of other SPEs). Then you can say:
 * <pre>
 * 		SolarParticleEventInterface yourSPE = new SolarParticleEvent(1e9,0,30,"yourSPE");
 * 		// make other SPEs here
 *		EnergySpectrumFluenceGraph graph=new EnergySpectrumGraph(yourSPE); // create the object. It must be passed your SPE
 *		EnergySpectrumChartPanel graphPanel=graph.getChartPanel();
 *		
 *		// Put other SPEs in the chart now
 *	 	graph.addOtherSPE(anotherSPE); // etc, 
 *		
 *		// put the chart in a panel.
*		mainPanel.add(graphPanel); 
 * </pre>
 * The last tricky thing to realize about this class is that it gets fluence points from 10 to 1000
 * to chart on the graph. But  of looping from 10 to 1000 in even increments would disproportionately
 * put points towards the right. Instead, this class loops from {@link #ENERGY_START} to {@link #ENERGY_STOP} in 
 * {@link #ENERGY_STEP} step sizes. This
 * means that the class loop from 1 to 3.1 in .1 step sizes. Each time it gets a value by incrementing 
 * by the step size, it finds
 * the fluence by raising 10 to that value. This means that on a log graph, points are all placed evenly
 * along the x axis.
 * @author Joshua Lande
 */
public class EnergySpectrumGraph {
  
	/**
	 * The XY Series holding your SPE. This is useful 
	 * to have when changing your SPE with a call to {@link #changeYourSPE}.
	 */
    private XYSeries yourSPESeries=null;
    
    /**
     * The XY Series holding the first curve of your SPE, if your SPE is a double Event. This is only useful if the graph is passed a double event.
     */
    private XYSeries yourSPESeriesCurve_1=null;
    
    /**
     * Like {@link #yourSPESeriesCurve_1}, but for the second curve of the double event.
     */
    private XYSeries yourSPESeriesCurve_2=null;
    
    /**
     * The data set of the chart. it is used later to add other SPEs and change your SPE.
     */
    private XYSeriesCollection dataset;
    
    /**
     * This is the chart that holds the curves
     */
    private JFreeChart chart;

    /**
     * This is the maximum fluence value found for other SPEs. It is used for finding
     * the upper range of the domain (Y-axis) by {@link #resetRangeAxis}. It defaults 
     * to 1, which is also the minimum fluence value.
     */
    private double maxOtherSPEFluenceValue=1;
    /**
     * This is the maximum fluence value found for your SPE. It is used for finding
     * the upper range of the domain (Y-axis) by {@link #resetRangeAxis}. It defaults 
     * to 1, which is also the minimum fluence value.
     */
    private double maxYourSPEFluenceValue=1;
    
    /**
     * The minimum energy value to loop from when findinding fluence values. The actual energy value
     * used though is instead 10^ENERGY_START = 10.
     */
    private static final double ENERGY_START=1;
    /**
     * The maximum energy value to loop to when finding fluence values. The actual energy value used 
     * though is instead 10^ENERGY_STOP which is slightly bigger then 1000.
     */
    private static final double ENERGY_STOP=3.1;
    /**
     * The step size to use when looping from {@link #ENERGY_START} to {@link #ENERGY_STOP} to find energy fluence values.
     */
    private static final double ENERGY_STEP=.1;

    
    /**
     * This constructor takes in your SPE and initializes the chart 
     * with that SPE in it. 
     * @param event
     */
    public EnergySpectrumGraph(SolarParticleEventInterface event) {
        dataset = new XYSeriesCollection();
        chart = createChart(dataset);
        addYourSPE(event);
    }

    /**
     * Exact same as {@link #EnergySpectrumGraph(SolarParticleEventInterface)}, but takes a {@link DoubleEvent}.
     * @param event
     */
    public EnergySpectrumGraph(DoubleEvent event) {
        dataset = new XYSeriesCollection();
        chart = createChart(dataset);
        addYourSPE(event);
    }

    /**
     * Exact same as {@link #EnergySpectrumGraph(SolarParticleEventInterface)}, but takes a {@link EventWithShockEnhancedPeak}.
     * @param event
     */
    public EnergySpectrumGraph(EventWithShockEnhancedPeak event) {
        dataset = new XYSeriesCollection();
        chart = createChart(dataset);
        addYourSPE(event);
    }

    /**
     * This method puts the energy spectrum graph into a chart panel, 
     * disables zooming the graph, disables the right
     * click popup menu of the graph, and returns the panel for use.
     * @return A ChartPanel 
     */
    public ChartPanel getChartPanel() {
    	ChartPanel panel= new ChartPanel(chart);
    	panel.setDomainZoomable(false);
    	panel.setRangeZoomable(false);
    	panel.setPopupMenu(null); 
        return panel;
    }

    /**
     * Sets the scale of the chart so that it's lowest point is 1 and it's highest point is the larger
     * of {@link #maxYourSPEFluenceValue} and {@link #maxOtherSPEFluenceValue}.
     */
    private void resetRangeAxis() {
    	if (chart==null) return;
    	double max=Log.roundUpOrderOfMagnitude(Math.max(maxYourSPEFluenceValue,maxOtherSPEFluenceValue));
    	max = Math.max(max,1); // max must be at least 1
    	((XYPlot)chart.getPlot()).getRangeAxis().setRange(1.0,max);
    }
    
    /**
     * Adds your SPE to the chart. It gets fluence values from
     * the SPE for energy values ranging from 10 to 1000. It uses the 10^value trick to get 
     * even increments on a log graph.
     */
    private void addYourSPE(SolarParticleEventInterface yourInputSPE) {
    	if (yourInputSPE==null) throw new IllegalArgumentException("SPEs sent to the energy spectrum graph must be defined");
    	yourSPESeries = new XYSeries(yourInputSPE.getName()); // store the series for safe keeping
        try {
        	for (double E =ENERGY_START;E<=ENERGY_STOP;E+=ENERGY_STEP) { // loop through all energy values
        		double temp=yourInputSPE.getEnergySpectrumFluence(Math.pow(10,E));
        		maxYourSPEFluenceValue = Math.max(maxYourSPEFluenceValue, temp); // store max
        		yourSPESeries.add(Math.pow(10,E),temp); // add point to series
        	}
        } catch (IllegalArgumentException exception) { // catch errors (such as if the SPE is not set
        } finally {
            dataset.addSeries(yourSPESeries); // add series to data set 
            resetRangeAxis();
        	XYPlot plot = (XYPlot) chart.getPlot(); // set shapes of yourSPE to be visible.
        	XYLineAndShapeRenderer renderer=(XYLineAndShapeRenderer)plot.getRenderer();
        	renderer.setSeriesShapesVisible(0,true);
        	renderer.setSeriesPaint(0,Color.RED);
        }
    }
    
    /**
     * Exact same as {@link EnergySpectrumGraph#addYourSPE(SolarParticleEventInterface)}, but takes a {@link DoubleEvent}. 
     * It needs the double event so that it can draw individual curves for each part of the event.
     */
    private void addYourSPE(DoubleEvent yourInputSPE) {
    	if (yourInputSPE==null) throw new IllegalArgumentException("SPEs sent to the energy spectrum graph must be defined");
    	
    	
    	yourSPESeries = new XYSeries(yourInputSPE.getName()); // store the series for safe keeping    	
    	yourSPESeriesCurve_1 = new XYSeries("Event 1");
    	yourSPESeriesCurve_2 = new XYSeries("Event 2");
        try {
        	for (double E =ENERGY_START;E<=ENERGY_STOP;E+=ENERGY_STEP) { // loop through all energy values
        		double temp=yourInputSPE.getEnergySpectrumFluence(Math.pow(10,E));
        		maxYourSPEFluenceValue = Math.max(maxYourSPEFluenceValue, temp); // store max
        		yourSPESeries.add(Math.pow(10,E),temp); // add point to series
        		
        		// add points for the first and second curve, who's sum is the total curve.
        		yourSPESeriesCurve_1.add(Math.pow(10,E),yourInputSPE.getEnergySpectrumFluence_1(Math.pow(10,E)));
        		yourSPESeriesCurve_2.add(Math.pow(10,E),yourInputSPE.getEnergySpectrumFluence_2(Math.pow(10,E)));
        	}
        } catch (IllegalArgumentException exception) { // catch errors (such as if the SPE is not set
        } finally {
            dataset.addSeries(yourSPESeries); // add series to data set 
            dataset.addSeries(yourSPESeriesCurve_1); 
            dataset.addSeries(yourSPESeriesCurve_2); 
            resetRangeAxis();
        	XYPlot plot = (XYPlot) chart.getPlot(); // set shapes of yourSPE to be visible.
        	XYLineAndShapeRenderer renderer=(XYLineAndShapeRenderer)plot.getRenderer();
        	renderer.setSeriesShapesVisible(0,true);
        	renderer.setSeriesPaint(0,Color.BLACK);
        	renderer.setSeriesShapesVisible(1,true);
        	renderer.setSeriesPaint(1,Color.RED);
        	renderer.setSeriesShapesVisible(2,true);
        	renderer.setSeriesPaint(2,Color.RED);
        }
    }
    
    /**
     * Exact same as {@link EnergySpectrumGraph#addYourSPE(SolarParticleEventInterface)}, but takes an {@link EventWithShockEnhancedPeak}. 
     * It needs the double event so that it can draw individual curves for each part of the event.
     */
    private void addYourSPE(EventWithShockEnhancedPeak yourInputSPE) {
    	if (yourInputSPE==null) throw new IllegalArgumentException("SPEs sent to the energy spectrum graph must be defined");
    	yourSPESeries = new XYSeries(yourInputSPE.getName()); // store the series for safe keeping    	
    	yourSPESeriesCurve_1 = new XYSeries("Event");
    	yourSPESeriesCurve_2 = new XYSeries("Peak");
        try {
        	for (double E =ENERGY_START;E<=ENERGY_STOP;E+=ENERGY_STEP) { // loop through all energy values
        		double temp=yourInputSPE.getEnergySpectrumFluence(Math.pow(10,E));
        		maxYourSPEFluenceValue = Math.max(maxYourSPEFluenceValue, temp); // store max
        		yourSPESeries.add(Math.pow(10,E),temp); // add point to series
        		// add points for the first and second curve, who's sum is the total curve.
        		yourSPESeriesCurve_1.add(Math.pow(10,E),yourInputSPE.getEnergySpectrumFluence_1(Math.pow(10,E)));
        		yourSPESeriesCurve_2.add(Math.pow(10,E),yourInputSPE.getShockEnhancedPeakEnergySpectrumFluence(Math.pow(10,E)));       		
        	}
        } catch (IllegalArgumentException exception) { // catch errors (such as if the SPE is not set
        } finally {
            dataset.addSeries(yourSPESeries); // add series to data set 
            dataset.addSeries(yourSPESeriesCurve_1); 
            dataset.addSeries(yourSPESeriesCurve_2); 
            resetRangeAxis();
        	XYPlot plot = (XYPlot) chart.getPlot(); // set shapes of yourSPE to be visible.
        	XYLineAndShapeRenderer renderer=(XYLineAndShapeRenderer)plot.getRenderer();
        	renderer.setSeriesShapesVisible(0,true);
        	renderer.setSeriesPaint(0,Color.BLACK);
        	renderer.setSeriesShapesVisible(1,true);
        	renderer.setSeriesPaint(1,Color.RED);
        	renderer.setSeriesShapesVisible(2,true);
        	renderer.setSeriesPaint(2,Color.RED);
        }
    }
    
    /**
     * Changes your SPE by clearing all fluence points and replacing them with points from the newly passed
     * {@link SolarParticleEventInterface}.
     * @param yourInputSPE The updated solar particle event.
     */
    public void changeYourSPE(SolarParticleEventInterface yourInputSPE) {
    	if (yourInputSPE==null) throw new IllegalArgumentException("SPEs sent to the energy spectrum graph must be defined");
    	yourSPESeries.clear(); // remove old fluence values
        maxYourSPEFluenceValue=1; // reset minimum fluence value to the default.
        try {
        	for (double E =ENERGY_START;E<=ENERGY_STOP;E+=ENERGY_STEP) { // loop through all energy values
        		double temp=yourInputSPE.getEnergySpectrumFluence(Math.pow(10,E));
        		maxYourSPEFluenceValue = Math.max(maxYourSPEFluenceValue, temp); // store max
        		yourSPESeries.add(Math.pow(10,E),temp); // add back new point to series
       		}    
       } catch (IllegalArgumentException exception) {// catch errors (such as if the SPE is not set.
       } finally {
       		resetRangeAxis();
       }
    }
    
    /**
     * Exact same as {@link EnergySpectrumGraph#changeYourSPE(SolarParticleEventInterface)}, but takes a {@link DoubleEvent}.
     * It needs the double event so that it can draw individual curves for each part of the event.
     * @param yourInputSPE The updated solar particle event. 
     */
    public void changeYourSPE(DoubleEvent yourInputSPE) throws IllegalArgumentException {
    	if (yourInputSPE==null) throw new IllegalArgumentException("SPEs sent to the energy spectrum graph must be defined");
    	yourSPESeries.clear(); // remove old fluence values
    	yourSPESeriesCurve_1.clear();
    	yourSPESeriesCurve_2.clear();
        maxYourSPEFluenceValue=1; // reset minimum fluence value to the default.
        try {
        	for (double E =ENERGY_START;E<=ENERGY_STOP;E+=ENERGY_STEP) { // loop through all energy values
        		double temp=yourInputSPE.getEnergySpectrumFluence(Math.pow(10,E));
        		maxYourSPEFluenceValue = Math.max(maxYourSPEFluenceValue, temp); // store max
        		yourSPESeries.add(Math.pow(10,E),temp); // add back new point to series   		
        		// add points for the first and second curve, who's sum is the total curve.
        		yourSPESeriesCurve_1.add(Math.pow(10,E),yourInputSPE.getEnergySpectrumFluence_1(Math.pow(10,E)));
        		yourSPESeriesCurve_2.add(Math.pow(10,E),yourInputSPE.getEnergySpectrumFluence_2(Math.pow(10,E)));
       		}    
       } catch (IllegalArgumentException exception) {// catch errors (such as if the SPE is not set.
       } finally {
       		resetRangeAxis();
       }
    }

    /**
     * Exact same as {@link EnergySpectrumGraph#changeYourSPE(SolarParticleEventInterface)}, but takes a {@link DoubleEvent}.
     * It needs the double event so that it can draw individual curves for each part of the event.
     * @param yourInputSPE The updated solar particle event. 
     */
    public void changeYourSPE(EventWithShockEnhancedPeak yourInputSPE) throws IllegalArgumentException {
    	if (yourInputSPE==null) throw new IllegalArgumentException("SPEs sent to the energy spectrum graph must be defined");
    	yourSPESeries.clear(); // remove old fluence values
    	yourSPESeriesCurve_1.clear();
    	yourSPESeriesCurve_2.clear();
        maxYourSPEFluenceValue=1; // reset minimum fluence value to the default.
        try {
        	for (double E =ENERGY_START;E<=ENERGY_STOP;E+=ENERGY_STEP) { // loop through all energy values
        		double temp=yourInputSPE.getEnergySpectrumFluence(Math.pow(10,E));
        		maxYourSPEFluenceValue = Math.max(maxYourSPEFluenceValue, temp); // store max
        		yourSPESeries.add(Math.pow(10,E),temp); // add back new point to series        		
        		// add points for the first and second curve, who's sum is the total curve.
        		yourSPESeriesCurve_1.add(Math.pow(10,E),yourInputSPE.getEnergySpectrumFluence_1(Math.pow(10,E)));
        		yourSPESeriesCurve_2.add(Math.pow(10,E),yourInputSPE.getShockEnhancedPeakEnergySpectrumFluence(Math.pow(10,E)));
       		}    
       } catch (IllegalArgumentException exception) {// catch errors (such as if the SPE is not set.
       } finally {
       		resetRangeAxis();
       }
    }
    
    /**
     * This method adds another solar particle event to the graph. It gets fluence values from
     * the SPE for energy values ranging from 10 to 1000. It uses the 10^value trick to get 
     * even increments on a log graph.
     * @param inputEvent One of the other SPEs to add to the chart. The SPE must implement
     * {@link SolarParticleEventInterface}. Either a {@link SolarParticleEvent} or a {@link DoubleEvent} should do.
	 * @throws IllegalArgumentException If the object passed dose not implement the SolarParticleEventInterface.
     */
    public void addOtherSPE(Object inputEvent) {
    	SolarParticleEventInterface event = (SolarParticleEventInterface)inputEvent; // turn the inputted object into a SPE interface.    	
    	XYSeries newSeries = new XYSeries(event.getName()); // create a new data series
        try {      
        	for (double E = ENERGY_START; E<=ENERGY_STOP; E+=ENERGY_STEP) { // loop through all energy values
        		double currentFluence=event.getEnergySpectrumFluence(Math.pow(10,E));
        		maxOtherSPEFluenceValue = Math.max(maxOtherSPEFluenceValue, currentFluence); // store max
        		newSeries.add(Math.pow(10,E),currentFluence); // add point to series
        	}      
        	dataset.addSeries(newSeries); // add series to data set
        	resetRangeAxis(); 
        } catch (IllegalArgumentException exception) {} // do nothing	
    }
   
    /**
     * Creates a chart when given an XYDataset. It is given the proper title, x axis, y axis, 
     * and set to be a double log axis. 
     * @param dataset The data for the chart.
     * @return A chart.
     */
    private static JFreeChart createChart(XYDataset dataset) { 
        JFreeChart chart = ChartFactory.createXYLineChart(  // create the chart
            "Fluence",      // chart title 
            "Energy (MeV)", // x axis label label
            "Particle Fluence (protons/MeV-cm^2)",  // y axis label
            dataset,                  // data
            PlotOrientation.VERTICAL,
            true,                     // include legend
            true,                     // tooltips
            false                     // urls
        );
        chart.setBackgroundPaint(Color.white);
        XYPlot plot = (XYPlot) chart.getPlot();
        plot.setBackgroundPaint(Color.lightGray);
        plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
           
        // set log axis for the domain and range.
        LogarithmicAxis rangeAxis=new LogarithmicAxis("Particle Fluence (protons/MeV-cm^2)"); 
        rangeAxis.setLog10TickLabelsFlag(true);
        rangeAxis.setTickMarksVisible(false);
        plot.setRangeAxis(rangeAxis);
        
        LogarithmicAxis domainAxis=new LogarithmicAxis("Energy (MeV)"); 
	    domainAxis.setRange(10,1000); // range axis goes from 10 to 1000
        plot.setDomainAxis(domainAxis); 
        return chart; // return the created chart
    }
    
}
