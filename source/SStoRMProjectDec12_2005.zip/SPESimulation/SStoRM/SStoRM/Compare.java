package SStoRM;

/**
 * A class to compare two doubles.
 * @author Joshua Lande
 */
public class Compare {

	/**
	 * Returns the percent error between the first number (the measured
	 * quantity) and the second number (the actual quantity). If the
	 * actual value is 0, positive infinity is returned (because there is an 
	 * infinite difference between the values). Otherwise, the following 
	 * formula is used:
	 * <pre>
	 * % difference = | measured - actual | / actual 
	 * </pre>
	 * This returns the percent as a fraction of 1. You can convert it into 
	 * a classical percent by multiplying by 100. Ex. .99 = 99%, etc.
	 * @param measured The measured value.
	 * @param assumedToBeTrue The value assumed to be true (or the actual value).
	 * @return The percent error.
	 */
	public static double percentError(double measured, double assumedToBeTrue) {
		if (Double.isNaN(measured) || Double.isNaN(assumedToBeTrue)) throw new IllegalArgumentException("The parameters must be numbers");
		if (assumedToBeTrue == 0 && measured == 0) return 0; // if both #s are 0, there is no difference
		if (assumedToBeTrue == 0) return Double.POSITIVE_INFINITY; // any # but 0 is infinite away from 0
		return Math.abs(measured-assumedToBeTrue)/assumedToBeTrue;
	}

	/**
	 * Returns the larger of the percent errors between the numbers. 
	 * <b>
	 * This rule is broken by the program when exactally one of the numbers 
	 * being passed is 0. This
	 * is becasue the percent error between A and B is infinity if B is 0 
	 * (and A isn't).
	 * But this is not illuminating when trying to figure out the difference
	 * between 0 and a very small number (say 1e-20).  Furthermore, 
	 * the percent error between
	 * A and B is 1.00 if A is 0 (and B is not). 
	 * This is not illuminating either. 
	 * So although scientifically not correct, it makes sense from the scope of
	 * this function to define the maximum percent error between one number
	 * that is 0 and the other number that is not 0 to be the non 0 number.
	 * In this case (one number being 0), the 
	 * I.E.
	 * <pre>
	 * 	max = maximum( percentDiff(n1,n2) , percentDiff(n2,n1) )
	 * </pre>
	 * @param n1 The first number
	 * @param n2 The second number
	 * @return The larger percent error.
	 */
	public static double maxPercentError(double n1, double n2) {
		if (n1==0 && n2!=0) return n2;
		if (n1!=0 && n2==0) return n1;
		return Math.max(Compare.percentError(n1,n2),Compare.percentError(n2,n1));
	}
	
}	
	
