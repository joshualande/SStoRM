package SStoRM;
/**
 * A point in space.
 * @author Joshua Lande
 */
public class Point {
	double x=Double.NaN;
	double y=Double.NaN;
	double z=Double.NaN;
	
	public Point (double xInput, double yInput, double zInput) {
		x=xInput;
		y=yInput;
		z=zInput;
	}
	public Point() {
	}
	

	/**
	 * Tests whether 2 time objects are equal
	 */
	public boolean equals(Object anObject){
		
	    if (anObject instanceof Point) {
	        Point otherPoint= (Point)anObject;
	        return (this.x == otherPoint.x &&  
	        		this.y == otherPoint.y &&
					this.z == otherPoint.z );
	    }
	    return false;

	}
	
	public Object clone() {
		return new Point(this.x, this.y, this.z);
	}
	
	public String toString() {
		return "X="+x+"|Y="+y+"|Z="+z;
	}

}

	
