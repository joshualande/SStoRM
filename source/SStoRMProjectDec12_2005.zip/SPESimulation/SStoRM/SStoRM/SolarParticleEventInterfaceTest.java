package SStoRM;

import junit.framework.TestCase;

public class SolarParticleEventInterfaceTest extends TestCase {

	private static final double MAX_CALCULATED_PERCENT_ERROR = .00001;
	private static final double MAX_WEAKER_CALCULATED_PERCENT_ERROR = .001;
	private static final double MAX_EXACT_PERCENT_ERROR = .0000000000000000000000001;
	
	public void testWithASolarParticleEvent() {
		SolarParticleEvent event = new SolarParticleEvent(1.11e9,.125,50.0,"an SPE");
		event.setA(.5);
		event.setB1(2);
		event.setB2(1.5);
		AssertMore.assertEquals(2.84058e10/(0.333333*4*Math.PI*3600*24), event.getC(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(78488.1, event.getC(),MAX_CALCULATED_PERCENT_ERROR);
		
		SolarParticleEventInterface genericSPE = (SolarParticleEventInterface)event;
		
		AssertMore.assertEquals(3.98204e8, genericSPE.getEnergySpectrumFluence(30),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8.44761e7, genericSPE.getEnergySpectrumFluence(100),MAX_CALCULATED_PERCENT_ERROR);
	
		AssertMore.assertEquals(1.44481e10, genericSPE.getEnergySpectrumIntegralFluence(40),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(4.03978e9, genericSPE.getEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.84058e10, genericSPE.getEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals("an SPE",genericSPE.getName());
		
		AssertMore.assertEquals(0.00000056675509*1.11e9,genericSPE.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000056675509*1.11e9/2,genericSPE.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000078659355*1.11e9,genericSPE.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.SKIN,DoseLocation.FREE_SPACE),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000078659355*1.11e9/2,genericSPE.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE),MAX_EXACT_PERCENT_ERROR);
	
		//AssertMore.assertEquals(0.333333,genericSPE.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);
		
		//AssertMore.assertEquals(0.236423,genericSPE.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(78488.1*0.236423+.11,genericSPE.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		//AssertMore.assertEquals(0.0053674,genericSPE.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(78488.1*0.0053674+.11,genericSPE.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);
		//AssertMore.assertEquals(0.0000149109,genericSPE.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(78488.1*0.0000149109+.11,genericSPE.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);
	}

	public void testWithADoubleEvent() {
		DoubleEvent event = new DoubleEvent();
		event.setK_1(1e9);
		event.setGamma_1(.125);
		event.setE0_1(30);
		
		event.setK_2(2e9);
		event.setGamma_2(.25);
		event.setE0_2(50);
		event.setA_1(.5);
		event.setB1_1(2.2);
		event.setB2_1(2);
		event.setA_2(.4);
		event.setB1_2(3);
		event.setB2_2(2);
		event.setTimeDelayBetweenEvents(Time.inDays(3));
		event.setName("Another SPE, this one a double event");
		
		AssertMore.assertEquals(57714.4,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(148723,event.getC_2(),MAX_CALCULATED_PERCENT_ERROR);

		SolarParticleEventInterface genericSPE = (SolarParticleEventInterface)event;
		
		AssertMore.assertEquals("Another SPE, this one a double event",genericSPE.getName());
		AssertMore.assertEquals(5.37323E8+9.20812E8,genericSPE.getEnergySpectrumFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.40472E8+4.69E8,genericSPE.getEnergySpectrumFluence(30),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.0061E7+8.55935E7,genericSPE.getEnergySpectrumFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		

		AssertMore.assertEquals(1.39975E10+3.22947E10,genericSPE.getEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.70507E9+1.92316E10,genericSPE.getEnergySpectrumIntegralFluence(30),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.84199E8+3.91962E9,genericSPE.getEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);
	
		//AssertMore.assertEquals(0.0841566+0,genericSPE.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(57714.4*0.0841566+0+.11,genericSPE.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		
		//AssertMore.assertEquals(2.37586E-6,genericSPE.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(57714.4*2.37586E-6+0+.11,genericSPE.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);

		//AssertMore.assertEquals(0.0301633,genericSPE.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(4)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0301633*148723+.11,genericSPE.getTimeEvolutionFluxWithCWithGCR(Time.inDays(4)),MAX_CALCULATED_PERCENT_ERROR);
		
		
		//AssertMore.assertEquals(0.423379,genericSPE.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(1e9*0.00000029747835+2e9*0.00000063809034,genericSPE.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.FREE_SPACE),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals((1e9*0.00000029747835+2e9*0.00000063809034)/2,genericSPE.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1e9*0.00000013265651+2e9*0.00000031441593,genericSPE.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals((1e9*0.00000013265651+2e9*0.00000031441593)/2,genericSPE.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE),MAX_CALCULATED_PERCENT_ERROR);
	}
}