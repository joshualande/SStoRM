package SStoRM;

public enum LeftOrRight {
	LEFT,RIGHT,
}
