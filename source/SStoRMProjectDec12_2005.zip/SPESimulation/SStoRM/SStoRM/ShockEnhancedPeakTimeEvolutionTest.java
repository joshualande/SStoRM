package SStoRM;

import junit.framework.TestCase;

public class ShockEnhancedPeakTimeEvolutionTest extends TestCase {

	private static final double MAX_EXACT_PERCENT_ERROR = .00000000000000000000001;
	private static final double MAX_CALCULATED_PERCENT_ERROR = .00001;

	
	public void testEqualsObject() {

		ShockEnhancedPeakTimeEvolution evolution1 = new ShockEnhancedPeakTimeEvolution();
		evolution1.setB(1);
		evolution1.setC(2);
		evolution1.setTimeDelay(Time.inDays(20));
		AssertMore.assertEquals(evolution1,evolution1);
		
		ShockEnhancedPeakTimeEvolution evolution2 = new ShockEnhancedPeakTimeEvolution();
		evolution2.setB(1);
		evolution2.setC(2);
		evolution2.setTimeDelay(Time.inDays(20));		
		AssertMore.assertEquals(evolution2,evolution2);
		
		AssertMore.assertEquals(evolution1,evolution2);
		
		evolution2.setTimeDelay(Time.inDays(10));
		AssertMore.assertNotEquals(evolution1,evolution2);		
		evolution1.setTimeDelay(Time.inDays(10));
		AssertMore.assertEquals(evolution1,evolution2);

		evolution1.setB(2);
		AssertMore.assertNotEquals(evolution1,evolution2);		
		evolution2.setB(2);
		AssertMore.assertEquals(evolution1,evolution2);

		evolution2.setC(5);
		AssertMore.assertNotEquals(evolution1,evolution2);		
		evolution1.setC(5);
		AssertMore.assertEquals(evolution1,evolution2);	
	}

	public void testClone() {

		ShockEnhancedPeakTimeEvolution evolution1 = new ShockEnhancedPeakTimeEvolution();
		evolution1.setB(1);
		evolution1.setC(2);
		evolution1.setTimeDelay(Time.inDays(20));
		AssertMore.assertEquals(evolution1,evolution1);

		ShockEnhancedPeakTimeEvolution evolution2 = (ShockEnhancedPeakTimeEvolution)evolution1.clone();
		AssertMore.assertEquals(evolution1,evolution2);		
		
		evolution1.setB(2);
		AssertMore.assertNotEquals(evolution1,evolution2);		
		evolution2.setB(2);
		AssertMore.assertEquals(evolution1,evolution2);
		
		evolution1 = (ShockEnhancedPeakTimeEvolution)evolution2.clone();
		AssertMore.assertEquals(evolution1,evolution2);
		AssertMore.assertEquals(evolution1,evolution1);

		evolution1.setTimeDelay(Time.inDays(10));
		AssertMore.assertNotEquals(evolution1,evolution2);		
		evolution2.setTimeDelay(Time.inDays(10));
		AssertMore.assertEquals(evolution1,evolution2);
		
		
		AssertMore.assertEquals(evolution1,(ShockEnhancedPeakTimeEvolution)evolution1.clone());
		AssertMore.assertEquals(evolution2,(ShockEnhancedPeakTimeEvolution)evolution2.clone());
		
	}


	
	public void testGetSetC() {
		ShockEnhancedPeakTimeEvolution shockEnhancedPeak = new ShockEnhancedPeakTimeEvolution();
		
		try { 
			shockEnhancedPeak.getC();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			shockEnhancedPeak.setC(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			shockEnhancedPeak.setC(-2);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			shockEnhancedPeak.setC(-.001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		shockEnhancedPeak.setC(10);
		AssertMore.assertEquals(10,shockEnhancedPeak.getC(),MAX_EXACT_PERCENT_ERROR);
		
		shockEnhancedPeak.setC(40);
		AssertMore.assertEquals(40,shockEnhancedPeak.getC(),MAX_EXACT_PERCENT_ERROR);
		shockEnhancedPeak.setC(0);
		AssertMore.assertEquals(0,shockEnhancedPeak.getC(),MAX_EXACT_PERCENT_ERROR);
		
	}

	public void testGetSetB() {
		ShockEnhancedPeakTimeEvolution shockEnhancedPeak = new ShockEnhancedPeakTimeEvolution();

		try { 
			shockEnhancedPeak.getB();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			shockEnhancedPeak.setB(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			shockEnhancedPeak.setB(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			shockEnhancedPeak.setB(-.0001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			shockEnhancedPeak.setB(-10);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		shockEnhancedPeak.setB(10);
		AssertMore.assertEquals(10,shockEnhancedPeak.getB(),MAX_EXACT_PERCENT_ERROR);
		
		shockEnhancedPeak.setB(40);
		AssertMore.assertEquals(40,shockEnhancedPeak.getB(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetTimeDelay() {
		ShockEnhancedPeakTimeEvolution shockEnhancedPeak = new ShockEnhancedPeakTimeEvolution();
		AssertMore.assertEquals(Time.inDays(0),shockEnhancedPeak.getTimeDelay()); // 0 by default
		
		shockEnhancedPeak.setTimeDelay(Time.inDays(10));
		AssertMore.assertEquals(Time.inDays(10),shockEnhancedPeak.getTimeDelay());
		
		shockEnhancedPeak.setTimeDelay(Time.inDays(0));
		AssertMore.assertEquals(Time.inDays(0),shockEnhancedPeak.getTimeDelay());
		
		try { 
			shockEnhancedPeak.setTimeDelay(Time.inDays(-1));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			shockEnhancedPeak.setTimeDelay(Time.inDays(-.11));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}


	public void testGetFluxAndIntegralFluxWithAndWithoutC() {
		ShockEnhancedPeakTimeEvolution shockEnhancedPeak = new ShockEnhancedPeakTimeEvolution();
		shockEnhancedPeak.setB(10);
		
		shockEnhancedPeak.setC(101);
		AssertMore.assertEquals(1,shockEnhancedPeak.getFluxWithoutC(Time.inDays(0)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101,shockEnhancedPeak.getFluxWithC(Time.inDays(0)),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(0.99005,shockEnhancedPeak.getFluxWithoutC(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0,shockEnhancedPeak.getFluxWithoutC(Time.inDays(-1)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101*0.99005,shockEnhancedPeak.getFluxWithC(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.960789,shockEnhancedPeak.getFluxWithoutC(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0,shockEnhancedPeak.getFluxWithoutC(Time.inDays(-2)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101*0.960789,shockEnhancedPeak.getFluxWithC(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);
			
		
		AssertMore.assertEquals(0.778801,shockEnhancedPeak.getFluxWithoutC(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0,shockEnhancedPeak.getFluxWithoutC(Time.inDays(-5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101*0.778801,shockEnhancedPeak.getFluxWithC(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(7.46824,shockEnhancedPeak.getIntegralFluxWithoutC(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101*7.46824,shockEnhancedPeak.getIntegralFluxWithC(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(9.22562/2,shockEnhancedPeak.getIntegralFluxWithoutC(Time.inDays(-5),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.22562/2,shockEnhancedPeak.getIntegralFluxWithoutC(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101*9.22562/2,shockEnhancedPeak.getIntegralFluxWithC(Time.inDays(-5),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
	
		shockEnhancedPeak = new ShockEnhancedPeakTimeEvolution();
		shockEnhancedPeak.setB(.2);
		shockEnhancedPeak.setC(1000);
		shockEnhancedPeak.setTimeDelay(Time.inDays(5));

		AssertMore.assertEquals(1,shockEnhancedPeak.getFluxWithoutC(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1000,shockEnhancedPeak.getFluxWithC(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.38879E-11,shockEnhancedPeak.getFluxWithoutC(Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.38879E-11,shockEnhancedPeak.getFluxWithoutC(Time.inDays(4)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1000*1.38879E-11,shockEnhancedPeak.getFluxWithC(Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(0.00193045,shockEnhancedPeak.getFluxWithoutC(Time.inDays(5.5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00193045,shockEnhancedPeak.getFluxWithoutC(Time.inDays(4.5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1000*0.00193045,shockEnhancedPeak.getFluxWithC(Time.inDays(5.5)),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0,shockEnhancedPeak.getFluxWithoutC(Time.inDays(7)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0,shockEnhancedPeak.getFluxWithoutC(Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0,shockEnhancedPeak.getFluxWithC(Time.inDays(7)),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.354491,shockEnhancedPeak.getIntegralFluxWithoutC(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.177245,shockEnhancedPeak.getIntegralFluxWithoutC(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.177245,shockEnhancedPeak.getIntegralFluxWithoutC(Time.inDays(5),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.0000721303,shockEnhancedPeak.getIntegralFluxWithoutC(Time.inDays(5.5),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);
		
		
		
	}


}
