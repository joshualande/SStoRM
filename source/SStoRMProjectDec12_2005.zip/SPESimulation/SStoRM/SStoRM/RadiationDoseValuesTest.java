package SStoRM;

import junit.framework.TestCase;


/**
 * Tests for the module RadiationDoseValues.
 * @author Joshua Lande
 */
public class RadiationDoseValuesTest extends TestCase {

	/**
	 * The maximum percent error that the numbers can have. This is used for when 
	 * the numbers should be exact. Thus, no rounding 'should' have occured. Here, we can
	 * safely compare to a really small fraction.
	 */
	private static final double MAX_PERCENT_ERROR = .00000000000000000000000000000001; // a really small number
	/**
	 * This is the percent error for comparing interpolation. Iterpolated values are compared
	 * to calculations done in excel, and need only be accurate to one onethousandth of a percent.
	 */
	private static final double MAX_PERCENT_ERROR_FOR_INTERPOLATION= .000005; // one onethousandth of a percent
	
	/**
	 * Make sure values from getExactDose correspond to the output of BRYNTRN
	 */
	public void testGetExactDose() {
		RadiationDoseValues doses= new RadiationDoseValues();

		
		// make sure proper errors are thrown
		try { // Call should throw an error
			doses.getExactDose(-1.0, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, -.125,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 4.5,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 0,      -10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 0,      0,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 0,      510,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}



		// make sure it dosn't interpolate
		try { // Call should throw an error
			doses.getExactDose(1, 0.1,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 4.1,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 0.122,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 0,      11,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 0,      14,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getExactDose(1, 0,      141,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		// these numbers are compared to output from BRYNTRN in the tables
		AssertMore.assertEquals(0.00000070403064,         doses.getExactDose(1, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000022281255,         doses.getExactDose(1, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000015429306,       doses.getExactDose(1, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals( 0.00000047012099,        doses.getExactDose(1, 0.75,  450,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertNotEquals( 0.0000005,            doses.getExactDose(1, 0.75,  450,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR); // this is not true
		
		AssertMore.assertEquals(0.00000094430027,         doses.getExactDose(1, 0.625, 480, Thickness.ONE,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000084493395,          doses.getExactDose(1, 0.375, 470, Thickness.ONE,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertNotEquals(0.0000074493395,       doses.getDose(1, 0.375, 470, Thickness.ONE,		RadiationType.REM, BodyPart.SKIN),       MAX_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.000001346395,           doses.getExactDose(1, 0.75,  470, Thickness.ONE,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000024499285,    doses.getExactDose(1, 4,     260, Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(4.2875497E-14,            doses.getExactDose(1, 4.125,  10, Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000001669283,     doses.getExactDose(1, 4.125, 500, Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertNotEquals(0.000000000001692831,  doses.getExactDose(1, 4.125, 500, Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertNotEquals(0.0000000000016692829, doses.getExactDose(1, 4.125, 500, Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.000060348026,           doses.getExactDose(1, 0,     500, Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000015740048,           doses.getExactDose(1, 0.125, 500, Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000017522505,           doses.getExactDose(1, 0.125, 500, Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000017317887,           doses.getExactDose(1, 0.125, 500, Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000082150911,     doses.getExactDose(1, 1.625,  20, Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000063298734,     doses.getExactDose(1, 1.625,  20, Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000045508042,    doses.getExactDose(1, 1.625,  20, Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000012973093,      doses.getExactDose(1, 1.625,  20, Thickness.FIVE,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000095237367,     doses.getExactDose(1, 1.625,  20, Thickness.FIVE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000073112939,    doses.getExactDose(1, 1.625,  20, Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000014003176,       doses.getExactDose(1, 0,      10, Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000035926314,           doses.getExactDose(1, 0,     500, Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(3.953479E-17,             doses.getExactDose(1, 4.125,  10, Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(6.1047718E-14 ,           doses.getExactDose(1, 4.125, 500, Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000027777104,    doses.getExactDose(1, 0,      10,Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(2.1689817E-17,            doses.getExactDose(1, 4.125,  10,Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000025157018,           doses.getExactDose(1, 0,     500,Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(8.357322E-16,             doses.getExactDose(1, 4.125, 500,Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000016980616,        doses.getExactDose(1, 1.125, 290,Thickness.THIRTY,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000099093563,    doses.getExactDose(1, 2.5,   440,Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000049200609,    doses.getExactDose(1, 2.625, 440,Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000025662568,       doses.getExactDose(1, 1.5,   380,Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000011206039,         doses.getExactDose(1,  .375, 100,Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000089299137,          doses.getExactDose(1,  .125, 270,Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);   
		AssertMore.assertEquals(0.0000042227257,          doses.getExactDose(1,  .25,  270,Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000039604151,          doses.getExactDose(1,  .25,  260,Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000029764826,       doses.getExactDose(1, 1.125,  90,Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000039450558,       doses.getExactDose(1, 1.125, 100,Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000022628353,       doses.getExactDose(1, 1.5,   270,Thickness.THIRTY,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000018974713,      doses.getExactDose(1, 0,      10,Thickness.TEN,  RadiationType.REM, BodyPart.SKIN), MAX_PERCENT_ERROR);
		AssertMore.assertEquals(4.2578434E-17,            doses.getExactDose(1, 4.125,  10,Thickness.TEN,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000060006791,           doses.getExactDose(1, 0,     500,Thickness.TEN,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000000235696,    doses.getExactDose(1, 4.125, 500,Thickness.TEN,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000074961412,     doses.getExactDose(1, 0,      10,Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.7230071E-17,            doses.getExactDose(1, 4.125,  10,Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000033056775,           doses.getExactDose(1, 0,     500,Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.6004745E-14,            doses.getExactDose(1, 4.125, 500,Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000011797018,        doses.getExactDose(1, 1.375, 320,Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
 		AssertMore.assertEquals(0.0000000061652372,       doses.getExactDose(1, 1.5,   320,Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000001526657,         doses.getExactDose(1, 1.375, 500,Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000067081778,        doses.getExactDose(1, 1.125, 480,Thickness.TEN,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000019645702,      doses.getExactDose(1, 2.25,  330,Thickness.TEN,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000011387776,       doses.getExactDose(1, 1.75,  390,Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000044591548,       doses.getExactDose(1, 1.5,  390,Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),   MAX_PERCENT_ERROR);

		// make sure k scaling works
		AssertMore.assertEquals(0.000033056775*1e1,         doses.getExactDose(1e1,     0,     500,Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.6004745E-14*43,           doses.getExactDose(43,      4.125, 500,Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000011797018*111,      doses.getExactDose(111,     1.375, 320,Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
 		AssertMore.assertEquals(0.0000000061652372*.001,    doses.getExactDose(.001,    1.5,   320,Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000001526657*666,       doses.getExactDose(666,     1.375, 500,Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000067081778*1e9,      doses.getExactDose(1e9,     1.125, 480,Thickness.TEN,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000019645702*4.3e13, doses.getExactDose(4.3e13,  2.25,  330,Thickness.TEN,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000011387776*.223213, doses.getExactDose(.223213, 1.75,  390,Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000044591548*4e-21,   doses.getExactDose(4e-21,   1.5,   390,Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		
	}
	
	/**
	 * Make sure values from getDose correspond to the exact output of BRYNTRN and that the linear interpolation to new values works
	 */
	public void testGetDose() {
		RadiationDoseValues doses= new RadiationDoseValues();

		
		

		// make sure proper errors are thrown
		try { // Call should throw an error
			doses.getDose(-1.0, 0,     10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getDose(1, -.125,   10,  Thickness.POINT_THREE,RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getDose(1, 4.5,    10,  Thickness.POINT_THREE,RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getDose(1, 0,      -10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getDose(1, 0,      0,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			doses.getDose(1, 0,      510,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		
		AssertMore.assertEquals(0.00000070403064,      doses.getDose(1, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000019645702,   doses.getDose(1, 2.25,  330, Thickness.TEN,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(2.1689817E-17,         doses.getDose(1, 4.125,  10, Thickness.THIRTY,  RadiationType.RAD, BodyPart.BFO),  MAX_PERCENT_ERROR);
		
		
		
		// Do the same tests w/ function get dose. Make sure interprolation dosn't mess up exact values
		AssertMore.assertEquals(0.00000070403064,      doses.getDose(1, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000022281255,      doses.getDose(1, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000015429306,    doses.getDose(1, 0,      10,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000047012099,      doses.getDose(1, 0.75,  450,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertNotEquals(0.00000047013,      doses.getDose(1, 0.75,  450,  Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR); // this is not true
		
		AssertMore.assertEquals(0.00000094430027,      doses.getDose(1, 0.625, 480,  Thickness.ONE,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000084493395,       doses.getDose(1, 0.375, 470,  Thickness.ONE,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertNotEquals(0.0000074493395,    doses.getDose(1, 0.375, 470,  Thickness.ONE,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.000001346395,        doses.getDose(1, 0.75,  470,  Thickness.ONE,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000024499285, doses.getDose(1, 4,     260,  Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(4.2875497E-14,         doses.getDose(1, 4.125,  10,  Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000001669283,  doses.getDose(1, 4.125, 500,  Thickness.ONE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000060348026,        doses.getDose(1, 0,     500,  Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000015740048,        doses.getDose(1, 0.125, 500,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000017522505,        doses.getDose(1, 0.125, 500,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000017317887,        doses.getDose(1, 0.125, 500,  Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000082150911,  doses.getDose(1, 1.625,  20,  Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000063298734,  doses.getDose(1, 1.625,  20,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000045508042, doses.getDose(1, 1.625,  20,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000012973093,   doses.getDose(1, 1.625,  20,  Thickness.FIVE,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000095237367,  doses.getDose(1, 1.625,  20,  Thickness.FIVE,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000073112939, doses.getDose(1, 1.625,  20,  Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000014003176,    doses.getDose(1, 0,      10,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000035926314,        doses.getDose(1, 0,     500,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(3.953479E-17,          doses.getDose(1, 4.125,  10,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(6.1047718E-14 ,        doses.getDose(1, 4.125, 500,  Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000027777104, doses.getDose(1, 0,      10, Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(2.1689817E-17,         doses.getDose(1, 4.125,  10, Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000025157018,        doses.getDose(1, 0,     500, Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(8.357322E-16,          doses.getDose(1, 4.125, 500, Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000016980616,     doses.getDose(1, 1.125, 290, Thickness.THIRTY,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000099093563, doses.getDose(1, 2.5,   440, Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000049200609, doses.getDose(1, 2.625, 440, Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000025662568,    doses.getDose(1, 1.5,   380, Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000011206039,      doses.getDose(1,  .375, 100, Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000089299137,       doses.getDose(1,  .125, 270, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);   
		AssertMore.assertEquals(0.0000042227257,       doses.getDose(1,  .25,  270, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000039604151,       doses.getDose(1,  .25,  260, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000029764826,    doses.getDose(1, 1.125,  90, Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000039450558,    doses.getDose(1, 1.125, 100, Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000022628353,    doses.getDose(1, 1.5,   270, Thickness.THIRTY,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000018974713,   doses.getDose(1, 0,      10, Thickness.TEN,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(4.2578434E-17,         doses.getDose(1, 4.125,  10, Thickness.TEN,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000060006791,        doses.getDose(1, 0,     500, Thickness.TEN,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000000000235696, doses.getDose(1, 4.125, 500, Thickness.TEN,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000074961412,  doses.getDose(1, 0,      10, Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.7230071E-17,         doses.getDose(1, 4.125,  10, Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000033056775,        doses.getDose(1, 0,     500, Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.6004745E-14,         doses.getDose(1, 4.125, 500, Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000011797018,     doses.getDose(1, 1.375, 320, Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
 		AssertMore.assertEquals(0.0000000061652372,    doses.getDose(1, 1.5,   320, Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000001526657,      doses.getDose(1, 1.375, 500, Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000067081778,     doses.getDose(1, 1.125, 480, Thickness.TEN,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000019645702,   doses.getDose(1, 2.25,  330, Thickness.TEN,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000011387776,    doses.getDose(1, 1.75,  390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000044591548,    doses.getDose(1, 1.5,   390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);

		// make sure k scaling works
		AssertMore.assertEquals(0.000033056775*1e1,         doses.getDose(1e1,     0,     500, Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.6004745E-14*43,           doses.getDose(43,      4.125, 500, Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000011797018*111,      doses.getDose(111,     1.375, 320, Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
 		AssertMore.assertEquals(0.0000000061652372*.001,    doses.getDose(.001,    1.5,   320, Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000001526657*666,       doses.getDose(666,     1.375, 500, Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000067081778*1e9,      doses.getDose(1e9,     1.125, 480, Thickness.TEN,  RadiationType.REM,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000019645702*4.3e13, doses.getDose(4.3e13,  2.25,  330, Thickness.TEN,  RadiationType.REM,  BodyPart.EYE),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000011387776*.223213, doses.getDose(.223213, 1.75,  390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000044591548*4e-21,   doses.getDose(4e-21,   1.5,   390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.0,                        doses.getDose(    0,   1.5,   390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR);
		

		// test single interpolation b/n gamma 1.75 to 1.5 w/ E0=390
		AssertMore.assertEquals(0.0000000011387776,  doses.getDose(1, 1.75,  390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(0.00000000136093178, doses.getDose(1, 1.725, 390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000158308596, doses.getDose(1, 1.7,   390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000180524014, doses.getDose(1, 1.675, 390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000202739432, doses.getDose(1, 1.65,  390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION); 
		AssertMore.assertEquals(0.0000000022495485,  doses.getDose(1, 1.625, 390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(0.00000000269146976, doses.getDose(1, 1.6,   390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000313339102, doses.getDose(1, 1.575, 390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000357531228, doses.getDose(1, 1.55,  390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000401723354, doses.getDose(1, 1.525, 390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000044591548,  doses.getDose(1, 1.5,   390, Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO),  MAX_PERCENT_ERROR); // exact
		// test single interpolation b/n E0=260 to 270 w/ gamma = .25
		AssertMore.assertEquals(0.0000039604151,     doses.getDose(1,  .25,  260, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(0.00000398664616,    doses.getDose(1,  .25,  261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000401287722,    doses.getDose(1,  .25,  262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000403910828,    doses.getDose(1,  .25,  263, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000406533934,    doses.getDose(1,  .25,  264, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000040915704,     doses.getDose(1,  .25,  265, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000411780146,    doses.getDose(1,  .25,  266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000414403252,    doses.getDose(1,  .25,  267, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000417026358,    doses.getDose(1,  .25,  268, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000419649464,    doses.getDose(1,  .25,  269, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000042227257,     doses.getDose(1,  .25,  270, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR); // exact
		// test single interpolation b/n Eo=260 & 270 w/ gamma = .375
		AssertMore.assertEquals(0.0000018842788,  doses.getDose(1,  .375,  260, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(0.00000189633192, doses.getDose(1,  .375,  261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000190838504, doses.getDose(1,  .375,  262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000192043816, doses.getDose(1,  .375,  263, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000193249128, doses.getDose(1,  .375,  264, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000019445444,  doses.getDose(1,  .375,  265, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000195659752, doses.getDose(1,  .375,  266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000196865064, doses.getDose(1,  .375,  267, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000198070376, doses.getDose(1,  .375,  268, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000199275688, doses.getDose(1,  .375,  269, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002004813,   doses.getDose(1,  .375,  270, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR); // exact
		// test double interpolation (interpolate b/n interpolated values) for gamma=.25 to .375 w/ E0=262
		AssertMore.assertEquals(0.00000401287722,  doses.getDose(1,  .25,    262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003802428002, doses.getDose(1,  .2625,  262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003591978784, doses.getDose(1,  .275,   262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003381529566, doses.getDose(1,  .2875,  262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003171080348, doses.getDose(1,  .3,     262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000296063113,  doses.getDose(1,  .3125,  262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002750181912, doses.getDose(1,  .325,   262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002539732694, doses.getDose(1,  .3375,  262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002329283476, doses.getDose(1,  .35,    262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002118834258, doses.getDose(1,  .3625,  262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000190838504,  doses.getDose(1,  .375,   262, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		// test double interpolation (interpolate b/n interpolated values) for gamma=.25 to .375 w/ E0=266
		AssertMore.assertEquals(0.00000411780146,  doses.getDose(1,  .25,    266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003901681066, doses.getDose(1,  .2625,  266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003685560672, doses.getDose(1,  .275,   266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003469440278, doses.getDose(1,  .2875,  266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003253319884, doses.getDose(1,  .3,     266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000303719949,  doses.getDose(1,  .3125,  266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002821079096, doses.getDose(1,  .325,   266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002604958702, doses.getDose(1,  .3375,  266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002388838308, doses.getDose(1,  .35,    266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002172717914, doses.getDose(1,  .3625,  266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000195659752,  doses.getDose(1,  .375,   266, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		// test double interpolation (interpolate b/n interpolated values) for gamma=.25 to .375 w/ E0=261
		AssertMore.assertEquals(0.00000398664616,  doses.getDose(1,  .25,    261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003777614736, doses.getDose(1,  .2625,  261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003568583312, doses.getDose(1,  .275,   261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003359551888, doses.getDose(1,  .2875,  261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000003150520464, doses.getDose(1,  .3,     261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000294148904,  doses.getDose(1,  .3125,  261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002732457616, doses.getDose(1,  .325,   261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002523426192, doses.getDose(1,  .3375,  261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002314394768, doses.getDose(1,  .35,    261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000002105363344, doses.getDose(1,  .3625,  261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000189633192,  doses.getDose(1,  .375,   261, Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		
		
		// test single interpolation b/n gamma 2 to 2.125 w/ E0=200
		AssertMore.assertEquals(0.0000000007390083,   doses.getDose(1,  2,            200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(0.000000000706360565, doses.getDose(1,  2.0125,       200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000067371283,  doses.getDose(1,  2.025,        200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000641065095, doses.getDose(1,  2.0375,       200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000060841736,  doses.getDose(1,  2.05,         200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000575769625, doses.getDose(1,  2.0625,       200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000054312189,  doses.getDose(1,  2.075,        200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000510474155, doses.getDose(1,  2.0875,       200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000047782642,  doses.getDose(1,  2.1,          200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000445178685, doses.getDose(1,  2.1125,       200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000041253095,  doses.getDose(1,  2.125,        200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR); // exact
		// test single interpolation b/n gamma 2 to 2.125 w/ E0=210
		AssertMore.assertEquals(0.00000000076027212,   doses.getDose(1,  2,            210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(0.000000000726657592,  doses.getDose(1,  2.0125,       210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000693043064,  doses.getDose(1,  2.025,        210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000659428536,  doses.getDose(1,  2.0375,       210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.25814008000001E-10,  doses.getDose(1,  2.05,         210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000059219948,   doses.getDose(1,  2.0625,       210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000558584952,  doses.getDose(1,  2.075,        210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000524970424,  doses.getDose(1,  2.0875,       210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000491355896,  doses.getDose(1,  2.1,          210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000457741368,  doses.getDose(1,  2.1125,       210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.00000000042412684,   doses.getDose(1,  2.125,        210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR); // exact
		// test double interpolation (interpolate b/n interpolated values) for E0 200 to 210 & gamma = 2.025
		AssertMore.assertEquals(0.00000000067371283,    doses.getDose(1,  2.025,        200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006756458534,  doses.getDose(1,  2.025,        201, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006775788768,  doses.getDose(1,  2.025,        202, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006795119002,  doses.getDose(1,  2.025,        203, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006814449236,  doses.getDose(1,  2.025,        204, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000683377947,   doses.getDose(1,  2.025,        205, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006853109704,  doses.getDose(1,  2.025,        206, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006872439938,  doses.getDose(1,  2.025,        207, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006891770172,  doses.getDose(1,  2.025,        208, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000006911100406,  doses.getDose(1,  2.025,        209, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000693043064,   doses.getDose(1,  2.025,        210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		// test double interpolation (interpolate b/n interpolated values) for E0 200 to 210 & gamma = 2.0875
		AssertMore.assertEquals(0.000000000510474155,   doses.getDose(1,  2.0875,        200, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005119237819,  doses.getDose(1,  2.0875,        201, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005133734088,  doses.getDose(1,  2.0875,        202, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005148230357,  doses.getDose(1,  2.0875,        203, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005162726626,  doses.getDose(1,  2.0875,        204, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005177222895,  doses.getDose(1,  2.0875,        205, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005191719164,  doses.getDose(1,  2.0875,        206, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005206215433,  doses.getDose(1,  2.0875,        207, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005220711702,  doses.getDose(1,  2.0875,        208, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000005235207971,  doses.getDose(1,  2.0875,        209, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.000000000524970424,   doses.getDose(1,  2.0875,        210, Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		
		
		// test single interpolation b/n E0=490 to 500 w/ gamma = 4
		AssertMore.assertEquals(1.1153167E-13,     		doses.getDose(1,  4,        490, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(1.11572213E-13,    		doses.getDose(1,  4,        491, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11612756E-13,   		doses.getDose(1,  4,        492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11653299E-13,    		doses.getDose(1,  4,        493, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11693842E-13,    		doses.getDose(1,  4,        494, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11734385E-13,    		doses.getDose(1,  4,        495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11774928E-13,    		doses.getDose(1,  4,        496, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11815471E-13,    		doses.getDose(1,  4,        497, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11856014E-13,         doses.getDose(1,  4,        498, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.11896557E-13,   		doses.getDose(1,  4,        499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(0.0000000000001119371,  doses.getDose(1,  4,        500, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR); // exact
		//		 test single interpolation b/n E0=490 to 500 w/ gamma = 4.125
		AssertMore.assertEquals(6.4644762E-14,    doses.getDose(1,  4.125,    490, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR); // exact
		AssertMore.assertEquals(6.46676122E-14,   doses.getDose(1,  4.125,    491, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.46904624E-14,   doses.getDose(1,  4.125,    492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.47133126E-14,   doses.getDose(1,  4.125,    493, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.47361628E-14,   doses.getDose(1,  4.125,    494, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.4759013E-14,    doses.getDose(1,  4.125,    495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.47818632E-14,   doses.getDose(1,  4.125,    496, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.48047134E-14,   doses.getDose(1,  4.125,    497, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.48275636E-14 ,  doses.getDose(1,  4.125,    498, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.48504138E-14 ,  doses.getDose(1,  4.125,    499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.4873264E-14,    doses.getDose(1,  4.125,    500, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR); // exact
		//		 test double interpolation (interpolate b/n interpolated values) for gamma=4 to 4.125 w/ E0 = 499
		AssertMore.assertEquals(1.11896557E-13,          doses.getDose(1,  4,          499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.0719194268E-13,        doses.getDose(1,  4.0125,     499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.0248732836E-13,        doses.getDose(1,  4.025,      499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(9.77827140400001E-14,    doses.getDose(1,  4.0375,     499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(9.30780997200001E-14,    doses.getDose(1,  4.05,       499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(8.83734854E-14,          doses.getDose(1,  4.0625,     499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(8.36688710799999E-14,    doses.getDose(1,  4.075,      499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(7.89642567599999E-14,    doses.getDose(1,  4.0875,     499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(7.42596424400001E-14,    doses.getDose(1,  4.1,        499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.95550281200001E-14,    doses.getDose(1,  4.1125,     499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.48504138E-14,          doses.getDose(1,  4.125,      499, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		// test double interpolation (interpolate b/n interpolated values) for gamma=4 to 4.125 w/ E0 = 492
		AssertMore.assertEquals(1.11612756E-13,          doses.getDose(1,  4,          492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.0692052664E-13,        doses.getDose(1,  4.0125,     492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.0222829728E-13,        doses.getDose(1,  4.025,      492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(9.75360679200001E-14,    doses.getDose(1,  4.0375,     492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(9.28438385600001E-14,    doses.getDose(1,  4.05,       492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(8.81516092E-14,          doses.getDose(1,  4.0625,     492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(8.34593798399999E-14,    doses.getDose(1,  4.075,      492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(7.87671504799999E-14,    doses.getDose(1,  4.0875,     492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(7.40749211200001E-14,    doses.getDose(1,  4.1,        492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.93826917600001E-14,    doses.getDose(1,  4.1125,     492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.46904624E-14,          doses.getDose(1,  4.125,      492, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		// test double interpolation (interpolate b/n interpolated values) for gamma=4 to 4.125 w/ E0 = 495
		AssertMore.assertEquals(1.11734385E-13,          doses.getDose(1,  4,          495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),   MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.070368478E-13,         doses.getDose(1,  4.0125,     495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(1.023393106E-13,         doses.getDose(1,  4.025,      495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(9.76417734000001E-14,    doses.getDose(1,  4.0375,     495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(9.29442362000001E-14,    doses.getDose(1,  4.05,       495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(8.8246699E-14,           doses.getDose(1,  4.0625,     495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(8.35491617999999E-14,    doses.getDose(1,  4.075,      495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(7.88516245999999E-14,    doses.getDose(1,  4.0875,     495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(7.41540874000001E-14 ,   doses.getDose(1,  4.1,        495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.94565502000001E-14 ,   doses.getDose(1,  4.1125,     495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		AssertMore.assertEquals(6.4759013E-14,           doses.getDose(1,  4.125,      495, Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO),  MAX_PERCENT_ERROR_FOR_INTERPOLATION);
		
		
	}


}
