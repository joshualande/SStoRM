package SStoRM;

/**
 * This class allows for the easy creation of pieces of time. 
 * It is nice because it does all the unit conversions for you.
 * <p>
 * To create a time object, say
 * <code><pre>
 *	Time time=new Time();
 * </pre></code>
 * Then, you can set the time by saying
 * <code><pre>
 *	time.setHours(20.0);
 *	time.addHours(5);
 *	double minutes=time.getMinutes(); // returns 1500
 *	time.resetTime(); // reset the time.
 *	time.addSeconds(30);
 *	minutes=time.getMinutes(); // returns .5
 * </pre></code>
 * There is a corresponding {@link #setMinutes}, {@link #setDays}, and {@link #setSeconds}.
 * There is a corresponding {@link #addMinutes}, {@link #addDays}, and {@link #addSeconds}.
 * There is also a {@link #subtractSeconds}, {@link #subtractMinutes}, 
 * {@link #subtractHours}, and {@link #subtractDays}.
 * <p>
 * To add another time object, say
 * <code><pre>
 *	Time otherTime=new Time();
 *	otherTime.setMinute(30);
 *	time.add(otherTime);
 *	otherTime.subtract(time); // etc...
 * </pre></code>
 * For a quick and dirty way to make time objects, use the following syntax:
 * <code><pre>
 *	Time newTime= Time.inHours(2.0); // makes a time object filled with 2 hours
 *	newTime  = Time.inDays(3.0); // 3 days
 * </pre></code>
 * There is also a corresponding {@link #inMinutes} and {@link #inSeconds} function. 
 * This is a nice convenience.
 * @author Joshua Lande
 */
public class Time implements Cloneable {
	
	
	/**
	 * Performs the expected clone of a time object.
	 */
	public Object clone()
    {
       Time newTime = new Time();
       newTime.setSeconds(this.timeInSeconds);
       return newTime;
    }
	
	/**
	 * Tests whether 2 time objects are equal based on the number
	 * of seconds they hold.
	 */
	public boolean equals(Object anObject){
		
	    if (anObject instanceof Time) {
	        Time otherTime= (Time)anObject;
	        return  (this.getSeconds() == otherTime.getSeconds()); 
	    }
	    return false;

	}
	
	/**
	 * The number of seconds in a minute=60.
	 */
	public static double SECONDS_IN_A_MINUTE=60;
	
	/**
	 * The number of minutes in an hour=60.
	 */
	public static double MINUTES_IN_AN_HOUR=60;
	
	/**
	 * The number of hours in a day=24.
	 */
	public static double HOURS_IN_A_DAY=24;
	
	/**
	 * Holds the actual time (in seconds).
	 */
	private double timeInSeconds=0.0;
	
	/**
	 * Adds the number of days specified to the time object.
	 * @param days The number of days to add.
	 */
	public void addDays(double days) {
		if (Double.isNaN(days)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(days)) throw new IllegalArgumentException("The input cannot be infinity.");
		addHours(days*Time.HOURS_IN_A_DAY);
	}
	
	/**
	 * Subtracts the number of days specified from the time object. 
	 * @param days The number of days to subtract.
	 */
	public void subtractDays(double days) { addDays(-days); }
	
	/**
	 * Adds the number of hours specified to the time object.
	 * @param hours The number of hours to add.
	 */
	public void addHours(double hours) {
		if (Double.isNaN(hours)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(hours)) throw new IllegalArgumentException("The input cannot be infinity.");
		addMinutes(hours*Time.MINUTES_IN_AN_HOUR);
	}
	
	/**
	 * Subtracts the number of hours specified from the time object.
	 * @param hours The number of hours to subtract.
	 */
	public void subtractHours(double hours) { addHours(-hours); }
	
	/**
	 * Adds the number of minutes specified to the time object.
	 * @param minutes The number of minutes to add.
	 */
	public void addMinutes(double minutes) {
		if (Double.isNaN(minutes)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(minutes)) throw new IllegalArgumentException("The input cannot be infinity.");
		addSeconds(minutes*Time.SECONDS_IN_A_MINUTE);
	}
	
	/**
	 * Subtracts the number of minutes specified from the time object.
	 * @param minutes The number of minutes to subtract.
	 */
	public void subtractMinutes(double minutes) { addMinutes(-minutes); }
	
	/**
	 * Adds the number of seconds specified to the time object.
	 * @param seconds The number of seconds to add.
	 */
	public void addSeconds(double seconds) {
		if (Double.isNaN(seconds)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(seconds)) throw new IllegalArgumentException("The input cannot be infinity.");
		timeInSeconds+=seconds;
	}
	
	/**
	 * Subtracts the number of seconds specified from the time.
	 * @param seconds The number of seconds to subtract.
	 */
	public void subtractSeconds(double seconds) { addSeconds(-seconds); }
	
	/**
	 * Adds the passed time object to the current one.
	 * @param otherTime The time to add.
	 */
	public void add(Time otherTime) {
		addSeconds(otherTime.getSeconds());
	}
	
	/**
	 * Subtracts the passed time object from the current one.
	 * @param otherTime The time to subtract.
	 */
	public void subtract(Time otherTime) {
		subtractSeconds(otherTime.getSeconds());
	}
	
	/**
	 * Sets the time object to 0 seconds.
	 */
	public void reset() {
		timeInSeconds=0.0;
	}
	
	/**
	 * Sets the time object to the number of seconds specified by the input.
	 * @param days The number of days to set the object to.
	 */
	public void setDays(double days) {
		if (Double.isNaN(days)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(days)) throw new IllegalArgumentException("The input cannot be infinity.");
		reset();
		addDays(days);
	}
	
	/**
	 * Sets the time object to the number of hours specified by the input.
	 * @param hours The number of hours to set the object to.
	 */
	public void setHours(double hours) {
		if (Double.isNaN(hours)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(hours)) throw new IllegalArgumentException("The input cannot be infinity.");
		reset();
		addHours(hours);
	}
	
	/**
	 * Sets the time object to the number of minutes specified by the input.
	 * @param minutes The number of minutes to set the object to.
	 */
	public void setMinutes(double minutes) {
		if (Double.isNaN(minutes)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(minutes)) throw new IllegalArgumentException("The input cannot be infinity.");
		reset();
		addMinutes(minutes);
	}
	
	/**
	 * Sets the time object to the number of seconds specified by the input.
	 * @param seconds The number of seconds to set the object to.
	 */
	public void setSeconds(double seconds) {
		if (Double.isNaN(seconds)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(seconds)) throw new IllegalArgumentException("The input cannot be infinity.");
		reset();
		addSeconds(seconds);
	}
	
	/**
	 * Returns the number of days in the time object.
	 * @return The number of days.
	 */
	public double getDays() {
		return timeInSeconds/(Time.SECONDS_IN_A_MINUTE*Time.MINUTES_IN_AN_HOUR*Time.HOURS_IN_A_DAY);
	}
	
	/**
	 * Returns the number of hours in the time object.
	 * @return The number of days.
	 */
	public double getHours() {
		return timeInSeconds/(Time.SECONDS_IN_A_MINUTE*Time.MINUTES_IN_AN_HOUR);
	}	
	
	/**
	 * Returns the number of minutes in the time object.
	 * @return The number of minutes.
	 */
	public double getMinutes() {
		return timeInSeconds/(Time.SECONDS_IN_A_MINUTE);
	}

	/**
	 * Returns the number of seconds in the time object.
	 * @return the number of seconds.
	 */
	public double getSeconds() {
		return timeInSeconds;
	}
	
	/**
	 * Creates and returns a time object with the specified number of days in it.
	 * @param days  The number of days to set the object to.
	 * @return a Time object with the specified number of days in it.
	 */
	public static Time inDays(double days) {
		if (Double.isNaN(days)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(days)) throw new IllegalArgumentException("The input cannot be infinity.");
		Time time=new Time();
		time.setDays(days);
		return time;
	}
	
	/**
	 * Creates and returns a time object with the specified number of hours in it.
	 * @param hours The number of hours to set the object to.
	 * @return a Time object with the specified number of hours in it.
	 */
	public static Time inHours(double hours) {
		if (Double.isNaN(hours)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(hours)) throw new IllegalArgumentException("The input cannot be infinity.");
		Time time=new Time();
		time.setHours(hours);
		return time;
	}

	/**
	 * Creates and returns a time object with the specified number of minutes in it.
	 * @param minutes The number of minutes to set the object to.
	 * @return a Time object with the specified number of minutes in it.
	 */
	public static Time inMinutes(double minutes) {
		if (Double.isNaN(minutes)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(minutes)) throw new IllegalArgumentException("The input cannot be infinity.");
		Time time=new Time();
		time.setMinutes(minutes);
		return time;
	}

	/**
	 * Creates and returns a time object with the specified number of seconds in it.
	 * @param seconds The number of seconds to set the object to.
	 * @return a Time object with the specified number of seconds in it.
	 */
	public static Time inSeconds(double seconds) {
		if (Double.isNaN(seconds)) throw new IllegalArgumentException("The input must be a number (and defined).");
		if (Double.isInfinite(seconds)) throw new IllegalArgumentException("The input cannot be infinity.");
		Time time=new Time(); 
		time.setSeconds(seconds);
		return time;
	}
	
	
	/**
	 * Turns the current time negative, though this is not quite accurate. It multiplies the number of seconds
	 * in the object by negative 1. So, 10 seconds becomes -10 seconds, 5 hours becomes -5 hours, etc. But 
	 * -10 seconds becomes 10 seconds and -5 hours becomes 5 hours.
	 */
	public void negative() {
		timeInSeconds*=-1;
	}
	
	/**
	 * A more convenient syntax for calling {@link #negative}. To make a new object which is the negative
	 * of an old object, all you have to do is say:
	 * <pre>
	 * 	Time newTime = negative(oldTime);
	 * </pre>
	 * @param time The object to get the negative value of.
	 * @return A cloned object holding the negative of the passed object.
	 */
	public static Time negative(Time time) {
		Time newTime = (Time) time.clone();
		newTime.negative();
		return newTime;
	}
	
	/**
	 * An easier syntax for adding two numbers. All you have to say is:
	 * <pre>
	 * Time sum = Time.add( firstTime, secondsTime);
	 * </pre>
	 * @param time1 The first time.
	 * @param time2 The second time.
	 * @return A new object holding the sum of the first two numbers.
	 */
	public static Time add(Time time1, Time time2) {
		Time newTime = (Time) time1.clone();
		newTime.add(time2);
		return newTime;
	}

	public static Time subtract(Time time1, Time time2) {
		Time newTime = (Time) time1.clone();
		newTime.subtract(time2);
		return newTime;
	}

}
