package SStoRM;

import junit.framework.TestCase;

public class EventWithShockEnhancedPeakTest extends TestCase {

	private static final double MAX_EXACT_PERCENT_ERROR = .00000000000000000000001;
	private static final double MAX_CALCULATED_PERCENT_ERROR = .000005;
	private static final double MAX_WEAKER_CALCULATED_PERCENT_ERROR = .00005;
	private static final double MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR = .0005;


	public void testGetSetName() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		AssertMore.assertEquals("",event.getName());
		event.setName("A name of an SPE");
		AssertMore.assertEquals("A name of an SPE",event.getName());
		event.setName("another name");
		AssertMore.assertEquals("another name",event.getName());
	}


	public void testEventWithShockEnhancedPeakString() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak("A name of an SPE");
		AssertMore.assertEquals("A name of an SPE",event.getName());
		event = new EventWithShockEnhancedPeak("another name");
		AssertMore.assertEquals("another name",event.getName());
	}

	public void testGetSetTimeDelayBeforeShockEnhancedPeak() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		AssertMore.assertEquals(Time.inDays(0),event.getTimeDelayBeforeShockEnhancedPeak());
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(Time.inDays(5),event.getTimeDelayBeforeShockEnhancedPeak());
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(2));
		AssertMore.assertEquals(Time.inDays(2),event.getTimeDelayBeforeShockEnhancedPeak());

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(Time.inDays(0),event.getTimeDelayBeforeShockEnhancedPeak());

		try { 
			event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(-1));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(-.00001));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

	}


	public void testGetSetGamma_1() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();

		try { 
			event.getGamma_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setGamma_1(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setGamma_1(4.12501);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		event.setGamma_1(0);
		AssertMore.assertEquals(0,event.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
		
		event.setGamma_1(4.125);
		AssertMore.assertEquals(4.125,event.getGamma_1(),MAX_EXACT_PERCENT_ERROR);

		event.setGamma_1(2.111);
		AssertMore.assertEquals(2.111,event.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
	}

	
	public void testGetSetE0_1() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();

		try { 
			event.getE0_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setE0_1(9.9999);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setE0_1(500.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		event.setE0_1(10);
		AssertMore.assertEquals(10,event.getE0_1(),MAX_EXACT_PERCENT_ERROR);
		
		event.setE0_1(500);
		AssertMore.assertEquals(500,event.getE0_1(),MAX_EXACT_PERCENT_ERROR);

		event.setE0_1(201.111);
		AssertMore.assertEquals(201.111,event.getE0_1(),MAX_EXACT_PERCENT_ERROR);
	}


	public void testGetSetA_1() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();

		try { 
			event.getA_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setA_1(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			event.setA_1(-1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	
		event.setA_1(1);
		AssertMore.assertEquals(1,event.getA_1(),MAX_EXACT_PERCENT_ERROR);
		event.setA_1(.5);
		
		AssertMore.assertEquals(.5,event.getA_1(),MAX_EXACT_PERCENT_ERROR);
	}


	public void testGetSetB1_1() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();

		try { 
			event.getB1_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setB1_1(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		event.setB1_1(1);
		AssertMore.assertEquals(1,event.getB1_1(),MAX_EXACT_PERCENT_ERROR);
		
		event.setB1_1(1111);
		AssertMore.assertEquals(1111,event.getB1_1(),MAX_EXACT_PERCENT_ERROR);

		event.setB1_1(-1);
		AssertMore.assertEquals(-1,event.getB1_1(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetB2_1() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();

		try { 
			event.getB2_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setB2_1(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		event.setB2_1(1);
		AssertMore.assertEquals(1,event.getB2_1(),MAX_EXACT_PERCENT_ERROR);
		
		event.setB2_1(1111);
		AssertMore.assertEquals(1111,event.getB2_1(),MAX_EXACT_PERCENT_ERROR);

		event.setB2_1(-1);
		AssertMore.assertEquals(-1,event.getB2_1(),MAX_EXACT_PERCENT_ERROR);
	}
	
	public void testGetSetEmin() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		try { 
			event.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		try { 
			event.setEmin(9.99);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setEmin(1500.01);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setEmin(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		event.setEmin(10);
		AssertMore.assertEquals(10,event.getEmin(),MAX_EXACT_PERCENT_ERROR);
		
		event.setEmin(1500);
		AssertMore.assertEquals(1500,event.getEmin(),MAX_EXACT_PERCENT_ERROR);
		
		event.setEmin(30);
		AssertMore.assertEquals(30,event.getEmin(),MAX_EXACT_PERCENT_ERROR);		
	}




	public void testGetSetShockEnhancedPeakGamma() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		try { 
			event.getShockEnhancedPeakGamma();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setShockEnhancedPeakGamma(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setShockEnhancedPeakGamma(4.12501);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		event.setShockEnhancedPeakGamma(0);
		AssertMore.assertEquals(0,event.getShockEnhancedPeakGamma(),MAX_EXACT_PERCENT_ERROR);
		
		event.setShockEnhancedPeakGamma(4.125);
		AssertMore.assertEquals(4.125,event.getShockEnhancedPeakGamma(),MAX_EXACT_PERCENT_ERROR);

		event.setShockEnhancedPeakGamma(2.111);
		AssertMore.assertEquals(2.111,event.getShockEnhancedPeakGamma(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testSetShockEnhancedPeakE0() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		try { 
			event.getShockEnhancedPeakE0();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setShockEnhancedPeakE0(9.9999);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setShockEnhancedPeakE0(500.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		event.setShockEnhancedPeakE0(10);
		AssertMore.assertEquals(10,event.getShockEnhancedPeakE0(),MAX_EXACT_PERCENT_ERROR);
		
		event.setShockEnhancedPeakE0(500);
		AssertMore.assertEquals(500,event.getShockEnhancedPeakE0(),MAX_EXACT_PERCENT_ERROR);

		event.setShockEnhancedPeakE0(201.111);
		AssertMore.assertEquals(201.111,event.getShockEnhancedPeakE0(),MAX_EXACT_PERCENT_ERROR);
	}



	public void testGetSetShockEnhancedPeakB() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		try { 
			event.getShockEnhancedPeakE0();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setShockEnhancedPeakE0(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setShockEnhancedPeakE0(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setShockEnhancedPeakE0(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		event.setShockEnhancedPeakE0(10);
		AssertMore.assertEquals(10,event.getShockEnhancedPeakE0(),MAX_EXACT_PERCENT_ERROR);

		event.setShockEnhancedPeakE0(201.111);
		AssertMore.assertEquals(201.111,event.getShockEnhancedPeakE0(),MAX_EXACT_PERCENT_ERROR);
	}


	public void testGetDose() {

		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setEmin(45);
		event.setGamma_1(1.5);
		event.setE0_1(310);
		event.setEnergySpectrumIntegralFluence_1(1.5E8);
		AssertMore.assertEquals(1.07862E9, event.getK_1(),  MAX_CALCULATED_PERCENT_ERROR);
		
		event.setShockEnhancedPeakGamma(2);
		event.setShockEnhancedPeakE0(30);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(3E9);
		AssertMore.assertEquals(1.84677E12, event.getShockEnhancedPeakK(),  MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(1.07862E9*0.0000001389908, event.getDose_1(Thickness.POINT_THREE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.84677E12*0.00000001776271, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.07862E9*0.0000001389908+1.84677E12*0.00000001776271, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.07862E9*0.00000001006711, event.getDose_1(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.84677E12*0.000000000049105768, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.07862E9*0.00000001006711+1.84677E12*0.000000000049105768, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.07862E9*0.0000000016493923, event.getDose_1(Thickness.THIRTY, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.84677E12*8.7101347E-14, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.07862E9*0.0000000016493923+1.84677E12*8.7101347E-14, event.getDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		event = new EventWithShockEnhancedPeak();
		event.setEmin(500);
		event.setGamma_1(3.25);
		event.setE0_1(90);
		event.setEnergySpectrumIntegralFluence_1(2E9);
		AssertMore.assertEquals(5.18805E18,event.getK_1(),  MAX_CALCULATED_PERCENT_ERROR);

		event.setShockEnhancedPeakGamma(1.25);
		event.setShockEnhancedPeakE0(230);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(2E18);
		AssertMore.assertEquals(2.6255E20, event.getShockEnhancedPeakK(),  MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(5.18805E18*0.00000000010730455, event.getDose_1(Thickness.POINT_THREE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.6255E20*0.0000001426601, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.18805E18*0.00000000010730455+2.6255E20*0.0000001426601, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		

		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(2E10);
		AssertMore.assertEquals(2.6255E12, event.getShockEnhancedPeakK(),  MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(5.18805E18*8.5718521E-14, event.getDose_1(Thickness.TEN, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.6255E12*0.000000010866231, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.18805E18*8.5718521E-14+2.6255E12*0.000000010866231, event.getDose(Thickness.TEN, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		

		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(2E20);
		AssertMore.assertEquals(2.6255E22, event.getShockEnhancedPeakK(),  MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(5.18805E18*0.000000000002361491, event.getDose_1(Thickness.FIVE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.6255E22* 0.000000042345956, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.18805E18*0.00000000000236149+2.6255E22*0.000000042345956, event.getDose(Thickness.FIVE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
	}
	
	
	
	public void testGetDose_1() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(0);
		event.setShockEnhancedPeakE0(10);
		event.setShockEnhancedPeakGamma(0);
		
		event.setEmin(10);
		
		event.setGamma_1(0); 
		event.setE0_1(10); 
		event.setEnergySpectrumIntegralFluence_1(3.6787944117144);
		// here, k is calculated automatically
		AssertMore.assertEquals(1, event.getK_1(),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064/2, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.0000000014003176, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000014003176/2, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.000000000048144395, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000048144395/2, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		event.setGamma_1(4);
		event.setE0_1(250);
		event.setEmin(15);
		event.setEnergySpectrumIntegralFluence_1(1E9);
		AssertMore.assertEquals(1.10661E13, event.getK_1(),  MAX_CALCULATED_PERCENT_ERROR);
		

		AssertMore.assertEquals(1.10661E13*1.4836583E-14, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*1.4836583E-14/2, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.10661E13*3.3202516E-14, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*3.3202516E-14/2, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		

		AssertMore.assertEquals(1.10661E13*3.0827117E-14, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*3.0827117E-14/2, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.10661E13*9.346491E-15, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*9.346491E-15/2, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		
		event.setGamma_1(2.5);
		event.setE0_1(110);
		event.setEmin(50);
		event.setEnergySpectrumIntegralFluence_1(1.1E10);

		AssertMore.assertEquals(1.36475E13, event.getK_1(),  MAX_CALCULATED_PERCENT_ERROR);
		
		/* test all of one gamma E0 variation */
		AssertMore.assertEquals(1.36475E13*0.0000000000028125206, event.getDose(Thickness.THIRTY, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000028125206/2, event.getDose(Thickness.THIRTY, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000029545487, event.getDose(Thickness.THIRTY, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000029545487/2, event.getDose(Thickness.THIRTY, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016553532, event.getDose(Thickness.THIRTY, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016553532/2, event.getDose(Thickness.THIRTY, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016848071, event.getDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016848071/2, event.getDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000017327517, event.getDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000017327517/2, event.getDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000009776007, event.getDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000009776007/2, event.getDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);


		AssertMore.assertEquals(1.36475E13*0.000000000023670038, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000023670038/2, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000022511033, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000022511033/2, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000081301511, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000081301511/2, event.getDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000001637482, event.getDose(Thickness.TEN, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000001637482/2, event.getDose(Thickness.TEN, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015832651, event.getDose(Thickness.TEN, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015832651/2, event.getDose(Thickness.TEN, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000056601997, event.getDose(Thickness.TEN, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000056601997/2, event.getDose(Thickness.TEN, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);


		AssertMore.assertEquals(1.36475E13*0.000000000077856006, event.getDose(Thickness.FIVE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000077856006/2, event.getDose(Thickness.FIVE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000067124903, event.getDose(Thickness.FIVE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000067124903/2, event.getDose(Thickness.FIVE, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015837663, event.getDose(Thickness.FIVE, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015837663/2, event.getDose(Thickness.FIVE, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000053171228, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000053171228/2, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000047625879, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000047625879/2, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000011357964, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000011357964/2, event.getDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		
		AssertMore.assertEquals(1.36475E13*0.0000000010235774, event.getDose(Thickness.ONE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000010235774/2, event.getDose(Thickness.ONE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000051621263, event.getDose(Thickness.ONE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000051621263/2, event.getDose(Thickness.ONE, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000036169422, event.getDose(Thickness.ONE, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000036169422/2, event.getDose(Thickness.ONE, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000057066807, event.getDose(Thickness.ONE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000057066807/2, event.getDose(Thickness.ONE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000032892383, event.getDose(Thickness.ONE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000032892383/2, event.getDose(Thickness.ONE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000026031883, event.getDose(Thickness.ONE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000026031883/2, event.getDose(Thickness.ONE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		
		AssertMore.assertEquals(1.36475E13*0.0000000066618648, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000066618648/2, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000001392415, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000001392415/2, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000045009375, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000045009375/2, event.getDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000027985583, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000027985583/2, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000079459922, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000079459922/2, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000032162981, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000032162981/2, event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

	}
	public void testGetShockEnhancedPeakDose() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		
		event.setEnergySpectrumIntegralFluence_1(0);
		event.setE0_1(10);
		event.setGamma_1(0);
		
		event.setEmin(10);
		
		event.setShockEnhancedPeakGamma(0); 
		event.setShockEnhancedPeakE0(10); 
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(3.6787944117144);
		// here, k is calculated automatically
		AssertMore.assertEquals(1, event.getShockEnhancedPeakK(),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064/2, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.0000000014003176, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000014003176/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.000000000048144395, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000048144395/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		event.setShockEnhancedPeakGamma(4);
		event.setShockEnhancedPeakE0(250);
		event.setEmin(15);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);
		AssertMore.assertEquals(1.10661E13, event.getShockEnhancedPeakK(),  MAX_CALCULATED_PERCENT_ERROR);
		

		AssertMore.assertEquals(1.10661E13*1.4836583E-14, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*1.4836583E-14/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.10661E13*3.3202516E-14, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*3.3202516E-14/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		

		AssertMore.assertEquals(1.10661E13*3.0827117E-14, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*3.0827117E-14/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.10661E13*9.346491E-15, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.10661E13*9.346491E-15/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		
		event.setShockEnhancedPeakGamma(2.5);
		event.setShockEnhancedPeakE0(110);
		event.setEmin(50);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1.1E10);

		AssertMore.assertEquals(1.36475E13, event.getShockEnhancedPeakK(),  MAX_CALCULATED_PERCENT_ERROR);
		
		/* test all of one gamma E0 variation */
		AssertMore.assertEquals(1.36475E13*0.0000000000028125206, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000028125206/2, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000029545487, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000029545487/2, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016553532, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016553532/2, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016848071, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000016848071/2, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000017327517, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000017327517/2, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000009776007, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000009776007/2, event.getShockEnhancedPeakDose(Thickness.THIRTY, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);


		AssertMore.assertEquals(1.36475E13*0.000000000023670038, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000023670038/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000022511033, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000022511033/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000081301511, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000081301511/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000001637482, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000001637482/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015832651, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015832651/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000056601997, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000000056601997/2, event.getShockEnhancedPeakDose(Thickness.TEN, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);


		AssertMore.assertEquals(1.36475E13*0.000000000077856006, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000077856006/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000067124903, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000067124903/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015837663, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000015837663/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000053171228, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000053171228/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000047625879, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000047625879/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000011357964, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000011357964/2, event.getShockEnhancedPeakDose(Thickness.FIVE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		
		AssertMore.assertEquals(1.36475E13*0.0000000010235774, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000010235774/2, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000051621263, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000051621263/2, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000036169422, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000036169422/2, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000057066807, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000057066807/2, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000032892383, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000032892383/2, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000026031883, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000026031883/2, event.getShockEnhancedPeakDose(Thickness.ONE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);

		
		AssertMore.assertEquals(1.36475E13*0.0000000066618648, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000066618648/2, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000001392415, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000001392415/2, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000045009375, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000045009375/2, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.REM, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000027985583, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.0000000027985583/2, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000079459922, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.00000000079459922/2, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000032162981, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36475E13*0.000000000032162981/2, event.getShockEnhancedPeakDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
	}
	
	

	public void testGetSetEnergySpectrumIntegralAndRegularFluence_1AndTestGetK_1() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setGamma_1(2);
		event.setE0_1(30);
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_1(1e9);
		
		AssertMore.assertEquals(1e9/0.0440235,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30);
		AssertMore.assertEquals(1e9/0.00494985,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(2.35643E8,event.getEnergySpectrumIntegralFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.43287E7,event.getEnergySpectrumIntegralFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(0,event.getEnergySpectrumIntegralFluence_1(1000),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setGamma_1(4);
		event.setE0_1(300);
		event.setEmin(100);
		event.setEnergySpectrumIntegralFluence_1(1000);
		AssertMore.assertEquals(1000/2.07189E-7,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);

		event.setGamma_1(4);
		event.setE0_1(300);
		event.setEmin(10);
		AssertMore.assertEquals(1000/0.000317193,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.653194,event.getEnergySpectrumIntegralFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(0.0225898,event.getEnergySpectrumFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.426986,event.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(304.93,event.getEnergySpectrumFluence_1(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(18.4333,event.getEnergySpectrumFluence_1(20),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.52178,event.getEnergySpectrumFluence_1(30),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.07778,event.getEnergySpectrumFluence_1(40),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.199165,event.getEnergySpectrumFluence_1(60),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10398,event.getEnergySpectrumFluence_1(70),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0589528,event.getEnergySpectrumFluence_1(80),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0355974,event.getEnergySpectrumFluence_1(90),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0149233,event.getEnergySpectrumFluence_1(110),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0101914,event.getEnergySpectrumFluence_1(120),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00715663,event.getEnergySpectrumFluence_1(130),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00514628,event.getEnergySpectrumFluence_1(140),MAX_CALCULATED_PERCENT_ERROR);
		
		
		event = new EventWithShockEnhancedPeak();
		event.setEmin(30);
		event.setGamma_1(2.75);
		event.setE0_1(120);
		event.setEnergySpectrumIntegralFluence_1(1E9); 
		AssertMore.assertEquals(1.07039E12,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setEmin(20);
		AssertMore.assertEquals(4.56497E11,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.14823E6,event.getEnergySpectrumFluence_1(70),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36902E6,event.getEnergySpectrumFluence_1(80),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(911068.,event.getEnergySpectrumFluence_1(90),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(444125.,event.getEnergySpectrumFluence_1(110),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(321659.,event.getEnergySpectrumFluence_1(120),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(237470.,event.getEnergySpectrumFluence_1(130),MAX_CALCULATED_PERCENT_ERROR);
		
		
	}
	
	
	public void testGetSetShockEnhancedPeakEnergySpectrumFluenceAndIntegralFluenceAndTestGetK() {

		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setShockEnhancedPeakGamma(2);
		event.setShockEnhancedPeakE0(30);
		event.setEmin(10);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1e9);
		
		AssertMore.assertEquals(1e9/0.0440235,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30);
		AssertMore.assertEquals(1e9/0.00494985,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(2.35643E8,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(50),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.43287E7,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(0,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(1000),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setShockEnhancedPeakGamma(4);
		event.setShockEnhancedPeakE0(300);
		event.setEmin(100);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1000);
		AssertMore.assertEquals(1000/2.07189E-7,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);

		event.setShockEnhancedPeakGamma(4);
		event.setShockEnhancedPeakE0(300);
		event.setEmin(10);
		AssertMore.assertEquals(1000/0.000317193,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.653194,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(0.0225898,event.getShockEnhancedPeakEnergySpectrumFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.426986,event.getShockEnhancedPeakEnergySpectrumFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(304.93,event.getShockEnhancedPeakEnergySpectrumFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(18.4333,event.getShockEnhancedPeakEnergySpectrumFluence(20),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.52178,event.getShockEnhancedPeakEnergySpectrumFluence(30),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.07778,event.getShockEnhancedPeakEnergySpectrumFluence(40),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.199165,event.getShockEnhancedPeakEnergySpectrumFluence(60),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10398,event.getShockEnhancedPeakEnergySpectrumFluence(70),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0589528,event.getShockEnhancedPeakEnergySpectrumFluence(80),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0355974,event.getShockEnhancedPeakEnergySpectrumFluence(90),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0149233,event.getShockEnhancedPeakEnergySpectrumFluence(110),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0101914,event.getShockEnhancedPeakEnergySpectrumFluence(120),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00715663,event.getShockEnhancedPeakEnergySpectrumFluence(130),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00514628,event.getShockEnhancedPeakEnergySpectrumFluence(140),MAX_CALCULATED_PERCENT_ERROR);
		
		
		event = new EventWithShockEnhancedPeak();
		event.setEmin(30);
		event.setGamma_1(2.75);
		event.setE0_1(120);
		event.setEnergySpectrumIntegralFluence_1(1E9); 
		AssertMore.assertEquals(1.07039E12,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setEmin(20);
		AssertMore.assertEquals(4.56497E11,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.14823E6,event.getEnergySpectrumFluence_1(70),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36902E6,event.getEnergySpectrumFluence_1(80),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(911068.,event.getEnergySpectrumFluence_1(90),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(444125.,event.getEnergySpectrumFluence_1(110),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(321659.,event.getEnergySpectrumFluence_1(120),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(237470.,event.getEnergySpectrumFluence_1(130),MAX_CALCULATED_PERCENT_ERROR);		
	}
	

	
	public void testClone() {
		EventWithShockEnhancedPeak event1 = new EventWithShockEnhancedPeak();
		event1.setEmin(30);
		event1.setGamma_1(2.75);
		event1.setE0_1(120);
		event1.setEnergySpectrumIntegralFluence_1(10);
		event1.setB1_1(2);
		event1.setB2_1(2);	
		event1.setA_1(1);
		event1.setShockEnhancedPeakGamma(4);
		event1.setShockEnhancedPeakE0(300);
		event1.setShockEnhancedPeakB(1);
		event1.setShockEnhancedPeakEnergySpectrumIntegralFluence(1000);		
		event1.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(2));
		
		EventWithShockEnhancedPeak event2 = (EventWithShockEnhancedPeak)event1.clone();
		AssertMore.assertEquals(event1,event2);
		AssertMore.assertEquals(event1,event1.clone());
		AssertMore.assertEquals(event2,event2.clone());
		
		event2.setEmin(50);
		AssertMore.assertNotEquals(event1,event2);
		event1.setEmin(50);
		AssertMore.assertEquals(event1,event2);

		event1 =(EventWithShockEnhancedPeak)event2.clone();
		event1.setEmin(33);
		AssertMore.assertNotEquals(event1,event2);
		event1.setEmin(50);
		AssertMore.assertEquals(event1,event2);
		event2.setEmin(22);
		AssertMore.assertNotEquals(event1,event2);
		event1.setEmin(22);
		AssertMore.assertEquals(event1,event2);
		event1.setEmin(50);
		event2.setEmin(50);
		AssertMore.assertEquals(event1,event2);
		
		
		event2.setB1_1(5);
		AssertMore.assertNotEquals(event1,event2);
		event1=(EventWithShockEnhancedPeak)event2.clone();
		AssertMore.assertEquals(event1,event2);
		
		event2.setGamma_1(2);
		AssertMore.assertNotEquals(event1,event2);
		event2=(EventWithShockEnhancedPeak)event1.clone();
		AssertMore.assertEquals(event1,event2);

		event2.setGamma_1(4);
		AssertMore.assertNotEquals(event1,event2);
		event1=(EventWithShockEnhancedPeak)event2.clone();
		AssertMore.assertEquals(event1,event2);
		
		AssertMore.assertEquals(event1,event1.clone());
		
	}

	public void testEqualsObject() {

		EventWithShockEnhancedPeak event1 = new EventWithShockEnhancedPeak();
		event1.setEmin(30);
		event1.setGamma_1(2.75);
		event1.setE0_1(120);
		event1.setEnergySpectrumIntegralFluence_1(10);
		event1.setB1_1(2);
		event1.setB2_1(2);	
		event1.setA_1(1);
		event1.setShockEnhancedPeakGamma(4);
		event1.setShockEnhancedPeakE0(300);
		event1.setShockEnhancedPeakB(1);
		event1.setShockEnhancedPeakEnergySpectrumIntegralFluence(1000);		
		event1.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(2));
		
		EventWithShockEnhancedPeak event2 = new EventWithShockEnhancedPeak();
		event2.setEmin(30);
		event2.setGamma_1(2.75);
		event2.setE0_1(120);
		event2.setEnergySpectrumIntegralFluence_1(10);
		event2.setB1_1(2);
		event2.setB2_1(2);	
		event2.setA_1(1);	
		event2.setShockEnhancedPeakGamma(4);
		event2.setShockEnhancedPeakE0(300);
		event2.setShockEnhancedPeakB(1);
		event2.setShockEnhancedPeakEnergySpectrumIntegralFluence(1000);		
		event2.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(2));

		
		AssertMore.assertTrue(event1.equals(event1));
		AssertMore.assertEquals(event1,event1);		
		AssertMore.assertEquals(event1,event2);
		
		event2.setEmin(20);
		AssertMore.assertNotEquals(event1,event2);
		event1.setEmin(20);
		AssertMore.assertEquals(event1,event2);
		
		event1.setGamma_1(2);
		AssertMore.assertNotEquals(event1,event2);
		event2.setGamma_1(2);
		AssertMore.assertEquals(event1,event2);

		event2.setE0_1(20);
		AssertMore.assertNotEquals(event1,event2);
		event1.setE0_1(20);
		AssertMore.assertEquals(event1,event2);
		

		event2.setA_1(20);
		AssertMore.assertNotEquals(event1,event2);
		event1.setA_1(20);
		AssertMore.assertEquals(event1,event2);

		event2.setB1_1(5);
		AssertMore.assertNotEquals(event1,event2);
		event1.setB1_1(6);
		AssertMore.assertNotEquals(event1,event2);
		event1.setB1_1(5);
		AssertMore.assertEquals(event1,event2);
		
	}
	

	public void testGetTimeEvolutionIntegralFluxAndRegularFluxAndTestGetC__AllForTheRegularEvent() {

		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setEnergySpectrumIntegralFluence_1(1E2);
		event.setGamma_1(.125);
		event.setE0_1(20);
		event.setEmin(40);
	
		AssertMore.assertEquals(61.258,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);		
		
		event.setA_1(2);
		event.setB1_1(2.2);
		event.setB2_1(5);
		
		AssertMore.assertEquals(0.000816319,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(0.561651,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.441615,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0671903,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00739811,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000805327,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(.25)),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		

		event.setShockEnhancedPeakGamma(0);
		event.setShockEnhancedPeakE0(10);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(0);
		event.setShockEnhancedPeakB(1);

		AssertMore.assertEquals(0,event.getShockEnhancedPeakC());
		
		AssertMore.assertEquals(1.12097E-6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.0000386281+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);			
		AssertMore.assertEquals(0.000172196+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000341928+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000300307+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		
		
		event.setEnergySpectrumIntegralFluence_1(1E12);
		AssertMore.assertEquals(1.12097E-6*1E10+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.0000386281*1E10+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);			
		AssertMore.assertEquals(0.000172196*1E10+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000341928*1E10+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000300307*1E10+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		
		

		event.setEnergySpectrumIntegralFluence_1(1E7);
		AssertMore.assertEquals(1.12097E-6*1E5+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.0000386281*1E5+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);			
		AssertMore.assertEquals(0.000172196*1E5+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000341928*1E5+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000300307*1E5+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		
		
		
		event.setGamma_1(4);
		event.setE0_1(50);
		event.setEmin(100);
		event.setEnergySpectrumIntegralFluence_1(4.44E8);
		event.setA_1(4);
		event.setB1_1(5);
		event.setB2_1(5);
		AssertMore.assertEquals(1.77438E16,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.54995E6,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);				

		
		AssertMore.assertEquals(0.734535,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(0.010241,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(0.000162674,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(2.54309E-6,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(1.6276E-10,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);		
		
		
		AssertMore.assertEquals(0.0541987+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(169.366+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5414.58+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(800714.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(21223.7+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.78214+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(7)),MAX_CALCULATED_PERCENT_ERROR);

		event.setEnergySpectrumIntegralFluence_1(4.44E4);

		AssertMore.assertEquals(0.0541987*1E-4+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(169.366*1E-4+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5414.58*1E-4+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(800714.*1E-4+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(21223.7*1E-4+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.78214*1E-4+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(7)),MAX_CALCULATED_PERCENT_ERROR);

		event.setEnergySpectrumIntegralFluence_1(4.44);

		AssertMore.assertEquals(0.0541987*1E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(169.366*1E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5414.58*1E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(800714.*1E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(21223.7*1E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.78214*1E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(7)),MAX_CALCULATED_PERCENT_ERROR);
	}
	
	public void testGetShockEnhancedPeakTimeEvolutionFluxAndIntegralFluxWithoutCWithoutGCR() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setEnergySpectrumIntegralFluence_1(0);
		event.setGamma_1(0);
		event.setE0_1(10);
		event.setA_1(1);
		event.setB1_1(1);
		event.setB2_1(1);
		event.setEmin(40);
		AssertMore.assertEquals(0,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);				
		AssertMore.assertEquals(0,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);	
		
		event.setShockEnhancedPeakGamma(4);
		event.setShockEnhancedPeakE0(25);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);
		
		AssertMore.assertEquals(1.57316E15,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2.9754E11,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);	
		
		event.setShockEnhancedPeakB(.2);
		AssertMore.assertEquals(2.9754E11/(0.177245*4*Math.PI*3600*24),event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(1.54614E6,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(0.177245,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0922562,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999167,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000999992,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.001)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(1.20413E6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1.5461E6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.001)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(568791.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2984.74+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.0000214726+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1.54614E6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(0)),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1));
		AssertMore.assertEquals(Time.inDays(1),event.getTimeDelayBeforeShockEnhancedPeak());
		AssertMore.assertEquals(773066.,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(0.177245,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(11)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0922562,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(1.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999167,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(1.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000999992,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(1.001)),MAX_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(602064.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(773047.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.001)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(284395.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1492.37+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.0000107363+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(773066.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(3));
		
		AssertMore.assertEquals(0.177245,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(3),Time.inDays(13)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0922562,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(3),Time.inDays(3.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999167,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(3),Time.inDays(3.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000999992,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(3),Time.inDays(3.001)),MAX_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(602064.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(773047.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3.001)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(284395.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1492.37+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.0000107363+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(4)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(773066.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(1.54614E6,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(2.9754E11/(0.177245*4*Math.PI*3600*24),event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(1.54614E6,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(0.177245,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0922562,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999167,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.000999992,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.001)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(1.20413E6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1.5461E6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.001)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(568791.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2984.74+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.0000214726+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1.54614E6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(0)),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	

		event.setEmin(30);

		event.setShockEnhancedPeakGamma(2);
		event.setShockEnhancedPeakE0(300);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E8);

		AssertMore.assertEquals(4.15199E9,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(3.62046E8,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);	
		
		event.setShockEnhancedPeakB(.7);	
		AssertMore.assertEquals(537.523,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(0.000999999,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.001)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999932,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0993239,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.593465,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620326,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620359,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(537.523+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(0)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(526.664+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(495.387+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(447.331+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.3)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(387.781+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.4)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(322.714+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(257.824+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.6)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(197.744+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.7)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(145.598+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.8)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(102.916+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.9)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(69.8364+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(5.44738+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.153157+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.00155212+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(5.66969E-6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(7.46509E-9+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3.5)),MAX_CALCULATED_PERCENT_ERROR);	
		
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(268.761,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(0.000999999,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(5.001)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999932,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(5.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0993239,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(5.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.593465,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620326,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(7)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620359,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(8)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(0.620359,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.85309,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(4.5),Time.inDays(5.5)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.479531,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(4.75),Time.inDays(5.25)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(268.761*1.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.979799+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.92161+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.832208+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.3)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.721422+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.4)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.600373+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.479652+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.6)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.367879+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.7)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.270868+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.8)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.191463+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(5.9)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.129923+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.0101342+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(6.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*0.00028493+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(7)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*2.88755E-6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(7.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*1.05478E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(8)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(268.761*1.38879E-11+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(8.5)),MAX_CALCULATED_PERCENT_ERROR);	
	
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1));
		AssertMore.assertEquals(274.716,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		

		AssertMore.assertEquals(0.000999999,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(1.001)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999932,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(1.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0993239,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(1.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.593465,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620326,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620359,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(1),Time.inDays(4)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(1.21382,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(11)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(1.21379,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.479531,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(.75),Time.inDays(1.25)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.85309,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(.5),Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.900566,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(1.33)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(274.716*1.+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.979799+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.92161+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.832208+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.3)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.721422+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.4)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.600373+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.479652+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.6)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.367879+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.7)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.270868+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.8)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.191463+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.9)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.129923+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.0101342+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*0.00028493+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*2.88755E-6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*1.05478E-8+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(4)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(274.716*1.38879E-11+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(4.5)),MAX_CALCULATED_PERCENT_ERROR);	

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(537.523,event.getShockEnhancedPeakC(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(0.000999999,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.001)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.00999932,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.01)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.0993239,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.593465,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620326,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);		
		AssertMore.assertEquals(0.620359,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);		
		
		AssertMore.assertEquals(537.523+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(0)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(526.664+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(495.387+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(447.331+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.3)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(387.781+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.4)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(322.714+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(257.824+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.6)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(197.744+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.7)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(145.598+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.8)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(102.916+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(.9)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(69.8364+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(5.44738+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(1.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.153157+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(0.00155212+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(2.5)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(5.66969E-6+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3)),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(7.46509E-9+.11,event.getTimeEvolutionFluxWithCWithGCR(Time.inDays(3.5)),MAX_CALCULATED_PERCENT_ERROR);	
	}


	public void testGetEnergySpectrumFuenceAndIntegralFluence() {
		/* This is fluence & integral fluence for both event & SEP added together */
		
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setName("name");
		event.setEnergySpectrumIntegralFluence_1(1E10);
		event.setGamma_1(2);
		event.setE0_1(30);
		
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E10);
		event.setShockEnhancedPeakGamma(2.5);
		event.setShockEnhancedPeakE0(50);
		
		AssertMore.assertEquals(1E10,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1E10,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2E10,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);	
		try{ // cannot get the individual fluence until an Emin is specified.
			event.getEnergySpectrumFluence_1(10);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try{
			event.getShockEnhancedPeakEnergySpectrumFluence(10);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		
		event.setEmin(10);

		AssertMore.assertEquals(2.27151E11,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(7.20489E11,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);	
		

		AssertMore.assertEquals(1.71613E7,event.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.49937E7,event.getShockEnhancedPeakEnergySpectrumFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.71613E7+1.49937E7,event.getEnergySpectrumFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		

		AssertMore.assertEquals(810338.,event.getEnergySpectrumFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(975076.,event.getShockEnhancedPeakEnergySpectrumFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(810338+975076,event.getEnergySpectrumFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(0.0524969,event.getEnergySpectrumFluence_1(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.85137,event.getShockEnhancedPeakEnergySpectrumFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0524969+5.85137,event.getEnergySpectrumFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(2.64948E8,event.getEnergySpectrumIntegralFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2.57763E8,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.64948E8+2.57763E8,event.getEnergySpectrumIntegralFluence(50),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.41359,event.getEnergySpectrumIntegralFluence_1(500),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(237.433,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.41359+237.433,event.getEnergySpectrumIntegralFluence(500),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.61106E7,event.getEnergySpectrumIntegralFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2.41139E7,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.61106E7+2.41139E7,event.getEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);

		// again
		
		event.setEnergySpectrumIntegralFluence_1(1.5E10);
		event.setGamma_1(4);
		event.setE0_1(350);
		
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E10);
		event.setShockEnhancedPeakGamma(3.5);
		event.setShockEnhancedPeakE0(400);
		
		AssertMore.assertEquals(1.5E10,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1E10,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1.5E10+1E10,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);	
		
		event.setEmin(100);

		AssertMore.assertEquals(6.77905E16,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(3.68466E15,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);	
		

		AssertMore.assertEquals(9.40258E9,event.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.67888E9,event.getShockEnhancedPeakEnergySpectrumFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.40258E9+3.67888E9,event.getEnergySpectrumFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		

		AssertMore.assertEquals(2.39266E7,event.getEnergySpectrumFluence_1(200),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.97536E7,event.getShockEnhancedPeakEnergySpectrumFluence(200),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.39266E7+1.97536E7,event.getEnergySpectrumFluence(200),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(3893.39,event.getEnergySpectrumFluence_1(1000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9564.48,event.getShockEnhancedPeakEnergySpectrumFluence(1000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3893.39+9564.48,event.getEnergySpectrumFluence(1000),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(1.46718E11,event.getEnergySpectrumIntegralFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(6.83073E10,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.46718E11+6.83073E10,event.getEnergySpectrumIntegralFluence(50),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(2.725315776415639E7,event.getEnergySpectrumIntegralFluence_1(500),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(4.6040438542337224E7,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.725315776415639E7+4.6040438542337224E7,event.getEnergySpectrumIntegralFluence(500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.5E10,event.getEnergySpectrumIntegralFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1E10,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.5E10+1E10,event.getEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);
			
		// again
		
		event.setEnergySpectrumIntegralFluence_1(1E5);
		event.setGamma_1(1.1);
		event.setE0_1(222);
		
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(2E5);
		event.setShockEnhancedPeakGamma(3.1);
		event.setShockEnhancedPeakE0(111);
		

		AssertMore.assertEquals(1E5,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2E5,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1E5+2E5,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);	
		
		event.setEmin(1000);

		AssertMore.assertEquals(9.83289E7,event.getK_1(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(3.87641E16,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);	
		

		AssertMore.assertEquals(1.0617E6,event.getEnergySpectrumFluence_1(50),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.33658E11,event.getShockEnhancedPeakEnergySpectrumFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.33658E11+1.0617E6,event.getEnergySpectrumFluence(50),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		

		AssertMore.assertEquals(36.6909,event.getEnergySpectrumFluence_1(1500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.47657,event.getShockEnhancedPeakEnergySpectrumFluence(1500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(36.6909+7.47657,event.getEnergySpectrumFluence(1500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(2.8118,event.getEnergySpectrumFluence_1(2000),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0338931,event.getShockEnhancedPeakEnergySpectrumFluence(2000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.8118+0.0338931,event.getEnergySpectrumFluence(2000),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(294.42,event.getEnergySpectrumFluence_1(1111),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(630.752,event.getShockEnhancedPeakEnergySpectrumFluence(1111),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(294.42+630.752,event.getEnergySpectrumFluence(1111),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(11109.,event.getEnergySpectrumFluence_1(500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.84222E6,event.getShockEnhancedPeakEnergySpectrumFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.84222E6+11109.,event.getEnergySpectrumFluence(500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(6.85661E7,event.getEnergySpectrumIntegralFluence_1(50),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2.41778E12,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.85661E7+2.41778E12,event.getEnergySpectrumIntegralFluence(50),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(1.78231E6,event.getEnergySpectrumIntegralFluence_1(500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(1.27004E8,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.78231E6+1.27004E8,event.getEnergySpectrumIntegralFluence(500),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(3.62818E7,event.getEnergySpectrumIntegralFluence_1(100),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(2.98709E11,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.62818E7+2.98709E11,event.getEnergySpectrumIntegralFluence(100),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(100000.,event.getEnergySpectrumIntegralFluence_1(1000),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(200000.,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(1000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100000.+200000.,event.getEnergySpectrumIntegralFluence(1000),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(26194.597660471594,event.getEnergySpectrumIntegralFluence_1(1250),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(11039.8,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(1250),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(26194.597660471594+11039.8,event.getEnergySpectrumIntegralFluence(1250),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(54876.,event.getEnergySpectrumIntegralFluence_1(1111),MAX_WEAKER_CALCULATED_PERCENT_ERROR);	
		AssertMore.assertEquals(54336.6,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(1111),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(54876.+54336.6,event.getEnergySpectrumIntegralFluence(1111),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

	}
	



	
	
	public void testGetShockEnhancedPeakC() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E10);
		event.setShockEnhancedPeakGamma(1.6);
		event.setShockEnhancedPeakE0(10);
		event.setEmin(50);
		AssertMore.assertEquals(9.93426E13,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(4.2782E12,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		event.setShockEnhancedPeakB(2);
		
		AssertMore.assertEquals(2.22312E6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.77245,
			event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)),
			MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(.5));
		AssertMore.assertEquals(1.74181E6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1));
		AssertMore.assertEquals(1.4621E6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);


		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1.5));
		AssertMore.assertEquals(1.29919E6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
			
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(5E8);
		event.setShockEnhancedPeakGamma(2);
		event.setShockEnhancedPeakE0(100);
		event.setEmin(40);
		AssertMore.assertEquals(5.13653E10,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);
	
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1.5));
		AssertMore.assertEquals(1127.06,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(1928.57,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(964.679,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(8));
		AssertMore.assertEquals(1046.6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
			
		

		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1);
		event.setShockEnhancedPeakGamma(1.111);
		event.setShockEnhancedPeakE0(111);
		event.setEmin(111);
		AssertMore.assertEquals(8.07224,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);
	
		AssertMore.assertEquals(10.4766,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1.5));
		AssertMore.assertEquals(3.18151E-6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(5.44406E-6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);			
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(2.72314E-6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);			
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(8));
		AssertMore.assertEquals(2.95439E-6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
			
		event.setShockEnhancedPeakB(1);

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1.5));
		AssertMore.assertEquals(5.53791E-6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(0.0000108881,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);			
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(5.44406E-6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);			
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(8));
		AssertMore.assertEquals(5.45682E-6,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
			

		event.setShockEnhancedPeakB(.5);

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1.5));
		AssertMore.assertEquals(0.0000108882,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(0.0000217762,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);			
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(0.0000108881,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);	
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(8));
		AssertMore.assertEquals(0.0000108881,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);		
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(.25));
		AssertMore.assertEquals(0.0000143218,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		

		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E20);
		event.setShockEnhancedPeakGamma(3.3);
		event.setShockEnhancedPeakE0(202);
		event.setEmin(500);
		event.setShockEnhancedPeakB(20);
		
		AssertMore.assertEquals(1.01285E28,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.02735E25,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(2.024E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(.25));
		AssertMore.assertEquals(2.0122E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(.5));
		AssertMore.assertEquals(2.00108E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1));
		AssertMore.assertEquals(1.98079E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(1.90624E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);

		
		event.setShockEnhancedPeakB(2);
		
		AssertMore.assertEquals(1.01285E28,event.getShockEnhancedPeakK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.02735E25,event.getShockEnhancedPeakEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		AssertMore.assertEquals(1.05349E19,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(.25));
		AssertMore.assertEquals(9.23857E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(.5));
		AssertMore.assertEquals(8.25407E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1));
		AssertMore.assertEquals(6.92857E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(5));
		AssertMore.assertEquals(5.26959E18,event.getShockEnhancedPeakC(),MAX_CALCULATED_PERCENT_ERROR);
		
	}

	
	
	public void testCompareTo() {
		EventWithShockEnhancedPeak event1 = new EventWithShockEnhancedPeak();
		EventWithShockEnhancedPeak event2 = new EventWithShockEnhancedPeak();
		
		event1.setEnergySpectrumIntegralFluence_1(1E9);
		event1.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);		
		event2.setEnergySpectrumIntegralFluence_1(1E9);
		event2.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);
		
		AssertMore.assertEquals(0,event1.compareTo(event2));
		AssertMore.assertEquals(0,event2.compareTo(event1));
		
		event1.setEnergySpectrumIntegralFluence_1(1E10);
		
		AssertMore.assertEquals(1,event1.compareTo(event2));
		AssertMore.assertEquals(-1,event2.compareTo(event1));
		
		event2.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E10);
		AssertMore.assertEquals(0,event1.compareTo(event2));
		AssertMore.assertEquals(0,event2.compareTo(event1));

		event1.setEnergySpectrumIntegralFluence_1(2E9);
		event1.setShockEnhancedPeakEnergySpectrumIntegralFluence(2E9);		
		event2.setEnergySpectrumIntegralFluence_1(1E9);
		event2.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);

		AssertMore.assertEquals(1,event1.compareTo(event2));
		AssertMore.assertEquals(-1,event2.compareTo(event1));
		

		event1.setEnergySpectrumIntegralFluence_1(1E9);
		event1.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);		
		event2.setEnergySpectrumIntegralFluence_1(2E9);
		event2.setShockEnhancedPeakEnergySpectrumIntegralFluence(2E9);

		AssertMore.assertEquals(-1,event1.compareTo(event2));
		AssertMore.assertEquals(1,event2.compareTo(event1));

		event1.setEnergySpectrumIntegralFluence_1(1E9);
		event2.setEnergySpectrumIntegralFluence_1(1E9);
		
		event1.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);		
		event2.setShockEnhancedPeakEnergySpectrumIntegralFluence(1.001E9);		

		AssertMore.assertEquals(-1,event1.compareTo(event2));
		AssertMore.assertEquals(1,event2.compareTo(event1));

		event1.setShockEnhancedPeakEnergySpectrumIntegralFluence(1.001E9);		
		event2.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E9);	
		AssertMore.assertEquals(1,event1.compareTo(event2));
		AssertMore.assertEquals(-1,event2.compareTo(event1));
	}


	public void testDoesTimeEvolutionIntegralFluxDecreaseFastEnough() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setEnergySpectrumIntegralFluence_1(1E10);
		event.setGamma_1(2);
		event.setE0_1(100);
		event.setEmin(10);

		event.setA_1(3);
		event.setB1_1(4);
		event.setB2_1(2);
		

		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(0);
		event.setShockEnhancedPeakGamma(3);
		event.setShockEnhancedPeakE0(30);
		
		event.setShockEnhancedPeakB(2);
		
		
		AssertMore.assertEquals(1.29233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.390142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.29233*.01>0.390142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2_1(1);

		AssertMore.assertEquals(1.98311,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.8079,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.98311*.01>1.8079,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_1(.5);
		AssertMore.assertEquals(11.649,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.259828,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(11.649*.01>0.259828,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_1(.25);
		AssertMore.assertEquals(5.9999,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000979444,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.9999*.01>0.0000979444,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB1_1(10);
		AssertMore.assertEquals(897392.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8824.08,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(897392.*.01>8824.08,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_1(11);
		AssertMore.assertEquals(9.76578E6,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(188235.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.76578E6*.01>188235.,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2_1(.9);
		AssertMore.assertEquals(2.12754E8,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.67902E7,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.12754E8*.01>5.67902E7,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_1(.5);
		event.setB2_1(.5);
		AssertMore.assertEquals(0.823263,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0433142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.823263*.01>0.0433142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_1(1);
		AssertMore.assertEquals(1.95894,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.202575,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.95894*.01>0.202575,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_1(.5);
		event.setB1_1(1);
		event.setB2_1(1);
		AssertMore.assertEquals(0.49975,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000209762,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.49975*.01>0.000209762,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_1(2);
		AssertMore.assertEquals(1.42541,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.176298,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.42541*.01>0.176298,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_1(1.7);
		AssertMore.assertEquals(1.34622,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.128003,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.34622*.01>0.128003,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_1(1.8);
		AssertMore.assertEquals(1.3772,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.144543,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3772*.01>0.144543,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_1(1.75);
		AssertMore.assertEquals(1.36233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.136313,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36233*.01>0.136313,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	
		event.setA_1(1.78);
		AssertMore.assertEquals(1.3714,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.141262,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3714*.01>0.141262,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	

		event.setEnergySpectrumIntegralFluence_1(0);
		

		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E10);
		event.setShockEnhancedPeakGamma(3);
		event.setShockEnhancedPeakE0(30);
		
		event.setShockEnhancedPeakB(2);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(0));
		
		AssertMore.assertEquals(1.77173,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000682149,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.77173*.01>0.000682149,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	


		event.setShockEnhancedPeakB(5);
		AssertMore.assertEquals(3.73412,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.299603,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.73412*.01>0.299603,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setShockEnhancedPeakB(3);
		AssertMore.assertEquals(2.6097,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0365419,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.6097*.01>0.0365419,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	

		event.setShockEnhancedPeakB(2.8);
		AssertMore.assertEquals(2.45276,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0226194,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.45276*.01>0.0226194,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setShockEnhancedPeakB(2.9);
		AssertMore.assertEquals(2.53213,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0290997,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.53213*.01>0.0290997,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setShockEnhancedPeakB(2.85);
		AssertMore.assertEquals(2.49266,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0257388,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.49266*.01>0.0257388,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	
		event.setShockEnhancedPeakB(1);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(3));
		AssertMore.assertEquals(1.76829,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00412596,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.76829*.01>0.00412596,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(3.5));
		AssertMore.assertEquals(1.74241,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0296779,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.74241*.01>0.0296779,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	

		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(3.25));
		AssertMore.assertEquals(1.76064,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0117227,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.76064*.01>0.0117227,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	

		event.setShockEnhancedPeakB(1.05);
		AssertMore.assertEquals(1.84392,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0169449,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.84392*.01>0.0169449,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setShockEnhancedPeakB(1.1);
		AssertMore.assertEquals(1.92583,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0234444,event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.92583*.01>0.0234444,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	}
	
	
	public void testSimulateAstronautOnTheMoonSingleEventRepeat() {

		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(0);
		event.setShockEnhancedPeakGamma(0);
		event.setShockEnhancedPeakE0(10);
		event.setShockEnhancedPeakB(1);
		
		event.setEmin(10);
		double K = 1e10;
		event.setEnergySpectrumIntegralFluence_1(10969196.719763);
		event.setGamma_1(3);
		event.setE0_1(10);
		event.setA_1(.6);
		event.setB1_1(2);
		event.setB2_1(1);

		
		double timeEvolutionIntegralFlux = 1.1999891455365;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		double energySpectrumIntegralFlux = 10969196.719763;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0),.01);
		
		// the doses
		double totalDoseSuit = 1.5713174E-14*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.BFO,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		double totalDoseRover = 3.5777372E-16*K/2;
		AssertMore.assertEquals(totalDoseRover,   event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.BFO,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		double totalDoseBase = 1.4173827E-16*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.BFO,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		Time time1=Time.inHours(-1);
		Time time2=Time.inHours(1);
		Time time3=Time.inHours(1); 
		DoseInformation results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.BFO,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.FIVE,Thickness.THIRTY, new CumulativeDoseGraph());
		
		Time remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		double dosePriorToWarning = 6.3586136305558e-5 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		double doseWhilePackingUp = 4.194190460278e-4 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		double doseDuringTransit = .0010651172181945 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		double doseAtBase=1.1984410231359 * (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		double totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);


		
		
		
		
		
		/* AGAIN */
		K = 5e9;
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_1(8117128202.9725);
		event.setGamma_1(1);
		event.setE0_1(80);
		event.setA_1(.5);
		event.setB1_1(1);
		event.setB2_1(1);
		
		timeEvolutionIntegralFlux = .49999997835788;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 8117128202.9725;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		// the doses
		totalDoseSuit =0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseRover = 0.00000012680532*K/2;
		AssertMore.assertEquals(totalDoseRover,   event.getDose(Thickness.ONE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.000000034415528*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(1);
		time2=Time.inHours(5);
		time3=Time.inHours(5); 
		results = event.simulateAstronautOnTheMoon(RadiationType.RAD,BodyPart.SKIN,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.ONE,Thickness.FIVE,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = 0 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp =  .022312459617474* (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .064366806734138 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .41332071200624* (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		

		
		
		
		/* AGAIN */
		K = 5e9;
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_1(8117128202.9725);
		event.setGamma_1(1);
		event.setE0_1(80);
		event.setA_1(.5);
		event.setB1_1(1);
		event.setB2_1(1);
		
		timeEvolutionIntegralFlux = .49999997835788;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 8117128202.9725;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		// the doses
		totalDoseSuit =0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseRover = 0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(-5);
		time2=Time.inHours(5);
		time3=Time.inHours(5); 
		results = event.simulateAstronautOnTheMoon(RadiationType.RAD,BodyPart.SKIN,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.POINT_THREE,Thickness.POINT_THREE,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = .033037886941352 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp =  .068580421927162 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .076063794663774 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .32231787482556* (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals( totalDoseSuit, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		

		
		
		
		/* AGAIN */
		K = 7e9;
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_1(37626315626.873);
		event.setGamma_1(.5);
		event.setE0_1(40);
		event.setA_1(.8);
		event.setB1_1(5);
		event.setB2_1(2);
		
		timeEvolutionIntegralFlux = .8;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 37626315626.873;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		
		double totalDoseBefore =0.00000081004993*K/2;
		AssertMore.assertEquals(totalDoseBefore,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseSuit =0.00000049260291*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.ONE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		
		totalDoseRover = 0.000000121331*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.0000000038056167*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(2);
		time2=Time.inHours(24);
		time3=Time.inHours(10); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = 0 * (totalDoseBefore)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp = .11670110228596  * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .30348477319373 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .37981412452039 * (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		
		
		
		
		
		/* AGAIN */
		K = 1;
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_1(5.3751879466961);
		event.setGamma_1(.5);
		event.setE0_1(40);
		event.setA_1(.8);
		event.setB1_1(5);
		event.setB2_1(2);
		
		timeEvolutionIntegralFlux = .8;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 5.3751879466961 ;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		
		totalDoseBefore =0.00000081004993*K/2;
		AssertMore.assertEquals(totalDoseBefore,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseSuit =0.00000049260291*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.ONE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		
		totalDoseRover = 0.000000121331*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.0000000038056167*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(2);
		time2=Time.inHours(24);
		time3=Time.inHours(10); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = 0 * (totalDoseBefore)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp = .11670110228596  * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .30348477319373 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .37981412452039 * (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		
		/* AGAIN */
		K = 1;
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_1(5.3751879466961);
		event.setGamma_1(.5);
		event.setE0_1(40);
		event.setA_1(.8);
		event.setB1_1(5);
		event.setB2_1(2);
		
		timeEvolutionIntegralFlux = .8;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 5.3751879466961 ;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		
		totalDoseBefore =0.00000081004993*K/2;
		AssertMore.assertEquals(totalDoseBefore,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseSuit =0.00000049260291*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.ONE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		
		totalDoseRover = 0.000000121331*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.0000000038056167*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(7);
		time2=Time.inHours(24);
		time3=Time.inHours(10); 
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.POINT_THREE,Thickness.POINT_THREE,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBefore, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.ONE,time2,Thickness.ONE,time3,Thickness.ONE,Thickness.ONE,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseSuit, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.FIVE,time2,Thickness.FIVE,time3,Thickness.FIVE,Thickness.FIVE,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseRover, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.THIRTY,time2,Thickness.THIRTY,time3,Thickness.THIRTY,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBase, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);

		
		/* AGAIN */		
		time1=Time.inDays(0);
		time2=Time.inDays(10);
		time3=Time.inDays(0); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseSuit, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseSuit/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		time1=Time.inDays(-10);
		time2=Time.inDays(0);
		time3=Time.inDays(0); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBefore, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBefore/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
				
		time1=Time.inDays(0);
		time2=Time.inDays(0);
		time3=Time.inDays(10); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseRover, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseRover/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseRover, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		time1=Time.inDays(0);
		time2=Time.inDays(0);
		time3=Time.inDays(0); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBase, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBase/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		time1=Time.inDays(10);
		time2=Time.inDays(5);
		time3=Time.inDays(5); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( totalDoseBase, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBase/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( totalDoseBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
	}
	
	

	public void testSimulateAnAstronautOnTheMoon_PART_A_1() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(5);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = 2;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =3.54347;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.00187129;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0.00569847;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =3.5359;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}
	

	public void testSimulateAnAstronautOnTheMoon_PART_A_2() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(0);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = 2;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =1.77245;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.489776;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0.432786;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =0.849892;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}

	public void testSimulateAnAstronautOnTheMoon_PART_A_3() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(2.5);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = 2;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =3.40825;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.14215;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0.233158;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =3.03294;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}

	public void testSimulateAnAstronautOnTheMoon_PART_A_4() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(2.5);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = 5;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =6.58735;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.408141;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0.442075;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =5.73713;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}
	

	public void testSimulateAnAstronautOnTheMoon_PART_A_5() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(.5);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = .5;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =0.816526;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.373412;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0.373412;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =0.0697014;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}

	public void testSimulateAnAstronautOnTheMoon_PART_A_6() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(0);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = .1;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =0.0886227;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.0886227;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =0;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}
	

	public void testSimulateAnAstronautOnTheMoon_PART_A_7() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(5);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = 10;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =9.22562;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.398963;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0.417319;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =8.40934;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}
	

	public void testSimulateAnAstronautOnTheMoon_PART_A_8() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(1);   	
		double Emin = 10;		
		double K_1 = 1.32E12;
		double integralFluence_1 =1.0029083902698023E9;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double shockEnhancedPeakK = 1.17E10;
		double shockEnhancedPeakIntegralFluence=9.98640503161835E8;
		double shockEnhancedPeakGamma = 2;
		double shockEnhancedPeakE0 = 250;
		double shockEnhancedPeakB = 50;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFluxShockEnhancedPeak =9.9036;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak =0.499883;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak =0.499983;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =8.90374;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
			B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
			radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
			totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
			totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
			totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
			totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
			timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);
	}
	
	
	public void testSimulateAnAstronautOnTheMoon_PART_B_1() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(1); 		
		double Emin=10;
		double integralFluence_1=2.753999722385943E11;
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double shockEnhancedPeakIntegralFluence=3.3547077833097095E10;
		double shockEnhancedPeakK = 1.000107346848698E10;
		double shockEnhancedPeakGamma = 1;
		double shockEnhancedPeakE0 = 500;
		double shockEnhancedPeakB=1;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFluxShockEnhancedPeak = 1.63305;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak = 0.285543;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak = 0.922562;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak = 0.285543;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak = 0.139403;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
				B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
				radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
				totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
				totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
				totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
				totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
				timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
				timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
				timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
				timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);			
	}
	
	
	

	public void testSimulateAnAstronautOnTheMoon_PART_B_2() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(5);    	
		
		double Emin=10;
		double integralFluence_1=2.753999722385943E11;
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double shockEnhancedPeakIntegralFluence=3.3547077833097095E10;
		double shockEnhancedPeakK = 1.000107346848698E10;
		double shockEnhancedPeakGamma = 1;
		double shockEnhancedPeakE0 = 500;
		double shockEnhancedPeakB=1;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFluxShockEnhancedPeak = 1.77245;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak = 1.72884E-10;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak = 6.5838E-7;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak = 0.0000189186;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak = 1.77243;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
				B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
				radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
				totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
				totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
				totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
				totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
				timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
				timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
				timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
				timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);			
	}


	public void testSimulateAnAstronautOnTheMoon_PART_B_3() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(0);    	
		
		double Emin=10;
		double integralFluence_1=2.753999722385943E11;
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double shockEnhancedPeakIntegralFluence=3.3547077833097095E10;
		double shockEnhancedPeakK = 1.000107346848698E10;
		double shockEnhancedPeakGamma = 1;
		double shockEnhancedPeakE0 = 500;
		double shockEnhancedPeakB=1;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFluxShockEnhancedPeak =0.886227;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak = 0.461281;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak = 0.394907;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak = 0.025893;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak =0.00414553;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
				B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
				radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
				totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
				totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
				totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
				totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
				timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
				timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
				timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
				timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);			
	}
	

	public void testSimulateAnAstronautOnTheMoon_PART_B_4() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(0);    	
		
		double Emin=10;
		double integralFluence_1=2.753999722385943E11;
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double shockEnhancedPeakIntegralFluence=3.3547077833097095E10;
		double shockEnhancedPeakK = 1.000107346848698E10;
		double shockEnhancedPeakGamma = 1;
		double shockEnhancedPeakE0 = 500;
		double shockEnhancedPeakB=1.5;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFluxShockEnhancedPeak = 1.32934;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak = 0.482083;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak = 0.638153;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak = 0.130213;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak = 0.0788916;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
				B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
				radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
				totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
				totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
				totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
				totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
				timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
				timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
				timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
				timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);			
	}
	

	public void testSimulateAnAstronautOnTheMoon_PART_B_5() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(3);    	
		
		double Emin=10;
		double integralFluence_1=2.753999722385943E11;
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double shockEnhancedPeakIntegralFluence=3.3547077833097095E10;
		double shockEnhancedPeakK = 1.000107346848698E10;
		double shockEnhancedPeakGamma = 1;
		double shockEnhancedPeakE0 = 500;
		double shockEnhancedPeakB=3;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFluxShockEnhancedPeak = 4.89658;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak = 0.216134 ;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak = 0.640496;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak = 0.419677;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak = 3.62027;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
				B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
				radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
				totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
				totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
				totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
				totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
				timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
				timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
				timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
				timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);			
	}

	public void testSimulateAnAstronautOnTheMoon_PART_B_6() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(2);    	
		
		double Emin=10;
		double integralFluence_1=2.753999722385943E11;
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double shockEnhancedPeakIntegralFluence=3.3547077833097095E10;
		double shockEnhancedPeakK = 1.000107346848698E10;
		double shockEnhancedPeakGamma = 1;
		double shockEnhancedPeakE0 = 500;
		double shockEnhancedPeakB=7;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFluxShockEnhancedPeak = 7.49264 ;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak = 0.469532 ;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak = 0.978203 ;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak = 0.499151 ;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak = 5.54575 ;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
				B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
				radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
				totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
				totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
				totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
				totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
				timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
				timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
				timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
				timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);			
	}

	public void testSimulateAnAstronautOnTheMoon_PART_B_7() {	
		Time timeDelayBeforeShockEnhancedPeak = Time.inDays(1);    	
		
		double Emin=10;
		double integralFluence_1=2.753999722385943E11;
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double shockEnhancedPeakIntegralFluence=3.3547077833097095E10;
		double shockEnhancedPeakK = 1.000107346848698E10;
		double shockEnhancedPeakGamma = 1;
		double shockEnhancedPeakE0 = 500;
		double shockEnhancedPeakB=50;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarningShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUpShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransitShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBaseShockEnhancedPeak = (shockEnhancedPeakK/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFluxShockEnhancedPeak = 9.9036 ;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak = 0.499883 ;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak = 0.999967 ;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak = 0.499883 ;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak = 7.90387 ;
		
		testSimulateAstronautOnTheMoon_HELPER(Emin,timeDelayBeforeShockEnhancedPeak,integralFluence_1,gamma_1,E0_1,A_1,
				B1_1,B2_1,shockEnhancedPeakIntegralFluence,shockEnhancedPeakGamma,shockEnhancedPeakE0,shockEnhancedPeakB,
				radiationType,bodyPart,thicknessPriorToWarning,timePriorToWarning,totalEventDosePriorToWarning_1,
				totalEventDosePriorToWarningShockEnhancedPeak,timeToPackUp,thicknessWhilePackingUp,totalEventDoseWhilePackingUp_1,
				totalEventDoseWhilePackingUpShockEnhancedPeak,timeInTransit,thicknessWhileInTransit,
				totalEventDoseWhileInTransit_1 ,totalEventDoseWhileInTransitShockEnhancedPeak,	thicknessAtBase,
				totalEventDoseAtBase_1,totalEventDoseAtBaseShockEnhancedPeak,timeEvolutionFlux_1,timeEvolutionFluxShockEnhancedPeak,
				timeEvolutionIntegralFluxPriorToWarning_1,timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
				timeEvolutionIntegralFluxWhilePackingUp_1,timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
				timeEvolutionIntegralFluxWhileInTransit_1,timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
				timeEvolutionIntegralFluxAtBase_1,timeEvolutionIntegralFluxAtBaseShockEnhancedPeak);			
	}
	
	private void testSimulateAstronautOnTheMoon_HELPER(
			double Emin,
			Time timeDelayBeforeShockEnhancedPeak,
			double integralFluence_1,
			double gamma_1,
			double E0_1,
			double A_1,
			double B1_1,
			double B2_1,
			double shockEnhancedPeakIntegralFluence,
			double shockEnhancedPeakGamma,
			double shockEnhancedPeakE0,
			double shockEnhancedPeakB,
			RadiationType radiationType,
			BodyPart bodyPart,
			Thickness thicknessPriorToWarning,
			Time timePriorToWarning,
			double totalEventDosePriorToWarning_1,
			double totalEventDosePriorToWarningShockEnhancedPeak,
			Time timeToPackUp,
			Thickness thicknessWhilePackingUp,
			double totalEventDoseWhilePackingUp_1,
			double totalEventDoseWhilePackingUpShockEnhancedPeak,					
			Time timeInTransit,
			Thickness thicknessWhileInTransit,
			double totalEventDoseWhileInTransit_1 ,
			double totalEventDoseWhileInTransitShockEnhancedPeak,					
			Thickness thicknessAtBase,
			double totalEventDoseAtBase_1,
			double totalEventDoseAtBaseShockEnhancedPeak,
			double timeEvolutionFlux_1,
			double timeEvolutionFluxShockEnhancedPeak,
			double timeEvolutionIntegralFluxPriorToWarning_1,
			double timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			double timeEvolutionIntegralFluxWhilePackingUp_1,
			double timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,			
			double timeEvolutionIntegralFluxWhileInTransit_1,
			double timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,			
			double timeEvolutionIntegralFluxAtBase_1,
			double timeEvolutionIntegralFluxAtBaseShockEnhancedPeak) {
		
		
		/* all parameters to do the test have been entered, run through and make sure everything is good */
		
		/* set event */
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		event.setEmin(Emin);
		
		event.setEnergySpectrumIntegralFluence_1(integralFluence_1);
		event.setGamma_1(gamma_1);
		event.setE0_1(E0_1);
		event.setA_1(A_1);
		event.setB1_1(B1_1);
		event.setB2_1(B2_1);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(shockEnhancedPeakIntegralFluence);
		event.setShockEnhancedPeakGamma(shockEnhancedPeakGamma);
		event.setShockEnhancedPeakE0(shockEnhancedPeakE0);
		event.setShockEnhancedPeakB(shockEnhancedPeakB);		
		event.setTimeDelayBeforeShockEnhancedPeak(timeDelayBeforeShockEnhancedPeak);
		
		/* Run simulation */
		DoseInformation information = event.simulateAstronautOnTheMoon(radiationType, bodyPart,
			timePriorToWarning,thicknessPriorToWarning,timeToPackUp,thicknessWhilePackingUp,timeInTransit,
			thicknessWhileInTransit,thicknessAtBase,new CumulativeDoseGraph());
		
		/* Test that all the event radiation doses are correct */
		AssertMore.assertEquals(totalEventDosePriorToWarning_1,
			event.getDose_1(thicknessPriorToWarning,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhilePackingUp_1,
			event.getDose_1(thicknessWhilePackingUp,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhileInTransit_1,
			event.getDose_1(thicknessWhileInTransit,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseAtBase_1,
			event.getDose_1(thicknessAtBase,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDosePriorToWarningShockEnhancedPeak,
			event.getShockEnhancedPeakDose(thicknessPriorToWarning,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhilePackingUpShockEnhancedPeak,
			event.getShockEnhancedPeakDose(thicknessWhilePackingUp,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhileInTransitShockEnhancedPeak,
			event.getShockEnhancedPeakDose(thicknessWhileInTransit,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseAtBaseShockEnhancedPeak,
			event.getShockEnhancedPeakDose(thicknessAtBase,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDosePriorToWarning_1+totalEventDosePriorToWarningShockEnhancedPeak,
			event.getDose(thicknessPriorToWarning,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhilePackingUp_1+totalEventDoseWhilePackingUpShockEnhancedPeak,
			event.getDose(thicknessWhilePackingUp,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhileInTransit_1+totalEventDoseWhileInTransitShockEnhancedPeak,
			event.getDose(thicknessWhileInTransit,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseAtBase_1+totalEventDoseAtBaseShockEnhancedPeak,
			event.getDose(thicknessAtBase,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_CALCULATED_PERCENT_ERROR
		);

		/* Test that the time evolution fluxes are correct */
		AssertMore.assertEquals(timeEvolutionFlux_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionFluxShockEnhancedPeak,
			event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)),
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Test that the fractions of time evolution fluxes are correct */
		AssertMore.assertEquals(timeEvolutionIntegralFluxPriorToWarning_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.negative(timePriorToWarning)),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak,
			event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.negative(timePriorToWarning)),
			MAX_CALCULATED_PERCENT_ERROR			
		);
		
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhilePackingUp_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(
				Time.negative(timePriorToWarning),
				Time.add(Time.negative(timePriorToWarning),timeToPackUp)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak,
			event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(
				Time.negative(timePriorToWarning),
				Time.add(Time.negative(timePriorToWarning),timeToPackUp)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhileInTransit_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(
				Time.add(Time.negative(timePriorToWarning),timeToPackUp),
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak,
			event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(
				Time.add(Time.negative(timePriorToWarning),timeToPackUp),
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit)
			), MAX_CALCULATED_PERCENT_ERROR
		);

		AssertMore.assertEquals(timeEvolutionIntegralFluxAtBase_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit),
				Time.inDays(10)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		
		AssertMore.assertEquals(timeEvolutionIntegralFluxAtBaseShockEnhancedPeak,
			event.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit),
				Time.inDays(10)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Now, test to see if the simulation works right */
		double dosePriorToWarning = 
			totalEventDosePriorToWarning_1*
				(timeEvolutionIntegralFluxPriorToWarning_1/timeEvolutionFlux_1)+
			totalEventDosePriorToWarningShockEnhancedPeak*
				(timeEvolutionIntegralFluxPriorToWarningShockEnhancedPeak/timeEvolutionFluxShockEnhancedPeak);			
		AssertMore.assertEquals(
			dosePriorToWarning,
			information.dosePriorToWarning, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		double doseWhilePackingUp = 
			totalEventDoseWhilePackingUp_1*
			(timeEvolutionIntegralFluxWhilePackingUp_1/timeEvolutionFlux_1)+
			totalEventDoseWhilePackingUpShockEnhancedPeak*
			(timeEvolutionIntegralFluxWhilePackingUpShockEnhancedPeak/timeEvolutionFluxShockEnhancedPeak);		
		AssertMore.assertEquals(
			doseWhilePackingUp,
			information.doseWhilePackingUp, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		double doseWhileInTransit = 
			totalEventDoseWhileInTransit_1*
			(timeEvolutionIntegralFluxWhileInTransit_1/timeEvolutionFlux_1)+
			totalEventDoseWhileInTransitShockEnhancedPeak*
			(timeEvolutionIntegralFluxWhileInTransitShockEnhancedPeak/timeEvolutionFluxShockEnhancedPeak);
		AssertMore.assertEquals(
			doseWhileInTransit,
			information.doseDuringTransit, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		double doseAtBase=
			totalEventDoseAtBase_1*
			(timeEvolutionIntegralFluxAtBase_1/timeEvolutionFlux_1)+
			totalEventDoseAtBaseShockEnhancedPeak*
			(timeEvolutionIntegralFluxAtBaseShockEnhancedPeak/timeEvolutionFluxShockEnhancedPeak);
		AssertMore.assertEquals(
			doseAtBase,
			information.doseAtBase, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Make sure total is correct */
		double totalDose=dosePriorToWarning+doseWhilePackingUp+doseWhileInTransit+doseAtBase;
		AssertMore.assertEquals(
				totalDose,
			information.totalDoseAwayFromShelter, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Make sure percentages are right */
		AssertMore.assertEquals(
			100*dosePriorToWarning/totalDose,
			information.percentOfTotalPriorToWarning, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseWhilePackingUp/totalDose,
			information.percentOfTotalWhilePackingUp, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseWhilePackingUp/totalDose,
			information.percentOfTotalWhilePackingUp, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseWhileInTransit/totalDose,
			information.percentOfTotalDuringTransit,
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseAtBase/totalDose,
			information.percentOfTotalAtBase,
			MAX_CALCULATED_PERCENT_ERROR
		);
		
	}


	public void testIsEventLargeEnough() {
		EventWithShockEnhancedPeak event = new EventWithShockEnhancedPeak();
		
		event.setEmin(10);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(0);
		event.setShockEnhancedPeakE0(10);
		event.setShockEnhancedPeakGamma(0);
		event.setShockEnhancedPeakB(1);
		
		double C;
		
		event.setA_1(3);
		event.setB1_1(2);
		event.setB2_1(2);
		AssertMore.assertEquals(1.3292624332267, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);

		try {
			event.getC_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		event.setGamma_1(0.222);
		event.setE0_1(333.0);
		
		event.setEnergySpectrumIntegralFluence_1(1.0152632909385885E12);
		AssertMore.assertEquals(1E10,event.getK_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0152632909385885E12,event.getEnergySpectrumIntegralFluence(10.0),MAX_CALCULATED_PERCENT_ERROR);
		 C=1015263290938.5/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertTrue( event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(101.52632909385885);
		AssertMore.assertEquals(1,event.getK_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101.52632909385885,event.getEnergySpectrumIntegralFluence(10.0),MAX_CALCULATED_PERCENT_ERROR);
		C=101.52632909385/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertFalse( event.isEventLargeEnough());

		
		event.setEmin(10);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(0);
		event.setShockEnhancedPeakE0(10);
		event.setShockEnhancedPeakGamma(0);
		event.setShockEnhancedPeakB(1);
		
		event.setEnergySpectrumIntegralFluence_1(1E6);
		event.setGamma_1(1);
		event.setE0_1(10);
		event.setA_1(2);
		event.setB1_1(2);
		event.setB2_1(2);
		AssertMore.assertEquals(1.0392773271962623,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);
		//maximum at t=2
		
		/*
		 * Mathematica code to te
		 * totalfluence = 1*10^6
		 * gamma = 1
		 * E0 = 10
		 * Emin = 10
		 * A = 2
		 * B1 = 2
		 * B2 = 2
		 * Cee = CalculateC[CalculateK[totalfluence, gamma, E0, Emin], gamma, E0, A, B1, B2]
		 * FindMaximum[Flux[Cee, A, B1, B2, t], {t, .01}]
		 *
		 * Prints out: {0.382329, {t -> 2.}}, which is larger then .1, so it is good enough.
		 */
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		

		event.setEnergySpectrumIntegralFluence_1(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
	
		event.setB1_1(3);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(3.1E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setGamma_1(4);
		event.setB2_1(6);
		event.setEnergySpectrumIntegralFluence_1(1.25E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		event.setEnergySpectrumIntegralFluence_1(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(0);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		/*
		 * : Mathematica code used to find the maximum flux to see if is big enough. 
		 * totalfluence = 1.25*10^5
		 * gamma = 4
		 * E0 = 10
		 * Emin = 10
		 * A = 2
		 * B1 = 3
		 * B2 = 6
		 * 
		 * totalfluenceSEP = .1*10^5
		 * gammaSEP = 4
		 * E0SEP = 10
		 * BSEP = .99
		 * delaySEP = 1
		 * FindMaximum[Flux[CalculateC[CalculateK[
		 * totalfluence, gamma, E0, Emin], gamma, E0, A, B1, B2], A, B1, B2, t], {t, 0}]
		 * FindMaximum[SEPFlux[CalculateSEPC[CalculateK[totalfluenceSEP, gammaSEP, E0SEP, Emin], gammaSEP, E0SEP, BSEP, delaySEP], BSEP, t - delaySEP], {t, 0}]
		 * FindMaximum[Flux[CalculateC[CalculateK[totalfluence, gamma, E0, Emin], gamma, E0, A, B1, B2], A, B1, B2, t] + SEPFlux[CalculateSEPC[CalculateK[totalfluenceSEP, gammaSEP, E0SEP, Emin], gammaSEP, E0SEP, BSEP, delaySEP],   BSEP, t - delaySEP], {t, 0}]
		 */		
		event.setEnergySpectrumIntegralFluence_1(1.25E5);
		event.setGamma_1(4);
		event.setE0_1(10);
		event.setEmin(10);
		event.setA_1(2);
		event.setB1_1(3);
		event.setB2_1(6);
		
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(2.2E5);
		event.setShockEnhancedPeakGamma(4);
		event.setShockEnhancedPeakE0(10);
		event.setShockEnhancedPeakB(.99);
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(1));


		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(1.25E5);
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(.1E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		

		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(.01E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(1.5E5);
		event.setShockEnhancedPeakB(.50);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(1.1E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		
		event.setShockEnhancedPeakEnergySpectrumIntegralFluence(1E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(3));
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		event.setTimeDelayBeforeShockEnhancedPeak(Time.inDays(2));
		AssertMore.assertEquals(true,event.isEventLargeEnough());
	}
	
	
	
}
