package SStoRM;
import java.io.*;
import java.util.regex.*;

/**
 * This class holds the radiation doses
 * that have came out of BRYNTRN. It stores the values based on the
 * exponential curve <i>Flux</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>
 * E/E0</sup>, where gamma, E0, and K are free parameters.
 * <p>
 * <b>Usage</b>
 * Assuming the files are set up correctally (see below), you can use this function as follows:
 * <pre>
 * RadiationDoseValues doses = new RadiationDoseValues();
 * doses.getDose(K, gamma, E0, Thickness.ONE, RadiationType.REM, BodyPart.SKIN);
 * </pre>E0, gamma, and K specify the parameters of the exponential curve.
 * <p>
 * This function works by storing lots and lots of gamma and E0 values and 
 * interpolating to get inbetween values. Gamma values are kept between 0 and 
 * 4.125 going up in uniform .125 step size. E0 varies from 10 to 50, 
 * going up in uniform 10 step sizes. 
 * <p>
 * For each E0 and gamma
 * value, this class holds the radiation doses for 5 thicknesses, .3, 1, 5, 10, and 30.
 * For each of these values, the radiation doses are kept for both dose equivalent (REM) and
 * absorbed dose (RAD). And for each Gamma, E0, dose type, and thickness, 3 radiation
 * doses are kept: one for the dose to the skin, one for the dose to the eye, and one
 * for the dose to the BFO (blood flowing organs). This object
 * requires more then 2 megs of memory to hold all the values. Needless to day, this function is
 * quite a memory hog. Only create on of these guys when you really
 * need to use it. There is no reason to instantiate more then one.
 * <p>
 * <b>To Set up to class</b>
 * <p>
 * To use this class, you
 * must make sure that there are the following text files in the same folder as this class: (it is ok if you
 * are missing some)
 * <pre>
 * DATA_RAD (thickness .3).DAT  , DATA_RAD (thickness .3 in-between).DAT
 * DATA_RAD (thickness 1).DAT   , DATA_RAD (thickness 1 in-between).DAT
 * DATA_RAD (thickness 5).DAT   , DATA_RAD (thickness 5 in-between).DAT
 * DATA_RAD (thickness 10).DAT  , DATA_RAD (thickness 10 in-between).DAT
 * DATA_RAD (thickness 30).DAT  , DATA_RAD (thickness 30 in-between).DAT
 * DATA_REM (thickness .3).DAT  , DATA_REM (thickness .3 in-between).DAT
 * DATA_REM (thickness 1).DAT   , DATA_REM (thickness 1 in-between).DAT
 * DATA_REM (thickness 5).DAT   , DATA_REM (thickness 5 in-between).DAT
 * DATA_REM (thickness 10).DAT  , DATA_REM (thickness 10 in-between).DAT
 * DATA_REM (thickness 30).DAT  , DATA_REM (thickness 30 in-between).DAT
 * </pre>According to convention, the file holds what is specified. 
 * But honestally, it dosn't really matter what radiation values are in
 * what file, because it can read any radiation dose from any file dynamically as it parses them. All 
 * that matters is that all the doses are somewhere in these files.
 * If you don't like this convention, you can also specify more file names using {@link #readInAndParseIndividualFile}.
 * <p>
 * <b>Each file must be formatted as follows</b>
 * <pre>
 * HISTORICAL PART OF CODE
 * GAMMA =                   0.1250000  
 * E0 =                       20.00000    
 * THICKNESS =                1.000000    
 * THIS IS RAD dose measurement
 * COLUMN 1 (SKIN REM) =        ...      6.0157078E-07
 * COLUMN 2 (EYE REM)=          ...      3.9690457E-07
 * COLUMN 3 (BFO REM) =         ...      2.2082448E-08
 * 
 * </pre>
 * Here, the ... means that there are many more spaces. In the file,
 * these blocks should be separated by 0 or more blank lines. 
 * <p>
 * <b>Implementation</b>
 * To store the radiation values, this module maps gamma and E0 values to integers. This allows them
 * to be placed inside an array. To do this, a gamma of GAMMA_START corresponds to a gamma index of 0. A gamma
 * of GAMMA_START+GAMMA_STEP corresponds to a gamma index of 1. The same goes for E0. E0_START+2*E0_STEP corresponds
 * to an index of 2. This is how the radiation dose values are stored inside in the array, and this is why
 * methods like {@link #isExactE0Value} work.
 * 
 * @author Joshua Lande
 *
 * @version 1.0
 */
public class RadiationDoseValues {
	
	/** The starting Gamma value. It is hard coded to 0. */
	private static final double GAMMA_START=0;
	
	/** The ending Gamma value. It is hard coded to 4.125. */
	private static final double GAMMA_STOP=4.125;
	
	/**
	 * The Gamma step size. Gamma values go up in uniform
	 * step sizes. All gamma values are of the form:
	 * <p>
	 * GAMMA_START, GAMMA_START+GAMMA_STEP, GAMMA_START+2*GAMMA_STEP, GAMMA_START+3*GAMMA_STEP, ...
	 * <p>
	 * The value is hardcoded to .125. 
	 */
	private static final double GAMMA_STEP=.125;
	
	/**
	 * NUMBER_OF_GAMMA holds the total number of gamma values. This is calculated
	 * at compile time by subtracting GAMMA_STOP from GAMMA_START to find the range
	 * of gamma and then dividing by GAMMA_STEP. NUMBER_OF_GAMMA is one more then this 
	 * value to account for boundary effects.
	 * <p>
	 * for example, if GAMMA_START=10, GAMMA_STOP=20 & GAMMA_STEP=10,
	 * NUMBER_OF_GAMMA would otherwise be calculated (20-10)/10=1,
	 * but it is really 2, because both ends must be counted. 
	 * <p>If GAMMA_STOP on the other hand
	 * If GAMMA_STOP is not an even number of gammaSteps away from gamamStart, the final GAMMA_STOP is not 
	 * be included in the array. For example, if GAMMA_STOP was instead 35, 
	 * NUMBER_OF_GAMMA would be (int)(35-10)/10)+1 = 3. We would only
	 * include the values 10, 20, 30, not 35.
	 */
	private static final int NUMBER_OF_GAMMA=(int)((GAMMA_STOP-GAMMA_START)/GAMMA_STEP)+1;
	
	/** Similar to {@link #GAMMA_START}, but for E0. It is hardcoded to 10. */
	private static final double E0_START=10;
	
	/** Similar to {@link #GAMMA_STOP}, but for E0. It is hardcoded to 500. */
	private static final double E0_STOP=500;
	
	/** Similar to {@link #GAMMA_STEP}, but for E0. It is hardcoded to 10 */
	private static final double E0_STEP=10;
	
	/**
	 * Similar to {@link #NUMBER_OF_GAMMA}.
	 */
	private static final int NUMBER_OF_E0=(int)((E0_STOP-E0_START)/E0_STEP)+1;
	
	/**
	 * The number of thicknesses. It is hardcoded to 5, to correspond to
	 * the thicknesses .3, 1, 5, 10, and 30.
	 */
	private static final int NUMBER_OF_THICKNESSES=5;
	
	/**
	 * 5 dimensional array that holds radiation doses for all thicknesses, gammas, E0s, rems, rads,
	 * skins, eyes, and BFOs. The following convention is used to store values inside and take values
	 * away from the array.
	 * <pre>
	 * The first subscript corresponds to does of 
	 * 		0: REM 
	 * 		1: RAD
	 * The second subscript corresponds to thickness of
	 * 		0: .3
	 * 		1: 	1
	 * 		2:	5	
	 * 		3: 10
	 * 		4: 30
	 * The third subscript corresponds to gamma values of
	 * 		0: GAMMA_START
	 * 		1: GAMMA_START+1*GAMMA_STEP
	 * 		2: GAMMA_START+2*GAMMA_STEP
	 * 		3: GAMMA_START+3*GAMMA_STEP
	 * 		4: ...
	 * The Fourth subscript corresponds to E0 values of
	 * 		0: E0_START
	 * 		1: E0_START+1*E0_STEP
	 * 		2: E0_START+2*E0_STEP
	 * 		3: E0_START+3*E0_STEP
	 * 		4: ...
	 * The Fifth subscript corresponds to does of
	 * 		0: Skin
	 * 		1: Eye
	 * 		2: BFO
	 * The actual order of Skin, Eye, BFO, the thicknesses, and rem and rad are decided by the enumerated types, and may not be in that order.
	 * </pre>
	 */
	private double[][][][][] radiationDose=
		new double[2][NUMBER_OF_THICKNESSES][NUMBER_OF_GAMMA][NUMBER_OF_E0][3];
	
	
	/**
	 * Decides whether a given value is exactally in the array. It does so by deciding if the value is an
	 * even multiple of GAMMA_STEP away from GAMMA_START. This is calculated using the algorithm:
	 * <pre>
	 * if (gammaValue-GAMMA_START)%GAMMA_STEP equals 0, the value is an even distance away
	 * It is false otherwise.
	 * </pre>
	 * Here, % is the modular operator. GammaValue-GAMMA_START is the distance between the first gamma value
	 * and the current gamma value. gammaValue is an even distance away if GAMMA_STEP can go into the distance an even
	 * number of times. This is true if (gammaValue-GAMMA_START)%GAMMA_STEP equals 0.
	 * @param gammaValue The value to check.
	 * @return Whether it is exact.
	 */
	private boolean isExactGammaValue(double gammaValue) {
		return ((gammaValue-GAMMA_START)%GAMMA_STEP == 0);
	}
	
	/**
	 * Returns the gammaIndex that corresponds to a gammaValue. This allows for accessing radiation does
	 * inside {@link #radiationDose}. This method works by using the formula:
	 * <pre> 
	 * index = (gammaValue - GAMMA_START) / GAMMA_STEP.
	 * </pre>gammaValue-GAMMA_START is the range between the start and the current value. 
	 * Therefore, (gammaValue-GAMMA_START)/gammStep is the total number of items up to and including gammaValue, or
	 * the index we want.
	 * 
	 * @param gammaValue The gamma value to find the index for.
	 * @return the index of the gamma value.
	 * @throws IllegalArgumentException If gamma is not defined or does not correspond to an exact gamma Index.
	 */
	private int getGammaIndex(double gammaValue) throws IllegalArgumentException {
		if (Double.isNaN(gammaValue)) throw new IllegalArgumentException("Gamma must be defined before it is used.");
		if (gammaValue<GAMMA_START) throw new IllegalArgumentException("Gamma must be at least as large as GAMMA_START.");
		if (gammaValue>GAMMA_STOP) throw new IllegalArgumentException("Gamma must be at least as small as GAMMA_STOP.");
		if (!isExactGammaValue(gammaValue))throw new IllegalArgumentException("The gamma value is not exact");
		return (int)((gammaValue-GAMMA_START)/GAMMA_STEP);
	}
	
	/**
	 * Like {@link #isExactGammaValue} but for E0.
	 * @param E0Value Value to test.
	 * @return true if E0Value is an exact E0 value, false otherwise.
	 */
	private boolean isExactE0Value(double E0Value) {
		return ((E0Value-E0_START)%E0_STEP==0); 
	}
	
	/**
	 * Like {@link #getGammaIndex} but for E0
	 * @param E0Value Value to find index of.
	 * @return the index of E0Value.
	 * @throws IllegalArgumentException If E0 is not defined or does not correspond to an exact E0 Index.
	 */
	private int getE0Index(double E0Value) throws IllegalArgumentException {
		if (Double.isNaN(E0Value)) throw new IllegalArgumentException("E0 must be defined before it is used.");
		if (E0Value< E0_START) throw new IllegalArgumentException("E0 must be at least as large as E0_START");
		if (E0Value>E0_STOP) throw new IllegalArgumentException("E0 must be at least as small as E0_STOP.");
		if (!isExactE0Value(E0Value)) throw new IllegalArgumentException("The E0 value is not exact");
		return (int)( (E0Value-E0_START)/E0_STEP);
	}
	
	/**
	 * Returns the index of the thickness value. It lets the enumerated type {@link SStoRM#Thickness} do the work.
	 * @param thickness The thickness.
	 * @return The index of the thickness inputted.
	 */
	private int getThicknessIndex(Thickness thickness){
		return thickness.ordinal();
	}
	
	/**
	 * Returns the index for a radiationType. It lets the enumerated type {@link SStoRM#RadiationType} do the work.
	 * @param radiationType What radiation type to get radiation doses for.
	 * @return The index of the radiation type.
	 */
	private int getRemOrRadIndex(RadiationType radiationType) {
		return radiationType.ordinal();
	}
	
	/**
	 * Returns the index for the body part. It lets the enumerated type {@link SStoRM#BodyPart} do the work.
	 * @param bodyPart A string saying if the value is skinEyeOrBFO.
	 * @return The index of the body part.
	 */
	private int getSkinEyeBFOIndex(BodyPart bodyPart) {
		return bodyPart.ordinal();
	}


	/**
	 * This method tests to see if a string line matches another string toFind. If there is a match,
	 * the first number inside line is returned. For example,
	 * <pre>
	 * double gamma=getValueIfFound("GAMMA =   0.1250000",".*gamma.*"); // returns .125
	 * </pre>
	 * This method is useful for getting a desired number out of a line only if the number is correctally labeled.
	 * 
	 * @param line The line to search.
	 * @param toFind The string that must be found inside the line for the first number inside line to be returned.
	 * @return the number found inside the line, or -1 if line is null, the match is not found inside line, 
	 * or if no number is found inside the string
	 */
	private double getValueIfFound(String line,String toFind) throws IllegalArgumentException {

		if (line == null) return -1 ;
		// pattern to search for, any valid number, in both scientific 
		Pattern pattern=Pattern.compile("\\d*\\.\\d+[eE]{0,1}[-\\+]{0,1}[\\d]*");
		
		// if you can't find the passed string in the line, return -1.
		if (!(line.toLowerCase().matches(toFind))) return -1;
		
		Matcher matcher=pattern.matcher(line);
		if (!matcher.find()) return -1;
		
		return	Double.parseDouble(matcher.group());
	}
	
	
	/**
	 * Parses an individual file for radiation doses. It must be passed a file name. The file should be in
	 * the same folder as this program. Files must be of the form:
	 * <pre>
	 *  HISTORICAL PART OF CODE
	 *  GAMMA =                   0.1250000  
	 *  E0 =                       20.00000    
	 *  THICKNESS =                1.000000    
	 *  THIS IS RAD dose measurement
	 *  COLUMN 1 (SKIN REM) =        ...      6.0157078E-07
	 *  COLUMN 2 (EYE REM)=          ...      3.9690457E-07
	 *  COLUMN 3 (BFO REM) =         ...      2.2082448E-08
	 * </pre>Here, (...) represents a bunch of blank spaces. This segment of radiation does can be repeated as
	 * many times in the file as necessary 
	 * <p>
	 * <b>The algorithm to parse the file is as follows:</b>
	 * <pre>
	 *Loop through the file and whenever "historical part of code" is in the current line:
	 *	read the next line
	 *	if the word "gamma" is in the line, parse the number and store it
	 *	otherwise, go to the top of the loop
	 *
	 *	read the next line
	 *	if the word "E0" is in the line, parse the number and store it
	 *	otherwise, go to the top of the loop
	 *
	 *	read the next line
	 *	if the word "thickness" is in the line, parse the number and store it
	 *	otherwise, go to the top of the loop
	 *
	 *	if the next line contains "rem", remember we are using rem 
	 *	If the next line contains "rad", remember we are using rad
	 *	otherwise, go to the top of the loop
	 *
	 *	read the next line
	 *	if the word "skin" is in the line, parse the number and store it
	 *	otherwise, go to the top of the loop
	 *
	 *
	 *	read the next line
	 *	if the word "eye" is in the line, parse the number and store it
	 *	otherwise, go to the top of the loop
	 *
	 *
	 *	read the next line
	 *	if the word "bfo" is in the line, parse the number and store it
	 *	otherwise, go to the top of the loop
	 *
	 *	Now, since we are here, we have read from the file correctally. So we can store the skin, eye, and BFO radiation doses
	 *	based on the gamma, E0, thickness, and rem/rad values that we found.
	 *End loop 
	 * </pre>The pattern used to find numbers in a line of text is as follows: "\\d*\\.\\d+[eE]{0,1}[-\\+]{0,1}[\\d]*".
	 * This looks bad, but don't be afraid. It first matches any number of digits ("\\d*\\"), a period ("."),
	 * any number of digits ("\\d+"), an 'e' or an 'E' at most once ("[eE]{0,1}"), a '-' or a '+' at most once 
	 * ("[-\\+]{0,1}"), and finally any number of digits. This pattern works by demanding that there is always
	 * a decimal followed by one or more digits. Then there is an optional e/E, +/-, and any number more digits.
	 * This means it will match, .11, 0.11, 1.1e-1, 0.1e-21, etc. 
	 * @param fileName The input stream to read the file from.
	 */
	public void readInAndParseIndividualFile(String fileName) {
		
		try {
		
			// This syntax found at http://www.rgagnon.com/javadetails/java-0077.html
			InputStream stream = getClass().getResourceAsStream(fileName);
			if (stream == null) return; // if you can't open the file, quit
			
			BufferedReader in = new BufferedReader(new InputStreamReader(stream));
			
			double gamma, E0, skin, eye, bfo;
			Thickness thickness;
			RadiationType remOrRad;
			String line;
			
			while((line=in.readLine()) != null) { // loop to the end of the file
				if (line.matches(".*HISTORICAL PART OF CODE.*")) { // only read from historical part of code
					
						// find gamma
						line = in.readLine(); if (line == null) break; // if the line is null, end of file so break loop
						gamma=getValueIfFound(line,".*gamma.*");
						if (gamma==-1) continue; // if gamma is -1, line is not formatted correctally, so begin search for doses gain
						
						// find E0
						line = in.readLine(); if (line == null) break;
						E0=getValueIfFound(line,".*e0.*");
						if (E0==-1) continue;
						
						// find thickness
						line = in.readLine(); if (line == null) break;
						double temp_thickness = getValueIfFound(line,".*thickness.*");
						
						if (temp_thickness == .3) {
							thickness=Thickness.POINT_THREE;
						} else if (temp_thickness == 1) {
							thickness=Thickness.ONE;
						} else if (temp_thickness == 5) {
							thickness = Thickness.FIVE;
						} else if (temp_thickness == 10) {
							thickness = Thickness.TEN;
						} else if (temp_thickness == 30) {
							thickness = Thickness.THIRTY;
						} else continue;
						
						// find rem/rad
						line=in.readLine(); if (line == null) break; 
						if (line.toLowerCase().matches(".* rem .*")) remOrRad=RadiationType.REM;
						else if (line.toLowerCase().matches(".* rad .*")) remOrRad=RadiationType.RAD;
						else continue;

						// find skin
						line = in.readLine(); if (line == null) break;
						skin=getValueIfFound(line,".*skin.*");
						if (skin==-1) continue;
						
						// find eye
						line = in.readLine(); if (line == null) break;
						eye=getValueIfFound(line,".*eye.*");
						if (eye==-1) continue;
						
						// find bfo
						line = in.readLine(); if (line == null) break;
						bfo=getValueIfFound(line,".*bfo.*");
						if (bfo==-1) continue;
						
						// if the program's gotten here, everything is OK, so set the skin/eye/BFO dose
						try {
							setDose(gamma, E0, thickness, 
								remOrRad, BodyPart.SKIN, skin);
							setDose(gamma, E0, thickness, 
								remOrRad, BodyPart.EYE, eye);
							setDose(gamma, E0, thickness, 
								remOrRad, BodyPart.BFO, bfo);
						} catch (IllegalArgumentException exception) {
							// If you can't set the doses, keep going through the file.
						}
				}		
			}		
		} catch (FileNotFoundException exception) { // catch several errors but do nothing.
		} catch (IOException exception) { // end of file, so quit
		}
		
	}
	
	/**
	 * Reads in and has parsed all desired files.
	 */
	private void readInAndParseAllFiles() {
		
		String[] files = new String[] {"DATA_RAD (thickness .3).DAT", "DATA_RAD (thickness .3 in-between).DAT",
									   "DATA_RAD (thickness 1).DAT", "DATA_RAD (thickness 1 in-between).DAT",
									   "DATA_RAD (thickness 5).DAT", "DATA_RAD (thickness 5 in-between).DAT",
									   "DATA_RAD (thickness 10).DAT", "DATA_RAD (thickness 10 in-between).DAT",
									   "DATA_RAD (thickness 30).DAT", "DATA_RAD (thickness 30 in-between).DAT",
									   "DATA_REM (thickness .3).DAT", "DATA_REM (thickness .3 in-between).DAT",
									   "DATA_REM (thickness 1).DAT", "DATA_REM (thickness 1 in-between).DAT",
									   "DATA_REM (thickness 5).DAT", "DATA_REM (thickness 5 in-between).DAT",
									   "DATA_REM (thickness 10).DAT", "DATA_REM (thickness 10 in-between).DAT",
									   "DATA_REM (thickness 30).DAT", "DATA_REM (thickness 30 in-between).DAT"};
		for(String file : files) readInAndParseIndividualFile(file);
	}
	
	public double getExactDose(double K,double gamma, double E0, Thickness thickness, 
			RadiationType radiationType, BodyPart bodyPart)
	throws IllegalArgumentException {
		if (K<0) throw new IllegalArgumentException("K must be greater then or equal to 0");
		return K*radiationDose[getRemOrRadIndex(radiationType)]
							   [getThicknessIndex(thickness)]
								[getGammaIndex(gamma)]
								 [getE0Index(E0)]
								  [getSkinEyeBFOIndex(bodyPart)];
	}	

	private void setDose(double gamma, double E0, Thickness thickness, 
			RadiationType radiationType, BodyPart bodyPart, double dose) {
		radiationDose[getRemOrRadIndex(radiationType)]
		              [getThicknessIndex(thickness)]
		               [getGammaIndex(gamma)]
		                [getE0Index(E0)]
		                 [getSkinEyeBFOIndex(bodyPart)] = dose;
	}

	

	
	/**
	 * Uses bilinear interpolation to find the dose for any value
	 * between GAMMA_START and gammaEnd, and E0_START and E0End.
	 * @param KInput
	 * @param gammaInput
	 * @param E0Input
	 * @param thicknessInput
	 * @param remOrRad
	 * @param skinEyeOrBFO
	 * @return The dose.
	 * @throws IllegalArgumentException
	 */
	public double getDose(double KInput, double gammaInput, double E0Input,
			Thickness thicknessInput ,RadiationType remOrRad,BodyPart skinEyeOrBFO) 
	throws IllegalArgumentException {

		double gammaLeft=gammaInput-gammaInput%GAMMA_STEP;
		double gammaRight=gammaLeft+GAMMA_STEP;
		/*
		 * in the case where you wan't to find the point at gammaLeft,
		 * we can't interpolate w/ the point gammaLeft+GAMMA_STOP. So,
		 * setting both points to be GAMMA_STOP will essentially only do
		 * a single interpolation, which is sufficient.
		 */ 
		if (gammaLeft==GAMMA_STOP) gammaRight = GAMMA_STOP;
		
		
		double E0Lower=E0Input-E0Input%E0_STEP;
		double E0Upper=E0Lower+E0_STEP;
		if (E0Lower == E0_STOP) E0Upper = E0_STOP; // same for E0
		
		// set it so if E0lower = E0end, E0upper=E0lower;
		
		Point lowerLeft = new Point(gammaLeft, E0Lower, this.getExactDose(KInput,gammaLeft,E0Lower,
				thicknessInput,remOrRad,skinEyeOrBFO));
		Point lowerRight = new Point(gammaRight,E0Lower,this.getExactDose(KInput,gammaRight,E0Lower,
				thicknessInput,remOrRad,skinEyeOrBFO));

		Point upperLeft = new Point(gammaLeft, E0Upper, this.getExactDose(KInput,gammaLeft,E0Upper,
				thicknessInput,remOrRad,skinEyeOrBFO));
		Point upperRight = new Point(gammaRight, E0Upper, this.getExactDose(KInput,gammaRight,E0Upper,
				thicknessInput,remOrRad,skinEyeOrBFO));
	
		Point interpolatedPoint = 
			Interpolation.bilinear(gammaInput,E0Input,upperLeft,upperRight,lowerLeft,lowerRight);
		if (interpolatedPoint==null) throw new IllegalArgumentException("Interpolation not sucessful");
		return interpolatedPoint.z; // return the dose value 

	}
	
	
	/**
	 * The basic constructor.
	 * 
	 * @throws IllegalArgumentException You should never worry about this. If
	 * this exception is thrown, there is something wrong with the class itself,
	 * which should never happen.
	 */
	public RadiationDoseValues() throws IllegalArgumentException {
		
		// Initialize the array
		for(RadiationType radiationType: RadiationType.values())
			for(Thickness thickness: Thickness.values()) 
				for (int gammaLoop=0;gammaLoop<NUMBER_OF_GAMMA;gammaLoop++) 
					for (int E0Loop=0;E0Loop<NUMBER_OF_E0;E0Loop++)
						for (BodyPart bodyPart: BodyPart.values()) 
							radiationDose[this.getRemOrRadIndex(radiationType)]
							              [this.getThicknessIndex(thickness)]
							               [gammaLoop]
							                [E0Loop]
							                 [this.getSkinEyeBFOIndex(bodyPart)]=Double.NaN;
		readInAndParseAllFiles();
	}
}
