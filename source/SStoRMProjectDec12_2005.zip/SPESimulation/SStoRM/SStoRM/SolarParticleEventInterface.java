package SStoRM;

/**
 * This interface is things that all Solar Particle Events should have, regardless 
 * of their internal implementation.
 * @author Joshua Lande
 */
public interface SolarParticleEventInterface {
	public double getEnergySpectrumFluence(double EInput);
	public double getEnergySpectrumIntegralFluence(double EminInput);
	public String getName();
	public double getTimeEvolutionFluxWithCWithGCR(Time timeInput);
    public double getDose(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO, DoseLocation lunarSurfaceOrFreeSpace);
      
    
    public void setEmin(double EminInput);
    public double getEmin();
    public double getEnergySpectrumIntegralFluence();
	
}
