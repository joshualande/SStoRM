package SStoRM;

import junit.framework.TestCase;

public class ConvertTest extends TestCase {

	public void testFormatSciTwoDec() {

		try { // make sure they throw errors.
			Convert.toStringScientificNotation(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		AssertMore.assertEquals("1.11E0",Convert.toStringScientificNotation(1.11111));
		AssertMore.assertEquals("1.23E7",Convert.toStringScientificNotation(12345454.992));
		AssertMore.assertEquals("1.24E-5",Convert.toStringScientificNotation(.00001235));
	}

	public void testFormatRegTwoDec() {
		
		try { // make sure they throw errors.
			Convert.toStringTwoDecimal(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		AssertMore.assertEquals("1.11",Convert.toStringTwoDecimal(1.11111));
		AssertMore.assertEquals("12345455.00",Convert.toStringTwoDecimal(12345454.996));
		AssertMore.assertEquals("12345454.99",Convert.toStringTwoDecimal(12345454.992));
		AssertMore.assertEquals("0.00",Convert.toStringTwoDecimal(.00001235));
		AssertMore.assertEquals("1.01",Convert.toStringTwoDecimal(1.00701235));
	}

	
	public void testParseDouble() {
		AssertMore.assertEquals(1e9,Convert.parseDouble("1e9","number"));
		AssertMore.assertEquals(5.32,Convert.parseDouble("5.32","number"));
		AssertMore.assertEquals(0,Convert.parseDouble("0","number"));
		AssertMore.assertEquals(-2.2,Convert.parseDouble("-2.2","number"));
		
		try { 
			Convert.parseDouble("a","Gamma");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("Gamma is currently set to \"a\". This is not a valid number.", e.getMessage());
		}
		

		try { 
			Convert.parseDouble("","\u03A6");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("Please specify a value for \u03A6.", e.getMessage());
		}
		
		
		try { 
			Convert.parseDouble("1111.111 z","E0");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("E0 is currently set to \"1111.111 z\". This is not a valid number.", e.getMessage());
		}
		

		try { 
			Convert.parseDouble("","Gamma");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("Please specify a value for Gamma.", e.getMessage());
		}



		
		
		try { 
			Convert.parseDouble("1111.111 z","The integral flux");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("The integral flux is currently set to \"1111.111 z\". This is not a valid number.", e.getMessage());
		}
		try { 
			Convert.parseDouble("1111.111 z","the integral flux");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("The integral flux is currently set to \"1111.111 z\". This is not a valid number.", e.getMessage());
		}
		

		try { 
			Convert.parseDouble("","The integral flux");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("Please specify a value for the integral flux.", e.getMessage());
		}

		try { 
			Convert.parseDouble("","The integral flux");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {
			AssertMore.assertEquals("Please specify a value for the integral flux.", e.getMessage());
		}
	}
}
