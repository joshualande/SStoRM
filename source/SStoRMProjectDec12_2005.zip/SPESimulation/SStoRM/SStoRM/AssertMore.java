package SStoRM;

import junit.framework.Assert;

/**
 * Subclass of Assert that gives more assert statements to play with.
 * @author Joshua Lande
 *
 *  */
public class AssertMore extends Assert {

	/**
	 * Performs a test to see if the maximum percent difference between num1 and num2 is
	 * at most maxAllowedPercentError. It performs a {@link junit.framework.Assert#assertTrue} 
	 * test where {@link Compare#maxPercentError} passed num1 and num2 is compared to maxAllowedPercentError.
	 * <p>
	 * The test is true if the maximum percent error between the 2 numbers is at
	 * most maxAllowedPercentError.
	 * The test is false otherwise.
	 * @param num1 First number to compare.
	 * @param num2 Second number to compare.
	 * @param maxAllowedPercentError The maximum percent error that is allowed. It should be a
	 * fraction value. Ex: 5% should be passed as 0.05.
	 */
	public static void assertEquals(double num1, double num2, double maxAllowedPercentError) {
		double calculatedPercentError=Compare.maxPercentError(num1,num2);
		Assert.assertTrue("First= "+num1+" Second ="+num2+" Max % error = "+calculatedPercentError+" Allowed % error = "+maxAllowedPercentError,
				calculatedPercentError <= maxAllowedPercentError);
		
	}
	
	/**
	 * Like {@link #assertEquals} but with maxPercentError defaulted to 0.
	 * @param num1
	 * @param num2
	 */
	public static void assertEquals(double num1, double num2) {
		double calculatedPercentError=Compare.maxPercentError(num1,num2);
		Assert.assertTrue("First= "+num1+" Second ="+num2+" Max % error = "+calculatedPercentError+" Allowed % error = 0",
				calculatedPercentError == 0.0);
	}

	/**
	 * Performs a test to see if the maximum percent difference between num1 and num2 is
	 * greater then maxAllowedPercentError. It performs a {@link junit.framework.Assert#assertTrue}
	 * test where {@link Compare#maxPercentError} passed num1 and num2 is compared to maxAllowedPercentError.
	 * <p>
	 * The test is true if the maximum percent error between the 2 numbers is larger then
	 * maxAllowedPercentError. The test is false otherwise.
	 * @param num1 First number to compare.
	 * @param num2 Second number to compare.
	 * @param maxAllowedPercentError The maximum percent error that is allowed. It should be a
	 * fraction value. Ex: 5% should be passed as 0.05.
	 */
	public static void assertNotEquals(double num1, double num2, double maxAllowedPercentError) {
		double calculatedPercentError=Compare.maxPercentError(num1,num2);
		Assert.assertTrue("First= "+num1+" Second ="+num2+" Min % error = "+calculatedPercentError+" Allowed % error = 0",
						Compare.maxPercentError(num1,num2) > maxAllowedPercentError);
	}
	
	/**
	 * Like {@link #assertNotEquals} but with maxPercentError defaulted to 0.
	 * @param num1
	 * @param num2
	 */
	public static void assertNotEquals(double num1, double num2) {
		double calculatedPercentError=Compare.maxPercentError(num1,num2);
		Assert.assertTrue("First= "+num1+" Second ="+num2+" Minimum % error = "+calculatedPercentError+" Allowed % error = 0",
				calculatedPercentError != 0.0);
	}
	
	/**
	 * Tests if object 1 equals object 2 using object 1's equal method. If
	 * they are equal, the test fails. If they are not equal, the test succeeds.
	 * @param object1 
	 * @param object2
	 */
	public static void assertNotEquals(Object object1, Object object2) {
		Assert.assertTrue("object1= "+object1+" Second =" +object2,
				!object1.equals(object2));
				
	}
	
	
	
}
