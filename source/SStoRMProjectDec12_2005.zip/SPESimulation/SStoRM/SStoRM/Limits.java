package SStoRM;

import java.awt.Color;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.ui.LengthAdjustmentType;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.TextAnchor;

/**
 * Provides a class for adding legislated and biological limits to a XYPlot.
 * @author Joshua Lande
 */
public class Limits {
	/**
	 * Adds limits to a plot by adding horizonal markers and labeling them either on the right or left with
	 * the appropriate label. It will only add limits to BFO dose. The limits are taken from:
	 * 
	 * Absorbed Dose (RAD): United States Armed Forces Radiological Research Institute's (AFRRI's) Medical Management 
	 * of Radiological Casualties Handbook. These are biological limits
	 * Dose Equivalent (REM): The National Council on Radiation Protection and Measurement (NCRP). These are 
	 * legislated limits.
	 * 
	 * <pre>
	 * 	Limits.toAPlot(plot,BodyPart.SKIN,RadiationType.REM,LeftOrRight.RIGHT);
	 * </pre>
	 * @param plot The plot to add the limits too.
	 * @param skinEyeOrBFO Whether the limits should be to the {@link BodyPart#SKIN}, {@link BodyPart#EYE}, or
	 * {@link BodyPart#BFO}.
	 * @param remOrRad Weather the limits are absorbed dose {@link RadiationType#RAD} or dose equivalent {@link RadiationType#REM}.
	 * @param orientaiton Must be either {@link LeftOrRight#LEFT} or {@link LeftOrRight#RIGHT}. 
	 * {@link LeftOrRight#LEFT} puts the limit marker labels on
	 * the right of the graph. {@link LeftOrRight#RIGHT} puts them on the right of the graph.
	 * @return The largest limit added to the graph. It returns {@link Double#NaN} if no limits are added to
	 * the graph.
	 */
	public static double addLimitsToAPlot(XYPlot plot, BodyPart skinEyeOrBFO, RadiationType remOrRad,LeftOrRight orientaiton) {
		
		if (skinEyeOrBFO == BodyPart.BFO) {
			if (remOrRad == RadiationType.REM) {
        		addLimitMarker(plot, orientaiton, 25, "30 Day Limit");
        		addLimitMarker(plot, orientaiton, 50, "Annual Limit");
    			return 50;
			} else { // it is rad dose
				addLimitMarker(plot, orientaiton,  75, "5% Change of Vomiting");
        		addLimitMarker(plot, orientaiton, 300, "10% Chance of Death");
        		return 300;
			}
		}		
	    return Double.NaN;
	}
	
	/**
	 * Adds a limit marker to a plot given a dose and label. It is labeled either on the "left" or "right" depending
	 * on the value of leftOrRight. 
	 * @param plot The plot to put the marker.
	 * @param orientaiton Which side to put the limits.
	 * @param dose The dose value of the limit.
	 * @param label The label of the limit (30 Day Limit, etc).
	 * @throws IllegalArgumentException If leftOrRight is not passed correctally.
	 */
	public static void addLimitMarker(XYPlot plot, LeftOrRight orientaiton, double dose, String label) 
	throws IllegalArgumentException {
		Marker marker = new ValueMarker(dose);
	    marker.setLabelOffsetType(LengthAdjustmentType.EXPAND);
	    marker.setPaint(Color.RED);
	    marker.setLabel(label);	    
	    // add limits to either the left or the right
	    if (orientaiton == LeftOrRight.LEFT) {
	    	marker.setLabelAnchor(RectangleAnchor.LEFT);
	    	marker.setLabelTextAnchor(TextAnchor.CENTER_LEFT);
	    } else{ // put them on the right
	    	marker.setLabelAnchor(RectangleAnchor.RIGHT);
	    	marker.setLabelTextAnchor(TextAnchor.CENTER_RIGHT);
	    } 
	    plot.addRangeMarker(marker);
	}	
}
