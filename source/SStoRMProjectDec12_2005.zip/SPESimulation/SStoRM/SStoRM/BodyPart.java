package SStoRM;
public enum BodyPart {
	SKIN,
	EYE,
	BFO;
	
	public String toString() {
		switch(this) {
		case SKIN:
			return "Skin";
		case EYE:
			return "Eye";
		case BFO:
			return "BFO";
		}
		return "";	
	}
}
