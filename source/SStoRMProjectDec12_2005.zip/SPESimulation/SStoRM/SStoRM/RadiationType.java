package SStoRM;

public enum RadiationType {
	REM,
	RAD;
	
	public String getUnits() {
		switch(this) {
		case REM:
			return "cSv";
		case RAD:
			return "cGy";
		}
		return "";
	}

	public String toString() {
		switch(this) {
		case REM:
			return "Dose Equivalent";
		case RAD:
			return "Absorbed Dose";
		}
		return "";	
	}
}
