package SStoRM;

import org.apache.commons.math.analysis.RombergIntegrator;
import org.apache.commons.math.analysis.UnivariateRealFunction;
/**
 * This class implements a shock enhanced peak (SEP). 
 * A shock enhanced peak is like the {@link TimeEvolution},
 * except that it uses a different curve to measure the magnitude of the event over time. 
 * Specifically, it uses a Gaussian curve to measure the SEP.
 * The time evolution of the SEP thus looks like C*exp(-(t-delay)^2/b^2) where C is the magnitude,
 * B is the width (typically between 0.01 and 0.2), 
 * and the delay is the time delay from baseline event onset (typically 0.5 to 2.0 days).
 * The user can specify all 3 parameters of the event, and then obtain useful information from it.
 * For example
 * 
 * <pre>
 *   ShockEhancedPeak shockEhancedPeak= new ShockEhancedPeak();
 *   shockEhancedPeak.setC(1000);
 *   shockEhancedPeak.setB(Time.inDays(.2));
 *   shockEhancedPeak.setTimeDelay(Time.inDays(2)); // default to zero.
 *   
 *   // get the data back out
 *   double CConstant = shockEhancedPeak.getC();
 *   Time BConstant = shockEhancedPeak.getB();
 *   Time delay = shockEhancedPeak.getTimeDelaly(); // The amount of time after t=0 before the middle of Gaussian curve.
 *   
 *   // get the flux at any given point (value of curve at a point)
 *   double fluxWithoutC = shockEhancedPeak.getFluxWithoutC(Time.inDays(2));
 *   double fluxWithC = shockEnhancedPeak.getFluxWithC(Time.inDays(2));
 *   
 *   // get the integral flux between a time range (total number of particles).
 *   double getIntegralFluxWithoutC(Time.inDays(0),Time.inDays(5);
 *   double getIntegralFluxWithC(Time.inDays(0),Time.inDays(5);
 * </pre>
 * @author Joshua Lande
 *
 */
public class ShockEnhancedPeakTimeEvolution implements UnivariateRealFunction {

	/**
	 * The C scaling constant of the Gaussian curve. It must be larger then 0.
	 */
	double C=Double.NaN;
	
	/**
	 * The B width constant of the Gaussian curve.
	 */
	double B=Double.NaN;
	
	/**
	 * The time delay before the middle of the event. 
	 * This is the time delay before the Gaussian curve reaches a max.
	 * So even before this time value, the curve will start increasing.
	 */
	Time timeDelay=Time.inDays(0);

	/**
	 * Tests whether 2 shock enhanced peaks are equal. They are only equal if B, C, and the time delay are equal.
	 */
	public boolean equals(Object anObject){
		if (anObject instanceof ShockEnhancedPeakTimeEvolution) {
			try {
				ShockEnhancedPeakTimeEvolution otherShockEnhancedPeak= (ShockEnhancedPeakTimeEvolution)anObject;
		    	return  (
						(this.getB() 	== otherShockEnhancedPeak.getB()	) &&
						(this.getC() 	== otherShockEnhancedPeak.getC()	) &&
						(this.getTimeDelay().equals(otherShockEnhancedPeak.getTimeDelay()))
		    	);
			} catch (Exception exception) {}
		}	
		return false;
	}
	

	/**
	 * Performs the expected clone of a SolarParticleEvent.
	 */
	public Object clone()
    {   
       	try {
       		ShockEnhancedPeakTimeEvolution copy =  new ShockEnhancedPeakTimeEvolution();
       		copy.setB(this.getB());
       		copy.setC(this.getC());
       		copy.setTimeDelay(this.getTimeDelay());
       		return copy;
       	} catch (Exception exception) {
			return null;
		}
    }

	
	
	/**
	 * Sets the scaling factor of the shock enhanced peak to that of the input.
	 * @param CInput The scaling factor to use.
	 * @throws IllegalArgumentException If the scaling factor is negative.
	 */
	public void setC(double CInput) throws IllegalArgumentException {
		if (Double.isNaN(CInput)) throw new IllegalArgumentException("The shock enhanced peak's scaling factor must be a number.");
		if (CInput<0) throw new IllegalArgumentException("The shock enhanced peak cannot have a negative scaling factor.");
		if (Double.isInfinite(CInput)) throw new IllegalArgumentException("The shock enhanced peak must have a finite scaling factor.");
		C = CInput;
	}
	
	/**
	 * Sets the B parameter of the shock enhanced peak to that of the input.
	 * The B parameter corresponds to the width of the event. 
	 * It is typically between 0.01 and 0.2.
	 * @param BInput The B value to use.
	 * @throws IllegalArgumentException If the B value is 0.
	 */
	public void setB(double BInput) throws IllegalArgumentException {
		if (Double.isNaN(BInput)) throw new IllegalArgumentException("The B parameter of the shock enhanced peak must have a value.");
		if (BInput<=0) throw new IllegalArgumentException("The B parameter of the shock enhanced peak must be larger then 0.");
		if (Double.isInfinite(BInput)) throw new IllegalArgumentException("The B parameter of the shock enhanced peak must be finite.");
		B=BInput;
	}
	
	/**
	 * Sets the time delay of the shock enhanced peak between t=0 and time when the Gaussian curve gets to it's maximum.
	 * @param timeDelayInput The time delay.
	 * @throws IllegalArgumentException If the time delay is less then 0.
	 */
	public void setTimeDelay(Time timeDelayInput) throws IllegalArgumentException { 
		if (timeDelayInput == null) throw new IllegalArgumentException("The time delay of the shock enhanced peak must have a value.");
		if (timeDelayInput.getDays()<0) throw new IllegalArgumentException("The time delay of the shock enhanced peak cannot be negative.");
		timeDelay=(Time)timeDelayInput.clone();
	}
	
	/**
	 * Returns the scaling factor of the shock enhanced peak.
	 * @return The C value.
	 * @throws IllegalArgumentException If the C value has not previously been specified.
	 */
	public double getC() throws IllegalArgumentException {
		if (Double.isNaN(C)) throw new IllegalArgumentException("The scaling factor of the shock enhanced peak must be specified before it can be used.");
		return C;
	}
	
	/**
	 * Returns the B parameter of the shock enhanced peak. The B parameter corresponds to the width of the event. 
	 * @return The B parameter of the event.
	 * @throws IllegalArgumentException If the B value has not previously been specified.
	 */
	public double getB() throws IllegalArgumentException {
		if (Double.isNaN(B)) throw new IllegalArgumentException("The B parameter of the shock enhanced peak must be specified before it can be used.");
		return B;
	}
	
	/**
	 * Returns the time delay before the middle of the shock enhanced peak. 
	 * @return The time delay.
	 * @throws IllegalArgumentException If the time delay has not previously been specified.
	 */
	public Time getTimeDelay() throws IllegalArgumentException{
		if (timeDelay==null) throw new IllegalArgumentException("The Time delay before the shock enhanced peak must be defined before it can be used.");
		return timeDelay;
	}
	
	/**
	 * Returns the flux of the shock enhanced peak for a specific time value. 
	 * It is calculated using the formula C*exp(-(t-delay)^2/b^2).
	 * Here, C is assumed to be 1. If you want to get the flux including C, use {@link #getFluxWithC(Time)}.
	 * For any point less then t=0, the flux is defined as 0.
	 * @param timeInput The time value to calculate the flux for.
	 * @return The flux at that point.
	 * @throws IllegalArgumentException If B, or the time delay have not previously been specified.
	 */
	double getFluxWithoutC(Time timeInput) throws IllegalArgumentException{
		if (timeInput.getDays()<0) return 0;
		return Math.exp(-Math.pow(timeInput.getDays()-timeDelay.getDays(),2)/(Math.pow(this.getB(),2)));
	}

	/**
	 * Returns the flux of the shock enhanced with the C value. 
	 * If you want it without the C value, use {@link #getFluxWithoutC(Time)}.
	 * @param timeInput The time value to calculate the flux for.
	 * @return The flux at that point.
	 * @throws IllegalArgumentException If B, C, or the time delay have not previously been specified.
	 */
	double getFluxWithC(Time timeInput) throws IllegalArgumentException{
		return this.getC()*getFluxWithoutC(timeInput);
	}
	
	/**
	 * Returns the integral flux of the shock enhanced peak from timeMin to timeMax. 
	 * This is the total number of particles of the shock enhanced peak.
	 * It does not include the C scaling factor. 
	 * The integral fluence for any time less then zero is defined as 0. 
	 * @param timeMin The minimum time value used in the integral.
	 * @param timeMax The maximum time value used in the integral.
	 * @return The integral fluence.
	 * @throws IllegalArgumentException If B, or the time delay have not previously been specified. 
	 * If, for any reason, the function cannot be integrated (this should not happen).
	 */	
	double getIntegralFluxWithoutC(Time timeMin, Time timeMax) throws IllegalArgumentException {    
		if (timeMin.getDays()<0) timeMin=Time.inDays(0);
		if (timeMin.getDays() >= timeMax.getDays()) return 0;
		RombergIntegrator integrator = new RombergIntegrator(this);
		try{
			return integrator.integrate(timeMin.getDays(),timeMax.getDays());
		} catch (Exception e) {
			throw new IllegalArgumentException("Function not integratable: "+e.getMessage());
		}
	}

	/**
	 * Returns the integral flux of the shock enhanced peak from timeMin to timeMax. 
	 * This is the total number of particles of the shock enhanced peak.
	 * It includes the C scaling factor.
	 * @param timeMin The minimum time value used in the integral.
	 * @param timeMax The maximum time value used in the integral.
	 * @return The integral fluence.
	 * @throws IllegalArgumentException If B, C, or the time delay have not previously been specified. 
	 * If, for any reason, the function cannot be integrated (this should not happen).
	 */	
	double getIntegralFluxWithC(Time timeMin, Time timeMax) throws IllegalArgumentException {    
		return C*getIntegralFluxWithoutC(timeMin,timeMax);
	}
	
    /**
     * Method used so that the integral can be calculated by RombergIntegrator. It returns the flux of the event at the inputted time (in days).
     * It returns the flux without C and without GCR.
     * @param timeInput The time value
     * @return The Flux at that time value (without C).
     */
    public double value(double timeInput) {
    	return getFluxWithoutC(Time.inDays(timeInput));
    }
   
}
