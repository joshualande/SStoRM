package SStoRM;

import org.apache.commons.math.analysis.RombergIntegrator;
import org.apache.commons.math.analysis.UnivariateRealFunction;
/**
 * This class holds the time evolution of a solar particle event.
 * This class uses the curve 
 * <i>Flux</i>=C((t-delay)/A)<sup>B1</sup><i>e</i>-((t-delay)/A)^B2 to
 * represent the time evolution of the SPE. The time evolution 
 * is a function of the total number of particles 
 * as a function of time. So the integral of it is the total number
 * of particles of the SPE. 
 * The timeDelay allows for the event to begin latter in time then t=0. 
 * This is useful for a delayed event.
 * 
 * 
 * <p>
 * <b>Usage:</b>
 * <p>
 * The main purpose of this function is to create time evolution curves
 * So you can create them by saying:
 * <pre>
 * 	TimeEvolution evolution=new TimeEvolution();
 * </pre>	
 * You can then set the time evolution of the SPE by saying:
 * <pre>
 * evolution.setA(.15);
 * evolution.setB1(2);
 * evolution.setB2(1);
 * evolution.setC(5);
 * evolution.setTimeDelay(Time.inDays(1)); // at t=1 day, the event begins
 * </pre>
 * You can then get any of the values by saying
 * <pre>
 * evolution.getC();
 * evolution.getA();
 * evolution.getB1();
 * evolution.getB2();
 * </pre>
 * 
 * As a note, the following constraints are enforced: A must not be 0 and C must be at least 0.
 * @author Joshua Lande
 */
public class TimeEvolution implements UnivariateRealFunction {

	/**
	 * This is the time delay before the event begins. 
	 */
	private Time timeDelay=Time.inDays(0); 
	

    /**
     * One of the parameters of the time evolution curve of the SPE.
     * <p>To modify, see {@link #setA} and {@link #getA}.
     */
    private double A=Double.NaN;
    
    /**
     * One of the parameters of the time evolution curve of the SPE.
     * <p>To modify, see {@link #setB1} and {@link #getB1}.  
     */
    private double B1=Double.NaN;
    
    /**
     * One of the parameters of the time evolution curve of  the SPE.
     * <p>To modify, see {@link #setB2} and {@link #setB2}.
     */
    private double B2=Double.NaN;
    
    /**
     * One of the parameters of the time evolution curve of the SPE.
     * <p>To modify, see {@link #setC} and {@link #getC}.
     */
    private double C=Double.NaN;
    /**
     * The is the BACKGROUND radiation level of the solar particle event.
     * This means that when calculating the time evolution flux of a point in time
     * (from the time evolution of the SPE), we use the formula
     * <p><i>Flux</i>=C(t/A)<sup>B1</sup><i>e</i>-(t/A)^B2+BACKGROUND.
     * <p>
     * This BACKGROUND roughly correlates to radiation exposure from
     * the galactic cosmic rays, but mainly allows for the time evolution 
     * curve to flatten out in a proper way.
     * 
     * The calculation of flux is done at {@link #getFluxWithCWithGCR}.
     */
    public static double BACKGROUND=.11;
            
	/**
	 * Tests whether 2 time evolutions are equal. They are only equal if gamma, A, B1, and B2, C and the time delay are equal.
	 */
	public boolean equals(Object anObject){
		if (anObject instanceof TimeEvolution) {
			try {
				TimeEvolution otherTimeEvolution= (TimeEvolution)anObject;
		    	return  (
						(this.getA() 	== otherTimeEvolution.getA()	) &&
						(this.getB1() 	== otherTimeEvolution.getB1()	) &&
						(this.getB2() 	== otherTimeEvolution.getB2()  	) &&
						(this.getC()    == otherTimeEvolution.getC()   	) &&
						(this.getTimeDelay().equals(otherTimeEvolution.getTimeDelay()))
		    	);
			} catch (Exception exception) {}
		}	
		return false;
	}
	
	/**
	 * Performs the expected clone of a SolarParticleEvent.
	 */
	public Object clone()
    {   
       	try {
       		TimeEvolution copy =  new TimeEvolution(this.getA(),this.getB1(),this.getB2(),this.getC());
       		copy.setTimeDelay(this.getTimeDelay());
       		return copy;
       	} catch (Exception exception) {
			return null;
		}
    }

    /**
     * Constructor that does nothing.
     */
    public TimeEvolution() {
    }	

    /**
     * Constructor that sets A, B1, B2, and C to the inputted values.
     * @param A The A parameter.
     * @param B1 The B1 parameter.
     * @param B2 The B2 parameter
     * @param C The C parameter.
     * @throws IllegalArgumentException If A, B1, B2, or C are not valid.
     */
    public TimeEvolution(double A, double B1, double B2,double C) throws IllegalArgumentException {
    	setTimeEvolution(A,B1,B2,C);
    }

    /**
     * Sets A, B1, B2, and C to the inputted values.
     * @param A The A parameter.
     * @param B1 The B1 parameter.
     * @param B2 The B2 parameter
     * @param C The C parameter.
     * @throws IllegalArgumentException If A, B1, B2, or C are not valid.
     */
    public void setTimeEvolution(double A, double B1, double B2,double C) throws IllegalArgumentException {
        setC(C);
        setA(A);
        setB1(B1);
        setB2(B2);
    }	

    /**
     * Sets the A parameter of the time evolution of the SPE. It
     * cannot be 0 because this would lead to division by 0 in
     * the time evolution equation.
     * @param AInput The A parameter.
     */
    public void setA(double AInput) {      
        if (Double.isNaN(AInput)) throw new IllegalArgumentException("AInput must be a number.");  
        if (Double.isInfinite(AInput)) throw new IllegalArgumentException("AInput must not be infinite."); 
        if (AInput<=0) throw new IllegalArgumentException("A cannot be 0.");
    	A=AInput; // set A
    }
	
    /** 
     * Sets the B1 parameter of the time evolution of the SPE.
     * @param B1Input The B1 parameter. 
     */
	public void setB1(double B1Input) {
		if (Double.isNaN(B1Input)) throw new IllegalArgumentException("B1 must be a number.");
        if (Double.isInfinite(B1Input)) throw new IllegalArgumentException("B1 must not be infinite.");
        B1=B1Input; // set B1
	}
	
	/**
	 * Sets the B2 parameter of the time evolution of the SPE.
	 * @param B2Input The B2 parameter of the time evolution curve.
	 */
	public void setB2(double B2Input) {
        if (Double.isNaN(B2Input)) throw new IllegalArgumentException("B2 must be a number.");
        if (Double.isInfinite(B2Input)) throw new IllegalArgumentException("B2 must not be infinite.");
        B2=B2Input; // set B2
	}

	/**
	 * Sets the C parameter of the time evolution of the SPE. C must be set to a value at least 0.
	 * @param CInput The C parameter of the time evolution curve.
	 */
	public void setC(double CInput) {
		if (Double.isNaN(CInput)) throw new IllegalArgumentException("C must be a number.");
		if (Double.isInfinite(CInput)) throw new IllegalArgumentException("C must not be infinite.");
		if (CInput<0.0) throw new IllegalArgumentException("C must be at least 0.");
		C = CInput;
	}
	
	/**
	 * Gets the A parameter of the time evolution curve. 
	 * @return A
	 * @throws IllegalArgumentException If A is not defined
	 */
	public double getA() throws IllegalArgumentException {
		if (Double.isNaN(A)) throw new IllegalArgumentException("A is not defined.");
    	return A; 
	}
	
	/**
	 * Gets the B1 parameter of the time evolution curve. 
	 * @return B1
	 * @throws IllegalArgumentException If B1 is not defined
	 */
	public double getB1() throws IllegalArgumentException {
		if (Double.isNaN(B1)) throw new IllegalArgumentException("B1 is not defined.");
    	return B1;
	}
	
	/**
	 * Gets the B2 parameter of the time evolution curve. 
	 * @return The B2 parameter of the time evolution curve.
	 * @throws IllegalArgumentException If B2 is not defined.
	 */
	public double getB2() throws IllegalArgumentException {
		if (Double.isNaN(B2)) throw new IllegalArgumentException("B2 is not defined.");
    	return B2;
	}
	
	/**
	 * Gets the C parameter of the time evolution curve
	 * @return The C parameter of the time evolution curve.
	 * @throws IllegalArgumentException If C is not defined.
	 */
	public double getC() throws IllegalArgumentException {
		if (Double.isNaN(C)) throw new IllegalArgumentException("C is not defined.");
		return C;
	}

    /**
     * Calculates the flux of the time evolution of the SPE for a given
     * time value. The flux is calculated using the formula
     * <p><i>Flux</i>=C((t-delay)/A)<sup>B1</sup><i>e</i>-((t-delay)/A)^B2
     * <p>where C is assumed to be 1. The delay allows the event to be offset.
     * If time is less then timeDelay, 0 is returned for the radiation dose by definition. This
     * means no radiation is given before the event starts.
     * @param time The time to calculate the flux for.
     * @return The time evolution flux at a given point in time.
     * @throws IllegalArgumentException If A, B1, or B2 are not defined.
     */
    public double getFluxWithoutCWithoutGCR(Time time)
    throws IllegalArgumentException {
    	if (time.getDays() <timeDelay.getDays()) return 0; // no radiation before the event starts
    	return Math.pow(( (time.getDays()-timeDelay.getDays())/getA()),getB1())*
			Math.exp(-Math.pow(((time.getDays()-timeDelay.getDays())/getA()),getB2()));
    }
    
    /**
     * Calculates the flux of the time evolution of the SPE for a given
     * time value. The flux is calculated using the formula
     * <p><i>Flux</i>=C((t-delay)/A)<sup>B1</sup><i>e</i>-((t-delay)/A)^B2+<b>BACKGROUND</b>
     * <p>where C is not assumed to be 1 and is instead used. 
     * The delay allows the event to be offset. 
     * Background is the BACKGROUND ever present GCR radiation which will not die out, even
     * after an SPE ends. It's value is set with {@link #BACKGROUND}.
     * <p> 
     * @param time The time to calculate the flux for.
     * @return the time evolution flux at a particular time.
     * @throws If A, B1, B2, gamma, K, E0, or Emin are undefined.
     */
    public double getFluxWithCWithGCR(Time time) throws IllegalArgumentException {
    	return getC()*getFluxWithoutCWithoutGCR(time)+BACKGROUND;
    }    
    
    /**
     * Calculates the time evolution integral flux from timeMin to timeMax.
     * <p>
     * What is returned by the integral is the total number of particles 
     * of the time evolution during the specified interval (assuming C is equal to 1).
     * <p>
     * This function does <b>NOT</b> include the {@link #BACKGROUND} radiation.
     * 
     * @param timeMin The lower bound on the integral.
     * @param timeMax The upper bound on the integral.
     * @return The time evolution integral flux.
     * @throws IllegalArgumentException If A, B1, or B2 are not defined.
     */
    public double getIntegralFluxWithoutCWithoutGCR(Time timeMin, Time timeMax)
    throws IllegalArgumentException {

    	if (timeMin.getDays()<timeDelay.getDays()) timeMin = (Time)timeDelay.clone(); // no reason to find dose before t=0
    	
		if (timeMin.getDays() >= timeMax.getDays()) return 0;
		RombergIntegrator integrator = new RombergIntegrator(this);
		try{
			return integrator.integrate(timeMin.getDays(),timeMax.getDays());
		} catch (Exception e) {
			throw new IllegalArgumentException("Function not integratable: "+e.getMessage());
		}			
    }

    /**
     * Method used so that the integral can be calculated by RombergIntegrator. It returns the flux of the event at the inputted time (in days).
     * It returns the flux without C and without GCR.
     * @param timeInput The time value
     * @return The Flux at that time value (without C or GCR).
     */
    public double value(double timeInput) {
    	return getFluxWithoutCWithoutGCR(Time.inDays(timeInput));
    }

    /**
     * Holds the time delay before the event begins.
     * @param timeDelayInput The time delay.
     * @throws IllegalArgumentException If the time delay is less then 0.
     */
    public void setTimeDelay(Time timeDelayInput) throws IllegalArgumentException {
    	if (timeDelayInput == null) throw new IllegalArgumentException("The time delay between events must have a value");
    	if (timeDelayInput.getDays() < 0 ) throw new IllegalArgumentException("The time delay between events must be greater then or equal to 0 days.");
    	this.timeDelay = (Time)timeDelayInput.clone();
    }

    /**
     * Returns the time delay before the event begins.
     * @return The time delay before the event begins.
     * @throws IllegalArgumentException If the time delay has not been defined yet.
     */    
     public Time getTimeDelay() throws IllegalArgumentException {
     	if (this.timeDelay == null) throw new IllegalArgumentException("The time delay has not been set yet");
     	return this.timeDelay;
     }	
}
