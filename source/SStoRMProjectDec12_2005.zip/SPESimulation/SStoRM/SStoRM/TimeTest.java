package SStoRM;


import junit.framework.TestCase;

/**
 * This class does some fun little testing of the time object
 * @author Joshua Lande
 */

public class TimeTest extends TestCase {

	
	public void testClone() {
		Time time1 = Time.inSeconds(10);
		Time time2 = (Time)time1.clone();
		time1.setSeconds(0); // change time 1, time2 still is 10 seconds.
		AssertMore.assertEquals( time2, Time.inSeconds(10));
		
		

		time1 = Time.inSeconds(20);
		time2 = (Time)time1.clone();
		AssertMore.assertEquals( time1, time2);
		time1.setSeconds(10); // change time 1, time2 still is 10 seconds.
		AssertMore.assertNotEquals( time1, time2);
		
	}
	
	public void testAddSubtractStaticMethods() {
		AssertMore.assertEquals(Time.inHours(30), Time.add(Time.inHours(20),Time.inHours(10)));
		AssertMore.assertEquals(Time.inMinutes(10), Time.add(Time.inSeconds(60),Time.inSeconds(60*9)));
		AssertMore.assertEquals(Time.inHours(10), Time.subtract(Time.inHours(20),Time.inHours(10)));
		AssertMore.assertEquals(Time.inMinutes(8), Time.subtract(Time.inSeconds(60*9),Time.inSeconds(60)));
		
	}
	
	
	public void testTurnNegative() {
		Time time;
		
		time= Time.inSeconds(10);
		time.negative();
		AssertMore.assertEquals( time, Time.inSeconds(-10));
		
		time = Time.inHours(-5);
		time.negative();
		AssertMore.assertEquals( time, Time.inHours(5));
		
		// the alternative syntax
		AssertMore.assertEquals( Time.negative(Time.inHours(10)), Time.inHours(-10));
		AssertMore.assertEquals( Time.negative(Time.inHours(-5)), Time.inHours(5));
		
	}
	
	public void testSetAndGetMinutes() {
		Time sixtyMinutes=new Time();
		sixtyMinutes.setMinutes(60.0);
		AssertMore.assertEquals(sixtyMinutes.getMinutes(), 60.0);
		AssertMore.assertNotEquals(sixtyMinutes.getMinutes(), 50.0);

		sixtyMinutes.setMinutes(-60.0);
		AssertMore.assertEquals(sixtyMinutes.getMinutes(), -60.0);
		AssertMore.assertNotEquals(sixtyMinutes.getMinutes(), -50.0);

		try { 
			sixtyMinutes.setMinutes(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			sixtyMinutes.setMinutes(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}
	
	public void testStaticFunctions() {

		try { 
			Time.inSeconds(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			Time.inSeconds(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		try { 
			Time.inMinutes(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Time.inMinutes(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		try { 
			Time.inHours(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Time.inHours(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try { 
			Time.inDays(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Time.inDays(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		
		
		Time time=new Time();
		time.setHours(24.0);
		AssertMore.assertEquals(time,Time.inSeconds(60*60*24));
		AssertMore.assertEquals(time,Time.inMinutes(60*24));
		AssertMore.assertEquals(time,Time.inHours(24));
		AssertMore.assertEquals(time,Time.inDays(1));
		

		time.setHours(-24.0);
		AssertMore.assertEquals(time,Time.inSeconds(-60*60*24));
		AssertMore.assertEquals(time,Time.inMinutes(-60*24));
		AssertMore.assertEquals(time,Time.inHours(-24));
		AssertMore.assertEquals(time,Time.inDays(-1));
		
	}
	public void testSetAndGetHours() {
		Time twentyHours=new Time();
		twentyHours.setHours(20.0);
		
		AssertMore.assertEquals(twentyHours.getHours(), 20.0);
		AssertMore.assertNotEquals(twentyHours.getHours(), 5.0);
		
		try { // Call should throw an error
			twentyHours.setHours(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			twentyHours.setHours(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		

		twentyHours.setHours(-20.0);
		
		AssertMore.assertEquals(twentyHours.getHours(), -20.0);
		AssertMore.assertNotEquals(twentyHours.getHours(), -5.0);
	}
	
	public void testSetAndGetDays() {
		Time fiveDays=new Time();
		fiveDays.setDays(5.0);
		AssertMore.assertEquals(fiveDays.getDays(),5);
		AssertMore.assertNotEquals(fiveDays.getDays(),3.0);

		try { // Call should throw an error
			fiveDays.setDays(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			fiveDays.setDays(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testUnitConversions() {
		AssertMore.assertEquals(Time.inDays(1.0),Time.inHours(24.0));
		AssertMore.assertEquals(Time.inMinutes(60*24),Time.inDays(1.0));
		AssertMore.assertNotEquals(Time.inSeconds(59.9),Time.inMinutes(1.0));
		AssertMore.assertEquals(Time.inHours(.5),Time.inMinutes(30));
		AssertMore.assertEquals(Time.inDays(2),Time.inSeconds(60*60*24*2));
	}


	public void testResetTime() {
		Time time=Time.inSeconds(1.0);
		AssertMore.assertEquals(Time.inSeconds(1.0),time);
		
		time.reset();
		assertTrue(time.equals(Time.inSeconds(0.0)));
		AssertMore.assertNotEquals(Time.inSeconds(0.1),time);
	}
	
	public void testAdd() {
		Time time=Time.inDays(1);
		time.addDays(2);
		AssertMore.assertEquals(Time.inDays(3),time);
		time.addDays(2);
		AssertMore.assertNotEquals( Time.inDays(3),time);
		AssertMore.assertEquals( Time.inDays(5),time);
		
		time = Time.inSeconds(60*60*24*2.5);
		time.addDays(4);
		AssertMore.assertEquals(Time.inHours(6.5*24),time);
		

		try { // Call should throw an error
			time.addDays(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { // Call should throw an error
			time.addDays(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testSet() {
		Time time=Time.inDays(4);
		AssertMore.assertNotEquals(Time.inDays(2),time);
		time.setDays(2);
		AssertMore.assertEquals(Time.inDays(2),time);
		time.setHours(2);
		AssertMore.assertEquals(Time.inHours(2),time);
		time.setSeconds(60);
		AssertMore.assertEquals(Time.inMinutes(1),time);

	}
	
}
