
package SStoRM;
/**
 * This class represents a Solar Particle Event (SPE). It uses the
 * exponential curve <i>Fluence</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>
 * E/Eo</sup> to represent the energy spectrum. The energy spectrum
 * represents the total number of particles at a given energy value as a function
 * of that energy value. It is essentially a frequency distribution. 
 * The integral of the energy spectrum is the
 * total number of particles of the SPE. The lower bounds of the integral 
 * (Emin) allows for the calculation of the total number of particles
 * above a certain energy value. The energy spectrum is internally stored inside a {@link EnergySpectrum} object.
 * <p>
 * The energy spectrum integral fluence and the K constant are intimately related. We can show that:
 * <pre>
 * K = (> Emin) integral fluence / (>Emin) integral fluence without K
 * </pre>
 * Where the energy spectrum integral fluence without K is found using specific E0 and gamma values. This means that
 * if the (>Emin) integral fluence (with K) is specified, K can be found from it. This class
 * allows for either K or the integral fluence to be specified, and the other to be calculated automatically behind the scenes.
 * <p>
 * This class also uses the curve 
 * <i>Flux</i>=C(t/A)<sup>B1</sup><i>e</i><sup>-(t/A)^B2</sup>
 * to represent the time evolution of the SPE. The time evolution 
 * is a function of the total number of particles over the duration of the event.
 * The time evolution is stored in a {@link TimeEvolution} object. 
 * The integral time evolution flux is also the total number of particles. 
 * So C can be set automatically (as this class automatically does) so that 
 * the >10 MeV energy spectrum integral fluence equal the time evolution graph's
 * integral flux. This is done with the formula:
 * <pre>
 * C = (>10 MeV) energy spectrum integral fluence/(time evolution integral flux from 0 to 10 days * 24*3600*4*pi)
 * </pre>
 * This formula can be derived by equating the two integrals. The 24*3600 accounts for a conversion from days to
 * seconds and the 4*pi accounts for 4*pi steradians in free space. 
 * <p>
 * <b>Usage:</b>
 * <p>
 * You can create SPEs by saying:
 * <pre>
 * 	SolarParticleEvent SPE=new SolarParticleEvent("SPE Name");
 * </pre>
 * You can then specify the shape of the energy spectrum by
 * setting the K, gamma, and E0 values.
 * <pre>
 * SPE.setK(1e9);
 * SPE.setGamma(0);
 * SPE.setE0(30);
 * SPE.setEmin(50);
 * </pre>
 * This sets the energy spectrum of the event. The integral fluence above
 * the Emin value can be calculated by saying:
 * <pre>
 * integralFluence=SPE.getEnergySpectrumIntegralFluence();
 * </pre>
 * If you know what the integral fluence should be and know what the spectral shape of the event is,
 * you can specify the SPE without giving a K and K is automatically calculated so that the integral fluence
 * is set right.
 * <pre>
 * SolarParticleEvent SPE=new SolarParticleEvent("SPE Name");
 * SPE.setEmin(30);
 * SPE.setEnergySpectrumIntegralFluence(1.88E10); 
 * SPE.setGamma(0);
 * SPE.setE0(30);
 * K = SPE.getK(); // returns the computed value of K based on the spectral shape and energy spectrum
 * </pre>
 * <p>You can then set the time evolution of the SPE by saying:
 * <pre>
 * SPE.setA(.15);
 * SPE.setB1(2);
 * SPE.setB2(1);
 * </pre>
 * <p>The scaling factor (C) can now automatically be retrieved by saying
 * <pre>
 * SPE.getC();
 * </pre>
 * As a note, the following constraints are enforced:
 * <p>
 * K must be at least 0. Emin must be at least 10 and at most 1500. Gamma must be at least 0 and at most
 * 4.125. E0 must be at least 10 and at most 1500. If the energy spectrum integral fluence is set, it must
 * be at least 0.
 * @author Joshua Lande
 */
public class SolarParticleEvent implements Comparable, SolarParticleEventInterface  {

	
	
	/**
	 * Object that holds all of the radiation dose values for a solar particle event.
	 * We can call methods on it to get out the doses.
	 * <b>
	 * This object is incredibly memory intensive
	 * because it has to read in and hold over 2 meg
	 * of information about the solar particle event radiation doses.
	 * So, it will only be created when you explicitly 
	 * ask for a solar particle event's radiation dose.
	 * That way, if doses are not desired, it will not
	 * be necessary to load one into memory.
	 * </b>
	 */
	private RadiationDoseValues radiationDoseValues;
	
    /**
     * The name of the solar particle event.
     * <p>
     * To modify, see {@link #setName} and {@link #getName}. 
     */
	private String name="";

	/**
	 * Holds the time evolution of the solar particle event.
	 */
    TimeEvolution timeEvolution = new TimeEvolution();
    
    /**
     * Holds the energy spectrum of the solar particle event.
     */
    EnergySpectrum energySpectrum = new EnergySpectrum();
    
    /**
     * Tries to set a value for C.
     * C is calculated so that the integral fluence of the energy spectrum
     * equals the integral flux of the time evolution curve. 
     * <p>
     * C is calculated this way so that the total number of particles
     * from the energy spectrum (the integral fluence) and the total number of
     * particles from the time evolution (the integral flux) are the same. 
     * This ensure that the 2 SPE curves are really talking
     * about the same event.
     * <p>
     * The formula used is C = the >10 MeV integral fluence of the energy spectrum divided
     * by the Integral flux of the time evolution of the event (from 0 to 10 days)
     * and then again by 4 days worth of seconds * 4 pi steradians.
     * <p>
     * If C cannot be set (for example, some parameters are not yet initialized), nothing happens
     * and the function returns with no change. C is not set at all.
     */
    private void attemptToResetC() {
    	try {
    		timeEvolution.setC(
    				energySpectrum.getIntegralFluence(10.0) // Cache new C value
    				/(timeEvolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0.0),Time.inDays(10.0))*24*3600*4*Math.PI)
			);
    	} catch (Exception e) { }
    }
    
	/**
	 * Tests whether 2 SPEs are equal. They are only equal if gamma, E0
	 * K, Emin, A, B1, and B2 are defined and set to the same value.
	 * The name dose not necessarily need to be the same.
	 */
	public boolean equals(Object anObject){
		if (anObject instanceof SolarParticleEvent) {
			try {
				SolarParticleEvent otherEvent= (SolarParticleEvent)anObject;
		    	return  (
		    			(this.timeEvolution.equals(otherEvent.timeEvolution) &&
		    			 this.energySpectrum.equals(otherEvent.energySpectrum))					
		    	);
			} catch (Exception exception) {}
		}	
		return false;
	}
	
	/**
	 * Performs the expected clone of a SolarParticleEvent.
	 */
	public Object clone() {   
       	try {
            SolarParticleEvent newEvent = new SolarParticleEvent(this.getName());
       		newEvent.energySpectrum = (EnergySpectrum)this.energySpectrum.clone();
       		newEvent.timeEvolution = (TimeEvolution)this.timeEvolution.clone();
       		return newEvent;
       	} catch (Exception exception) {
			return null;
		}
    }	
	    
    /** 
     * compares a SolarParticleEventInterface to another SolarParticleEventInterface
     * based on the value of their energy spectrum integral fluence. T
     * <p>
     * If, for any reason, the integral fluence cannot be calculated 
     * (for example any E,E0,gamma, or Emin is not defined) 0 is returned by default
     * <p>
     * This function is weird in how it sorts but
     *  useful because it lets you sort an array of SPEs based on energy spectrum integral fluences.
     * All you have to say is:
     * <pre>
     * 	sort(SPEArray); // sorts in ascending order</pre> 
     * 
     * @param otherObject Another object of the same type to compare
     * 
     * @return 
     * <p>
     * <code> 1</code> If the SPE of the current object has a higher
     * integral fluence then the SPE of the inputted object.
     * <p>
     * <code>-1</code> If the SPE of the inputted object has a
     * higher integral fluence then the SPE of the current object.
     * 			
     * <p><code> 0</code> If the two SPEs have the same integral fluence,
     * or, for whatever reason, the integral fluence cannot be calculated.
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object) 
     */
    public int compareTo(Object otherObject) {
        SolarParticleEventInterface RHS=(SolarParticleEventInterface)otherObject;
        try{
        	if(this.getEnergySpectrumIntegralFluence()<RHS.getEnergySpectrumIntegralFluence())
        		return -1;
        	if (this.getEnergySpectrumIntegralFluence()>RHS.getEnergySpectrumIntegralFluence())
        		return 1;
        	return 0;
        } catch (IllegalArgumentException exception) {
        	return 0;// if the fluence cannot be calculated, return 0        	
        }
	}

    /**
     * Constructor that does nothing.
     */
    public SolarParticleEvent() {}
    
    /**
     * Constructor that sets the name of the SPE but nothing else.
     * @param name The name of the SPE.
     */
    public SolarParticleEvent(String name) {
    	setName(name);
    }
    
    /**
     * Constructor that sets the energy spectrum,
     * Emin value, and name of the event.
     * @param KInput The K parameter.
     * @param gammaInput The gamma parameter.
     * @param E0Input The E0 parameter.
     * @param nameInput The name parameter.
     * @throws 	IllegalArgumentException if KInput, gammaInput, or E0Input are not valid.
     */
    public SolarParticleEvent(double KInput,double gammaInput, double E0Input,
    		String nameInput) throws IllegalArgumentException {
    	setSPE(KInput,gammaInput,E0Input, nameInput);
    }

    /**
     * Sets the energy spectrum and name of the SPE.
     * @param KInput The K parameter.
     * @param gammaInput The gamma parameter.
     * @param E0Input The E0 parameter.
     * @param nameInput The name parameter.
     * @throws 	IllegalArgumentException if KInput, gammaInput, or E0Input are not valid.
     */
    public void setSPE(double KInput,double gammaInput, double E0Input, String nameInput) throws IllegalArgumentException {
        setK(KInput);
        setE0(E0Input);
        setGamma(gammaInput);
        setName(nameInput);
    }

    /**
     * Same as {@link #setSPE(double, double, double, String)} but dosn't set the name.
     * @param KInput
     * @param gammaInput
     * @param E0Input
     * @throws IllegalArgumentException
     */
    public void setSPE(double KInput,double gammaInput, double E0Input ) throws IllegalArgumentException {
        setK(KInput);
        setE0(E0Input);
        setGamma(gammaInput);
    }    
    
    /**
     * Sets the Emin value. Emin is the lower bounds of the integral of the energy 
     * spectrum. Emin will only be set if
     * it is at least 10 and at most 1500. 
     * @param EminInput The new minimum energy value to integrate from.
     * @throws IllegalArgumentException If EminInput is smaller then 10, larger then 1500, or not a number.
     */
    public void setEmin(double EminInput) throws IllegalArgumentException {
        energySpectrum.setEmin(EminInput); // set Emin
        attemptToResetC();
    }

    /** 
     * Sets the E0 parameter of the energy spectrum to E0Input. It is set only if
     * E0Input is at least 10 and at most 500. 
     * @param E0Input
     * @throws IllegalArgumentException If E0Input is less 10 or greater then 500.
     */
    public void setE0(double E0Input) throws IllegalArgumentException {
       energySpectrum.setE0(E0Input);
       attemptToResetC();
    }

    /** 
     * Sets the gamma parameter of the energy spectrum. It is set only if
     * gammaInput is at least 0 and at most 4.125. 
     * @param gammaInput
     * @throws IllegalArgumentException If gammaInput is less 0 or greater then 4.125.
     */
    public void setGamma(double gammaInput) throws IllegalArgumentException { 
        energySpectrum.setGamma(gammaInput);
        attemptToResetC();
    }    

    /** 
     * Sets the name of the SPE.
     * @param nameInput The name of the SPE.
     */
    public void setName(String nameInput) throws IllegalArgumentException {
    	if (nameInput == null) throw new IllegalArgumentException("The name must not be null."); 
		name=nameInput;
    }
    
    /** 
     * Sets the K parameter of the energy spectrum. K is only set if it is at least 0.
     * By setting K, it is assumed that the energy spectrum integral fluence should be 
     * calculated automatically.
     * @param KInput The K value to set
     * @throws IllegalArgumentException If KInput is less then 0.
     */
    public void setK(double KInput) throws IllegalArgumentException {
    	energySpectrum.setK(KInput);        
    	 attemptToResetC();
    }	
    
    /**
     * Sets the > Emin energySpectrumIntegralFluence. When this is set, K is assumed to be calculated
     * automatically.
     * @param integralFluenceInput The integral fluence to set.
     * @throws IllegalArgumentException If the integral fluence is smaller then 0.
     */
    public void setEnergySpectrumIntegralFluence(double integralFluenceInput) throws IllegalArgumentException {
        energySpectrum.setIntegralFluence(integralFluenceInput);
        attemptToResetC();
    }	
 
    /**
     * Calculates the energy spectrum fluence for the SPE at any given
     * energy value over 0. It includes the K value.
     * <p>
     * <i>Fluence</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>E/Eo</sup>
     * @param EInput The energy value.
     * @return The fluence value for a given energy value.
     * @throws IllegalArgumentException If K, gamma, or E0 are not defined or
     * if EInput is less then or equal to 0.
     */
    public double getEnergySpectrumFluence(double EInput) throws IllegalArgumentException {
        return energySpectrum.getFluence(EInput);
    }
   
  	/**
  	 * Returns the energy spectrum integral fluence.
  	 * If the energy spectrum integral fluence is set explicity, that value is returned.
  	 * Otherwise, this function calculates the energy spectrum integral fluence numerically using the specified K value. 
  	 * Emin must have been previously set by an explicity call to {@link #setEmin}. 
  	 * <p>
  	 * What is returned is the total number of particles with energy values
  	 * above Emin.
  	 * @return The energy spectrum integral fluence.
  	 * @throws IllegalArgumentException If any of the parameters of the energy spectrum are 
  	 * not specified.
  	 */
    public double getEnergySpectrumIntegralFluence() throws IllegalArgumentException {
    	return energySpectrum.getIntegralFluence();
    }
    
    /** 
     * Does the actual numeric integration of the energy spectrum integral 
     * fluence from the inputted Emin value to 1500 (basically infinity). The integral fluence is 
     * calculated using trapezoid approximations.
     * @param EminInput The lower bound of the integral.
     * @return The energy spectrum integral fluence.
     * @throws IllegalArgumentException If EminInput is less then 10 or if E0 is not defined.
     */
    public double getEnergySpectrumIntegralFluence(double EminInput) throws IllegalArgumentException {
    	return energySpectrum.getIntegralFluence(EminInput);
    }
    
    /**
     * Returns the K parameter of the energy spectrum of the SPE. If K has been set explicitly,
     * that value is returned. Otherwise, K is calculated automatically using the formula
     * <pre>
     * 	K = inputted integral fluence / calculated integral fluence without K
     * </pre> 
     * @return K
     * @throws IllegalArgumentException If K is not defined.
     */
    public double getK() throws IllegalArgumentException {
    	return energySpectrum.getK();
    }
      
    /**
     * Sets the A parameter of the time evolution of the SPE. It
     * cannot be 0 because this would lead to division by 0 (bad).
     * @param AInput The A parameter.
     */
    public void setA(double AInput) {      
    	timeEvolution.setA(AInput);
    	 attemptToResetC();
	}
	
    /** 
     * Sets the B1 parameter of the time evolution of the SPE.
     * @param B1Input The B1 parameter. 
     */
	public void setB1(double B1Input) {
		timeEvolution.setB1(B1Input);
		attemptToResetC();
	}
	
	/**
	 * Sets the B2 parameter of the time evolution of the SPE.
	 * @param B2Input The B2 parameter.
	 */
	public void setB2(double B2Input) {
        timeEvolution.setB2(B2Input);
        attemptToResetC();
	}

	/**
	 * Gets the A parameter of the time evolution curve. 
	 * @return The value of A.
	 * @throws IllegalArgumentException If A is not defined.
	 */
	public double getA() throws IllegalArgumentException {
		return timeEvolution.getA();
	}
	
	/**
	 * Gets the B1 parameter of the time evolution curve. 
	 * @return The value of B1.
	 * @throws IllegalArgumentException If B1 is not defined.
	 */
	public double getB1() throws IllegalArgumentException {
		return timeEvolution.getB1();
	}
	
	/**
	 * Gets the B2 parameter of the time evolution curve. 
	 * @return The value of B2.
	 * @throws IllegalArgumentException If B2 is not defined.
	 */
	public double getB2() throws IllegalArgumentException {
		return timeEvolution.getB2();
	}
	
	/**
	 * Gets the Emin value of the SPE.
	 * @return The value of Emin.
	 * @throws IllegalArgumentException If Emin is not defined.
	 */
    public double getEmin() throws IllegalArgumentException {
    	return energySpectrum.getEmin();
    }
    
    /**
     * Gets the gamma parameter of the energy spectrum of the SPE.
     * @return The gamma value.
     * @throws IllegalArgumentException If gamma is not defined.
     */
    public double getGamma() throws IllegalArgumentException {
        return energySpectrum.getGamma();
    }    
    
    /**
     * Gets the E0 parameter of the energy spectrum of the SPE.
     * @return The E0 value.
     * @throws IllegalArgumentException If E0 is not defined.
     */
    public double getE0() throws IllegalArgumentException {
    	return energySpectrum.getE0();
    }
  
    /**
     * Gets the name of the SPE.
     * @return the name of the SPE.
     */
    public String getName() {
        return name;
    }
   
    /**
     * Calculates the flux of the time evolution of the SPE for a given
     * time value. The flux is calculated using the formula
     * <p><i>Flux</i>=C(t/A)<sup>B1</sup><i>e</i>-(t/A)^B2
     * <p>where C is assumed to be 1.
     * If time is less then 0, 0 is returned. This
     * means that no radiation is given before the event starts.
     * @param timeInput The time to calculate the flux with.
     * @return The time evolution flux at the given point in time.
     * @throws IllegalArgumentException If A, B1, or B2 are not defined.
     */
    public double getTimeEvolutionFluxWithoutCWithoutGCR(Time timeInput)
    throws IllegalArgumentException {
    	return timeEvolution.getFluxWithoutCWithoutGCR(timeInput);
    }
    
    /**
     * Calculates the flux of the time evolution of the SPE for a given
     * time value. The flux is calculated using the formula
     * <p><i>Flux</i>=C(t/A)<sup>B1</sup><i>e</i>-(t/A)^B2+<b>BACKGROUND</b>
     * <p>where C is taken from the function {@link #getC}.
     * C is set automatically such that the time evolution integral flux is equal to
     * the energy spectrum integral flux.  
     * C is calculated this way so that the total number of particles
     * from the energy spectrum (the integral fluence) and the total number of
     * particles from the time evolution (the integral flux) are the same. 
     * This ensure that the 2 separate SPE curves are really talking about the same event.
     * BACKGROUND is the background ever present GCR radiation. 
     * It's value is set with {@link TimeEvolution#BACKGROUND}.
     * The flux with C and the GCR at the inputted time value is returned.<p>
     *
     * @param timeInput The time to find the flux for.
     * @return the time evolution flux at a particular time.
     * @throws If A, B1, B2, gamma, K, E0, or Emin are undefined.
     */
    public double getTimeEvolutionFluxWithCWithGCR(Time timeInput) throws IllegalArgumentException {
    	return timeEvolution.getFluxWithCWithGCR(timeInput);
    }    
    
    /**
     * Calculates the time evolution integral flux from timeMin to timeMax
     * The integral flux is calculated by integrating the time
     * evolution equation with trapezoid approximations. Each trapezoid
     * has a width of timeStep. timeMin and timeMax are the bounds of the integral.
     * <p>
     * What is returned by the integral is the total number of particles 
     * released over the 10 days of the event (assuming C is equal to 1).
     * <p>
     * This function does <b>NOT</b> include the {@link TimeEvolution#BACKGROUND} radiation.
     * 
     * @param timeMin The lower bound on the integral.
     * @param timeMax The upper bound on the integral.
     * @return The time evolution integral flux.
     * @throws IllegalArgumentException If A, B1, or B2 are not defined.
     */
    public double getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time timeMin, Time timeMax)
    throws IllegalArgumentException {
    	return timeEvolution.getIntegralFluxWithoutCWithoutGCR(timeMin,timeMax);
    }

    /** 
     * Decides whether or not the time evolution integral flux decreases fast enough.
     * The time evolution is considered to decrease fast enough if the total number of
     * particles (time evolution integral flux)
     * during the 6th day is less then 1/100th of the total number of particles
     * from the first 5 days.
     * @return <code>true</code> if the number of particles from the sixth day is less then
     * 1/100th the number of particles from the first five days. <code>false</code> otherwise.
     */
    public boolean doesTimeEvolutionIntegralFluxDecreaseFastEnough() {
    	double firstFiveDays=getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5));
    	double sixthDay=getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6));
    	if (sixthDay<.01*firstFiveDays) return true;
    	return false;
    }
    
    /**
     * This function decides if the SPE is sufficiently 'large'. The criteria for an SPE being
     * "large" is that at any point in time from 0 to 10 days the flux (including C)
     * is larger then the BACKGROUND radiation. If, at some point in time, the flux (including C)
     * is larger then the BACKGROUND radiation, true is returned. Otherwise, false is returned.
     * <p>
     * This is useful as a warning for the user. If this returns false, you know to warn the user
     * to make K or the energy spectrum integral fluence bigger (to increase the size of the SPE).
     * @return <code>true</code> if the time evolution flux (including C) is larger then the BACKGROUND
     * radiation at any point in time during the SPE. <code>false</code> otherwise.
     */
     public boolean isEventLargeEnough() {
        Time timeMin=Time.inDays(0);
        Time timeMax=Time.inDays(10);
        Time timeStep=Time.inDays(0.1);
    	for(Time time=(Time)timeMin.clone();time.getDays()<timeMax.getDays();time.add(timeStep)) 
		    if (getC()*getTimeEvolutionFluxWithoutCWithoutGCR(time) > TimeEvolution.BACKGROUND) return true;
		return false;
     }
     
    /**
     * Returns the value of C, the final parameter of the time evolution curve.
     * This is calculated automatically so that the integral fluence of the energy spectrum
     * equals the integral flux of the time evolution curve. 
     * @return The value of C.
     * @throws IllegalArgumentException if gamma, E0, K, A, B1, B2, or C
     * are not defined.
     */
    public double getC() throws IllegalArgumentException {
    	return timeEvolution.getC();
    }
 
    /**
     * Returns the dose that an astronaut would receive from the SPE. The does is returned based on
     * an input thickness to the Skin Eye or BFO. This method can return dose equivalent (RAD) or absorbed dose
     * (REM) in free space or lunar surface. Dose on the lunar surface is 1/2 the dose in free space
     * because the moon blocks out half the radiation dose.
     * @param thickness The thickness under which the dose is required.
     * @param remOrRad REM (dose equivalent) or RAD (absorbed dose).
     * @param skinEyeOrBFO Specifies dose to the skin, eye, or BFO.
     * @param lunarSurfaceOrFreeSpace Specifies dose on the lunar surface or dose in free space.
     * @return The desired dose.
     * @throws IllegalArgumentException If any of K, gamma, or E0 are not specified.
     */
    public double getDose(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO,
    		DoseLocation lunarSurfaceOrFreeSpace)  throws IllegalArgumentException {
    	
    	if (radiationDoseValues==null) radiationDoseValues=new RadiationDoseValues();
    	
    	double dose=radiationDoseValues.getDose(getK(),getGamma(),getE0(),thickness,remOrRad,skinEyeOrBFO);
    	
    	if (lunarSurfaceOrFreeSpace == DoseLocation.LUNAR_SURFACE) return dose/2;   	
    	return dose;
    	
    }
    
    /**
     * This method simulates a man on the moon during a solar particle event. To do this we must be able
     * to find the dose received by a person on the lunar surface during any period of time during the event.
     * To calculate the dose that a person received under a given thickness x with a given total dose Dose<sub>x</sub>,
     * we use the formula:
     * <pre>
     *	C<sub>x</sub> = Dose<sub>x</sub> / The integral of the time evolution flux from 0 to 10 days.
     * </pre>
     * This essentially creates a new C for the time evolution curve such that if we now integrate form 0 to 10 days,
     * we get the total dose. Now, the dose from T<sub>start</sub> to T<sub>stop</sub> is:
     * <pre>
     * 	Dose = C<sub>x</sub>*The integral of the time evolution flux without C from T<sub>start</sub> to T<sub>stop</sub>.
     * </pre>
     * Therefore, when we want to simulate an astronaut on the moon under different thicknesses, we first calculate
     * new Cs for all thicknesses desired. We then integrate for the desired time periods with the desired Cs to
     * figure out all the individual doses during the event. The sum of them is the total dose received by an
     * astronaut.     
     * @param remOrRad rem (dose equivalent) or rad (absorbed dose).
     * @param skinEyeOrBFO Specifies dose to the skin, eye, or BFO.
     * @param priorToWarning The amount of time before the beginning of the SPE that the astronaut is given warning
     * that the event is about to happen. A negative value implies the time <b>AFTER</b> the event has begun
     * before he is given warning about the event.
     * @param thicknessPriorToWarning The thickness the astronaut is under during the time prior to warning.
     * @param packingUp The time it takes him to pack up and enter the rover.
     * @param thicknessPackingUp The thickness he is under when he packs up and enters the rover.
     * @param transitToBase The time it takes him to drive back to the base.
     * @param thicknessTransitToBase The thickness he is under when he drives back to the base.
     * @param thicknessAtBase The thickness he is under at the base until the end of the event (Until 10 days ends).
     * @param cumulativeDoseGraph A graph holding the cumulative dose over time.
     * @return An object holding all desired information. This includes doses and percents of total
     *  during different stages of the event. It also includes
     * the total dose the astronaut received and the ratio of total dose to dose under shelter the whole time.
     * @throws IllegalArgumentException If the SPE is undefined. If the time to pack up and enter the rover
     * or the time it takes to drive back to the base is less then 0 hours. If the entire time it takes to get back
     * to the base is greater then 10 days.
     */
    public DoseInformation simulateAstronautOnTheMoon(RadiationType remOrRad,BodyPart skinEyeOrBFO,
    		Time priorToWarning, Thickness thicknessPriorToWarning, Time packingUp, Thickness thicknessPackingUp,
			Time transitToBase, Thickness thicknessTransitToBase, Thickness thicknessAtBase,
			CumulativeDoseGraph cumulativeDoseGraph) throws IllegalArgumentException {
    	
		if (packingUp.getDays() < 0)
			throw new IllegalArgumentException("The time it takes to pack up must be >= 0.");
		if (transitToBase.getDays() < 0) 
			throw new IllegalArgumentException("The time it takes to return to the base must be >= 0");
			
		Time lengthOfEvent = Time.inDays(10); 
		
		// total time of simulation must be less then or equal to 10 days.
    	if ((-1*priorToWarning.getDays()+packingUp.getDays()+transitToBase.getDays())> lengthOfEvent.getDays())
			throw new IllegalArgumentException("The arrival time at the base must be at most 10 days");
 
		// total time evolution flux is the time evolution flux without C from 0 to 10 days
    	double timeEvolutionIntegralFlux=this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),lengthOfEvent);
    	
    	// calculate all the C values
    	double CPriorToOnset=this.getDose(thicknessPriorToWarning,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux;
    	double CPackingUp=this.getDose(thicknessPackingUp,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux;
    	double CTransitToBase=this.getDose(thicknessTransitToBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux;
    	double CAtBase=this.getDose(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux;
    	

		// throw all calculated values into an object to return.
    	DoseInformation doseInformation = new DoseInformation();
    	
    	
    	// the current time starts at the negative of the time prior to warning.
    	Time currentTime = Time.negative ((Time)priorToWarning.clone());
    	Time timeStepForGraph = Time.inDays(.1); // every twenty minutes
    	
    	
    	cumulativeDoseGraph.reset(remOrRad, skinEyeOrBFO);
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Warning");
    	double dose;
    	double cumulativeDose = 0;
    	
    	
    	for (Time loop = Time.inDays(0); loop.getDays()< currentTime.getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > currentTime.getDays()) 
    			nextTimeInterval = (Time)currentTime.clone();
    		
    		dose=CPriorToOnset*
				this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
    	// calculate the dose received by the astronaut prior to warning by integrating with the correct C from 0 to the current time.
    	doseInformation.dosePriorToWarning=CPriorToOnset*
			this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),currentTime);
    	    	
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.add(currentTime,packingUp).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.add(currentTime,packingUp).getDays()) 
    			nextTimeInterval = Time.add(currentTime,packingUp);
    	
    		dose=CPackingUp*
				this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
    	// calculate the dose received by the astronaut while packing up by integrating with the correct C from the current time for the amount of time packing up
    	doseInformation.doseWhilePackingUp=CPackingUp*
			this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(currentTime,Time.add(currentTime,packingUp));
    	
    	currentTime.add(packingUp); // advance the current time
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Rover");
    	
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.add(currentTime,transitToBase).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.add(currentTime,transitToBase).getDays()) 
    			nextTimeInterval = Time.add(currentTime,transitToBase);
    		
    		dose=CTransitToBase*
				this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
    	// Calculate the dose received by the astronaut while in transit by integrating with the correct C from an advanced current time for the amount of time in transit.
    	doseInformation.doseDuringTransit=CTransitToBase*
			this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(currentTime,Time.add(currentTime,transitToBase));
    	    	
    	currentTime.add(transitToBase); // advance the current time
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Base");
    	
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.inDays(10).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.inDays(10).getDays())
    			nextTimeInterval = Time.inDays(10);
    		
    		dose=CAtBase*
				this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		

    	// Calculate the dose received by the astronaut in base by integrating with the correct C from an advanced current time to the end of the even (10 days)
    	doseInformation.doseAtBase=CAtBase*
			this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(currentTime, lengthOfEvent);
    	
    	// the total time exposed at the base is 10 - the current time (when you get to the base)
    	doseInformation.timeExposedInBase=Time.subtract( lengthOfEvent , currentTime);
    	
    	// the total dose is the sum of all other doses.
    	doseInformation.totalDoseAwayFromShelter=
    		doseInformation.dosePriorToWarning + doseInformation.doseWhilePackingUp +
			doseInformation.doseDuringTransit + doseInformation.doseAtBase;
    	
    	// the ratio higher then always at the base is the total dose away / the total dose at the base
    	doseInformation.ratioHigherThenAlwaysAtBase=doseInformation.totalDoseAwayFromShelter/
			this.getDose(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE);
    	
    	doseInformation.percentOfTotalPriorToWarning=
    		100*doseInformation.dosePriorToWarning/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalWhilePackingUp=
    		100*doseInformation.doseWhilePackingUp/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalDuringTransit=
    		100*doseInformation.doseDuringTransit/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalAtBase=
    		100*doseInformation.doseAtBase/doseInformation.totalDoseAwayFromShelter;
    	    	
    	return doseInformation; // return everything to the user
    }
}