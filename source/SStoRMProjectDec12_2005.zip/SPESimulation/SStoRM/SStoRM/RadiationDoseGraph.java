package SStoRM;

import java.awt.Color;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 * This object uses a bar graph to graph radiation doses to different body parts under different 
 * thicknesses. It graphs doses
 * to the skin, eye, and BFO under a thickness of .3, 1, 5, 10, and 30 g/cm2. The trickiest part of this object
 * is the function
 * {@link RadiationDoseGraph#setDoses(Object, RadiationType, DoseLocation)}. It must be given an SPE to graph the doses of. It must also
 * be told
 * whether the doses being graphed are absorbed dose (RAD) or dose equivalent (REM) and whether they are 
 * on the lunar surface or free space. It then pulls all of the doses out of the SPE object and graphs them.
 * <p>
 * <b>USAGE:</b>
 * <pre>
 *	SolarParticleEvent yourSPE = new SolarParticleEvent(1e9,0,30,"yourSPE");
 *	RadiationDoseGraph graph=new RadiationDoseGraph(); // create the object. 
 *	graph.setDoses(yourSPE, RadiationType.REM, DoseLocation.LUNAR_SURFACE); // set the doses
 *	EnergySpectrumChartPanel graphPanel=graph.getChartPanel(); // get a panel to use
 *	mainPanel.add(graphPanel); // put the chart in a panel.
 * </pre>
 * @author Joshua Lande
 */
public class RadiationDoseGraph  {

	/**	
	 * The chart to hold the radiation doses.
	 */
	JFreeChart chart;
	
	/**
	 * The dataset to hold the radiation doses.
	 */
	DefaultCategoryDataset dataset;

	/**
	 * Creates the dataset and chart with nothing in it.
	 */
    public RadiationDoseGraph() {
        dataset = new DefaultCategoryDataset();
        chart = createChart(dataset);
    }

    /**
     * Creates a chart when given an CategoryDataset. It is given the proper title, and labels to it
     * and set to the correct range.
     * @param dataset The data for the chart.
     * @return A chart.
     */
    private static JFreeChart createChart(CategoryDataset dataset) {
        
        // create the chart...
        JFreeChart chart = ChartFactory.createBarChart(
            "  ",        				// chart title
            "Thickness",              	// domain axis label
            "  ",                       // range axis label
            dataset,                  	// data
            PlotOrientation.VERTICAL, 	// orientation
            true,                     	// include legend
            true,                     	// tooltips?
            false                     	// URLs?
        );
        chart.setBackgroundPaint(Color.white);
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(Color.lightGray);

        // remove gridlines (the dotted lines in the background of the graph)
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);
                
        // set log Y axis
        LogarithmicAxis rangeAxis=new LogarithmicAxis("  "); 
        rangeAxis.setLog10TickLabelsFlag(true);
        rangeAxis.setTickMarksVisible(true);
        rangeAxis.setAutoRangeNextLogFlag(true);
        plot.setRangeAxis(rangeAxis);
        
        // change the color of the series to be the same as in RON's spreadsheet
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(153,153,255));
        renderer.setSeriesPaint(1, new Color(153,51,102));
        renderer.setSeriesPaint(2, new Color(255,255,204));

        // set the margin between categories (in percent)
        CategoryAxis axis = plot.getDomainAxis();
        axis.setLowerMargin(0.02); 
        axis.setCategoryMargin(0.10); 
        axis.setUpperMargin(0.02); 
        
        // set the space between items in a category to 0.
        renderer.setItemMargin(0.0); 
        return chart;
    }
    
    /**
     * This function graphs radiation doses to the skin, eye, and BFO under thicknesses .3, 1, 5, 10, and 30 g/cm2.
     * @param inputEvent The SPE to graph radiation doses for. It must be an object that implements SolarParticleEventInterface.
     * @param remOrRad The radiation type.
     * @param lunarSurfaceOrFreeSpace Where to graph radiation for.
     * @throws IllegalArgumentException If the object passed does not implement SolarParticleEventInterface.
    
     */
    public void setDoses(Object inputEvent, RadiationType remOrRad, DoseLocation lunarSurfaceOrFreeSpace) {
    	SolarParticleEventInterface yourSPE = (SolarParticleEventInterface)inputEvent; // turn the inputted object into a SPE interface.  
    	dataset.clear(); // clear out the old values
    	 
    	try {
    		for(BodyPart bodyPartLoop: BodyPart.values() ) {
    			for(Thickness thicknessLoop: Thickness.values() ) {
    				double dose=yourSPE.getDose(thicknessLoop,remOrRad,bodyPartLoop,lunarSurfaceOrFreeSpace); // get the dose
    		    	dataset.addValue(dose,bodyPartLoop.toString(),thicknessLoop.toString()); // add the dose to the graph
    			}
    		}    		    		
            chart.setTitle("Total Event "+remOrRad.toString()+" "+lunarSurfaceOrFreeSpace.whereItIs()+" ("+remOrRad.getUnits()+")");
    		CategoryPlot plot = chart.getCategoryPlot();
    		plot.getRangeAxis().setLabel(remOrRad.toString()+" ("+remOrRad.getUnits()+")");   	   		
    	}catch (Exception exception) {
     		dataset.clear(); // if anything goes wrong, clear graph
    	}
    }

    /**
     * This method puts the energy spectrum graph into a chart panel, 
     * disables zooming the graph, disables the right
     * click pop up menu of the graph, and returns the panel for use.
     * @return A ChartPanel 
     */
    public ChartPanel getChartPanel() {
    	ChartPanel panel= new ChartPanel(chart);
    	panel.setDomainZoomable(false);
    	panel.setRangeZoomable(false);
    	panel.setPopupMenu(null); 
        return panel;
    }
}
