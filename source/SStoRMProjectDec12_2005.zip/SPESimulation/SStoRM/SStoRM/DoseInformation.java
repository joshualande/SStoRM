package SStoRM;

/**
 * This object holds all of the interesting information obtained from
 * calculating the time evolution dose. It is basically a poor man's
 * C++ struct, but is is easier then returning all of these variables
 * seperatly.
 * <p>
 * Note that none of the variables have getter and setter functions.
 * This is because I am lazy.
 * 
 * @author Joshua Lande 
 */
public class DoseInformation {
	public double totalDoseAwayFromShelter;
	public double ratioHigherThenAlwaysAtBase;
	
	public double dosePriorToWarning;
	public double percentOfTotalPriorToWarning;
	
	
	public double doseWhilePackingUp;
	public double percentOfTotalWhilePackingUp;
	
	public double doseDuringTransit;
	public double percentOfTotalDuringTransit;
	
	public double doseAtBase;
	public double percentOfTotalAtBase;
	
	
	public Time timeExposedInBase;
	
	
}
