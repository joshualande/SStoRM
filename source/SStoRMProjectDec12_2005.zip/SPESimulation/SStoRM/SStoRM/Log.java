package SStoRM;
/**
 * This class allows for the easy calculations using logs base 10.
 * Basically, all Math.java gives as a function is Math.log()
 * which does logarithms base 10. Why they didn't call it
 * Math.ln(), I don't know. But anyway, to find the log base 10
 * of a number, all you have to say is,
 * <pre><code>
 * 	value = Log.base10(1000) // returns 3
 * </code></pre>
 * The other feature is that you can round a number up or down
 * to the next order of magnitude. For example,
 * <pre><code>
 * 	value=Log.roundDownOrderOfMagnitude( 999.9) // returns 100
 * 	value=Log.roundDownOrderOfMagnitude(1000.1) // returns 1000
 * 	value=Log.roundUpOrderOfMagnitude( 99.9) // returns 100
 * 	value=Log.roundUpOrderOfMagnitude(100.1) // returns 1000
 * </code></pre>
 * @author Joshua Lande
 */
public class Log {
	
	/**
	 * Returns the log base 10 of the input. For example,
	 * <pre>
	 * double value = Log.base10(1000) // returns 3
	 * </pre>
	 * @param value The value to perform the log of.
	 * @return The log of the value.
	 * @throws IllegalArgumentException If the input is less then or equal to 0.
     */
	public static double base10(double value) throws IllegalArgumentException{
		if (value <= 0) throw new IllegalArgumentException("Logs (base 10) can only be take of values larger then 0");
		return Math.log(value)/Math.log(10);
	}

	/**
	 * Rounds a number down to the last order of magnitude. For example,
	 * 10.1 gets rounded down to 10, but 9.9 gets rounded down to 1.
	 * We do this by taking the log base 10 of the value, doing the ceiling of that
	 * value, and rasing 10 to that value. Or, in math talk:
	 * <pre>
	 *   value=10^(floor(Log(input)))
	 * </pre>
	 * 0 is rounded to 0. Negative values are handled properly using the formula:
	 * <pre>
	 * 	value = (-1)*roundUpOrderOfMagnitude(-1*input)
	 * </pre>
	 * All this does is convert the number to a positive, round it <b>up</b>, and turn it
	 * back negative, obtaining the value we want. For example, -11 gets rounded to -100.
	 * @param value value to round up.
	 * @return The input rounded up to the next order of magnitude
	 */
	public static double roundDownOrderOfMagnitude(double value) {
		if (Double.isNaN(value)) throw new IllegalArgumentException("The value passed to roundDownOrderOfMagnitude must be a number.");
		if (Double.isInfinite(value)) throw new IllegalArgumentException("You cannot round numbers that are infinatly large.");
		if (value==0) return 0;
		if (value<0) return (-1)*Log.roundUpOrderOfMagnitude((-1)*value);
		return Math.pow(10,Math.floor(Log.base10(value)));
	}

	/**
	 * Rounds a number up to the next order of magnitude. For example,
	 * 10.1 gets rounded up to 100.0, but 9.9 gets rounded up to 10.0.
	 * We do this by taking the log base 10 of the value, doing the floor of
	 * that value, and rasing 10 to that value. Or, in math talk:
	 * <pre>
	 *   value=10^(ceiling(Log(input)))
	 * <pre>
	 * 0 is rounded to 0. Negative values are handled properly using the formula:
	 * <pre>
	 * 	value = (-1)*roundDownOrderOfMagnitude(-1*input)
	 * </pre>
	 * All this does is convert the number to a positive, round it <b>down</b>, and turn it
	 * back negative, obtaining the value we want. For example, -11 gets rounded to -10.
	 * @param value value to round up.
	 * @return The input rounded up to the next order of magnitude
	 */
	public static double roundUpOrderOfMagnitude(double value) {
		if (Double.isNaN(value)) throw new IllegalArgumentException("The value passed to roundUpOrderOfMagnitude must be a number.");
		if (Double.isInfinite(value)) throw new IllegalArgumentException("You cannot round numbers that are infinatly large.");
		if (value==0) return 0;
		if (value<0) return (-1)*Log.roundDownOrderOfMagnitude(Math.abs(value));
		return Math.pow(10,Math.ceil(Log.base10(value)));
	}
			
}
