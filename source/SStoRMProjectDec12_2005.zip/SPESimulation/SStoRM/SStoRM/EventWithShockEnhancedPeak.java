package SStoRM;

/**
 * This object holds a solar particle event that includes a Gaussian shock enhanced peak.
 * Whenever the event WITHOUT the shock enhanced peak is affected by a function, the function will be appended with a "_1".
 * For example, {@link #getDose_1} refers to getting the dose without the Shock Enhanced Peak (SEP). 
 * (This is a bit weird, but I couldn't think up a better notation, and at least it is consistent).
 * Whenever the shock enhance peak itself is intended, a function will have ShockEnhancedPeak in the title.
 * For example, {@link #getShockEnhancedPeakDose} gets the shock enhanced peak dose. 
 * Whenever the entire event (including both the event and the shock enhanced peak) is desired,
 * it is referred to without reference to either in specific. For example, {@link #getDose} gets the cumulative dose of the entire event. 
 * <p>
 * This class uses the exponential curve <i>Fluence</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>
 * E/Eo</sup> to represent the energy spectrum of the event and the Shock Enhanced Peak. The energy spectrum of a SPE
 * represents the total number of particles at a given energy value as a function
 * of that energy value. 
 * The integral of the energy spectrum is the
 * total number of particles of the SPE. The lower bounds of the integral 
 * (Emin) allows for the calculation of the total number of particles
 * above a certain energy value. The energy spectrum is internally stored inside a {@link EnergySpectrum} object.
 * <p>
 * The energy spectrum integral fluence and the K constant are intimately related. We can show that:
 * <pre>
 * K = (> Emin) integral fluence / (>Emin) integral fluence without K
 * </pre>
 * Where the energy spectrum integral fluence without K is found using specific E0 and gamma values. This class
 * only lets the integral fluence be specified. K is calculated automatically behind the scenes.
 * <p>
 * This class also uses the curve 
 * <i>Flux</i>=C(t/A)<sup>B1</sup><i>e</i><sup>-(t/A)^B2</sup>
 * to represent the time evolution of the event without the shock enhanced peak. The time evolution 
 * is a function of the total number of particles over the duration of the event.
 * The time evolution is stored in a {@link TimeEvolution} object. 
 * The integral time evolution flux is also the total number of particles. 
 * C is set automatically so that the >10 MeV energy spectrum integral fluence equals the time evolution graph's
 * integral flux. This is done with the formula:
 * <pre>
 * C_1 = Event 1 (>10 MeV) energy spectrum integral fluence/(event 1 time evolution integral flux from 0 to 10 days * 24*3600*4*pi)
 * </pre>
 * This formula can be derived by equating the two integrals. The 24*3600 accounts for a conversion from days to
 * seconds and the 4*pi accounts for 4*pi steradians in free space. This C constant is useful for 
 * comparing the time evolutions to the time evolution of the graphs in the widget.
 * <p>
 * The time evolution of the shock enhanced peak is stored differently. It is stored using the Gaussian curve
 * <i>Flux</i>=C*e<sup>(t-delay)^2/B^2</sup>
 * where delay is the delay before the shock enhanced peak is at its full. 
 * This curve represents the same physical quantity as the other time evolution, only in a different form. 
 * This class still sets C automatically using the formula
 * <pre>
 * ShockEnhancedPeak C = Shock Enhanced Peak (>10 MeV) energy spectrum integral fluence / (Shock Enhanced Peak time evolution integral flux from 0 to 10 days * 24*3600*4*pi)
 * </pre>
 * The shock enhanced peak time evolution is stored in a {@link SStoRM.ShockEnhancedPeakTimeEvolution} object.
 * <p>
 * <b>Usage:</b>
 * <p>
 * You can create SPEs by saying:
 * <pre>
 * 	EventWithShockEnhancedPeak SPE=new EventWithShockEnhancedPeak("SPE Name");
 * </pre>
 * You can then specify the shape of the energy spectrum by
 * setting the K, gamma, and E0 values for each curve.
 * <pre>
 * //Set The main event without shock enhanced peak energy spectrum
 * SPE.setEnergySpectrumIntegralFluence_1(1.88E10); 
 * SPE.setGamma_1(0);
 * SPE.setE0_1(30);
 * K = SPE.getK_1(); 
 * 
 * //sets shock enhanced peak energy spectrum.
 * SPE.setShockEnhancedPeakEnergySpectrumIntegralFluence_1(1.88E10); 
 * SPE.setShockEnhancedPeakGamma_2(.1);
 * SPE.setShockEnhancedPeakE0(35);
 * K = SPE.getShockEnhancedPeakK_1(); 
 * 
 * //sets Emin for both events
 * SPE.setEmin(50);
 * </pre>
 * <pre>
 * integralFluence_1=SPE.getEnergySpectrumIntegralFluence_1();
 * integralFluence_2=SPE.getShockEnhancedPeakEnergySpectrumIntegralFluence();
 * // or the total including both
 * integralFluence=SPE.getEnergySpectrumIntegralFluence();
 * // Or from a nondefault Emin * 
 * integralFluence=SPE.getEnergySpectrumIntegralFluence(50);
 * </pre>
 * <p>You can then set the time evolution of the SPE by saying:
 * <pre>
 * SPE.setA_1(.15);
 * SPE.setB1_1(2);
 * SPE.setB2_1(1);
 * SPE.setShockEnhancedPeakB(.15);
 * SPE.setTimeDelayBetweenEvents(Time.inDays(1));
 * </pre>
 * <p>The scaling factor (C) for the event and the peak can now automatically be retrieved by saying
 * <pre>
 * C_1=SPE.getC_1();
 * C_2=SPE.getShockEnhancedPeakC();
 * </pre>
 * As a note, the following constraints are enforced:
 * <p>
 * The Ks must be at least 0. Emin must be at least 10 and at most 1500. The gammas must be at least 0 and at most
 * 4.125. The E0s must be at least 10 and at most 1500. The energy spectrum integral fluences must be at least 0.
 * @author Joshua Lande
 */


public class EventWithShockEnhancedPeak implements Comparable, SolarParticleEventInterface  {
	
	/**
	 * Object that holds all of the radiation dose values for the solar particle event.
	 * We can call methods on this object to get out the doses.
	 * <b>This object is incredibly memory intensive
	 * because it has to read in and hold over 2 meg
	 * of information about the solar particle event radiation doses.
	 * So, it will only be created when you explicitly 
	 * ask for a solar particle event's radiation dose.
	 * That way, if doses are not desired, it will not
	 * be necessary to load this into memory.
	 * </b>
	 */
	private RadiationDoseValues radiationDoseValues=null;
	
    /**
     * The name of the solar particle event.
     * <p>
     * To modify, see {@link #setName} and {@link #getName}. 
     */
	private String name="";

	/**
	 * Holds the time evolution of the solar particle event.
	 */
    private TimeEvolution timeEvolution_1 = new TimeEvolution();
    
    /**
     * Holds the energy spectrum of the solar particle event.
     */
    private EnergySpectrum energySpectrum_1 = new EnergySpectrum();
    
    /**
     * Holds the energy spectrum of the shock enhanced peak.
     */
    private EnergySpectrum shockEnhancedPeakEnergySpectrum = new EnergySpectrum();

	/**
	 * Holds the  time evolution of the shock enhanced peak.
	 */
    private ShockEnhancedPeakTimeEvolution shockEnhancedPeakTimeEvolution = new ShockEnhancedPeakTimeEvolution();
        
    /**
     * Trys to set a value for the event C scaling constant (C_1).
     * C is calculated so that the integral fluence of the energy spectrum of the event
     * equals the integral flux of the time evolution curve of the event (excluding the shock enhanced peak). 
     * <p>
     * C is calculated this way so that the total number of particles
     * from the energy spectrum (the integral fluence) and the total number of
     * particles from the time evolution (the integral flux) are the same. 
     * This ensure that the 2 SPE curves are really talking
     * about the same event.
     * <p>
     * The formula used is C = the >10 MeV integral fluence of the energy spectrum divided
     * by the Integral flux of the time evolution of the event (from 0 to 10 days)
     * and then again by 4 days worth of seconds * 4 pi steradians.
     * <p>
     * If C cannot be set (for example, some parameters are not yet initialized), nothing happens
     * and the function returns with no change. C is not set and no errors are thrown. This allows other
     * functions to call it whenever they want to try to fix the state of the object. It C shouldn't have 
     * a value yet, nothing bad will happen.
     */
    private void attemptToResetC_1() {
    	try {
    		timeEvolution_1.setC(
    				energySpectrum_1.getIntegralFluence(10.0) 
    				/(timeEvolution_1.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0.0),Time.inDays(10.0))*24*3600*4*Math.PI)
			);
    	} catch (Exception e) { }
    }
     
    /**
     * Tries to set the C value for the shock enhanced peak.
     * C is calculated so that the integral fluence of the shock enhanced peak
     * equals the integral flux of the time evolution curve of the shock enhanced peak.
     * <p>
     * C is calculated this way so that the total number of particles
     * from the shock enhanced peak's energy spectrum (the integral fluence) and the total number of
     * particles from the shock enhanced peak's time evolution (the integral flux) are the same. 
     * This ensure that the 2 SPE curves are really talking
     * about the same event.
     * <p>
     * The formula used is C = the >10 MeV integral fluence of the shock enhanced peak divided
     * by the Integral flux of the shock enhanced peak's time evolution (from 0 to 10 days)
     * and then again by 4 days worth of seconds * 4 pi steradians.
     * <p>
     * If C cannot be set (for example, some parameters are not yet initialized), nothing happens
     * and the function returns with no change. C is not set and no errors are thrown. This allows other
     * functions to call it whenever they want to try to fix the state of the object. It C shouldn't have 
     * a value yet, nothing bad will happen.
     */
    private void attemptToResetCForShockEnhancedPeak() {
    	try {
    		shockEnhancedPeakTimeEvolution.setC(
    				shockEnhancedPeakEnergySpectrum.getIntegralFluence(10.0) 
    				/(shockEnhancedPeakTimeEvolution.getIntegralFluxWithoutC(Time.inDays(0.0),Time.inDays(10.0))*24*3600*4*Math.PI)
			);
    	} catch (Exception e) { }
    }

    /**
	 * Tests whetherr the event and shock enhanced peak are equal. They are equal only if each event
	 * has the same energy spectrum, time evolution, and shock enhanced peak.
	 */
	public boolean equals(Object anObject){
		if (anObject instanceof EventWithShockEnhancedPeak) {
			try {
				EventWithShockEnhancedPeak otherEvent=(EventWithShockEnhancedPeak)anObject;
				return  (
		    		this.timeEvolution_1.equals(otherEvent.timeEvolution_1) &&
		    		this.energySpectrum_1.equals(otherEvent.energySpectrum_1) &&
		    		this.shockEnhancedPeakTimeEvolution.equals(otherEvent.shockEnhancedPeakTimeEvolution) &&
		    		this.shockEnhancedPeakEnergySpectrum.equals(otherEvent.shockEnhancedPeakEnergySpectrum) 
				);
			} catch (Exception exception) { }
		}	
		return false;
	}
	
	/**
	 * Performs the expected clone of a DoubleEvent.
	 */
	public Object clone() {   
       	try {
            EventWithShockEnhancedPeak newEvent = new EventWithShockEnhancedPeak(this.getName());
       		newEvent.energySpectrum_1 = (EnergySpectrum)this.energySpectrum_1.clone();
       		newEvent.timeEvolution_1  = (TimeEvolution)this.timeEvolution_1.clone();
       		newEvent.shockEnhancedPeakEnergySpectrum = (EnergySpectrum)this.shockEnhancedPeakEnergySpectrum.clone();
       		newEvent.shockEnhancedPeakTimeEvolution  = (ShockEnhancedPeakTimeEvolution)this.shockEnhancedPeakTimeEvolution.clone();
       		return newEvent;
       	} catch (Exception exception) {
			return null;
		}
    }	
	
    /** 
     * compares a SolarParticleEventInterface to another SolarParticleEventInterface
     * based on the value of their total energy spectrum integral fluence. 
     * The integral fluence is calculated using {@link #getEnergySpectrumIntegralFluence()}
     * <p>
     * If, for any reason, the integral fluence cannot be calculated, 0 is returned by default
     * <p>
     * This function is weird in how it sorts but useful because it lets you sort an array of 
     * EventWithShockEnhancedPeaks based on energy spectrum integral fluences.
     * All you have to say is:
     * <pre>
     * 	sort(SPEArray); // sorts in ascending order</pre> 
     * 
     * @param otherObject		Another object of the same type to compare
     * 
     * @return 
     * <p>
     * <code> 1</code> If the event of the current object has a higher
     * integral fluence then the Event of the inputted object.
     * <p>
     * <code>-1</code> If the event of the inputted object has a
     * higher integral fluence then the Event of the current object.
     * 			
     * <p><code> 0</code> If the two events have the same integral fluence,
     * or, for whatever reason, the integral fluence cannot be calculated.
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object) 
     */
    public int compareTo(Object otherObject) {
        SolarParticleEventInterface RHS=(SolarParticleEventInterface)otherObject;
        try{
        	if(this.getEnergySpectrumIntegralFluence()<RHS.getEnergySpectrumIntegralFluence())
        		return -1;
        	if (this.getEnergySpectrumIntegralFluence()>RHS.getEnergySpectrumIntegralFluence())
        		return 1;
        	return 0;
        } catch (IllegalArgumentException exception) {
        	return 0;// if the fluence cannot be calculated, return 0        	
        }
	}

    /**
     * Constructor that does nothing.
     */
    public EventWithShockEnhancedPeak() {}
    
    /**
     * Constructor that sets the name of the DoubleEvent but nothing else.
     * @param name The name of the DoubleEvent.
     */
    public EventWithShockEnhancedPeak(String name) {
    	this.setName(name);
    }	    

    /**
     * Stores the time delay between the beginning of the event and the middle of the shock enhanced peak.
     * @param timeDelayBeforeShockEnhancedPeakInput The time delay.
     * @throws IllegalArgumentException If the time delay is less then 0. 
     */
    public void setTimeDelayBeforeShockEnhancedPeak(Time timeDelayBeforeShockEnhancedPeakInput) throws IllegalArgumentException {
    	shockEnhancedPeakTimeEvolution.setTimeDelay(timeDelayBeforeShockEnhancedPeakInput);
    }

    /**
     * Returns the time delay between the beginning of the event and the middle of the shock enhanced peak.
     * @return The time delay.
     * @throws IllegalArgumentException If the time delay has not been defined yet.
     */    
     public Time getTimeDelayBeforeShockEnhancedPeak() throws IllegalArgumentException {
     	return shockEnhancedPeakTimeEvolution.getTimeDelay();
     }	
          
    /**
     * Sets the A parameter of the time evolution of the event. It
     * cannot be 0 because this would lead to division by 0 (bad).
     * @param AInput The A parameter.
     * @throws IllegalArgumentException If A is not defined or 0.
     */
    public void setA_1(double AInput) throws IllegalArgumentException {      
    	try{
    		if (AInput == timeEvolution_1.getA()) return;
    	} catch (Exception e) {};
    	timeEvolution_1.setA(AInput);
     	attemptToResetC_1();
 	}
     

     /** 
      * Sets the B1 parameter of the time evolution of the event.
      * @param B1Input The B1 parameter. 
      */
     public void setB1_1(double B1Input) {
    	 try {
    		 if (B1Input == timeEvolution_1.getB1()) return;
     	} catch (Exception e) {};
 		timeEvolution_1.setB1(B1Input);
 		attemptToResetC_1();
 	}
    
 	/**
 	 * Sets the B2 parameter of the time evolution of the event.
 	 * @param B2Input The B2 parameter.
 	 */
     public void setB2_1(double B2Input) {
    	 try {
    		 if (B2Input == timeEvolution_1.getB2()) return;
    	 } catch (Exception e) {};
    	 timeEvolution_1.setB2(B2Input);
         attemptToResetC_1();
 	} 
     
     /**
      * Sets the Emin value. Emin is the lower bounds of the integral of the energy 
      * spectrum. Emin will only be set if it is at least 10 and at most 1500. 
      * @param EminInput The new minimum energy value to integrate from.
      * @throws IllegalArgumentException If EminInput is smaller then 10, larger then 1500, or not a number.
      */
     public void setEmin(double EminInput) throws IllegalArgumentException {
    	 try {
    		 if (EminInput == energySpectrum_1.getEmin() && 
    			 EminInput == shockEnhancedPeakEnergySpectrum.getEmin()) return;
     	} catch (Exception e) {};
     	energySpectrum_1.setEmin(EminInput); // set Emin
      	attemptToResetC_1();
      	shockEnhancedPeakEnergySpectrum.setEmin(EminInput); // set Emin
        attemptToResetCForShockEnhancedPeak();        
     }
     
     /** 
      * Sets the E0 parameter of the energy spectrum to E0Input. It is set only if
      * E0Input is at least 10 and at most 500. 
      * @param E0Input
      * @throws IllegalArgumentException If E0Input is less 10 or greater then 500.
      */
     public void setE0_1(double E0Input) throws IllegalArgumentException {
    	 try {
    		 if (E0Input == energySpectrum_1.getE0()) return;
     	 } catch (Exception e) {};
    	 energySpectrum_1.setE0(E0Input);
    	 attemptToResetC_1();
     }
     
     /** 
      * Sets the gamma parameter of the energy spectrum to gammaInput. It is set only if
      * gammaInput is at least 0 and at most 4.125. 
      * @param gammaInput
      * @throws IllegalArgumentException If gammaInput is less 0 or greater then 4.125.
      */
     public void setGamma_1(double gammaInput) throws IllegalArgumentException { 
    	 try {
    		 if (gammaInput == energySpectrum_1.getGamma()) return;
     	 } catch (Exception e) {};
    	 energySpectrum_1.setGamma(gammaInput);
         attemptToResetC_1();
     }    

     /** 
      * Sets the name of the DoubleEvent.
      * @param nameInput The name of the Event.
      */
     public void setName(String nameInput) throws IllegalArgumentException {
     	if (nameInput == null) throw new IllegalArgumentException("The name must not be null."); 
 		name=nameInput;
     }
    
     /**
      * Sets the > Emin energySpectrumIntegralFluence of the energy spectrum. When this is set, K is assumed to be calculated
      * automatically.
      * @param integralFluenceInput The integral fluence to set.
      * @throws IllegalArgumentException If the integral fluence is smaller then 0.
      */
     public void setEnergySpectrumIntegralFluence_1(double integralFluenceInput) throws IllegalArgumentException {
         energySpectrum_1.setIntegralFluence(integralFluenceInput);
         attemptToResetC_1();
     }	
 	
 	/**
 	 * Sets the B parameter of the shock enhanced peak to that of the input.
 	 * The B parameter corresponds to the width of the event. 
 	 * It is typically between 0.01 and 0.2.
 	 * @param BInput The B value to use.
 	 * @throws IllegalArgumentException If the B value is 0.
 	 */
     public void setShockEnhancedPeakB(double BInput) throws IllegalArgumentException {
    	try {
    		 if (BInput==shockEnhancedPeakTimeEvolution.getB()) return;
    	} catch (Exception e) {};
 		shockEnhancedPeakTimeEvolution.setB(BInput);
        attemptToResetCForShockEnhancedPeak();
 	}    
    
    /** 
     * Sets the E0 parameter of the shock enhanced peak to E0Input. It is set only if
     * E0Input is at least 10 and at most 500. 
     * @param E0Input The E0 value.
     * @throws IllegalArgumentException If E0Input is less 10 or greater then 500.
     */
    public void setShockEnhancedPeakE0(double E0Input) throws IllegalArgumentException {
    	try{
    		if (E0Input == shockEnhancedPeakEnergySpectrum.getE0()) return;
    	} catch (Exception e) {};
    	shockEnhancedPeakEnergySpectrum.setE0(E0Input);
    	attemptToResetCForShockEnhancedPeak();
    }
    
    /** 
     * Sets the gamma parameter of the shock enhanced peak to gammaInput. It is set only if
     * gammaInput is at least 0 and at most 4.125. 
     * @param gammaInput The gamma value.
     * @throws IllegalArgumentException If gammaInput is less 0 or greater then 4.125.
     */
    public void setShockEnhancedPeakGamma(double gammaInput) throws IllegalArgumentException {
    	try {
    		if (gammaInput == shockEnhancedPeakEnergySpectrum.getGamma()) return;
    	} catch (Exception e) {};
    	shockEnhancedPeakEnergySpectrum.setGamma(gammaInput);
        attemptToResetCForShockEnhancedPeak();
    }     
    
    /**
     * Sets the > Emin energy spectrum integral fluence of the shock enhanced peak. K is assumed to be calculated
     * automatically.
     * @param integralFluenceInput The integral fluence to set.
     * @throws IllegalArgumentException If the integral fluence is smaller then 0.
     */
    public void setShockEnhancedPeakEnergySpectrumIntegralFluence(double integralFluenceInput) throws IllegalArgumentException {
    	shockEnhancedPeakEnergySpectrum.setIntegralFluence(integralFluenceInput);
        attemptToResetCForShockEnhancedPeak();
    }	

    /**
     * Calculates the energy spectrum fluence for the event at a given energy value
     * @param EInput The energy value.
     * @return The fluence for the event a given energy value of
     * @throws IllegalArgumentException If any of the parameters of the energy spectrum are 
  	 * not specified.
     */
    public double getEnergySpectrumFluence_1(double EInput) throws IllegalArgumentException {
        return energySpectrum_1.getFluence(EInput);
    }
    
    /**
     * Calculates the energy spectrum fluence for the shock enhanced peak at a given energy value
     * @param EInput The energy value.
     * @return The fluence for the shock enhanced peak at a given energy value of
     * @throws IllegalArgumentException If any of the parameters of the shock enhanced peak energy spectrum are 
  	 * not specified.
     */
    public double getShockEnhancedPeakEnergySpectrumFluence(double EInput) throws IllegalArgumentException {
        return shockEnhancedPeakEnergySpectrum.getFluence(EInput);
    }

    /**
     * Calculates the energy spectrum fluence for the event and shock enhanced peak at any given
     * energy value over 0. This is calculated by adding the energy spectrum of
     * the event and its shock enhanced peak to get the total spectrum. It includes the K value. 
     * @param EInput The energy value.
     * @return The fluence for a given energy value of the event and it's shock enhanced peak.
     * @throws IllegalArgumentException If any of the parameters of the energy spectrums are 
  	 * not specified.
     */
    public double getEnergySpectrumFluence(double EInput) throws IllegalArgumentException {
        return getEnergySpectrumFluence_1(EInput)+getShockEnhancedPeakEnergySpectrumFluence(EInput);
    }

  	/**
  	 * Returns the energy spectrum integral fluence. This is calculated by adding the energy spectrum of
     * the event and its shock enhanced peak to get the total spectrum.
  	 * Emin must have been previously set for the event by a call to {@link #setEmin}. 
  	 * <p>
  	 * What is returned is the total number of particles with energy values
  	 * above Emin.
  	 * @return The integral fluence the event and the shock enhanced peak.
  	 * @throws IllegalArgumentException If any of the parameters of the energy spectrums are 
  	 * not specified.
  	 */
    public double getEnergySpectrumIntegralFluence() throws IllegalArgumentException {
    	return getEnergySpectrumIntegralFluence_1()+getShockEnhancedPeakEnergySpectrumIntegralFluence();
    }
    
  	/**
  	 * Returns the energy spectrum integral fluence of
     * the event (without the shock enhanced peak).
  	 * Emin must have been previously set for the event by a call to {@link #setEmin}. 
  	 * @return The integral fluence.
  	 * @throws IllegalArgumentException If any of the parameters of the energy spectrum is
  	 * not specified.
  	 */
    public double getEnergySpectrumIntegralFluence_1() throws IllegalArgumentException {
    	return energySpectrum_1.getIntegralFluence();
    }
  	/**
  	 * Returns the energy spectrum integral fluence of the shock enhanced peak.
  	 * Emin must have been previously set for the event by a call to {@link #setEmin}. 
  	 * @return The integral fluence .
  	 * @throws IllegalArgumentException If any of the parameters of the energy spectrum is
  	 * not specified.
  	 */
    public double getShockEnhancedPeakEnergySpectrumIntegralFluence() throws IllegalArgumentException {
    	return shockEnhancedPeakEnergySpectrum.getIntegralFluence();
    }
    
    /**
     * Returns the K parameter of the energy spectrum of the event. If K has been set explicitly,
     * that value is returned. Otherwise, K is calculated automatically using the formula
     * <pre>
     * 	K = inputted integral fluence / calculated integral fluence without K
     * </pre> 
     * @return The K parameter of the event.
     * @throws IllegalArgumentException If K is not defined.
     */
    public double getK_1() throws IllegalArgumentException {
    	return energySpectrum_1.getK();
    }
    
    /**
     * Returns the K parameter of the energy spectrum of the shock enhanced peak. 
     * If K has been set explicitly that value is returned. 
     * Otherwise, K is calculated automatically using the formula
     * <pre>
     * 	K = inputted integral fluence / calculated integral fluence without K
     * </pre> 
     * @return The K parameter of the shock enhanced peak.
     * @throws IllegalArgumentException If K is not defined.
     */
    public double getShockEnhancedPeakK() throws IllegalArgumentException {
    	return shockEnhancedPeakEnergySpectrum.getK();
    }        
      
	/**
	 * Gets the A parameter of the time evolution curve of the event. 
	 * @return The value of A.
	 * @throws IllegalArgumentException If A is not defined.
	 */
	public double getA_1() throws IllegalArgumentException {
		return timeEvolution_1.getA();
	}  
    
	/**
	 * Gets the B1 parameter of the time evolution curve of the event. 
	 * @return The value of B1.
	 * @throws IllegalArgumentException If B1 is not defined.
	 */
	public double getB1_1() throws IllegalArgumentException {
		return timeEvolution_1.getB1();
	}

	/**
	 * Gets the B2 parameter of the time evolution curve of the event. 
	 * @return The value of B2.
	 * @throws IllegalArgumentException If B2 is not defined.
	 */
	public double getB2_1() throws IllegalArgumentException {
		return timeEvolution_1.getB2();
	}

    /**
     * Gets the gamma parameter of the energy spectrum of the event.
     * @return The gamma value.
     * @throws IllegalArgumentException If gamma is not defined.
     */
    public double getGamma_1() throws IllegalArgumentException {
        return energySpectrum_1.getGamma();
    }    

    /**
     * Gets the E0 parameter of the energy spectrum of the event.
     * @return The E0 value.
     * @throws IllegalArgumentException If E0 is not defined.
     */
    public double getE0_1() throws IllegalArgumentException {
    	return energySpectrum_1.getE0();
    }    

    /**
     * Returns the value of C of the event. This is the final parameter of the time evolution curve.
     * It is calculated automatically so that the integral fluence of the energy spectrum
     * equals the integral flux of the time evolution curve. 
     * @return The value of C.
     * @throws IllegalArgumentException if gamma, E0, K, A, B1, B2, or C
     * are not defined for the event.
     */
    public double getC_1() throws IllegalArgumentException {
    	attemptToResetC_1();
    	return timeEvolution_1.getC();
    }
        
	/**
	 * Gets the Emin value. Or, the minimum energy value to use when integrating the energy spectrum.
	 * @return The value of Emin.
	 * @throws IllegalArgumentException If Emin is not defined.
	 */
    public double getEmin() throws IllegalArgumentException {
    	double Emin=energySpectrum_1.getEmin();
    	if ( Emin != shockEnhancedPeakEnergySpectrum.getEmin())
    		throw new IllegalArgumentException("State of the object is not correct (Emin must be the same for both the event and the shock enhanced peak).");
    	return Emin;
    }	
    /**
     * Gets the name of the SPE.
     * @return the name of the SPE.
     */
    public String getName() {
        return name;
    }
    
    /** 
     * Returns the energy spectrum integral 
     * fluence from the inputted Emin value to 1500 (basically infinity) for each energy spectrum. 
     * The result is the sum of the integral fluence of the event and it's shock enhanced peak.
     * @param EminInput The lower bound of the integral.
     * @return The integral fluence above Emin.
     * @throws IllegalArgumentException If EminInput is less then 10 or if E0 is not defined.
     */
    public double getEnergySpectrumIntegralFluence(double EminInput) throws IllegalArgumentException {
    	return getEnergySpectrumIntegralFluence_1(EminInput)+getShockEnhancedPeakEnergySpectrumIntegralFluence(EminInput);
    }

    /** 
     * Returns the energy spectrum integral 
     * fluence from the inputted Emin value to 1500 (basically infinity) of the event. 
     * @param EminInput The lower bound of the integral.
     * @return The integral fluence above Emin.
     * @throws IllegalArgumentException If EminInput is less then 10 or if E0 is not defined.
     */
    public double getEnergySpectrumIntegralFluence_1(double EminInput) throws IllegalArgumentException {
    	return energySpectrum_1.getIntegralFluence(EminInput);
    }
    /** 
     * Returns the energy spectrum integral fluence from the inputted Emin value to 1500 (basically infinity) of the shock enhanced peak. 
     * @param EminInput The lower bound of the integral.
     * @return The integral fluence above Emin.
     * @throws IllegalArgumentException If EminInput is less then 10 or if E0 is not defined.
     */
    public double getShockEnhancedPeakEnergySpectrumIntegralFluence(double EminInput) throws IllegalArgumentException {
    	return shockEnhancedPeakEnergySpectrum.getIntegralFluence(EminInput);
    }
    
	/**
	 * Returns the scaling factor of the shock enhanced peak.
	 * @return The C value.
	 * @throws IllegalArgumentException If the C value has not previously been specified.
	 */
	public double getShockEnhancedPeakC() throws IllegalArgumentException {
		attemptToResetCForShockEnhancedPeak();
		return shockEnhancedPeakTimeEvolution.getC(); 
	}
	
	/**
	 * Returns the B parameter of the shock enhanced peak. The B parameter corresponds to the width of the event. 
	 * @return The B parameter of the event.
	 * @throws IllegalArgumentException If the B value has not previously been specified.
	 */
	public double getShockEnhancedPeakB() throws IllegalArgumentException {
		return shockEnhancedPeakTimeEvolution.getB();
	}
	
    
    /**
     * Returns the gamma parameter of the energy spectrum of the shock enhanced peak. 
     * @return The gamma value.
     * @throws IllegalArgumentException If gamma is not defined.
     */
    public double getShockEnhancedPeakGamma() throws IllegalArgumentException {
        return shockEnhancedPeakEnergySpectrum.getGamma();
    }    

    /**
     * Returns the E0 parameter of the energy spectrum of the shock enhanced peak. 
     * @return The E0 value.
     * @throws IllegalArgumentException If E0 is not defined.
     */
    public double getShockEnhancedPeakE0() throws IllegalArgumentException {
    	return shockEnhancedPeakEnergySpectrum.getE0();
    }
    
    /**
     * Returns the cumulative dose that an astronaut would receive from the event and its shock enhanced peak. 
     * The does is returned based on an input thickness to the Skin Eye or BFO for each SPE. 
     * This method can return dose equivalent (RAD) or absorbed dose (REM) in free space or lunar surface. 
     * Dose on the lunar surface is 1/2 the dose in free space because the moon blocks out half the radiation dose.
     * @param thickness The thickness under which the dose is required.
     * @param remOrRad The type of radiation dose to return.
     * @param skinEyeOrBFO Where to return dose from.
     * @param lunarSurfaceOrFreeSpace Where the dose is received.
     * @return The desired dose.
     * @throws IllegalArgumentException If the energy spectrum of the event or shock enhanced peak are not defined. 
     */
    public double getDose(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO,
			DoseLocation lunarSurfaceOrFreeSpace)  throws IllegalArgumentException {
		return( getDose_1(thickness, remOrRad,skinEyeOrBFO,lunarSurfaceOrFreeSpace)+
				getShockEnhancedPeakDose(thickness,remOrRad,skinEyeOrBFO,lunarSurfaceOrFreeSpace));		
    }

    /**
     * Returns the cumulative dose that an astronaut would receive from the event.
     * @param thickness The thickness under which the dose is required.
     * @param remOrRad The type of radiation dose to return.
     * @param skinEyeOrBFO Where to return dose from.
     * @param lunarSurfaceOrFreeSpace Where the dose is received.
     * @return The desired dose.
     * @throws IllegalArgumentException If the event's energy spectrum is not defined. 
     */
    public double getDose_1(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO,
			DoseLocation lunarSurfaceOrFreeSpace)  throws IllegalArgumentException {
    	if (radiationDoseValues==null) radiationDoseValues=new RadiationDoseValues();
    	double dose= radiationDoseValues.getDose(getK_1(),getGamma_1(),getE0_1(),thickness,remOrRad,skinEyeOrBFO);
    	if (lunarSurfaceOrFreeSpace == DoseLocation.LUNAR_SURFACE) return dose/2;   	
    	return dose;
    }
    
    /**
     * Returns the cumulative dose that an astronaut would receive from the shock enhanced peak.
     * @param thickness The thickness under which the dose is required.
     * @param remOrRad The type of radiation dose to return.
     * @param skinEyeOrBFO Where to return dose from.
     * @param lunarSurfaceOrFreeSpace Where the dose is received.
     * @return The desired dose.
     * @throws IllegalArgumentException If the shock enhanced peak's energy spectrum is not defined. 
     */
    public double getShockEnhancedPeakDose(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO,
			DoseLocation lunarSurfaceOrFreeSpace)  throws IllegalArgumentException {
    	if (radiationDoseValues==null) radiationDoseValues=new RadiationDoseValues();
    	double dose= radiationDoseValues.getDose(getShockEnhancedPeakK(),getShockEnhancedPeakGamma(),getShockEnhancedPeakE0(),thickness,remOrRad,skinEyeOrBFO);
    	if (lunarSurfaceOrFreeSpace == DoseLocation.LUNAR_SURFACE) return dose/2;   	
    	return dose;
    }

    /**
     * Calculates the flux of the time evolution of the event and shock enhanced peak for a given
     * time value. Here, the C's are calculated automatically so that 
     * the total number of particles form the energy spectrum (the integral fluence) and the total number of
     * particles from the time evolution (the integral flux) are the same. 
     * This ensure that the 2 separate curves for each event are really talking about the same event.
     * Background is the background ever present GCR radiation. It's value is determined by {@link TimeEvolution#BACKGROUND}.
     * @param timeInput The time to find the flux for.
     * @return the time evolution flux at a particular time.
     * @throws If any part of the energy spectrum or time evolution are not set correctally.
     */
    public double getTimeEvolutionFluxWithCWithGCR(Time timeInput) throws IllegalArgumentException {
    	return (getTimeEvolutionFluxWithCWithoutGCR(timeInput)+TimeEvolution.BACKGROUND);
    }  

    /**
     * Calculates the flux of the time evolution of the event and shock enhanced peak for a given
     * time value. Here, the C's are calculated automatically so that 
     * the total number of particles form the energy spectrum (the integral fluence) and the total number of
     * particles from the time evolution (the integral flux) are the same. 
     * This ensure that the 2 separate curves for each event are really talking about the same event.
     * @param timeInput The time to find the flux for.
     * @return the time evolution flux at a particular time.
     * @throws If any part of the energy spectrum or time evolution are not set correctally.
     */
    private double getTimeEvolutionFluxWithCWithoutGCR(Time timeInput) throws IllegalArgumentException {
    	return (this.getC_1()*timeEvolution_1.getFluxWithoutCWithoutGCR(timeInput)+
    			this.getShockEnhancedPeakC()*shockEnhancedPeakTimeEvolution.getFluxWithoutC(timeInput));
    }  
    
    /**
     * Returns the time evolution integral flux for the event from timeMin to timeMax.
     * This function does <b>NOT</b> include the GCR background radiation {@link TimeEvolution#BACKGROUND} or C.
     * @param timeMin The lower bound on the integral.
     * @param timeMax The upper bound on the integral.
     * @return The time evolution integral flux.
     * @throws IllegalArgumentException If the time evolution has not been properly defined.
     */
    public double getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time timeMin, Time timeMax)
    throws IllegalArgumentException {
    	return timeEvolution_1.getIntegralFluxWithoutCWithoutGCR(timeMin,timeMax);
    }   
    
    /**
     * Returns the time evolution integral flux for the shock enhanced peak from timeMin to timeMax.
     * This function does <b>NOT</b> include the GCR background radiation {@link TimeEvolution#BACKGROUND} or C.
     * @param timeMin The lower bound on the integral.
     * @param timeMax The upper bound on the integral.
     * @return The time evolution integral flux.
     * @throws IllegalArgumentException If the time evolution has not been properly defined.
     */
    public double getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time timeMin, Time timeMax)
    throws IllegalArgumentException {
    	return shockEnhancedPeakTimeEvolution.getIntegralFluxWithoutC(timeMin,timeMax);
    }
    
    /** 
     * Decides whether or not the total time evolution integral flux decreases fast enough.
     * The time evolution is considered to decrease fast enough if the total number of
     * particles (time evolution integral flux)
     * during the 6th day is less then 1/100th of the total number of particles
     * from the first 5 days.
     * @return <code>true</code> if the number of particles from the sixth day is less then
     * 1/100th the number of particles from the first five days. <code>false</code> otherwise.
     */
    public boolean doesTimeEvolutionIntegralFluxDecreaseFastEnough() {
    	double firstFiveDays=getC_1()*getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5))+
    		getShockEnhancedPeakC()*getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5));
    	
    	double sixthDay=getC_1()*getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6))+
    		getShockEnhancedPeakC()*getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6));
    	if (sixthDay<.01*firstFiveDays) return true;
    	return false;
    }
    
    /**
     * This function decides if the SPE is sufficiently 'large'. The criteria for an SPE being
     * "large" is that at any point in time from 0 to 10 days the flux (including C)
     * is larger then the BACKGROUND radiation. If, at some point in time, the flux (including C)
     * is larger then the BACKGROUND radiation, true is returned. Otherwise, false is returned.
     * <p>
     * This is useful as a warning for the user. If this returns false, you know to warn the user
     * to make K_1, K_2 or the energy spectrum integral fluence of event 1 or event 2 bigger (to increase the size of the SPE).
     * @return <code>true</code> if the time evolution flux (including C) is larger then the BACKGROUND
     * radiation at any point in time during the SPE. <code>false</code> otherwise.
     */
    public boolean isEventLargeEnough() {
        Time timeMin=Time.inDays(0);
        Time timeMax=Time.inDays(10);
        Time timeStep=Time.inDays(0.1);
    	for(Time time=(Time)timeMin.clone();time.getDays()<timeMax.getDays();time.add(timeStep)) 
    		// use the total time evolution flux from event and shock enhanced peak.
		    if (this.getTimeEvolutionFluxWithCWithoutGCR(time) > TimeEvolution.BACKGROUND) return true;
		return false;
    }
    
    /**
     * Like {@link SolarParticleEvent#simulateAstronautOnTheMoon},
     * this method simulates a man on the moon during a solar particle event. To do this we must be able
     * to find the dose received by a person on the lunar surface during any period of time during the event.
     * To calculate the dose that a person received under a given thickness x with a given total dose Dose<sub>x</sub>,
     * we use the formula:
     * <pre>
     *	C<sub>x</sub> = Dose<sub>x</sub> / The integral of the time evolution flux from 0 to 10 days.
     * </pre>
     * This essentially creates a new C for the time evolution curve such that if we now integrate form 0 to 10 days,
     * we get the total dose. Now, the dose from T<sub>start</sub> to T<sub>stop</sub> is:
     * <pre>
     * 	Dose = C<sub>x</sub>*The integral of the time evolution flux without C from T<sub>start</sub> to T<sub>stop</sub>.
     * </pre>
     * Therefore, when we want to simulate an astronaut on the moon under different thicknesses, we first calculate
     * new Cs for all thicknesses desired. We then integrate for the desired time periods with the desired Cs to
     * figure out all the individual doses during the event. The sum of them is the total dose received by an
     * astronaut.     
     * 
     * Unlike {@link SolarParticleEvent#simulateAstronautOnTheMoon}, this function operates differently because it
     * needs to deal with both an event and a shock enhanced peak. Thus, C values are created separately for the event 
     * and it's shock enhanced peak and doses are calculated individually for the event and the peak.
     * Afterwards, the total dose is calculated as the sum of
     * the dose of the event and the peak.
     * @param remOrRad rem (dose equivalent) or rad (absorbed dose).
     * @param skinEyeOrBFO Specifies dose to the skin, eye, or BFO.
     * @param priorToWarning The amount of time before the beginning of the SPE that the astronaut is given warning
     * that the event is about to happen. A negative value implies the time <b>AFTER</b> the event has begun
     * before he is given warning about the event.
     * @param thicknessPriorToWarning The thickness the astronaut is under during the time prior to warning.
     * @param packingUp The time it takes him to pack up and enter the rover.
     * @param thicknessPackingUp The thickness he is under when he packs up and enters the rover.
     * @param transitToBase The time it takes him to drive back to the base.
     * @param thicknessTransitToBase The thickness he is under when he drives back to the base.
     * @param thicknessAtBase The thickness he is under at the base until the end of the event (Until 10 days ends).
     * @param cumulativeDoseGraph A graph holding the cumulative dose over time.
     * @return An object holding all desired information. This includes doses and percents of total
     *  during different stages of the event. It also includes
     * the total dose the astronaut received and the ratio of total dose to dose under shelter the whole time.
     * @throws IllegalArgumentException If any of the SPE is undefined. If the time to pack up and enter the rover
     * or the time it takes to drive back to the base is less then 0 hours. If entire time it takes to get back
     * to the base is greater then 10 days.
     */
    public DoseInformation simulateAstronautOnTheMoon(RadiationType remOrRad,BodyPart skinEyeOrBFO,
    		Time priorToWarning, Thickness thicknessPriorToWarning, Time packingUp, Thickness thicknessPackingUp,
			Time transitToBase, Thickness thicknessTransitToBase, Thickness thicknessAtBase,
			CumulativeDoseGraph cumulativeDoseGraph) throws IllegalArgumentException {
    	    	
		if (packingUp.getDays() < 0)
			throw new IllegalArgumentException("The time it takes to pack up must be >= 0.");
		if (transitToBase.getDays() < 0) 
			throw new IllegalArgumentException("The time it takes to return to the base must be >= 0");
			
		Time lengthOfEvent = Time.inDays(10); 
		
		// total time of simulation must be less then or equal to 10 days.
    	if ((-1*priorToWarning.getDays()+packingUp.getDays()+transitToBase.getDays())> lengthOfEvent.getDays())
			throw new IllegalArgumentException("The arrival time at the base must be at most 10 days");
 
		// total time evolution flux is the time evolution flux without C from 0 to 10 days
    	double timeEvolutionIntegralFlux_1=this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),lengthOfEvent);
    	double timeEvolutionIntegralFlux_2=this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),lengthOfEvent);
    	    	
    	// calculate all the C values
    	double CPriorToOnset_1=this.getDose_1(thicknessPriorToWarning,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CPriorToOnset_2=this.getShockEnhancedPeakDose(thicknessPriorToWarning,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	double CPackingUp_1=this.getDose_1(thicknessPackingUp,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CPackingUp_2=this.getShockEnhancedPeakDose(thicknessPackingUp,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	double CTransitToBase_1=this.getDose_1(thicknessTransitToBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CTransitToBase_2=this.getShockEnhancedPeakDose(thicknessTransitToBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	double CAtBase_1=this.getDose_1(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CAtBase_2=this.getShockEnhancedPeakDose(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	DoseInformation doseInformation = new DoseInformation(); // throw all calculated values into an object to return.
    	
    	// the current time starts at the negative of the time prior to warning.
    	Time currentTime = Time.negative ((Time)priorToWarning.clone());
    	Time timeStepForGraph = Time.inDays(.1); // every twenty minutes
    	
    	cumulativeDoseGraph.reset(remOrRad, skinEyeOrBFO);
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Warning");
    	double dose;
    	double cumulativeDose = 0;
    	
    	
    	for (Time loop = Time.inDays(0); loop.getDays()< currentTime.getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > currentTime.getDays()) 
    			nextTimeInterval = (Time)currentTime.clone();
    		
			dose=CPriorToOnset_1*
				this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
				CPriorToOnset_2*
				this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);		
    		
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
    	// calculate the dose received by the astronaut prior to warning by integrating with the correct C from 0 to the current time.

		doseInformation.dosePriorToWarning=
    		CPriorToOnset_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),currentTime)+
			CPriorToOnset_2*this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),currentTime);
    	    	
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.add(currentTime,packingUp).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.add(currentTime,packingUp).getDays()) 
    			nextTimeInterval = Time.add(currentTime,packingUp);
    		
			dose=CPackingUp_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
				 CPackingUp_2*this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
		// calculate the dose received by the astronaut while packing up by integrating with the correct C from the current time for the amount of time packing up
    	doseInformation.doseWhilePackingUp=
    		CPackingUp_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(currentTime,Time.add(currentTime,packingUp))+
    		CPackingUp_2*this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(currentTime,Time.add(currentTime,packingUp));
    	
    	currentTime.add(packingUp); // advance the current time
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Rover");
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.add(currentTime,transitToBase).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.add(currentTime,transitToBase).getDays()) 
    			nextTimeInterval = Time.add(currentTime,transitToBase);
    		
			dose= CTransitToBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
    			 CTransitToBase_2*this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}   

		// Calculate the dose received by the astronaut while in transit by integrating with the correct C from an advanced current time for the amount of time in transit.
    	doseInformation.doseDuringTransit=
    		CTransitToBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(currentTime,Time.add(currentTime,transitToBase))+
    		CTransitToBase_2*this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(currentTime,Time.add(currentTime,transitToBase));
    	
    	currentTime.add(transitToBase); // advance the current time
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Base");
    	
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.inDays(10).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.inDays(10).getDays())
    			nextTimeInterval = Time.inDays(10);
    		
			dose=CAtBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
    			 CAtBase_2*this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
		
    	// Calculate the dose received by the astronaut in base by integrating with the correct C from an advacned current time to the end of the even (10 days)
    	doseInformation.doseAtBase=
    		CAtBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(currentTime, lengthOfEvent)+
    		CAtBase_2*this.getShockEnhancedPeakTimeEvolutionIntegralFluxWithoutCWithoutGCR(currentTime, lengthOfEvent);
    	
    	// the total time exposed at the base is 10 - the current time (when you get to the base)
    	doseInformation.timeExposedInBase=Time.subtract( lengthOfEvent , currentTime);
    	
    	// the total dose is the sum of all other doses.
    	doseInformation.totalDoseAwayFromShelter=
    		doseInformation.dosePriorToWarning + doseInformation.doseWhilePackingUp +
			doseInformation.doseDuringTransit + doseInformation.doseAtBase;
    	
    	// the ratio higher then always at the base is the total dose away / the total dose at the base
    	doseInformation.ratioHigherThenAlwaysAtBase=doseInformation.totalDoseAwayFromShelter/
			this.getDose(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE);
    	
    	doseInformation.percentOfTotalPriorToWarning=
    		100*doseInformation.dosePriorToWarning/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalWhilePackingUp=
    		100*doseInformation.doseWhilePackingUp/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalDuringTransit=
    		100*doseInformation.doseDuringTransit/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalAtBase=
    		100*doseInformation.doseAtBase/doseInformation.totalDoseAwayFromShelter;
    	    	
    	return doseInformation; // return everything to the user
    }
}