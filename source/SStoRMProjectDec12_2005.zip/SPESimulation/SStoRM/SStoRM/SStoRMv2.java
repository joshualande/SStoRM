package SStoRM;

import javax.swing.ButtonGroup;
import java.awt.Color;
import org.jfree.chart.ChartPanel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.BoxLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.GridLayout;
import javax.swing.JRadioButton;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.JDialog;
import java.awt.Cursor;
import java.net.URL;
import javax.swing.JMenuItem;
/**
 * This program is the GUI application called SStoRMv2. This class interfaces with all the other
 * classes in this package to provide a graphical application to analyze and learn about 
 * solar particle events.
 * <p>
 * To see what this program does and how to use it, please see the attached description of how to use it.
 * <p>
 * This class is really big, and frankly you don't have to know what all of it means. The GUI aspects
 * of this program can all be handled by (and were written by) Eclipse's Visual Editor. So if you just open this
 * with the visual editor, it can give you a graphical interface for modifying the program. 
 * It will draw what everything is and let you modify it easily.
 * There are a couple of important functions that you will need to understand to modify this program.
 * The functions that you will need to personally understand are as follows 
 * <p>
 * <b>Methods for initializing the program</b>
 * <ul>
 * <li>{@link #initializeCoverPanel()}</li>
 * <li>{@link #initializeEnergySpectrumPanel()}</li>
 * <li>{@link #initializeTimeEvolutionPanel()}</li>
 * <li>{@link #initializeEstimatedDosePanel()}</li>
 * <li>{@link #initializeExercisePanel()}</li>
 * <li>{@link #initializeSetUpDialog()}</li>
 * <li>{@link #initializeAboutEditorPane()}</li>
 * <li>And finally {@link #initialize()} </li>
 * </ul>
 * {@link #initialize()} is what is called by the constructor {@link #SStoRMv2()}, which is called directally
 * by {@link #main} when the program is run. So {@link #initialize()} is the key function that
 * initializes the program. {@link #initialize()} calls all other initialization code, so any of the code that isn't 
 * readily apparent from the visual editor is called from {@link #initialize()}.
 * <p>
 * The other functions that you need to worry about are the functions that change the state of the program 
 * after they have started. For simplicity, this program is set up so that whenever a button is pressed,
 * everything is recalculated. The method for recalculating everything is surprisingly enough called
 * {@link #doEverything()}. {@link #doEverything()} then calls 
 * <ul>
 * <li>{@link #doEnergySpectrumCalculations}</li>
 * <li>{@link #doTimeEvolutionCalculations}</li>
 * <li>{@link #doRadiationDoseCalculations}</li>
 * <li>and {@link #doExerciseCalculations}</li>
 * </ul>
 * Each method here will refresh the corresponding tab in the program. And that is basically how the program works.
 * <p>
 * Note that when this class is opened by the visual editor, a part of this class is custom written in
 * such a way that it will not be interpreted by the visual editor. This was done to increase efficiency
 * and decrease the amount of code by removing parallel declarations and creating arrays. 
 * The code in question is the table on the second
 * tab which displays integral fluence in descending order. It is created by {@link #allIntegralFluenceValuesPanel},
 * which creates the panel {@link #integralFluenceValuePanel}. Because this is not editable by the visual editor,
 * the objects which do the changes are well documented.
 * 
 * @author Joshua Lande
 */
public class SStoRMv2 extends JFrame {
	
	private Color background = null;
	private ButtonGroup freeSpaceLunarOrLunarSurfaceButtonGroup = null;
	private ButtonGroup remOrRadButtonGroup = null;
    
	private ButtonGroup skinEyeOrBFOButtonGroup;
	private ButtonGroup priorToOnsetMinutesOrHoursButtonGroup = null;
	private ButtonGroup packingUpMinutesOrHoursButtonGroup = null;
	private ButtonGroup transitMinutesOrHoursButtonGroup = null;
	private ButtonGroup inBaseMinutesOrHoursButtonGroup = null;
	
	private ButtonGroup spaceSuitThicknessButtonGroup = null;
	private ButtonGroup roverThicknessButtonGroup = null;
	private ButtonGroup baseThicknessButtonGroup = null;
	
	private DoubleEvent yourSPE=null;
    private SolarParticleEventInterface[] allSPEs;
    
    private ChartPanel energySpectrumChartPanel=null;  //  @jve:decl-index=0:visual-constraint="9,1274"
    private ChartPanel timeEvolutionChartPanel=null;  //  @jve:decl-index=0:visual-constraint="11,1595"
    private ChartPanel radiationDoseChartPanel=null;  //  @jve:decl-index=0:visual-constraint="10,1909"
    private ChartPanel cumulativeDoseChartPanel = null;  //  @jve:decl-index=0:visual-constraint="401,722"

    private EnergySpectrumGraph energySpectrumFluxGraph=null;
    private TimeEvolutionGraph timeEvolutionFluxGraph=null;
    private RadiationDoseGraph radiationDoseGraph=null;
    private CumulativeDoseGraph cumulativeDoseGraph = null;

	/** 
	 * This is the panel that holds the integral fluences sorted into descending order.
	 */
	private JPanel allIntegralFluenceValuesPanel = null;
	
	/**
	 * This is the array of panels that holds rows of integral fluences (both the name and value).
	 */
	private JPanel integralFluenceContainerPanel[] = new JPanel[7];
	
	/**
	 * This is the array of panels that holds names of integral fluences.
	 */
	private JPanel integralFluenceNamePanel[] = new JPanel[7];
	
	/**
	 * This is the array panels that holds values of integral fluences.
	 */
	private JPanel integralFluenceValuePanel[] = new JPanel[7];
	
	/**
	 * This is the array of labels that holds names of integral fluences.
	 */
	private JLabel integraFluenceNameLabel[] = new JLabel[7];
	
	/**
	 * This is the array of labels that holds values of integral fluences.
	 */
	private JLabel integraFluenceValueLabel[] = new JLabel[7];
	
	private javax.swing.JMenuBar jJMenuBar = null;  //  @jve:decl-index=0:
	private javax.swing.JMenu fileMenu = null;
	private javax.swing.JMenu helpMenu = null;
	private javax.swing.JMenuItem exitMenuItem = null;
	private JTabbedPane jTabbedPane = null;  //  @jve:decl-index=0:
	private JPanel coverPanel = null;
	private JPanel energySpectrumPanel = null;  //  @jve:decl-index=0:
	private JPanel timeEvolutionPanel = null;  //  @jve:decl-index=0:
	private JLabel titleLabel = null;  //  @jve:decl-index=0:
	private JLabel energySpectrumTitleLabel = null;
	private JPanel energySpectumInputPanel = null;  //  @jve:decl-index=0:
	private JPanel KPanel = null;
	private JPanel gammaPanel = null;
	private JPanel E0Panel = null;
	private JPanel EminPanel = null;
	private JTextField EminInput = null;
	private JTextField E0Input_1 = null;
	private JTextField gammaInput_1 = null;
	private JTextField KInput_1 = null;
	private JButton energySpectrumCalculateButton = null;
	private JLabel integralFluenceTitleLabel = null;	
	private JLabel timeEvolutionTitleLabel = null;
	private JPanel timeEvolutionInputPanel = null;
	private JPanel AInputPanel = null;
	private JPanel B1InputPanel = null;
	private JPanel B2InputPanel = null;  //  @jve:decl-index=0:
	private JPanel CNotInputPanel = null;
	private JPanel AInputNamePanel = null;
	private JPanel AInputValuePanel_1 = null;
	private JPanel B1InputNamePanel = null;
	private JPanel B1InputValuePanel_1 = null;
	private JPanel B2InputNamePanel = null;
	private JPanel B2InputValuePanel_1 = null;
	private JLabel AInputNameLabel = null;
	private JLabel B1InputNameLabel = null;
	private JLabel B2InputNameLabel = null;
	private JTextField AInput_1 = null;  //  @jve:decl-index=0:
	private JTextField B1Input_1 = null;
	private JTextField B2Input_1 = null;  //  @jve:decl-index=0:
	private JButton timeEvolutionCalculateButton = null;  //  @jve:decl-index=0:
	private JPanel estimatedDosePanel = null;
	private JLabel estimatedDoseLabel = null;
	private JPanel doseDataTablePanel = null;
	private JLabel spectraUnitsLabel = null;
	private JPanel doseDataTableTitlePanel = null;
	private JPanel doseDataPanel = null;
	private JPanel doseDataSkinEyeBFOPanel = null;  //  @jve:decl-index=0:
	private JPanel doseDataOuterTabelPanel = null;
	private JPanel eyeDataPanel = null;
	private JPanel skinDataPanel = null;
	private JPanel doseDataAluminumSheildingPanel = null;
	private JPanel doseDataThicknessPanel = null;
	private JPanel doseDataEyePanel = null;
	private JPanel doseDataSkinPanel = null;
	private JPanel doseDataBlankCornerPanel2 = null;  //  @jve:decl-index=0:
	private JPanel doseDataBlankCornerPanel1 = null;
	private JLabel doseDataSkinLabel = null;
	private JPanel doseDataBFOPanel = null;
	private JPanel BFODataPanel = null;
	private JLabel doseDataEyeLabel = null;
	private JLabel doseDataBFOLabel = null;
	private JLabel doseDataTableTitleLabel = null;
	private JLabel doseDataAluminumSheildingLabel = null;  //  @jve:decl-index=0:
	private JPanel doseDataThicknessPointThreePanel = null;
	private JPanel doseDataThicknessOnePanel = null;
	private JPanel doseDataThicknessFivePanel = null;
	private JPanel doseDataThicknessTenPanel = null;
	private JPanel skinPointThreePanel = null;
	private JPanel skinOnePanel = null;  //  @jve:decl-index=0:
	private JPanel skinFivePanel = null;
	private JPanel skinTenPanel = null;
	private JPanel eyePointThreePanel = null;
	private JPanel eyeOnePanel = null;
	private JPanel eyeFivePanel = null;
	private JPanel eyeTenPanel = null;
	private JPanel BFOPointThreePanel = null;  //  @jve:decl-index=0:
	private JPanel BFOOnePanel = null;
	private JPanel BFOFivePanel = null;
	private JPanel BFOTenPanel = null;
	private JPanel BFOThirtyPanel = null;
	private JPanel doseDataThicknessThirtyPanel = null;
	private JPanel skinThirtyPanel = null;
	private JPanel eyeThirtyPanel = null;
	private JLabel doseDataThicknessPointThreeLabel = null;
	private JLabel doseDataThicknessOneLabel = null;
	private JLabel doseDataThicknessFiveLabel = null;
	private JLabel doseDataThicknessTenLabel = null;
	private JLabel doseDataThicknessThirtyLabel = null;
	private JLabel skinPointThreeLabel = null;
	private JLabel skinOneLabel = null;
	private JLabel skinFiveLabel = null;  //  @jve:decl-index=0:
	private JLabel skinTenLabel = null;
	private JLabel skinThirtyLabel = null;
	private JLabel eyePointThreeLabel = null;
	private JLabel eyeOneLabel = null;
	private JLabel eyeFiveLabel = null;
	private JLabel eyeTenLabel = null;
	private JLabel eyeThirtyLabel = null;
	private JLabel BFOPointThreeLabel = null;
	private JLabel BFOOneLabel = null;
	private JLabel BFOFiveLabel = null;
	private JLabel BFOTenLabel = null;
	private JLabel BFOThirtyLabel = null;
	private JPanel lunarSurfaceOrFreeSpacePanel = null;
	private JPanel lunarSurfacePanel = null;
	private JPanel freeSpacePanel = null;
	private JPanel freeSpaceRadioButtonPanel = null;  //  @jve:decl-index=0:
	private JPanel lunarSurfaceRadioButtonLabel = null;
	private JPanel freeSpaceLabelPanel = null;
	private JPanel lunarSurfaceLabelPanel = null;
	private JRadioButton freeSpaceRadioButton = null;
	private JRadioButton lunarSurfaceRadioButton = null;
	private JLabel freeSpaceLabel = null;
	private JLabel lunarSurfaceLabel = null;
	private JPanel remOrRadPanel = null;
	private JPanel remPanel = null;
	private JPanel radPanel = null;
	private JPanel radRadioButtonPanel = null;
	private JPanel radLabelPanel = null;
	private JPanel remRadioButtonPanel = null;
	private JPanel remLabelPanel = null;
	private JRadioButton radRadioButton = null;  //  @jve:decl-index=0:
	private JRadioButton remRadioButton = null;
	private JLabel radLabel = null;
	private JLabel remLabel = null;
	private JScrollPane timeEvolutionDescriptionScrollPane = null;
	private JEditorPane timeEvolutionDescriptionPane = null;
	private JPanel CNotInputNamePanel = null;
	private JPanel CNotInputValuePanel_1 = null;
	private JLabel CNotInputNameLabel = null;
	private JTextField CNotInput_1 = null;
	private JPanel exercisePanel = null;
	private JPanel exerciseDoseSummaryPanel = null;
	private JPanel exerciseDoseSummaryTitlePanel = null;
	private JPanel exerciseDoseSummaryThicknessLabelPanel = null;  //  @jve:decl-index=0:
	private JPanel exerciseDoseSummaryValuePanel = null;
	private JLabel exerciseDoseSummaryTitleLabel = null;
	private JPanel exerciseDoseSummaryThicknessPointThreePanel = null;  //  @jve:decl-index=0:
	private JPanel exerciseDoseSummaryThicknessOneLabelPanel = null;
	private JPanel exerciseDoseSummaryThicknessPointThreeValuePanel = null;
	private JPanel exerciseDoseSummaryThicknessFiveLabelPanel = null;
	private JPanel exerciseDoseSummaryThicknessTenLabelPanel = null;
	private JPanel exerciseDoseSummaryThicknessThirtyLabelPanel = null;  //  @jve:decl-index=0:
	private JPanel exerciseDoseSummaryThicknessOneValuePanel = null;
	private JPanel exerciseDoseSummaryThicknessFiveValuePanel = null;
	private JPanel exerciseDoseSummaryThicknessTenValuePanel = null;
	private JPanel exerciseDoseSummaryThicknessThirtyValuePanel = null;
	private JLabel exerciseDoseSummaryThicknessPointThreeLabel = null;  //  @jve:decl-index=0:
	private JLabel exerciseDoseSummaryThicknessOneLabel = null;
	private JLabel exerciseDoseSummaryThicknessFiveLabel = null;
	private JLabel exerciseDoseSummaryThicknessTenLabel = null;
	private JLabel exerciseDoseSummaryThicknessThirtyLabel = null;
	private JLabel exerciseDoseSummaryThicknessPointThreeValue = null;
	private JLabel exerciseDoseSummaryThicknessOneValue = null;
	private JLabel exerciseDoseSummaryThicknessFiveValue = null;
	private JLabel exerciseDoseSummaryThicknessTenValue = null;
	private JLabel exerciseDoseSummaryThicknessThirtyValue = null;
	private JPanel exerciseTimeSelectionPanel = null;
	private JPanel exerciseTimeSelectionLabelsPanel = null;
	private JPanel exerciseTimeSelectionPriorToOnsetPanel = null;
	private JPanel exerciseTimeSelectionPackingUpPanel = null;
	private JPanel exerciseTimeSelectionTransitPanel = null;
	private JPanel exerciseTimeSelectionInBasePanel = null;
	private JPanel exerciseTimeSelectionPriorToOnsetLabelPanel = null;
	private JPanel exerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel = null;
	private JPanel exerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel = null;
	private JLabel exerciseTimeSelectionPriorToOnsetLabel = null;
	private JRadioButton priorToOnsetMinutesRadioButton = null;
	private JRadioButton priorToOnsetHoursRadioButton = null;
	private JPanel exerciseTimeSelectionPriorToOnsetDoseValuePanel = null;
	private JPanel exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel = null;
	private JPanel exerciseTimeSelectionPriorToOnsetInputPanel = null;
	private JTextField exerciseTimeSelectionPriorToOnsetInput = null;
	private JPanel exerciseTimeSelectionPackingUpLabelPanel = null;
	private JPanel exerciseTimeSelectionPackingUpInputPanel = null;
	private JPanel exerciseTimeSelectionPackingUpMinutesRadioButtonLabel = null;
	private JPanel exerciseTimeSelectionPackingUpHoursRadioButtonPanel = null;
	private JPanel exerciseTimeSelectionPackingUpDoseValuePanel = null;
	private JLabel exerciseTimeSelectionPackingUpLabel = null;
	private JTextField exerciseTimeSelectionPackingUpInput = null;
	private JRadioButton packingUpMinutesRadioButton = null;
	private JRadioButton packingUpHoursRadioButton = null;
	private JPanel exerciseTimeSelectionPackingUpPercentOfTotalValuePanel = null;
	private JPanel exerciseTimeSelectionTransitLabelPanel = null;
	private JPanel exerciseTimeSelectionTransitInputPanel = null;
	private JPanel exerciseTimeSelectionTransitMinutesRadioButtonPanel = null;
	private JPanel exerciseTimeSelectionTransitHoursRadioButtonPanel = null;
	private JPanel exerciseTimeSelectionTransitPercentOfTotalValuePanel = null;
	private JPanel exerciseTimeSelectionInBaseNotInputPanel = null;
	private JPanel exerciseTimeSelectionInBaseMinutesRadioButtonPanel = null;  //  @jve:decl-index=0:
	private JPanel exerciseTimeSelectionInBaseDoseValuePanel = null;
	private JPanel exerciseTimeSelectionInBasePercentOfTotalValuePanel = null;
	private JPanel exerciseTimeSelectionTopLeftCornerPanel = null;
	private JPanel exerciseTimeSelectionTimeInputLabelPanel = null;  //  @jve:decl-index=0:
	private JPanel exerciseTimeSelectionMinutesInputLabelPanel = null;
	private JPanel exerciseTimeSelectionHoursInputLabelPanel = null;  //  @jve:decl-index=0:
	private JPanel exerciseTimeSelectionDoseLabelPanel = null;
	private JLabel exerciseTimeSelectionTransitLabel = null;
	private JLabel exerciseTimeSelectionTimeInputLabel = null;
	private JPanel exerciseTimeSelectionPercentOfTotalValuePanel = null;
	private JPanel exerciseTimeSelectionTransitDoseValuePanel = null;
	private JPanel exerciseTimeSelectionInBaseLabelPanel = null;
	private JLabel exerciseTimeSelectionInBaseLabel = null;
	private JTextField exerciseTimeSelectionTransitInput = null;
	private JTextField exerciseTimeSelectionInBaseNotInput = null;
	private JRadioButton transitMinutesRadioButton = null;
	private JRadioButton transitHoursRadioButton = null;
	private JRadioButton inBaseMinutesRadioButton = null;
	private JLabel exerciseTimeSelectionMinutesInputLabel = null;  //  @jve:decl-index=0:
	private JLabel exerciseTimeSelectionHoursInputLabel = null;
	private JLabel exerciseTimeSelectionDoseValue = null;
	private JLabel exerciseTimeSelectionPercentOfTotalValue = null;
	private JLabel exerciseTimeSelectionPackingUpDoseValue = null;  //  @jve:decl-index=0:
	private JLabel exerciseTimeSelectionPackingUpPercentOfTotalValue = null;
	private JLabel exerciseTimeSelectionTransitDoseValue = null;
	private JLabel exerciseTimeSelectionTransitPercentOfTotalValue = null;  //  @jve:decl-index=0:
	private JLabel exerciseTimeSelectionInBaseDoseValue = null;
	private JLabel exerciseTimeSelectionInBasePercentOfTotalValue = null;
	private JLabel exerciseDoseLabel = null;  //  @jve:decl-index=0:
	private JPanel exerciseTotalTimeEvolutionDosePanel = null;
	private JPanel exerciseTotalTimeEvolutionDoseAwayFromShelterPanel = null;
	private JPanel exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel = null;
	private JPanel exerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel = null;
	private JPanel exerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel = null;
	private JPanel exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel = null;
	private JPanel exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel = null;  //  @jve:decl-index=0:
	private JLabel exerciseTotalTimeEvolutionDoseAwayFromShelterLabel = null;
	private JLabel exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabel = null;  //  @jve:decl-index=0:
	private JTextField exerciseTotalTimeEvolutionDoseAwayFromShelterValue = null;
	private JTextField exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue = null;
	private JButton exerciseCalculateButton = null;
	private JPanel exerciseSkinEyeOrBFOPanel = null;
	private JPanel exerciseSkinPanel = null;
	private JPanel exerciseEyePanel = null;
	private JPanel exerciseBFOPanel = null;
	private JPanel exerciseSkinLabelPanel = null;
	private JPanel exerciseSkinRadioButtonPanel = null;
	private JPanel exerciseEyeLabelPanel = null;
	private JPanel exerciseEyeRadioButtonPanel = null;
	private JPanel exerciseBFOLabelPanel = null;
	private JPanel exerciseBFORadioButtonPanel = null;
	private JLabel exerciseSkinLabel = null;
	private JLabel exerciseEyeLabel = null;  //  @jve:decl-index=0:
	private JLabel exerciseBFOLabel = null;
	private JRadioButton skinRadioButton = null;
	private JRadioButton eyeRadioButton = null;
	private JRadioButton BFORadioButton = null;
	private JPanel exerciseTimeSelectionInBaseHoursRadioButtonPanel = null;
	private JRadioButton inBaseHoursRadioButton = null;
	private JLabel exerciseTimeSelectionPriorToOnsetDoseValue = null;
	private JLabel exerciseTimeSelectionPriorToOnsetPercentOfTotalValue = null;
	private JScrollPane classExerciseDescriptionScrollPane = null;
	private JEditorPane classExerciseDescriptionPane = null;
	private JButton setUpButton = null;
	private JPanel setUpContentPane = null;
	private JDialog setUpDialog = null;  //  @jve:decl-index=0:visual-constraint="15,720"
	private JLabel setUpTitleLabel = null;
	private JPanel setUpThicknessTablePanel = null;
	private JPanel setUpThicknessTabelSpaceSuitPanel = null;
	private JPanel setUpThicknessTabelRoverPanel = null;
	private JPanel setUpThicknessTabelBasePanel = null;
	private JPanel setUpThicknessTabelSpaceSuitLabelPanel = null;
	private JPanel setUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel = null;
	private JPanel setUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel = null;
	private JPanel setUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel = null;
	private JPanel setUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel = null;  //  @jve:decl-index=0:
	private JPanel setUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel = null;
	private JPanel setUpThicknessTableRoverLabelPanel = null;
	private JPanel setUpThicknessTableRoverThicknessPointThreeRadioButtonPanel = null;
	private JPanel setUpThicknessTableRoverThicknessOneRadioButtonPanel = null;
	private JPanel setUpThicknessTableRoverThicknessFiveRadioButtonPanel = null;
	private JPanel setUpThicknessTableRoverThicknessTenRadioButtonPanel = null;
	private JPanel setUpThicknessTableRoverThicknessThirtyRadioButtonPanel = null;
	private JPanel setUpThicknessTableBaseLabelPanel = null;
	private JPanel setUpThicknessTableBaseThicknessPointThreeRadioButtonPanel = null;
	private JPanel setUpThicknessTableBaseThicknessOneRadioButtonPanel = null;
	private JPanel setUpThicknessTableBaseThicknessFiveRadioButtonPanel = null;
	private JPanel setUpThicknessTableBaseThicknessTenRadioButtonPanel = null;
	private JPanel setUpThicknessTableBaseThicknessThirtyRadioButtonPanel = null;
	private JRadioButton spaceSuitThicknessPointThreeRadioButton = null;
	private JRadioButton spaceSuitThicknessOneRadioButton = null;
	private JRadioButton spaceSuitThicknessFiveRadioButton = null;
	private JRadioButton spaceSuitThicknessTenRadioButton = null;
	private JRadioButton spaceSuitThicknessThirtyRadioButton = null;
	private JRadioButton roverThicknessPointThreeRadioButton = null;
	private JRadioButton roverThicknessOneRadioButton = null;
	private JRadioButton roverThicknessFiveRadioButton = null;
	private JRadioButton roverThicknessTenRadioButton = null;
	private JRadioButton roverThicknessThirtyRadioButton = null;
	private JRadioButton baseThicknessPointThreeRadioButton = null;
	private JRadioButton baseThicknessOneRadioButton = null;
	private JRadioButton baseThicknessFiveRadioButton = null;
	private JRadioButton baseThicknessTenRadioButton = null;
	private JRadioButton baseThicknessThirtyRadioButton = null;
	private JPanel setUpThicknessTableThicknessLabelsPanel = null;
	private JPanel setUpThicknessTableCornerPanel = null;
	private JPanel setUpThicknessTableThicknessPointThreeLabelPanel = null;
	private JPanel setUpThicknessTableThicknessOneLabelPanel = null;
	private JPanel setUpThicknessTableThicknessFiveLabelPanel = null;
	private JPanel setUpThicknessTabelThicknessTenLabelPanel = null;
	private JPanel setUpThicknessTabelThicknessThirtyLabelPanel = null;
	private JLabel setUpThicknessTableThicknessPointThreeLabel = null;
	private JLabel setUpThicknessTableThicknessOneLabel = null;
	private JLabel setUpThicknessTableThicknessFiveLabel = null;
	private JLabel setUpThicknessTabelThicknessTenLabel = null;
	private JLabel setUpThicknessTabelThicknessThirtyLabel = null;
	private JLabel setUpThicknessTabelSpaceSuitLabel = null;
	private JLabel setUpThicknessTableRoverLabel = null;
	private JLabel setUpThicknessTableBaseLabel = null;
	private JButton setUpCloseButton = null;
	private JPanel integraFluencePanel = null;
	private JTextField integralFluenceInput_1 = null;
	private JLabel anserLogoLabel = null;
	private JMenuItem aboutMenuItem = null;
	private JPanel aboutContentPane = null;
	private JDialog aboutDialog = null;  //  @jve:decl-index=0:visual-constraint="30,1019"
	private JEditorPane aboutEditorPane = null;
	private JLabel integralFluenceTitleSubNoteLabel = null;
	private JTextField gammaInput_2 = null;
	private JTextField E0Input_2 = null;
	private JTextField KInput_2 = null;
	private JTextField integralFluenceInput_2 = null;
	private JPanel AInputValuePanel_2 = null;
	private JTextField AInput_2 = null;
	private JPanel B1InputValuePanel_2 = null;
	private JPanel B2InputValuePanel_2 = null;
	private JPanel CNotInputValuePanel_2 = null;
	private JTextField B1Input_2 = null;
	private JTextField B2Input_2 = null;
	private JTextField CNotInput_2 = null;
	private JPanel gammaLabelPanel = null;
	private JLabel jLabel = null;
	private JPanel gammaInputPanel_1 = null;
	private JPanel gammaInputPanel_2 = null;
	private JPanel E0LabelPanel = null;
	private JLabel jLabel1 = null;
	private JPanel E0InputPanel_1 = null;
	private JPanel E0InputPanel_2 = null;
	private JPanel EminLabelPanel = null;
	private JPanel EminInputPanel_1 = null;
	private JLabel EminLabel = null;
	private JPanel KLabelPanel = null;
	private JPanel KInputPanel_1 = null;
	private JPanel KInputPanel_2 = null;
	private JLabel jLabel3 = null;
	private JPanel integralFluenceLabelPanel = null;
	private JPanel integralFluenceInputPanel_1 = null;
	private JPanel integralFluenceInputPanel_2 = null;
	private JLabel jLabel4 = null;
	private JPanel timeDelayBetweenEventsPanel = null;
	private JPanel timeDelayBetweenEventsLabelPanel = null;
	private JPanel timeDelayBetweenEventsInputPanel = null;
	private JTextField timeDelayBetweenEventsInput = null;
	private JLabel timeDelayBetweenEventsLabel = null;
	private JPanel timeEvolutionInputLabelPanel = null;
	private JPanel timeEvolutionInputCornerPanel = null;
	private JPanel timeEvolutionInputEventOnePanel = null;
	private JPanel timeEvolutionInputEventTwoPanel = null;
	private JTextField timeEvolutionInputEventOneLabel = null;
	private JTextField timeEvolutionInputEventTwoLabel = null;
	private JLabel timeEvolutioNInputCornerLabel = null;
	private JPanel energySpectrumLabelPanel = null;
	private JPanel energySpectrumCornerLabelPanel = null;
	private JPanel energySpectrumEventOnePanel = null;
	private JPanel energySpectrumEventTwoPanel = null;
	private JLabel energySpectrumCornerLabel = null;
	private JTextField energySpectrumEventOneLabel = null;
	private JTextField energySpectrumEventTwoLabel = null;
	private JEditorPane coverPanelEditorPane = null;
	private JTabbedPane getJTabbedPane() {
		if (jTabbedPane == null) {
			jTabbedPane = new JTabbedPane();
			jTabbedPane.addTab("Cover", null, getCoverPanel(), null);
			jTabbedPane.addTab("Energy Spectrum", null, getEnergySpectrumPanel(), null);
			jTabbedPane.addTab("Time Evolution", null, getTimeEvolutionPanel(), null);
			jTabbedPane.addTab("Estimated Dose", null, getEstimatedDosePanel(), null);
			jTabbedPane.addTab("Exercise", null, getExercisePanel(), null);
		}
		return jTabbedPane;
	}
	
	private JPanel getCoverPanel() {
		if (coverPanel == null) {
			
			anserLogoLabel = new JLabel();
			titleLabel = new JLabel();
			coverPanel = new JPanel();
			coverPanel.setLayout(null);
			titleLabel.setText("<html><h1>SStoRMv2: the Solar Storm Radiation Model</h1></html>");
			titleLabel.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
			titleLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
			titleLabel.setBounds(15, 15, 571, 76);
			anserLogoLabel.setBounds(555, 0, 106, 91);
			anserLogoLabel.setText("");
			coverPanel.add(titleLabel, null);
			coverPanel.add(anserLogoLabel, null);
			coverPanel.add(getCreatedByEditorPane(), null);
		}
		return coverPanel;
	}

	private JPanel getEnergySpectrumPanel() {
		if (energySpectrumPanel == null) {
			integralFluenceTitleSubNoteLabel = new JLabel();
			integralFluenceTitleLabel = new JLabel();
			energySpectrumTitleLabel = new JLabel();
			energySpectrumPanel = new JPanel();
			energySpectrumPanel.setLayout(null);
			energySpectrumTitleLabel.setText("<html><h1><i>Fluence(E)=kE<sup>-\u03B3</sup>e<sup>-E/Eo</sup></i></h1></html>");
			energySpectrumTitleLabel.setBounds(14, 2, 377, 59);
			integralFluenceTitleLabel.setBounds(330, 15, 335, 21);
			energySpectrumPanel.add(energySpectrumTitleLabel, null);
			energySpectrumPanel.add(getEnergySpectumInputPanel(), null);
			energySpectrumPanel.add(getEnergySpectrumCalculateButton(), null);
			energySpectrumPanel.add(integralFluenceTitleLabel, null);
			energySpectrumPanel.add(getAllIntegralFluenceValuesPanel(), null);
			integralFluenceTitleSubNoteLabel.setBounds(330, 45, 256, 15);
			integralFluenceTitleSubNoteLabel.setText("(ranking relative to other large events)");
			energySpectrumPanel.add(integralFluenceTitleSubNoteLabel, null);
			energySpectrumPanel.add(getEminPanel(), null);
		};
		return energySpectrumPanel;
	}

	private JPanel getTimeEvolutionPanel() {
		if (timeEvolutionPanel == null) {
			timeEvolutionTitleLabel = new JLabel();
			timeEvolutionPanel = new JPanel();
			timeEvolutionPanel.setLayout(null);
			timeEvolutionTitleLabel.setText("<html><h1><i>Flux(t)</i>=C(t/A)<sup>B1</sup>e<sup>-(t/A)^B2</sup>+.11</html>");
			timeEvolutionTitleLabel.setBounds(15, 0, 506, 51);
			timeEvolutionPanel.add(timeEvolutionTitleLabel, null);
			timeEvolutionPanel.add(getTimeEvolutionInputPanel(), null);
			timeEvolutionPanel.add(getTimeEvolutionCalculateButton(), null);
			timeEvolutionPanel.add(getTimeEvolutionDescriptionScrollPane(), null);
			timeEvolutionPanel.add(getTimeDelayBetweenEventsPanel(), null);
		}
		return timeEvolutionPanel;
	}

	private JPanel getEnergySpectumInputPanel() {
		if (energySpectumInputPanel == null) {
			energySpectumInputPanel = new JPanel();
			energySpectumInputPanel.setLayout(new BoxLayout(energySpectumInputPanel, BoxLayout.Y_AXIS));
			energySpectumInputPanel.setBounds(30, 75, 271, 151);
			energySpectumInputPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
			energySpectumInputPanel.add(getEnergySpectrumLabelPanel(), null);
			energySpectumInputPanel.add(getGammaPanel(), null);
			energySpectumInputPanel.add(getE0Panel(), null);
			energySpectumInputPanel.add(getKPanel(), null);
			energySpectumInputPanel.add(getIntegraFluencePanel(), null);
		}
		return energySpectumInputPanel;
	}

	private JPanel getKPanel() {
		if (KPanel == null) {
			KPanel = new JPanel();
			KPanel.setLayout(new BoxLayout(KPanel, BoxLayout.X_AXIS));
			KPanel.setPreferredSize(new java.awt.Dimension(75,25));
			KPanel.add(getKLabelPanel(), null);
			KPanel.add(getKInputPanel_1(), null);
			KPanel.add(getKInputPanel_2(), null);
		}
		return KPanel;
	}

	private JPanel getGammaPanel() {
		if (gammaPanel == null) {
			gammaPanel = new JPanel();
			gammaPanel.setLayout(new BoxLayout(gammaPanel, BoxLayout.X_AXIS));
			gammaPanel.setPreferredSize(new java.awt.Dimension(75,25));
			gammaPanel.add(getGammaLabelPanel(), null);
			gammaPanel.add(getGammaInputPanel_1(), null);
			gammaPanel.add(getGammaInputPanel_2(), null);
		}
		return gammaPanel;
	}

	private JPanel getE0Panel() {
		if (E0Panel == null) {
			E0Panel = new JPanel();
			E0Panel.setLayout(new BoxLayout(E0Panel, BoxLayout.X_AXIS));
			E0Panel.setPreferredSize(new java.awt.Dimension(75,25));
			E0Panel.add(getE0LabelPanel(), null);
			E0Panel.add(getE0InputPanel_1(), null);
			E0Panel.add(getE0InputPanel_2(), null);
		}
		return E0Panel;
	}

	private JPanel getEminPanel() {
		if (EminPanel == null) {
			EminPanel = new JPanel();
			EminPanel.setLayout(new BoxLayout(EminPanel, BoxLayout.X_AXIS));
			EminPanel.setPreferredSize(new java.awt.Dimension(75,25));
			EminPanel.setBounds(new java.awt.Rectangle(30,240,136,31));
			EminPanel.add(getEminLabelPanel(), null);
			EminPanel.add(getEminInputPanel_1(), null);
		}
		return EminPanel;
	}

	private JTextField getEminInput() {
		if (EminInput == null) {
			EminInput = new JTextField();
			EminInput.setPreferredSize(new java.awt.Dimension(20,16));
			EminInput.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					energySpectrumCalculateButton.requestFocus();
				}
			});
		}
		return EminInput;
	}

	private JTextField getE0Input_1() {
		if (E0Input_1 == null) {
			E0Input_1 = new JTextField();
			E0Input_1.setPreferredSize(new java.awt.Dimension(20,16));
			E0Input_1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					E0Input_2.requestFocus();
				}
			});
		}
		return E0Input_1;
	}

	private JTextField getGammaInput_1() {
		if (gammaInput_1 == null) {
			gammaInput_1 = new JTextField();
			gammaInput_1.setPreferredSize(new java.awt.Dimension(20,16));
			gammaInput_1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					gammaInput_2.requestFocus();
				}
			});
		}
		return gammaInput_1;
	}

	private JTextField getKInput_1() {
		if (KInput_1 == null) {
			KInput_1 = new JTextField();
			KInput_1.setPreferredSize(new java.awt.Dimension(20,16));
			KInput_1.addKeyListener(new java.awt.event.KeyAdapter() { 
				public void keyTyped(java.awt.event.KeyEvent e) {    
					integralFluenceInput_1.setText("");
					integralFluenceInput_2.setText("");
					
				}
			});
			KInput_1.addFocusListener(new java.awt.event.FocusAdapter() { 
				public void focusGained(java.awt.event.FocusEvent e) {  
					KInput_1.setEditable(true); 
					KInput_2.setEditable(true);
					integralFluenceInput_1.setEditable(false);
					integralFluenceInput_2.setEditable(false);
					integralFluenceInput_1.setText("");
					integralFluenceInput_2.setText("");
					KInput_1.setBackground(Color.WHITE);
					KInput_2.setBackground(Color.WHITE);
					integralFluenceInput_1.setBackground(background); 
					integralFluenceInput_2.setBackground(background); 
					// so a tab from Emin input will now jump to the K
					E0Input_2.setNextFocusableComponent(KInput_1);
					
				}
			});
			KInput_1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					KInput_2.requestFocus();
				}
			});
		}
		return KInput_1;
	}

	private JButton getEnergySpectrumCalculateButton() {
		if (energySpectrumCalculateButton == null) {
			energySpectrumCalculateButton = new JButton();
			energySpectrumCalculateButton.setBounds(180, 240, 121, 31);
			energySpectrumCalculateButton.setText("Calculate");
			energySpectrumCalculateButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					doEverything(WarningStage.ENERGY_SPECTRUM_WARNING);
				}
			});
		}
		return energySpectrumCalculateButton;
	}

	/**
	 * This method creates initializes {@link #allIntegralFluenceValuesPanel},
	 * the table which holds the integral fluence
	 * for all the SPEs. This method isn't understood by the visual editor because
	 * it relies on looping to create all the labels and panels. This is code is
	 * written in spite of the visual editor for increased simplicity and efficiency.
	 * Hopefully the fact that it cannot be read by the visual editor will not hinder
	 * it's use too much.
	 * <p>
	 * This method initializes {@link #allIntegralFluenceValuesPanel} 
	 * by placing all seven of
	 * the {@link #integralFluenceContainerPanel} panels in it. It does this by calling
	 * {@link #getIntegralFluxContainerPanel} for each index of the array (0 through 7).
	 * Each of these panels
	 * holds a corresponding {@link #integralFluenceNamePanel} panel and a
	 * corresponding {@link #integralFluenceValuePanel}. These panels then holds a
	 * corresponding {@link #integraFluenceNameLabel} and  
	 * {@link #integraFluenceValueLabel} that holds the actual values.
	 * 
	 * @return {@link #allIntegralFluenceValuesPanel}, now initialized.
	 */
	private JPanel getAllIntegralFluenceValuesPanel() {
		if (allIntegralFluenceValuesPanel == null) {
			allIntegralFluenceValuesPanel = new JPanel();
			allIntegralFluenceValuesPanel.setLayout(new BoxLayout(allIntegralFluenceValuesPanel, BoxLayout.Y_AXIS));
			allIntegralFluenceValuesPanel.setBounds(330, 75, 166, 151);
			
			// add each row to the chart
			for (int loop=0;loop<integralFluenceContainerPanel.length;loop++)
				allIntegralFluenceValuesPanel.add(getIntegralFluxContainerPanel(loop), null);
		}
		return allIntegralFluenceValuesPanel;
	}
	
	/** 
	 * This method initializes and returns the corresponding {@link #integralFluenceContainerPanel} panel for
	 * the loop that it is passed. It does so by adding the corresponding {@link #integralFluenceNamePanel}
	 * and {@link #integralFluenceValuePanel} panel to {@link #integralFluenceContainerPanel}. 
	 * {@link #integralFluenceNamePanel} is initialized by calling {@link #getIntegralFluxNamePanel} for
	 * the corresponding loop, which puts a corresponding {@link #integraFluenceNameLabel} in the panel.
	 * {@link #integralFluenceValuePanel} is initialized by calling {@link #getIntegralFluxValuePanel} for
	 * the corresponding loop, which puts a corresponding {@link #integraFluenceValueLabel} in the panel.
	 * 
	 * @param loop The loop of {@link #integralFluenceContainerPanel} to initialize.
	 * @return The corresponding {@link #integralFluenceContainerPanel} that is now initialized.
	 */
	private JPanel getIntegralFluxContainerPanel(int loop) {
		if (integralFluenceContainerPanel[loop] == null) {
			integralFluenceContainerPanel[loop] = new JPanel();
			integralFluenceContainerPanel[loop].setLayout(new BoxLayout(integralFluenceContainerPanel[loop], BoxLayout.X_AXIS));
			integralFluenceContainerPanel[loop].setPreferredSize(new java.awt.Dimension(200,25));
			integralFluenceContainerPanel[loop].add(getIntegralFluxNamePanel(loop), null);
			integralFluenceContainerPanel[loop].add(getIntegralFluxValuePanel(loop), null);
		}
		return integralFluenceContainerPanel[loop];
	}

	/**
	 * Initializes {@link #integralFluenceNamePanel}  for the corresponding input
	 * loop. This function does so by putting a corresponding {@link #integraFluenceNameLabel} in the panel.
	 * @param loop The loop for the corresponding {@link #integralFluenceNamePanel} to initialize
	 * @return The corresponding {@link #integralFluenceNamePanel} that is now initialized.
	 */
	private JPanel getIntegralFluxNamePanel(int loop) {
		if (integralFluenceNamePanel[loop] == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(1);
			integralFluenceNamePanel[loop] = new JPanel();
			integraFluenceNameLabel[loop] = new JLabel();
			integralFluenceNamePanel[loop].setLayout(gridLayout);
			integraFluenceNameLabel[loop].setText("");
			integraFluenceNameLabel[loop].setPreferredSize(new java.awt.Dimension(100,20));
			integraFluenceNameLabel[loop].setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			integraFluenceNameLabel[loop].setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			integraFluenceNameLabel[loop].setPreferredSize(new java.awt.Dimension(100,25));
			integralFluenceNamePanel[loop].add(integraFluenceNameLabel[loop], null);
		}
		return integralFluenceNamePanel[loop];
	}

	/**
	 * Initializes {@link #integralFluenceValuePanel}  for the corresponding input
	 * loop. This funciton does so by puttinga corresponding {@link #integraFluenceValueLabel} in the panel.
	 * @param loop The loop for the corresponding {@link #integralFluenceValuePanel} to initialize
	 * @return The corresponding {@link #integralFluenceValuePanel} that is now initialized.
	 */
	private JPanel getIntegralFluxValuePanel(int loop) {
		if (integralFluenceValuePanel[loop] == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(1);
			integralFluenceValuePanel[loop] = new JPanel();
			integraFluenceValueLabel[loop] = new JLabel();
			integralFluenceValuePanel[loop].setLayout(gridLayout);
			integraFluenceValueLabel[loop].setText("");
			integraFluenceValueLabel[loop].setPreferredSize(new java.awt.Dimension(100,20));
			integraFluenceValueLabel[loop].setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			integraFluenceValueLabel[loop].setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			integralFluenceValuePanel[loop].setPreferredSize(new java.awt.Dimension(100,25));
			integralFluenceValuePanel[loop].add(integraFluenceValueLabel[loop], null);
		}
		return integralFluenceValuePanel[loop];
	}

	private JPanel getTimeEvolutionInputPanel() {
		if (timeEvolutionInputPanel == null) {
			timeEvolutionInputPanel = new JPanel();
			timeEvolutionInputPanel.setLayout(new BoxLayout(timeEvolutionInputPanel, BoxLayout.Y_AXIS));
			timeEvolutionInputPanel.setBounds(15, 75, 271, 106);
			timeEvolutionInputPanel.add(getTimeEvolutionInputLabelPanel(), null);
			timeEvolutionInputPanel.add(getAInputPanel(), null);
			timeEvolutionInputPanel.add(getB1InputPanel(), null);
			timeEvolutionInputPanel.add(getB2InputPanel(), null);
			timeEvolutionInputPanel.add(getCNotInputPanel(), null);
		}
		return timeEvolutionInputPanel;
	}

	private JPanel getAInputPanel() {
		if (AInputPanel == null) {
			AInputPanel = new JPanel();
			AInputPanel.setLayout(new BoxLayout(AInputPanel, BoxLayout.X_AXIS));
			AInputPanel.setPreferredSize(new java.awt.Dimension(50,25));
			AInputPanel.add(getAInputNamePanel(), null);
			AInputPanel.add(getAInputValuePanel_1(), null);
			AInputPanel.add(getAInputValuePanel_2(), null);
		}
		return AInputPanel;
	}

	private JPanel getB1InputPanel() {
		if (B1InputPanel == null) {
			B1InputPanel = new JPanel();
			B1InputPanel.setLayout(new BoxLayout(B1InputPanel, BoxLayout.X_AXIS));
			B1InputPanel.setPreferredSize(new java.awt.Dimension(50,25));
			B1InputPanel.add(getB1InputNamePanel(), null);
			B1InputPanel.add(getB1InputValuePanel_1(), null);
			B1InputPanel.add(getB1InputValuePanel_2(), null);
		}
		return B1InputPanel;
	}

	private JPanel getB2InputPanel() {
		if (B2InputPanel == null) {
			B2InputPanel = new JPanel();
			B2InputPanel.setLayout(new BoxLayout(B2InputPanel, BoxLayout.X_AXIS));
			B2InputPanel.setPreferredSize(new java.awt.Dimension(50,25));
			B2InputPanel.add(getB2InputNamePanel(), null);
			B2InputPanel.add(getB2InputValuePanel_1(), null);
			B2InputPanel.add(getB2InputValuePanel_2(), null);
		}
		return B2InputPanel;
	}

	private JPanel getCNotInputPanel() {
		if (CNotInputPanel == null) {
			CNotInputPanel = new JPanel();
			CNotInputPanel.setLayout(new BoxLayout(CNotInputPanel, BoxLayout.X_AXIS));
			CNotInputPanel.setPreferredSize(new java.awt.Dimension(50,25));
			CNotInputPanel.add(getCNotInputNamePanel(), null);
			CNotInputPanel.add(getCNotInputValuePanel_1(), null);
			CNotInputPanel.add(getCNotInputValuePanel_2(), null);
		}
		return CNotInputPanel;
	}

	private JPanel getAInputNamePanel() {
		if (AInputNamePanel == null) {
			AInputNameLabel = new JLabel();
			AInputNamePanel = new JPanel();
			AInputNamePanel.setLayout(new BoxLayout(AInputNamePanel, BoxLayout.Y_AXIS));
			AInputNameLabel.setText("A");
			AInputNamePanel.setPreferredSize(new java.awt.Dimension(30,25));
			AInputNamePanel.add(AInputNameLabel, null);
		}
		return AInputNamePanel;
	}

	private JPanel getAInputValuePanel_1() {
		if (AInputValuePanel_1 == null) {
			AInputValuePanel_1 = new JPanel();
			AInputValuePanel_1.setLayout(new BoxLayout(AInputValuePanel_1, BoxLayout.Y_AXIS));
			AInputValuePanel_1.add(getAInput_1(), null);
		}
		return AInputValuePanel_1;
	}

	private JPanel getB1InputNamePanel() {
		if (B1InputNamePanel == null) {
			B1InputNameLabel = new JLabel();
			B1InputNamePanel = new JPanel();
			B1InputNamePanel.setLayout(new BoxLayout(B1InputNamePanel, BoxLayout.X_AXIS));
			B1InputNameLabel.setText("B1");
			B1InputNamePanel.setPreferredSize(new java.awt.Dimension(30,25));
			B1InputNamePanel.add(B1InputNameLabel, null);
		}
		return B1InputNamePanel;
	}

	private JPanel getB1InputValuePanel_1() {
		if (B1InputValuePanel_1 == null) {
			B1InputValuePanel_1 = new JPanel();
			B1InputValuePanel_1.setLayout(new BoxLayout(B1InputValuePanel_1, BoxLayout.Y_AXIS));
			B1InputValuePanel_1.add(getB1Input_1(), null);
		}
		return B1InputValuePanel_1;
	}

	private JPanel getB2InputNamePanel() {
		if (B2InputNamePanel == null) {
			B2InputNameLabel = new JLabel();
			B2InputNamePanel = new JPanel();
			B2InputNamePanel.setLayout(new BoxLayout(B2InputNamePanel, BoxLayout.X_AXIS));
			B2InputNameLabel.setText("B2");
			B2InputNamePanel.setPreferredSize(new java.awt.Dimension(30,25));
			B2InputNamePanel.add(B2InputNameLabel, null);
		}
		return B2InputNamePanel;
	}

	private JPanel getB2InputValuePanel_1() {
		if (B2InputValuePanel_1 == null) {
			B2InputValuePanel_1 = new JPanel();
			B2InputValuePanel_1.setLayout(new BoxLayout(B2InputValuePanel_1, BoxLayout.Y_AXIS));
			B2InputValuePanel_1.add(getB2Input_1(), null);
		}
		return B2InputValuePanel_1;
	}

	private JTextField getAInput_1() {
		if (AInput_1 == null) {
			AInput_1 = new JTextField();
			AInput_1.setPreferredSize(new java.awt.Dimension(30,25));
			AInput_1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					AInput_2.requestFocus();
				}
			});
		}
		return AInput_1;
	}

	private JTextField getB1Input_1() {
		if (B1Input_1 == null) {
			B1Input_1 = new JTextField();
			B1Input_1.setPreferredSize(new java.awt.Dimension(30,25));
			B1Input_1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					B1Input_2.requestFocus();
				}
			});
		}
		return B1Input_1;
	}

	private JTextField getB2Input_1() {
		if (B2Input_1 == null) {
			B2Input_1 = new JTextField();
			B2Input_1.setPreferredSize(new java.awt.Dimension(30,25));
			B2Input_1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					B2Input_2.requestFocus();
				}
			});
		}
		return B2Input_1;
	}

	private JButton getTimeEvolutionCalculateButton() {
		if (timeEvolutionCalculateButton == null) {
			timeEvolutionCalculateButton = new JButton();
			timeEvolutionCalculateButton.setBounds(15, 240, 151, 31);
			timeEvolutionCalculateButton.setText("Calculate");
			timeEvolutionCalculateButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					doEverything(WarningStage.TIME_EVOLUTION_WARNING); // show warnings
				}
			});
		}
		return timeEvolutionCalculateButton;
	}
  
	private JPanel getEstimatedDosePanel() {
		if (estimatedDosePanel == null) {
			spectraUnitsLabel = new JLabel();
			estimatedDoseLabel = new JLabel();
			estimatedDosePanel = new JPanel();
			estimatedDosePanel.setLayout(null);
			estimatedDosePanel.setName("Estimated Dose");
			estimatedDoseLabel.setBounds(15, 15, 601, 31);
			estimatedDoseLabel.setText("    ");
			spectraUnitsLabel.setBounds(15, 60, 391, 16);
			spectraUnitsLabel.setText("Spectra is protons/cm2-MeV");
			estimatedDosePanel.add(estimatedDoseLabel, null);
			estimatedDosePanel.add(getDoseDataTablePanel(), null);
			estimatedDosePanel.add(spectraUnitsLabel, null);
			estimatedDosePanel.add(getLunarSurfaceOrFreeSpacePanel(), null);
			estimatedDosePanel.add(getRemOrRadPanel(), null);
		}
		return estimatedDosePanel;
	}

	private JPanel getDoseDataTablePanel() {
		if (doseDataTablePanel == null) {
			doseDataTablePanel = new JPanel();
			doseDataTablePanel.setLayout(new BoxLayout(doseDataTablePanel, BoxLayout.Y_AXIS));
			doseDataTablePanel.setLocation(15, 90);
			doseDataTablePanel.setSize(406, 156);
			doseDataTablePanel.setPreferredSize(new java.awt.Dimension(300,200));
			doseDataTablePanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
			doseDataTablePanel.add(getDoseDataTableTitlePanel(), null);
			doseDataTablePanel.add(getDoseDataPanel(), null);
		}
		return doseDataTablePanel;
	}
  
	private JPanel getDoseDataTableTitlePanel() {
		if (doseDataTableTitlePanel == null) {
			doseDataTableTitleLabel = new JLabel();
			doseDataTableTitlePanel = new JPanel();
			doseDataTableTitlePanel.setPreferredSize(new java.awt.Dimension(5,5));
			doseDataTableTitleLabel.setText("    ");
			doseDataTableTitlePanel.add(doseDataTableTitleLabel, null);
		}
		return doseDataTableTitlePanel;
	}
 
	private JPanel getDoseDataPanel() {
		if (doseDataPanel == null) {
			doseDataPanel = new JPanel();
			doseDataPanel.setLayout(new BoxLayout(doseDataPanel, BoxLayout.X_AXIS));
			doseDataPanel.setPreferredSize(new java.awt.Dimension(300,400));
			doseDataPanel.add(getDoseDataSkinEyeBFOPanel(), null);
			doseDataPanel.add(getDoseDataOuterTabelPanel(), null);
		}
		return doseDataPanel;
	}
 
	private JPanel getDoseDataSkinEyeBFOPanel() {
		if (doseDataSkinEyeBFOPanel == null) {
			doseDataSkinEyeBFOPanel = new JPanel();
			doseDataSkinEyeBFOPanel.setLayout(new BoxLayout(doseDataSkinEyeBFOPanel, BoxLayout.Y_AXIS));
			doseDataSkinEyeBFOPanel.setPreferredSize(new java.awt.Dimension(30,80));
			doseDataSkinEyeBFOPanel.add(getDoseDataBlankCornerPanel1(), null);
			doseDataSkinEyeBFOPanel.add(getDoseDataBlankCornerPanel2(), null);
			doseDataSkinEyeBFOPanel.add(getDoseDataSkinPanel(), null);
			doseDataSkinEyeBFOPanel.add(getDoseDataEyePanel(), null);
			doseDataSkinEyeBFOPanel.add(getDoseDataBFOPanel(), null);
		}
		return doseDataSkinEyeBFOPanel;
	}

	private JPanel getDoseDataOuterTabelPanel() {
		if (doseDataOuterTabelPanel == null) {
			doseDataOuterTabelPanel = new JPanel();
			doseDataOuterTabelPanel.setLayout(new BoxLayout(doseDataOuterTabelPanel, BoxLayout.Y_AXIS));
			doseDataOuterTabelPanel.setPreferredSize(new java.awt.Dimension(300,300));
			doseDataOuterTabelPanel.add(getDoseDataAluminumSheildingPanel(), null);
			doseDataOuterTabelPanel.add(getDoseDataThicknessPanel(), null);
			doseDataOuterTabelPanel.add(getDoseDataFieldsPanel(), null);
			doseDataOuterTabelPanel.add(getEyeDataPanel(), null);
			doseDataOuterTabelPanel.add(getBFODataPanel(), null);
		}
		return doseDataOuterTabelPanel;
	}

	private JPanel getEyeDataPanel() {
		if (eyeDataPanel == null) {
			eyeDataPanel = new JPanel();
			eyeDataPanel.setLayout(new BoxLayout(eyeDataPanel, BoxLayout.X_AXIS));
			eyeDataPanel.add(getEyePointThreePanel(), null);
			eyeDataPanel.add(getEyeOnePanel(), null);
			eyeDataPanel.add(getEyeFivePanel(), null);
			eyeDataPanel.add(getEyeTenPanel(), null);
			eyeDataPanel.add(getEyeThirtyPanel(), null);
		}
		return eyeDataPanel;
	}
 
	private JPanel getDoseDataFieldsPanel() {
		if (skinDataPanel == null) {
			skinDataPanel = new JPanel();
			skinDataPanel.setLayout(new BoxLayout(skinDataPanel, BoxLayout.X_AXIS));
			skinDataPanel.add(getSkinPointThreePanel(), null);
			skinDataPanel.add(getSkinOnePanel(), null);
			skinDataPanel.add(getSkinFivePanel(), null);
			skinDataPanel.add(getSkinTenPanel(), null);
			skinDataPanel.add(getSkinThirtyPanel(), null);
		}
		return skinDataPanel;
	}

	private JPanel getDoseDataAluminumSheildingPanel() {
		if (doseDataAluminumSheildingPanel == null) {
			doseDataAluminumSheildingLabel = new JLabel();
			doseDataAluminumSheildingPanel = new JPanel();
			doseDataAluminumSheildingLabel.setText("   ");
			doseDataAluminumSheildingPanel.setPreferredSize(new java.awt.Dimension(50,5));
			doseDataAluminumSheildingPanel.add(doseDataAluminumSheildingLabel, null);
		}
		return doseDataAluminumSheildingPanel;
	}
   
	private JPanel getDoseDataThicknessPanel() {
		if (doseDataThicknessPanel == null) {
			doseDataThicknessPanel = new JPanel();
			doseDataThicknessPanel.setLayout(new BoxLayout(doseDataThicknessPanel, BoxLayout.X_AXIS));
			doseDataThicknessPanel.add(getDoseDataThicknessPointThreePanel(), null);
			doseDataThicknessPanel.add(getDoseDataThicknessOnePanel(), null);
			doseDataThicknessPanel.add(getDoseDataThicknessFivePanel(), null);
			doseDataThicknessPanel.add(getDoseDataThicknessTenPanel(), null);
			doseDataThicknessPanel.add(getDoseDataThicknessThirtyPanel(), null);
		}
		return doseDataThicknessPanel;
	}
   
	private JPanel getDoseDataEyePanel() {
		if (doseDataEyePanel == null) {
			doseDataEyeLabel = new JLabel();
			doseDataEyePanel = new JPanel();
			doseDataEyeLabel.setText("Eye");
			doseDataEyeLabel.setPreferredSize(new java.awt.Dimension(25,20));
			doseDataEyePanel.setPreferredSize(new java.awt.Dimension(10,10));
			doseDataEyePanel.add(doseDataEyeLabel, null);
		}
		return doseDataEyePanel;
	}
  
	private JPanel getDoseDataSkinPanel() {
		if (doseDataSkinPanel == null) {
			doseDataSkinLabel = new JLabel();
			doseDataSkinPanel = new JPanel();
			doseDataSkinLabel.setText("Skin");
			doseDataSkinPanel.setPreferredSize(new java.awt.Dimension(5,10));
			doseDataSkinPanel.add(doseDataSkinLabel, null);
		}
		return doseDataSkinPanel;
	}
 
	private JPanel getDoseDataBlankCornerPanel2() {
		if (doseDataBlankCornerPanel2 == null) {
			doseDataBlankCornerPanel2 = new JPanel();
			doseDataBlankCornerPanel2.setPreferredSize(new java.awt.Dimension(10,10));
		}
		return doseDataBlankCornerPanel2;
	}
 
	private JPanel getDoseDataBlankCornerPanel1() {
		if (doseDataBlankCornerPanel1 == null) {
			doseDataBlankCornerPanel1 = new JPanel();
			doseDataBlankCornerPanel1.setPreferredSize(new java.awt.Dimension(5,5));
		}
		return doseDataBlankCornerPanel1;
	}

	private JPanel getDoseDataBFOPanel() {
		if (doseDataBFOPanel == null) {
			doseDataBFOLabel = new JLabel();
			doseDataBFOPanel = new JPanel();
			doseDataBFOLabel.setText("BFO");
			doseDataBFOPanel.setPreferredSize(new java.awt.Dimension(10,10));
			doseDataBFOPanel.add(doseDataBFOLabel, null);
		}
		return doseDataBFOPanel;
	}

	private JPanel getBFODataPanel() {
		if (BFODataPanel == null) {
			BFODataPanel = new JPanel();
			BFODataPanel.setLayout(new BoxLayout(BFODataPanel, BoxLayout.X_AXIS));
			BFODataPanel.add(getBFOPointThreePanel(), null);
			BFODataPanel.add(getBFOOnePanel(), null);
			BFODataPanel.add(getBFOFivePanel(), null);
			BFODataPanel.add(getBFOTenPanel(), null);
			BFODataPanel.add(getBFOThirtyPanel(), null);
		}
		return BFODataPanel;
	}
 
	private JPanel getDoseDataThicknessPointThreePanel() {
		if (doseDataThicknessPointThreePanel == null) {
			doseDataThicknessPointThreeLabel = new JLabel();
			doseDataThicknessPointThreePanel = new JPanel();
			doseDataThicknessPointThreeLabel.setText("0.3");
			doseDataThicknessPointThreePanel.setPreferredSize(new java.awt.Dimension(10,10));
			doseDataThicknessPointThreePanel.add(doseDataThicknessPointThreeLabel, null);
		}
		return doseDataThicknessPointThreePanel;
	}

	private JPanel getDoseDataThicknessOnePanel() {
		if (doseDataThicknessOnePanel == null) {
			doseDataThicknessOneLabel = new JLabel();
			doseDataThicknessOnePanel = new JPanel();
			doseDataThicknessOneLabel.setText("1");
			doseDataThicknessOnePanel.setPreferredSize(new java.awt.Dimension(10,10));
			doseDataThicknessOnePanel.add(doseDataThicknessOneLabel, null);
		}
		return doseDataThicknessOnePanel;
	}

	private JPanel getDoseDataThicknessFivePanel() {
		if (doseDataThicknessFivePanel == null) {
			doseDataThicknessFiveLabel = new JLabel();
			doseDataThicknessFivePanel = new JPanel();
			doseDataThicknessFiveLabel.setText("5");
			doseDataThicknessFivePanel.setPreferredSize(new java.awt.Dimension(10,10));
			doseDataThicknessFivePanel.add(doseDataThicknessFiveLabel, null);
		}
		return doseDataThicknessFivePanel;
	}
  
	private JPanel getDoseDataThicknessTenPanel() {
		if (doseDataThicknessTenPanel == null) {
			doseDataThicknessTenLabel = new JLabel();
			doseDataThicknessTenPanel = new JPanel();
			doseDataThicknessTenLabel.setText("10");
			doseDataThicknessTenPanel.setPreferredSize(new java.awt.Dimension(10,10));
			doseDataThicknessTenPanel.add(doseDataThicknessTenLabel, null);
		}
		return doseDataThicknessTenPanel;
	}

	private JPanel getSkinPointThreePanel() {
		if (skinPointThreePanel == null) {
			GridLayout gridLayout12 = new GridLayout();
			skinPointThreeLabel = new JLabel();
			skinPointThreePanel = new JPanel();
			skinPointThreePanel.setLayout(gridLayout12);
			skinPointThreeLabel.setText("   ");
			skinPointThreeLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			skinPointThreeLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			skinPointThreePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout12.setRows(1);
			skinPointThreePanel.add(skinPointThreeLabel, null);
		}
		return skinPointThreePanel;
	}
  
	private JPanel getSkinOnePanel() {
		if (skinOnePanel == null) {
			GridLayout gridLayout14 = new GridLayout();
			skinOneLabel = new JLabel();
			skinOnePanel = new JPanel();
			skinOnePanel.setLayout(gridLayout14);
			skinOneLabel.setText("   ");
			skinOneLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			skinOneLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			skinOnePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout14.setRows(1);
			skinOnePanel.add(skinOneLabel, null);
		}
		return skinOnePanel;
	}
  
	private JPanel getSkinFivePanel() {
		if (skinFivePanel == null) {
			GridLayout gridLayout44 = new GridLayout();
			skinFiveLabel = new JLabel();
			skinFivePanel = new JPanel();
			skinFivePanel.setLayout(gridLayout44);
			skinFiveLabel.setText("   ");
			skinFiveLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			skinFiveLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			skinFivePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout44.setRows(1);
			skinFivePanel.add(skinFiveLabel, null);
		}
		return skinFivePanel;
	}
 
	private JPanel getSkinTenPanel() {
		if (skinTenPanel == null) {
			GridLayout gridLayout81 = new GridLayout();
			skinTenLabel = new JLabel();
			skinTenPanel = new JPanel();
			skinTenPanel.setLayout(gridLayout81);
			skinTenLabel.setText("   ");
			skinTenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			skinTenLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			skinTenPanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout81.setRows(1);
			skinTenPanel.add(skinTenLabel, null);
		}
		return skinTenPanel;
	}
 
	private JPanel getEyePointThreePanel() {
		if (eyePointThreePanel == null) {
			GridLayout gridLayout22 = new GridLayout();
			eyePointThreeLabel = new JLabel();
			eyePointThreePanel = new JPanel();
			eyePointThreePanel.setLayout(gridLayout22);
			eyePointThreeLabel.setText("   ");
			eyePointThreeLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			eyePointThreeLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			eyePointThreePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout22.setRows(1);
			eyePointThreePanel.add(eyePointThreeLabel, null);
		}
		return eyePointThreePanel;
	}

	private JPanel getEyeOnePanel() {
		if (eyeOnePanel == null) {
			GridLayout gridLayout23 = new GridLayout();
			eyeOneLabel = new JLabel();
			eyeOnePanel = new JPanel();
			eyeOnePanel.setLayout(gridLayout23);
			eyeOneLabel.setText("   ");
			eyeOneLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			eyeOneLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			eyeOnePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout23.setRows(1);
			eyeOnePanel.add(eyeOneLabel, null);
		}
		return eyeOnePanel;
	}
 
	private JPanel getEyeFivePanel() {
		if (eyeFivePanel == null) {
			GridLayout gridLayout53 = new GridLayout();
			eyeFiveLabel = new JLabel();
			eyeFivePanel = new JPanel();
			eyeFivePanel.setLayout(gridLayout53);
			eyeFiveLabel.setText("   ");
			eyeFiveLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			eyeFiveLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			eyeFivePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout53.setRows(1);
			eyeFivePanel.add(eyeFiveLabel, null);
		}
		return eyeFivePanel;
	}

	private JPanel getEyeTenPanel() {
		if (eyeTenPanel == null) {
			GridLayout gridLayout91 = new GridLayout();
			eyeTenLabel = new JLabel();
			eyeTenPanel = new JPanel();
			eyeTenPanel.setLayout(gridLayout91);
			eyeTenLabel.setText("   ");
			eyeTenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			eyeTenLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			eyeTenPanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout91.setRows(1);
			eyeTenPanel.add(eyeTenLabel, null);
		}
		return eyeTenPanel;
	}

	private JPanel getBFOPointThreePanel() {
		if (BFOPointThreePanel == null) {
			GridLayout gridLayout33 = new GridLayout();
			BFOPointThreeLabel = new JLabel();
			BFOPointThreePanel = new JPanel();
			BFOPointThreePanel.setLayout(gridLayout33);
			BFOPointThreeLabel.setText("   ");
			BFOPointThreeLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			BFOPointThreeLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			BFOPointThreePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout33.setRows(1);
			BFOPointThreePanel.add(BFOPointThreeLabel, null);
		}
		return BFOPointThreePanel;
	}
   
	private JPanel getBFOOnePanel() {
		if (BFOOnePanel == null) {
			GridLayout gridLayout34 = new GridLayout();
			BFOOneLabel = new JLabel();
			BFOOnePanel = new JPanel();
			BFOOnePanel.setLayout(gridLayout34);
			BFOOneLabel.setText("   ");
			BFOOneLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			BFOOneLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			BFOOnePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout34.setRows(1);
			BFOOnePanel.add(BFOOneLabel, null);
		}
		return BFOOnePanel;
	}

	private JPanel getBFOFivePanel() {
		if (BFOFivePanel == null) {
			GridLayout gridLayout62 = new GridLayout();
			BFOFiveLabel = new JLabel();
			BFOFivePanel = new JPanel();
			BFOFivePanel.setLayout(gridLayout62);
			BFOFiveLabel.setText("   ");
			BFOFiveLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			BFOFiveLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			BFOFivePanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout62.setRows(1);
			BFOFivePanel.add(BFOFiveLabel, null);
		}
		return BFOFivePanel;
	}
   
	private JPanel getBFOTenPanel() {
		if (BFOTenPanel == null) {
			GridLayout gridLayout101 = new GridLayout();
			BFOTenLabel = new JLabel();
			BFOTenPanel = new JPanel();
			BFOTenPanel.setLayout(gridLayout101);
			BFOTenLabel.setText("   ");
			BFOTenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			BFOTenLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			BFOTenPanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout101.setRows(1);
			BFOTenPanel.add(BFOTenLabel, null);
		}
		return BFOTenPanel;
	}
   
	private JPanel getBFOThirtyPanel() {
		if (BFOThirtyPanel == null) {
			GridLayout gridLayout131 = new GridLayout();
			BFOThirtyLabel = new JLabel();
			BFOThirtyPanel = new JPanel();
			BFOThirtyPanel.setLayout(gridLayout131);
			BFOThirtyLabel.setText("   ");
			BFOThirtyLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			BFOThirtyLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			BFOThirtyPanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout131.setRows(1);
			BFOThirtyPanel.add(BFOThirtyLabel, null);
		}
		return BFOThirtyPanel;
	}
   
	private JPanel getDoseDataThicknessThirtyPanel() {
		if (doseDataThicknessThirtyPanel == null) {
			doseDataThicknessThirtyLabel = new JLabel();
			doseDataThicknessThirtyPanel = new JPanel();
			doseDataThicknessThirtyLabel.setText("30");
			doseDataThicknessThirtyPanel.setPreferredSize(new java.awt.Dimension(10,10));
			doseDataThicknessThirtyPanel.add(doseDataThicknessThirtyLabel, null);
		}
		return doseDataThicknessThirtyPanel;
	}
   
	private JPanel getSkinThirtyPanel() {
		if (skinThirtyPanel == null) {
			GridLayout gridLayout111 = new GridLayout();
			skinThirtyLabel = new JLabel();
			skinThirtyPanel = new JPanel();
			skinThirtyPanel.setLayout(gridLayout111);
			skinThirtyLabel.setText("   ");
			skinThirtyLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			skinThirtyLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			skinThirtyPanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout111.setRows(1);
			skinThirtyPanel.add(skinThirtyLabel, null);
		}
		return skinThirtyPanel;
	}
  
	private JPanel getEyeThirtyPanel() {
		if (eyeThirtyPanel == null) {
			GridLayout gridLayout121 = new GridLayout();
			eyeThirtyLabel = new JLabel();
			eyeThirtyPanel = new JPanel();
			eyeThirtyPanel.setLayout(gridLayout121);
			eyeThirtyLabel.setText("   ");
			eyeThirtyLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			eyeThirtyLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			eyeThirtyPanel.setPreferredSize(new java.awt.Dimension(10,10));
			gridLayout121.setRows(1);
			eyeThirtyPanel.add(eyeThirtyLabel, null);
		}
		return eyeThirtyPanel;
	}
 
	private JPanel getLunarSurfaceOrFreeSpacePanel() {
		if (lunarSurfaceOrFreeSpacePanel == null) {
			lunarSurfaceOrFreeSpacePanel = new JPanel();
			lunarSurfaceOrFreeSpacePanel.setLayout(new BoxLayout(lunarSurfaceOrFreeSpacePanel, BoxLayout.Y_AXIS));
			lunarSurfaceOrFreeSpacePanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
			lunarSurfaceOrFreeSpacePanel.setLocation(435, 90);
			lunarSurfaceOrFreeSpacePanel.setSize(195, 61);
			lunarSurfaceOrFreeSpacePanel.add(getFreeSpacePanel(), null);
			lunarSurfaceOrFreeSpacePanel.add(getLunarSurfacePanel(), null);
		}
		

		
		return lunarSurfaceOrFreeSpacePanel;
	}
  
	private JPanel getLunarSurfacePanel() {
		if (lunarSurfacePanel == null) {
			lunarSurfacePanel = new JPanel();
			lunarSurfacePanel.setLayout(new BoxLayout(lunarSurfacePanel, BoxLayout.X_AXIS));
			lunarSurfacePanel.add(getLunarSurfaceRadioButtonLabel(), null);
			lunarSurfacePanel.add(getLunarSurfaceLabelPanel(), null);
		}
		return lunarSurfacePanel;
	}

	private JPanel getFreeSpacePanel() {
		if (freeSpacePanel == null) {
			freeSpacePanel = new JPanel();
			freeSpacePanel.setLayout(new BoxLayout(freeSpacePanel, BoxLayout.X_AXIS));
			freeSpacePanel.add(getFreeSpaceRadioButtonPanel(), null);
			freeSpacePanel.add(getFreeSpaceLabelPanel(), null);
		}
		return freeSpacePanel;
	}
 
	private JPanel getFreeSpaceRadioButtonPanel() {
		if (freeSpaceRadioButtonPanel == null) {
			freeSpaceRadioButtonPanel = new JPanel();
			freeSpaceRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			freeSpaceRadioButtonPanel.add(getFreeSpaceRadioButton(), null);
		}
		return freeSpaceRadioButtonPanel;
	}

	private JPanel getLunarSurfaceRadioButtonLabel() {
		if (lunarSurfaceRadioButtonLabel == null) {
			lunarSurfaceRadioButtonLabel = new JPanel();
			lunarSurfaceRadioButtonLabel.setPreferredSize(new java.awt.Dimension(10,10));
			lunarSurfaceRadioButtonLabel.add(getLunarSurfaceRadioButton(), null);
		}
		return lunarSurfaceRadioButtonLabel;
	}
  
	private JPanel getFreeSpaceLabelPanel() {
		if (freeSpaceLabelPanel == null) {
			freeSpaceLabel = new JLabel();
			freeSpaceLabelPanel = new JPanel();
			freeSpaceLabelPanel.setPreferredSize(new java.awt.Dimension(120,10));
			freeSpaceLabel.setText("Free Space");
			freeSpaceLabelPanel.add(freeSpaceLabel, null);
		}
		return freeSpaceLabelPanel;
	}
 
	private JPanel getLunarSurfaceLabelPanel() {
		if (lunarSurfaceLabelPanel == null) {
			lunarSurfaceLabel = new JLabel();
			lunarSurfaceLabelPanel = new JPanel();
			lunarSurfaceLabelPanel.setPreferredSize(new java.awt.Dimension(120,10));
			lunarSurfaceLabel.setText("Lunar Surface");
			lunarSurfaceLabelPanel.add(lunarSurfaceLabel, null);
		}
		return lunarSurfaceLabelPanel;
	}

	private JRadioButton getFreeSpaceRadioButton() {
		if (freeSpaceRadioButton == null) {
			freeSpaceRadioButton = new JRadioButton();
			freeSpaceRadioButton.setSelected(true);
			freeSpaceRadioButton.setPreferredSize(new java.awt.Dimension(21,21));
			freeSpaceRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (freeSpaceRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return freeSpaceRadioButton;
	}

	private JRadioButton getLunarSurfaceRadioButton() {
		if (lunarSurfaceRadioButton == null) {
			lunarSurfaceRadioButton = new JRadioButton();
			lunarSurfaceRadioButton.setSelected(false);
			lunarSurfaceRadioButton.addItemListener(new java.awt.event.ItemListener() {   
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (lunarSurfaceRadioButton.isSelected()) 
						doEverything();
				} 
			});
		}
		return lunarSurfaceRadioButton;
	}
 
	private JPanel getRemOrRadPanel() {
		if (remOrRadPanel == null) {
			remOrRadPanel = new JPanel();
			remOrRadPanel.setLayout(new BoxLayout(remOrRadPanel, BoxLayout.Y_AXIS));
			remOrRadPanel.setLocation(435, 180);
			remOrRadPanel.setSize(195, 61);
			remOrRadPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
			remOrRadPanel.setPreferredSize(new java.awt.Dimension(100,25));
			remOrRadPanel.add(getRadPanel(), null);
			remOrRadPanel.add(getRemPanel(), null);
		}
		return remOrRadPanel;
	}
 
	private JPanel getRemPanel() {
		if (remPanel == null) {
			remPanel = new JPanel();
			remPanel.setLayout(new BoxLayout(remPanel, BoxLayout.X_AXIS));
			remPanel.add(getRemRadioButtonPanel(), null);
			remPanel.add(getRemLabelPanel(), null);
		}
		return remPanel;
	}
 
	private JPanel getRadPanel() {
		if (radPanel == null) {
			radPanel = new JPanel();
			radPanel.setLayout(new BoxLayout(radPanel, BoxLayout.X_AXIS));
			radPanel.add(getRadRadioButtonPanel(), null);
			radPanel.add(getRadLabelPanel(), null);
		}
		return radPanel;
	}
 
	private JPanel getRadRadioButtonPanel() {
		if (radRadioButtonPanel == null) {
			radRadioButtonPanel = new JPanel();
			radRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			radRadioButtonPanel.add(getRadRadioButton(), null);
		}
		return radRadioButtonPanel;
	}
 
	private JPanel getRadLabelPanel() {
		if (radLabelPanel == null) {
			radLabel = new JLabel();
			radLabelPanel = new JPanel();
			radLabel.setText("Absorbed Dose (cGy)");
			radLabelPanel.setPreferredSize(new java.awt.Dimension(120,10));
			radLabelPanel.add(radLabel, null);
		}
		return radLabelPanel;
	}
 
	private JPanel getRemRadioButtonPanel() {
		if (remRadioButtonPanel == null) {
			remRadioButtonPanel = new JPanel();
			remRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			remRadioButtonPanel.add(getRemRadioButton(), null);
		}
		return remRadioButtonPanel;
	}
  
	private JPanel getRemLabelPanel() {
		if (remLabelPanel == null) {
			remLabel = new JLabel();
			remLabelPanel = new JPanel();
			remLabel.setText("Dose Equivalent (cSv)");
			remLabelPanel.setPreferredSize(new java.awt.Dimension(120,10));
			remLabelPanel.add(remLabel, null);
		}
		return remLabelPanel;
	}
 
	private JRadioButton getRadRadioButton() {
		if (radRadioButton == null) {
			radRadioButton = new JRadioButton();
			radRadioButton.setSelected(false);
			radRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (radRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return radRadioButton;
	}
 
	private JRadioButton getRemRadioButton() {
		if (remRadioButton == null) {
			remRadioButton = new JRadioButton();
			remRadioButton.setSelected(true);
			remRadioButton.setPreferredSize(new java.awt.Dimension(21,21));
			remRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (remRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return remRadioButton;
	}
  
	private JScrollPane getTimeEvolutionDescriptionScrollPane() {
		if (timeEvolutionDescriptionScrollPane == null) {
			timeEvolutionDescriptionScrollPane = new JScrollPane();
			timeEvolutionDescriptionScrollPane.setBounds(300, 75, 331, 151);
			timeEvolutionDescriptionScrollPane.setViewportView(getTimeEvolutionDescriptionPane());
		}
		return timeEvolutionDescriptionScrollPane;
	}

	private JEditorPane getTimeEvolutionDescriptionPane() {
		if (timeEvolutionDescriptionPane == null) {
			timeEvolutionDescriptionPane = new JEditorPane();
			timeEvolutionDescriptionPane.setEditable(false);
			timeEvolutionDescriptionPane.setBackground(background);
		}
		return timeEvolutionDescriptionPane;
	}
   
	private JPanel getCNotInputNamePanel() {
		if (CNotInputNamePanel == null) {
			CNotInputNamePanel = new JPanel();
			CNotInputNameLabel = new JLabel();
			CNotInputNamePanel.setLayout(new BoxLayout(CNotInputNamePanel, BoxLayout.X_AXIS));
			CNotInputNamePanel.setPreferredSize(new java.awt.Dimension(30,25));
			CNotInputNameLabel.setText("C");
			CNotInputNamePanel.add(CNotInputNameLabel, null);
		}
		return CNotInputNamePanel;
	}
  
	private JPanel getCNotInputValuePanel_1() {
		if (CNotInputValuePanel_1 == null) {
			CNotInputValuePanel_1 = new JPanel();
			CNotInputValuePanel_1.setLayout(new BoxLayout(CNotInputValuePanel_1, BoxLayout.Y_AXIS));
			CNotInputValuePanel_1.add(getCNotInput_1(), null);
		}
		return CNotInputValuePanel_1;
	}

	private JTextField getCNotInput_1() {
		if (CNotInput_1 == null) {
			CNotInput_1 = new JTextField();
			CNotInput_1.setEditable(false);
			CNotInput_1.setPreferredSize(new java.awt.Dimension(30,25));
			CNotInput_1.setBackground(this.getBackground());
		}
		return CNotInput_1;
	}

	private JPanel getExercisePanel() {
		if (exercisePanel == null) {
			exerciseDoseLabel = new JLabel();
			exercisePanel = new JPanel();
			exercisePanel.setLayout(null);
			exerciseDoseLabel.setText("   ");
			exerciseDoseLabel.setLocation(15, 11);
			exerciseDoseLabel.setSize(286, 20);
			exercisePanel.add(getExerciseDoseSummaryPanel(), null);
			exercisePanel.add(getExerciseTimeSelectionPanel(), null);
			exercisePanel.add(exerciseDoseLabel, null);
			exercisePanel.add(getExerciseTotalTimeEvolutionDosePanel(), null);
			exercisePanel.add(getExerciseCalculateButton(), null);
			exercisePanel.add(getExerciseSkinEyeOrBFOPanel(), null);
			exercisePanel.add(getClassExerciseDescriptionScrollPane(), null);
			exercisePanel.add(getSetUpButton(), null);
		}
		return exercisePanel;
	}

	private JPanel getExerciseDoseSummaryPanel() {
		if (exerciseDoseSummaryPanel == null) {
			exerciseDoseSummaryPanel = new JPanel();
			exerciseDoseSummaryPanel.setLayout(new BoxLayout(exerciseDoseSummaryPanel, BoxLayout.Y_AXIS));
			exerciseDoseSummaryPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
			exerciseDoseSummaryPanel.setPreferredSize(new java.awt.Dimension(330,80));
			exerciseDoseSummaryPanel.setLocation(15, 45);
			exerciseDoseSummaryPanel.setSize(286, 91);
			exerciseDoseSummaryPanel.add(getExerciseDoseSummaryTitlePanel(), null);
			exerciseDoseSummaryPanel.add(getExerciseDoseSummaryThicknessLabelPanel(), null);
			exerciseDoseSummaryPanel.add(getExerciseDoseSummaryValuePanel(), null);
		}
		return exerciseDoseSummaryPanel;
	}

	private JPanel getExerciseDoseSummaryTitlePanel() {
		if (exerciseDoseSummaryTitlePanel == null) {
			exerciseDoseSummaryTitleLabel = new JLabel();
			exerciseDoseSummaryTitlePanel = new JPanel();
			exerciseDoseSummaryTitleLabel.setText("<html>g/cm<sup>2</sup> Al Shielding</html>");
			exerciseDoseSummaryTitlePanel.setPreferredSize(new java.awt.Dimension(113,25));
			exerciseDoseSummaryTitlePanel.add(exerciseDoseSummaryTitleLabel, null);
		}
		return exerciseDoseSummaryTitlePanel;
	}
   
	private JPanel getExerciseDoseSummaryThicknessLabelPanel() {
		if (exerciseDoseSummaryThicknessLabelPanel == null) {
			exerciseDoseSummaryThicknessLabelPanel = new JPanel();
			exerciseDoseSummaryThicknessLabelPanel.setLayout(new BoxLayout(exerciseDoseSummaryThicknessLabelPanel, BoxLayout.X_AXIS));
			exerciseDoseSummaryThicknessLabelPanel.add(getExerciseDoseSummaryThicknessPointThreePanel(), null);
			exerciseDoseSummaryThicknessLabelPanel.add(getExerciseDoseSummaryThicknessOneLabelPanel(), null);
			exerciseDoseSummaryThicknessLabelPanel.add(getExerciseDoseSummaryThicknessFiveLabelPanel(), null);
			exerciseDoseSummaryThicknessLabelPanel.add(getExerciseDoseSummaryThicknessTenLabelPanel(), null);
			exerciseDoseSummaryThicknessLabelPanel.add(getExerciseDoseSummaryThicknessThirtyLabelPanel(), null);
		}
		return exerciseDoseSummaryThicknessLabelPanel;
	}

	private JPanel getExerciseDoseSummaryValuePanel() {
		if (exerciseDoseSummaryValuePanel == null) {
			exerciseDoseSummaryValuePanel = new JPanel();
			exerciseDoseSummaryValuePanel.setLayout(new BoxLayout(exerciseDoseSummaryValuePanel, BoxLayout.X_AXIS));
			exerciseDoseSummaryValuePanel.add(getExerciseDoseSummaryThicknessPointThreeValuePanel(), null);
			exerciseDoseSummaryValuePanel.add(getExerciseDoseSummaryThicknessOneValuePanel(), null);
			exerciseDoseSummaryValuePanel.add(getExerciseDoseSummaryThicknessFiveValuePanel(), null);
			exerciseDoseSummaryValuePanel.add(getExerciseDoseSummaryThicknessTenValuePanel(), null);
			exerciseDoseSummaryValuePanel.add(getExerciseDoseSummaryThicknessThirtyValuePanel(), null);
		}
		return exerciseDoseSummaryValuePanel;
	}
 
	private JPanel getExerciseDoseSummaryThicknessPointThreePanel() {
		if (exerciseDoseSummaryThicknessPointThreePanel == null) {
			exerciseDoseSummaryThicknessPointThreeLabel = new JLabel();
			exerciseDoseSummaryThicknessPointThreePanel = new JPanel();
			exerciseDoseSummaryThicknessPointThreeLabel.setText("0.3");
			exerciseDoseSummaryThicknessPointThreePanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessPointThreePanel.add(exerciseDoseSummaryThicknessPointThreeLabel, null);
		}
		return exerciseDoseSummaryThicknessPointThreePanel;
	}
 
	private JPanel getExerciseDoseSummaryThicknessOneLabelPanel() {
		if (exerciseDoseSummaryThicknessOneLabelPanel == null) {
			exerciseDoseSummaryThicknessOneLabel = new JLabel();
			exerciseDoseSummaryThicknessOneLabelPanel = new JPanel();
			exerciseDoseSummaryThicknessOneLabel.setText("1");
			exerciseDoseSummaryThicknessOneLabelPanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessOneLabelPanel.add(exerciseDoseSummaryThicknessOneLabel, null);
		}
		return exerciseDoseSummaryThicknessOneLabelPanel;
	}
 
	private JPanel getExerciseDoseSummaryThicknessPointThreeValuePanel() {
		if (exerciseDoseSummaryThicknessPointThreeValuePanel == null) {
			exerciseDoseSummaryThicknessPointThreeValue = new JLabel();
			exerciseDoseSummaryThicknessPointThreeValuePanel = new JPanel();
			exerciseDoseSummaryThicknessPointThreeValue.setText("   ");
			exerciseDoseSummaryThicknessPointThreeValuePanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessPointThreeValuePanel.add(exerciseDoseSummaryThicknessPointThreeValue, null);
		}
		return exerciseDoseSummaryThicknessPointThreeValuePanel;
	}

	private JPanel getExerciseDoseSummaryThicknessFiveLabelPanel() {
		if (exerciseDoseSummaryThicknessFiveLabelPanel == null) {
			exerciseDoseSummaryThicknessFiveLabel = new JLabel();
			exerciseDoseSummaryThicknessFiveLabelPanel = new JPanel();
			exerciseDoseSummaryThicknessFiveLabel.setText("5");
			exerciseDoseSummaryThicknessFiveLabelPanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessFiveLabelPanel.add(exerciseDoseSummaryThicknessFiveLabel, null);
		}
		return exerciseDoseSummaryThicknessFiveLabelPanel;
	}

	private JPanel getExerciseDoseSummaryThicknessTenLabelPanel() {
		if (exerciseDoseSummaryThicknessTenLabelPanel == null) {
			exerciseDoseSummaryThicknessTenLabel = new JLabel();
			exerciseDoseSummaryThicknessTenLabelPanel = new JPanel();
			exerciseDoseSummaryThicknessTenLabel.setText("10");
			exerciseDoseSummaryThicknessTenLabelPanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessTenLabelPanel.add(exerciseDoseSummaryThicknessTenLabel, null);
		}
		return exerciseDoseSummaryThicknessTenLabelPanel;
	}
 
	private JPanel getExerciseDoseSummaryThicknessThirtyLabelPanel() {
		if (exerciseDoseSummaryThicknessThirtyLabelPanel == null) {
			exerciseDoseSummaryThicknessThirtyLabel = new JLabel();
			exerciseDoseSummaryThicknessThirtyLabelPanel = new JPanel();
			exerciseDoseSummaryThicknessThirtyLabel.setText("30");
			exerciseDoseSummaryThicknessThirtyLabelPanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessThirtyLabelPanel.add(exerciseDoseSummaryThicknessThirtyLabel, null);
		}
		return exerciseDoseSummaryThicknessThirtyLabelPanel;
	}
 
	private JPanel getExerciseDoseSummaryThicknessOneValuePanel() {
		if (exerciseDoseSummaryThicknessOneValuePanel == null) {
			exerciseDoseSummaryThicknessOneValue = new JLabel();
			exerciseDoseSummaryThicknessOneValuePanel = new JPanel();
			exerciseDoseSummaryThicknessOneValue.setText("   ");
			exerciseDoseSummaryThicknessOneValuePanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessOneValuePanel.add(exerciseDoseSummaryThicknessOneValue, null);
		}
		return exerciseDoseSummaryThicknessOneValuePanel;
	}

	private JPanel getExerciseDoseSummaryThicknessFiveValuePanel() {
		if (exerciseDoseSummaryThicknessFiveValuePanel == null) {
			exerciseDoseSummaryThicknessFiveValue = new JLabel();
			exerciseDoseSummaryThicknessFiveValuePanel = new JPanel();
			exerciseDoseSummaryThicknessFiveValue.setText("   ");
			exerciseDoseSummaryThicknessFiveValuePanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessFiveValuePanel.add(exerciseDoseSummaryThicknessFiveValue, null);
		}
		return exerciseDoseSummaryThicknessFiveValuePanel;
	}

	private JPanel getExerciseDoseSummaryThicknessTenValuePanel() {
		if (exerciseDoseSummaryThicknessTenValuePanel == null) {
			exerciseDoseSummaryThicknessTenValue = new JLabel();
			exerciseDoseSummaryThicknessTenValuePanel = new JPanel();
			exerciseDoseSummaryThicknessTenValue.setText("   ");
			exerciseDoseSummaryThicknessTenValuePanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessTenValuePanel.add(exerciseDoseSummaryThicknessTenValue, null);
		}
		return exerciseDoseSummaryThicknessTenValuePanel;
	}

	private JPanel getExerciseDoseSummaryThicknessThirtyValuePanel() {
		if (exerciseDoseSummaryThicknessThirtyValuePanel == null) {
			exerciseDoseSummaryThicknessThirtyValue = new JLabel();
			exerciseDoseSummaryThicknessThirtyValuePanel = new JPanel();
			exerciseDoseSummaryThicknessThirtyValue.setText("   ");
			exerciseDoseSummaryThicknessThirtyValuePanel.setPreferredSize(new java.awt.Dimension(20,25));
			exerciseDoseSummaryThicknessThirtyValuePanel.add(exerciseDoseSummaryThicknessThirtyValue, null);
		}
		return exerciseDoseSummaryThicknessThirtyValuePanel;
	}

	private JPanel getExerciseTimeSelectionPanel() {
		if (exerciseTimeSelectionPanel == null) {
			exerciseTimeSelectionPanel = new JPanel();
			exerciseTimeSelectionPanel.setLayout(new BoxLayout(exerciseTimeSelectionPanel, BoxLayout.Y_AXIS));
			exerciseTimeSelectionPanel.setBounds(15, 195, 616, 151);
			exerciseTimeSelectionPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
			exerciseTimeSelectionPanel.add(getExerciseTimeSelectionLabelsPanel(), null);
			exerciseTimeSelectionPanel.add(getExerciseTimeSelectionPriorToOnsetPanel(), null);
			exerciseTimeSelectionPanel.add(getExerciseTimeSelectionPackingUpPanel(), null);
			exerciseTimeSelectionPanel.add(getExerciseTimeSelectionTransitPanel(), null);
			exerciseTimeSelectionPanel.add(getExerciseTimeSelectionInBasePanel(), null);
		}
		return exerciseTimeSelectionPanel;
	}
 
	private JPanel getExerciseTimeSelectionLabelsPanel() {
		if (exerciseTimeSelectionLabelsPanel == null) {
			exerciseTimeSelectionLabelsPanel = new JPanel();
			exerciseTimeSelectionLabelsPanel.setLayout(new BoxLayout(exerciseTimeSelectionLabelsPanel, BoxLayout.X_AXIS));
			exerciseTimeSelectionLabelsPanel.add(getExerciseTimeSelectionTopLeftCornerPanel(), null);
			exerciseTimeSelectionLabelsPanel.add(getExerciseTimeSelectionTimeInputLabelPanel(), null);
			exerciseTimeSelectionLabelsPanel.add(getExerciseTimeSelectionMinutesInputLabelPanel(), null);
			exerciseTimeSelectionLabelsPanel.add(getExerciseTimeSelectionHoursInputLabelPanel(), null);
			exerciseTimeSelectionLabelsPanel.add(getExerciseTimeSelectionDoseLabelPanel(), null);
			exerciseTimeSelectionLabelsPanel.add(getExerciseTimeSelectionPercentOfTotalValuePanel(), null);
		}
		return exerciseTimeSelectionLabelsPanel;
	}

	private JPanel getExerciseTimeSelectionPriorToOnsetPanel() {
		if (exerciseTimeSelectionPriorToOnsetPanel == null) {
			exerciseTimeSelectionPriorToOnsetPanel = new JPanel();
			exerciseTimeSelectionPriorToOnsetPanel.setLayout(new BoxLayout(exerciseTimeSelectionPriorToOnsetPanel, BoxLayout.X_AXIS));
			exerciseTimeSelectionPriorToOnsetPanel.add(getExerciseTimeSelectionPriorToOnsetLabelPanel(), null);
			exerciseTimeSelectionPriorToOnsetPanel.add(getExerciseTimeSelectionPriorToOnsetInputPanel(), null);
			exerciseTimeSelectionPriorToOnsetPanel.add(getExerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel(), null);
			exerciseTimeSelectionPriorToOnsetPanel.add(getExerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel(), null);
			exerciseTimeSelectionPriorToOnsetPanel.add(getExerciseTimeSelectionPriorToOnsetDoseValuePanel(), null);
			exerciseTimeSelectionPriorToOnsetPanel.add(getExerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel(), null);
		}
		return exerciseTimeSelectionPriorToOnsetPanel;
	}

	private JPanel getExerciseTimeSelectionPackingUpPanel() {
		if (exerciseTimeSelectionPackingUpPanel == null) {
			exerciseTimeSelectionPackingUpPanel = new JPanel();
			exerciseTimeSelectionPackingUpPanel.setLayout(new BoxLayout(exerciseTimeSelectionPackingUpPanel, BoxLayout.X_AXIS));
			exerciseTimeSelectionPackingUpPanel.add(getExerciseTimeSelectionPackingUpLabelPanel(), null);
			exerciseTimeSelectionPackingUpPanel.add(getExerciseTimeSelectionPackingUpInputPanel(), null);
			exerciseTimeSelectionPackingUpPanel.add(getExerciseTimeSelectionPackingUpMinutesRadioButtonLabel(), null);
			exerciseTimeSelectionPackingUpPanel.add(getExerciseTimeSelectionPackingUpHoursRadioButtonPanel(), null);
			exerciseTimeSelectionPackingUpPanel.add(getExerciseTimeSelectionPackingUpDoseValuePanel(), null);
			exerciseTimeSelectionPackingUpPanel.add(getExerciseTimeSelectionPackingUpPercentOfTotalValuePanel(), null);
		}
		return exerciseTimeSelectionPackingUpPanel;
	}

	private JPanel getExerciseTimeSelectionTransitPanel() {
		if (exerciseTimeSelectionTransitPanel == null) {
			exerciseTimeSelectionTransitPanel = new JPanel();
			exerciseTimeSelectionTransitPanel.setLayout(new BoxLayout(exerciseTimeSelectionTransitPanel, BoxLayout.X_AXIS));
			exerciseTimeSelectionTransitPanel.add(getExerciseTimeSelectionTransitLabelPanel(), null);
			exerciseTimeSelectionTransitPanel.add(getExerciseTimeSelectionTransitInputPanel(), null);
			exerciseTimeSelectionTransitPanel.add(getExerciseTimeSelectionTransitMinutesRadioButtonPanel(), null);
			exerciseTimeSelectionTransitPanel.add(getExerciseTimeSelectionTransitHoursRadioButtonPanel(), null);
			exerciseTimeSelectionTransitPanel.add(getExerciseTimeSelectionTransitDoseValuePanel(), null);
			exerciseTimeSelectionTransitPanel.add(getExerciseTimeSelectionTransitPercentOfTotalValuePanel(), null);
		}
		return exerciseTimeSelectionTransitPanel;
	}

	private JPanel getExerciseTimeSelectionInBasePanel() {
		if (exerciseTimeSelectionInBasePanel == null) {
			exerciseTimeSelectionInBasePanel = new JPanel();
			exerciseTimeSelectionInBasePanel.setLayout(new BoxLayout(exerciseTimeSelectionInBasePanel, BoxLayout.X_AXIS));
			exerciseTimeSelectionInBasePanel.add(getExerciseTimeSelectionInBaseLabelPanel(), null);
			exerciseTimeSelectionInBasePanel.add(getExerciseTimeSelectionInBaseNotInputPanel(), null);
			exerciseTimeSelectionInBasePanel.add(getExerciseTimeSelectionInBaseMinutesRadioButtonPanel(), null);
			exerciseTimeSelectionInBasePanel.add(getExerciseTimeSelectionInBaseHoursRadioButtonPanel(), null);
			exerciseTimeSelectionInBasePanel.add(getExerciseTimeSelectionInBaseDoseValuePanel(), null);
			exerciseTimeSelectionInBasePanel.add(getExerciseTimeSelectionInBasePercentOfTotalValuePanel(), null);
		}
		return exerciseTimeSelectionInBasePanel;
	}

	private JPanel getExerciseTimeSelectionPriorToOnsetLabelPanel() {
		if (exerciseTimeSelectionPriorToOnsetLabelPanel == null) {
			GridLayout gridLayout5 = new GridLayout();
			exerciseTimeSelectionPriorToOnsetLabel = new JLabel();
			exerciseTimeSelectionPriorToOnsetLabelPanel = new JPanel();
			exerciseTimeSelectionPriorToOnsetLabelPanel.setLayout(gridLayout5);
			exerciseTimeSelectionPriorToOnsetLabel.setText("  Warning time (prior to event onset):");
			exerciseTimeSelectionPriorToOnsetLabelPanel.setPreferredSize(new java.awt.Dimension(200,10));
			gridLayout5.setRows(1);
			exerciseTimeSelectionPriorToOnsetLabelPanel.add(exerciseTimeSelectionPriorToOnsetLabel, null);
		}
		return exerciseTimeSelectionPriorToOnsetLabelPanel;
	}

	private JPanel getExerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel() {
		if (exerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel == null) {
			exerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel = new JPanel();
			exerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel.add(getPriorToOnsetMinutesRadioButton(), null);
		}
		return exerciseTimeSelectionPriorToOnsetMinutesRadioButtonPanel;
	}
   
	private JPanel getExerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel() {
		if (exerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel == null) {
			exerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel = new JPanel();
			exerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel.add(getPriorToOnsetHoursRadioButton(), null);
		}
		return exerciseTimeSelectionPriorToOnsetHoursRadioButtonPanel;
	}
  
	private JRadioButton getPriorToOnsetMinutesRadioButton() {
		if (priorToOnsetMinutesRadioButton == null) {
			priorToOnsetMinutesRadioButton = new JRadioButton();
			priorToOnsetMinutesRadioButton.setSelected(true);
		}
		return priorToOnsetMinutesRadioButton;
	}
   
	private JRadioButton getPriorToOnsetHoursRadioButton() {
		if (priorToOnsetHoursRadioButton == null) {
			priorToOnsetHoursRadioButton = new JRadioButton();
		}
		return priorToOnsetHoursRadioButton;
	}
  
	private JPanel getExerciseTimeSelectionPriorToOnsetDoseValuePanel() {
		if (exerciseTimeSelectionPriorToOnsetDoseValuePanel == null) {
			GridLayout gridLayout10 = new GridLayout();
			exerciseTimeSelectionPriorToOnsetDoseValue = new JLabel();
			exerciseTimeSelectionPriorToOnsetDoseValuePanel = new JPanel();
			exerciseTimeSelectionPriorToOnsetDoseValuePanel.setLayout(gridLayout10);
			exerciseTimeSelectionPriorToOnsetDoseValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			exerciseTimeSelectionPriorToOnsetDoseValuePanel.setBackground(null);
			exerciseTimeSelectionPriorToOnsetDoseValuePanel.setComponentOrientation(java.awt.ComponentOrientation.UNKNOWN);
			exerciseTimeSelectionPriorToOnsetDoseValue.setText("   ");
			exerciseTimeSelectionPriorToOnsetDoseValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPriorToOnsetDoseValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			gridLayout10.setRows(1);
			exerciseTimeSelectionPriorToOnsetDoseValuePanel.add(exerciseTimeSelectionPriorToOnsetDoseValue, null);
		}
		return exerciseTimeSelectionPriorToOnsetDoseValuePanel;
	}

	private JPanel getExerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel() {
		if (exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel == null) {
			GridLayout gridLayout32 = new GridLayout();
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValue = new JLabel();
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel = new JPanel();
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel.setLayout(gridLayout32);
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel.setBackground(null);
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValue.setText("   ");
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			gridLayout32.setRows(1);
			exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel.add(exerciseTimeSelectionPriorToOnsetPercentOfTotalValue, null);
		}
		return exerciseTimeSelectionPriorToOnsetPercentOfTotalValuePanel;
	}
  
	private JPanel getExerciseTimeSelectionPriorToOnsetInputPanel() {
		if (exerciseTimeSelectionPriorToOnsetInputPanel == null) {
			GridLayout gridLayout1 = new GridLayout();
			exerciseTimeSelectionPriorToOnsetInputPanel = new JPanel();
			exerciseTimeSelectionPriorToOnsetInputPanel.setLayout(gridLayout1);
			exerciseTimeSelectionPriorToOnsetInputPanel.setPreferredSize(new java.awt.Dimension(60,20));
			gridLayout1.setRows(1);
			exerciseTimeSelectionPriorToOnsetInputPanel.add(getExerciseTimeSelectionPriorToOnsetInput(), null);
		}
		return exerciseTimeSelectionPriorToOnsetInputPanel;
	}

	private JTextField getExerciseTimeSelectionPriorToOnsetInput() {
		if (exerciseTimeSelectionPriorToOnsetInput == null) {
			exerciseTimeSelectionPriorToOnsetInput = new JTextField();
			exerciseTimeSelectionPriorToOnsetInput.setNextFocusableComponent(
				exerciseTimeSelectionPackingUpInput
		    );
			exerciseTimeSelectionPriorToOnsetInput.setPreferredSize(new java.awt.Dimension(15,20));
			exerciseTimeSelectionPriorToOnsetInput.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					exerciseTimeSelectionPackingUpInput.requestFocus();
				}
			});
		}
		return exerciseTimeSelectionPriorToOnsetInput;
	}

	private JPanel getExerciseTimeSelectionPackingUpLabelPanel() {
		if (exerciseTimeSelectionPackingUpLabelPanel == null) {
			GridLayout gridLayout6 = new GridLayout();
			exerciseTimeSelectionPackingUpLabel = new JLabel();
			exerciseTimeSelectionPackingUpLabelPanel = new JPanel();
			exerciseTimeSelectionPackingUpLabelPanel.setLayout(gridLayout6);
			exerciseTimeSelectionPackingUpLabel.setText("  Time to pack up and enter rover:");
			exerciseTimeSelectionPackingUpLabelPanel.setPreferredSize(new java.awt.Dimension(200,10));
			gridLayout6.setRows(1);
			exerciseTimeSelectionPackingUpLabelPanel.add(exerciseTimeSelectionPackingUpLabel, null);
		}
		return exerciseTimeSelectionPackingUpLabelPanel;
	}

	private JPanel getExerciseTimeSelectionPackingUpInputPanel() {
		if (exerciseTimeSelectionPackingUpInputPanel == null) {
			GridLayout gridLayout11 = new GridLayout();
			exerciseTimeSelectionPackingUpInputPanel = new JPanel();
			exerciseTimeSelectionPackingUpInputPanel.setLayout(gridLayout11);
			gridLayout11.setRows(1);
			exerciseTimeSelectionPackingUpInputPanel.setPreferredSize(new java.awt.Dimension(60,20));
			exerciseTimeSelectionPackingUpInputPanel.add(getExerciseTimeSelectionPackingUpInput(), null);
		}
		return exerciseTimeSelectionPackingUpInputPanel;
	}

	private JPanel getExerciseTimeSelectionPackingUpMinutesRadioButtonLabel() {
		if (exerciseTimeSelectionPackingUpMinutesRadioButtonLabel == null) {
			exerciseTimeSelectionPackingUpMinutesRadioButtonLabel = new JPanel();
			exerciseTimeSelectionPackingUpMinutesRadioButtonLabel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionPackingUpMinutesRadioButtonLabel.add(getPackingUpMinutesRadioButton(), null);
		}
		return exerciseTimeSelectionPackingUpMinutesRadioButtonLabel;
	}

	private JPanel getExerciseTimeSelectionPackingUpHoursRadioButtonPanel() {
		if (exerciseTimeSelectionPackingUpHoursRadioButtonPanel == null) {
			exerciseTimeSelectionPackingUpHoursRadioButtonPanel = new JPanel();
			exerciseTimeSelectionPackingUpHoursRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionPackingUpHoursRadioButtonPanel.add(getPackingUpHoursRadioButton(), null);
		}
		return exerciseTimeSelectionPackingUpHoursRadioButtonPanel;
	}
   
	private JPanel getExerciseTimeSelectionPackingUpDoseValuePanel() {
		if (exerciseTimeSelectionPackingUpDoseValuePanel == null) {
			GridLayout gridLayout9 = new GridLayout();
			exerciseTimeSelectionPackingUpDoseValue = new JLabel();
			exerciseTimeSelectionPackingUpDoseValuePanel = new JPanel();
			exerciseTimeSelectionPackingUpDoseValuePanel.setLayout(gridLayout9);
			exerciseTimeSelectionPackingUpDoseValue.setText("   ");
			exerciseTimeSelectionPackingUpDoseValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPackingUpDoseValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPackingUpDoseValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			gridLayout9.setRows(1);
			exerciseTimeSelectionPackingUpDoseValuePanel.add(exerciseTimeSelectionPackingUpDoseValue, null);
		}
		return exerciseTimeSelectionPackingUpDoseValuePanel;
	}
  
	private JTextField getExerciseTimeSelectionPackingUpInput() {
		if (exerciseTimeSelectionPackingUpInput == null) {
			exerciseTimeSelectionPackingUpInput = new JTextField();
			exerciseTimeSelectionPackingUpInput.setNextFocusableComponent(
				exerciseTimeSelectionTransitInput
			);
			exerciseTimeSelectionPackingUpInput.setPreferredSize(new java.awt.Dimension(15,20));
			exerciseTimeSelectionPackingUpInput.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					exerciseTimeSelectionTransitInput.requestFocus();
				}
			});
		}
		return exerciseTimeSelectionPackingUpInput;
	}
  
	private JRadioButton getPackingUpMinutesRadioButton() {
		if (packingUpMinutesRadioButton == null) {
			packingUpMinutesRadioButton = new JRadioButton();
			packingUpMinutesRadioButton.setSelected(true);
		}
		return packingUpMinutesRadioButton;
	}

	private JRadioButton getPackingUpHoursRadioButton() {
		if (packingUpHoursRadioButton == null) {
			packingUpHoursRadioButton = new JRadioButton();
		}
		return packingUpHoursRadioButton;
	}

	private JPanel getExerciseTimeSelectionPackingUpPercentOfTotalValuePanel() {
		if (exerciseTimeSelectionPackingUpPercentOfTotalValuePanel == null) {
			GridLayout gridLayout42 = new GridLayout();
			exerciseTimeSelectionPackingUpPercentOfTotalValue = new JLabel();
			exerciseTimeSelectionPackingUpPercentOfTotalValuePanel = new JPanel();
			exerciseTimeSelectionPackingUpPercentOfTotalValuePanel.setLayout(gridLayout42);
			exerciseTimeSelectionPackingUpPercentOfTotalValue.setText("   ");
			exerciseTimeSelectionPackingUpPercentOfTotalValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPackingUpPercentOfTotalValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPackingUpPercentOfTotalValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			gridLayout42.setRows(1);
			exerciseTimeSelectionPackingUpPercentOfTotalValuePanel.add(exerciseTimeSelectionPackingUpPercentOfTotalValue, null);
		}
		return exerciseTimeSelectionPackingUpPercentOfTotalValuePanel;
	}
  
	private JPanel getExerciseTimeSelectionTransitLabelPanel() {
		if (exerciseTimeSelectionTransitLabelPanel == null) {
			exerciseTimeSelectionTransitLabel = new JLabel();
			GridLayout gridLayout7 = new GridLayout();
			exerciseTimeSelectionTransitLabelPanel = new JPanel();
			exerciseTimeSelectionTransitLabelPanel.setLayout(gridLayout7);
			exerciseTimeSelectionTransitLabel.setText("  Transit time to base:");
			exerciseTimeSelectionTransitLabelPanel.setPreferredSize(new java.awt.Dimension(200,10));
			gridLayout7.setRows(1);
			exerciseTimeSelectionTransitLabelPanel.add(exerciseTimeSelectionTransitLabel, null);
		}
		return exerciseTimeSelectionTransitLabelPanel;
	}
 
	private JPanel getExerciseTimeSelectionTransitInputPanel() {
		if (exerciseTimeSelectionTransitInputPanel == null) {
			GridLayout gridLayout2 = new GridLayout();
			exerciseTimeSelectionTransitInputPanel = new JPanel();
			exerciseTimeSelectionTransitInputPanel.setLayout(gridLayout2);
			gridLayout2.setRows(1);
			exerciseTimeSelectionTransitInputPanel.setPreferredSize(new java.awt.Dimension(60,20));
			exerciseTimeSelectionTransitInputPanel.add(getExerciseTimeSelectionTransitInput(), null);
		}
		return exerciseTimeSelectionTransitInputPanel;
	}

	private JPanel getExerciseTimeSelectionTransitMinutesRadioButtonPanel() {
		if (exerciseTimeSelectionTransitMinutesRadioButtonPanel == null) {
			exerciseTimeSelectionTransitMinutesRadioButtonPanel = new JPanel();
			exerciseTimeSelectionTransitMinutesRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionTransitMinutesRadioButtonPanel.add(getTransitMinutesRadioButton(), null);
		}
		return exerciseTimeSelectionTransitMinutesRadioButtonPanel;
	}

	private JPanel getExerciseTimeSelectionTransitHoursRadioButtonPanel() {
		if (exerciseTimeSelectionTransitHoursRadioButtonPanel == null) {
			exerciseTimeSelectionTransitHoursRadioButtonPanel = new JPanel();
			exerciseTimeSelectionTransitHoursRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionTransitHoursRadioButtonPanel.add(getTransitHoursRadioButton(), null);
		}
		return exerciseTimeSelectionTransitHoursRadioButtonPanel;
	}

	private JPanel getExerciseTimeSelectionTransitPercentOfTotalValuePanel() {
		if (exerciseTimeSelectionTransitPercentOfTotalValuePanel == null) {
			GridLayout gridLayout51 = new GridLayout();
			exerciseTimeSelectionTransitPercentOfTotalValue = new JLabel();
			exerciseTimeSelectionTransitPercentOfTotalValuePanel = new JPanel();
			exerciseTimeSelectionTransitPercentOfTotalValuePanel.setLayout(gridLayout51);
			exerciseTimeSelectionTransitPercentOfTotalValue.setText("   ");
			exerciseTimeSelectionTransitPercentOfTotalValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionTransitPercentOfTotalValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionTransitPercentOfTotalValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			gridLayout51.setRows(1);
			exerciseTimeSelectionTransitPercentOfTotalValuePanel.add(exerciseTimeSelectionTransitPercentOfTotalValue, null);
		}
		return exerciseTimeSelectionTransitPercentOfTotalValuePanel;
	}

	private JPanel getExerciseTimeSelectionInBaseNotInputPanel() {
		if (exerciseTimeSelectionInBaseNotInputPanel == null) {
			GridLayout gridLayout3 = new GridLayout();
			exerciseTimeSelectionInBaseNotInputPanel = new JPanel();
			exerciseTimeSelectionInBaseNotInputPanel.setLayout(gridLayout3);
			gridLayout3.setRows(1);
			exerciseTimeSelectionInBaseNotInputPanel.setPreferredSize(new java.awt.Dimension(60,20));
			exerciseTimeSelectionInBaseNotInputPanel.add(getExerciseTimeSelectionInBaseNotInput(), null);
		}
		return exerciseTimeSelectionInBaseNotInputPanel;
	}

	private JPanel getExerciseTimeSelectionInBaseMinutesRadioButtonPanel() {
		if (exerciseTimeSelectionInBaseMinutesRadioButtonPanel == null) {
			exerciseTimeSelectionInBaseMinutesRadioButtonPanel = new JPanel();
			exerciseTimeSelectionInBaseMinutesRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionInBaseMinutesRadioButtonPanel.add(getExerciseTimeSelectionInBaseMinutesRadioButton(), null);
		}
		return exerciseTimeSelectionInBaseMinutesRadioButtonPanel;
	}
 
	private JPanel getExerciseTimeSelectionInBaseDoseValuePanel() {
		if (exerciseTimeSelectionInBaseDoseValuePanel == null) {
			GridLayout gridLayout71 = new GridLayout();
			exerciseTimeSelectionInBaseDoseValue = new JLabel();
			exerciseTimeSelectionInBaseDoseValuePanel = new JPanel();
			exerciseTimeSelectionInBaseDoseValuePanel.setLayout(gridLayout71);
			exerciseTimeSelectionInBaseDoseValue.setText("   ");
			exerciseTimeSelectionInBaseDoseValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionInBaseDoseValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionInBaseDoseValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			gridLayout71.setRows(1);
			exerciseTimeSelectionInBaseDoseValuePanel.add(exerciseTimeSelectionInBaseDoseValue, null);
		}
		return exerciseTimeSelectionInBaseDoseValuePanel;
	}
   
	private JPanel getExerciseTimeSelectionInBasePercentOfTotalValuePanel() {
		if (exerciseTimeSelectionInBasePercentOfTotalValuePanel == null) {
			GridLayout gridLayout61 = new GridLayout();
			exerciseTimeSelectionInBasePercentOfTotalValue = new JLabel();
			exerciseTimeSelectionInBasePercentOfTotalValuePanel = new JPanel();
			exerciseTimeSelectionInBasePercentOfTotalValuePanel.setLayout(gridLayout61);
			exerciseTimeSelectionInBasePercentOfTotalValue.setText("   ");
			exerciseTimeSelectionInBasePercentOfTotalValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionInBasePercentOfTotalValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionInBasePercentOfTotalValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			gridLayout61.setRows(1);
			exerciseTimeSelectionInBasePercentOfTotalValuePanel.add(exerciseTimeSelectionInBasePercentOfTotalValue, null);
		}
		return exerciseTimeSelectionInBasePercentOfTotalValuePanel;
	}
 
	private JPanel getExerciseTimeSelectionTopLeftCornerPanel() {
		if (exerciseTimeSelectionTopLeftCornerPanel == null) {
			exerciseTimeSelectionTopLeftCornerPanel = new JPanel();
			exerciseTimeSelectionTopLeftCornerPanel.setPreferredSize(new java.awt.Dimension(200,10));
		}
		return exerciseTimeSelectionTopLeftCornerPanel;
	}

	private JPanel getExerciseTimeSelectionTimeInputLabelPanel() {
		if (exerciseTimeSelectionTimeInputLabelPanel == null) {
			exerciseTimeSelectionTimeInputLabelPanel = new JPanel();
			exerciseTimeSelectionTimeInputLabel = new JLabel();
			exerciseTimeSelectionTimeInputLabel.setText("Time");
			exerciseTimeSelectionTimeInputLabelPanel.setPreferredSize(new java.awt.Dimension(60,20));
			exerciseTimeSelectionTimeInputLabelPanel.add(exerciseTimeSelectionTimeInputLabel, null);
		}
		return exerciseTimeSelectionTimeInputLabelPanel;
	}
   
	private JPanel getExerciseTimeSelectionMinutesInputLabelPanel() {
		if (exerciseTimeSelectionMinutesInputLabelPanel == null) {
			exerciseTimeSelectionMinutesInputLabelPanel = new JPanel();
			exerciseTimeSelectionMinutesInputLabel = new JLabel();
			exerciseTimeSelectionMinutesInputLabel.setText("Minutes");
			exerciseTimeSelectionMinutesInputLabelPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionMinutesInputLabelPanel.add(exerciseTimeSelectionMinutesInputLabel, null);
		}
		return exerciseTimeSelectionMinutesInputLabelPanel;
	}

	private JPanel getExerciseTimeSelectionHoursInputLabelPanel() {
		if (exerciseTimeSelectionHoursInputLabelPanel == null) {
			exerciseTimeSelectionHoursInputLabelPanel = new JPanel();
			exerciseTimeSelectionHoursInputLabel = new JLabel();
			exerciseTimeSelectionHoursInputLabel.setText("Hours");
			exerciseTimeSelectionHoursInputLabelPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionHoursInputLabelPanel.add(exerciseTimeSelectionHoursInputLabel, null);
		}
		return exerciseTimeSelectionHoursInputLabelPanel;
	}
 
	private JPanel getExerciseTimeSelectionDoseLabelPanel() {
		if (exerciseTimeSelectionDoseLabelPanel == null) {
			exerciseTimeSelectionDoseLabelPanel = new JPanel();
			exerciseTimeSelectionDoseValue = new JLabel();
			exerciseTimeSelectionDoseValue.setText("   ");
			exerciseTimeSelectionDoseLabelPanel.setPreferredSize(new java.awt.Dimension(25,10));
			exerciseTimeSelectionDoseLabelPanel.add(exerciseTimeSelectionDoseValue, null);
		}
		return exerciseTimeSelectionDoseLabelPanel;
	}
  
	private JPanel getExerciseTimeSelectionPercentOfTotalValuePanel() {
		if (exerciseTimeSelectionPercentOfTotalValuePanel == null) {
			exerciseTimeSelectionPercentOfTotalValue = new JLabel();
			exerciseTimeSelectionPercentOfTotalValuePanel = new JPanel();
			exerciseTimeSelectionPercentOfTotalValue.setText("  % of Total");
			exerciseTimeSelectionPercentOfTotalValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPercentOfTotalValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionPercentOfTotalValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			exerciseTimeSelectionPercentOfTotalValuePanel.add(exerciseTimeSelectionPercentOfTotalValue, null);
		}
		return exerciseTimeSelectionPercentOfTotalValuePanel;
	}
  
	private JPanel getExerciseTimeSelectionTransitDoseValuePanel() {
		if (exerciseTimeSelectionTransitDoseValuePanel == null) {
			GridLayout gridLayout8 = new GridLayout();
			exerciseTimeSelectionTransitDoseValue = new JLabel();
			exerciseTimeSelectionTransitDoseValuePanel = new JPanel();
			exerciseTimeSelectionTransitDoseValuePanel.setLayout(gridLayout8);
			exerciseTimeSelectionTransitDoseValue.setText("   ");
			exerciseTimeSelectionTransitDoseValue.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionTransitDoseValue.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			exerciseTimeSelectionTransitDoseValuePanel.setPreferredSize(new java.awt.Dimension(25,10));
			gridLayout8.setRows(1);
			exerciseTimeSelectionTransitDoseValuePanel.add(exerciseTimeSelectionTransitDoseValue, null);
		}
		return exerciseTimeSelectionTransitDoseValuePanel;
	}

	private JPanel getExerciseTimeSelectionInBaseLabelPanel() {
		if (exerciseTimeSelectionInBaseLabelPanel == null) {
			exerciseTimeSelectionInBaseLabel = new JLabel();
			GridLayout gridLayout4 = new GridLayout();
			exerciseTimeSelectionInBaseLabelPanel = new JPanel();
			exerciseTimeSelectionInBaseLabelPanel.setLayout(gridLayout4);
			exerciseTimeSelectionInBaseLabel.setText("  Exposed in base:");
			exerciseTimeSelectionInBaseLabelPanel.setPreferredSize(new java.awt.Dimension(200,10));
			gridLayout4.setRows(1);
			exerciseTimeSelectionInBaseLabelPanel.add(exerciseTimeSelectionInBaseLabel, null);
		}
		return exerciseTimeSelectionInBaseLabelPanel;
	}
  
	private JTextField getExerciseTimeSelectionTransitInput() {
		if (exerciseTimeSelectionTransitInput == null) {
			exerciseTimeSelectionTransitInput = new JTextField();
			exerciseTimeSelectionTransitInput.setNextFocusableComponent(
				exerciseCalculateButton
			);
			exerciseTimeSelectionTransitInput.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					exerciseCalculateButton.requestFocus();
				}
			});
		}
		return exerciseTimeSelectionTransitInput;
	}

	private JTextField getExerciseTimeSelectionInBaseNotInput() {
		if (exerciseTimeSelectionInBaseNotInput == null) {
			exerciseTimeSelectionInBaseNotInput = new JTextField();
			exerciseTimeSelectionInBaseNotInput.setEditable(false);
			exerciseTimeSelectionInBaseNotInput.setEnabled(true);
			exerciseTimeSelectionInBaseNotInput.setBackground(this.getBackground());
		}
		return exerciseTimeSelectionInBaseNotInput;
	}
  
	private JRadioButton getTransitMinutesRadioButton() {
		if (transitMinutesRadioButton == null) {
			transitMinutesRadioButton = new JRadioButton();
		}
		return transitMinutesRadioButton;
	}

	private JRadioButton getTransitHoursRadioButton() {
		if (transitHoursRadioButton == null) {
			transitHoursRadioButton = new JRadioButton();
			transitHoursRadioButton.setSelected(true);
		}
		return transitHoursRadioButton;
	}
 
	private JRadioButton getExerciseTimeSelectionInBaseMinutesRadioButton() {
		if (inBaseMinutesRadioButton == null) {
			inBaseMinutesRadioButton = new JRadioButton();
			inBaseMinutesRadioButton.setEnabled(false);
		}
		return inBaseMinutesRadioButton;
	}

	private JPanel getExerciseTotalTimeEvolutionDosePanel() {
		if (exerciseTotalTimeEvolutionDosePanel == null) {
			exerciseTotalTimeEvolutionDosePanel = new JPanel();
			exerciseTotalTimeEvolutionDosePanel.setLayout(new BoxLayout(exerciseTotalTimeEvolutionDosePanel, BoxLayout.Y_AXIS));
			exerciseTotalTimeEvolutionDosePanel.setLocation(165, 360);
			exerciseTotalTimeEvolutionDosePanel.setSize(466, 46);
			exerciseTotalTimeEvolutionDosePanel.add(getExerciseTotalTimeEvolutionDoseAwayFromShelterPanel(), null);
			exerciseTotalTimeEvolutionDosePanel.add(getExerciseTotalTimeEvolutionDoseAtShelterPanel(), null);
		}
		return exerciseTotalTimeEvolutionDosePanel;
	}

	private JPanel getExerciseTotalTimeEvolutionDoseAwayFromShelterPanel() {
		if (exerciseTotalTimeEvolutionDoseAwayFromShelterPanel == null) {
			exerciseTotalTimeEvolutionDoseAwayFromShelterPanel = new JPanel();
			exerciseTotalTimeEvolutionDoseAwayFromShelterPanel.setLayout(new BoxLayout(exerciseTotalTimeEvolutionDoseAwayFromShelterPanel, BoxLayout.X_AXIS));
			exerciseTotalTimeEvolutionDoseAwayFromShelterPanel.add(getExerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel(), null);
			exerciseTotalTimeEvolutionDoseAwayFromShelterPanel.add(getExerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel(), null);
		}
		return exerciseTotalTimeEvolutionDoseAwayFromShelterPanel;
	}

	private JPanel getExerciseTotalTimeEvolutionDoseAtShelterPanel() {
		if (exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel == null) {
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel = new JPanel();
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel.setLayout(new BoxLayout(exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel, BoxLayout.X_AXIS));
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel.add(getExerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel(), null);
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel.add(getExerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel(), null);
		}
		return exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBasePanel;
	}
 
	private JPanel getExerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel() {
		if (exerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel == null) {
			exerciseTotalTimeEvolutionDoseAwayFromShelterLabel = new JLabel();
			GridLayout gridLayout41 = new GridLayout();
			exerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel = new JPanel();
			exerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel.setLayout(gridLayout41);
			exerciseTotalTimeEvolutionDoseAwayFromShelterLabel.setText("   ");
			exerciseTotalTimeEvolutionDoseAwayFromShelterLabel.setPreferredSize(new java.awt.Dimension(250,15));
			gridLayout41.setRows(1);
			exerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel.add(exerciseTotalTimeEvolutionDoseAwayFromShelterLabel, null);
		}
		return exerciseTotalTimeEvolutionDoseAwayFromShelterLabelPanel;
	}

	private JPanel getExerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel() {
		if (exerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel == null) {
			GridLayout gridLayout13 = new GridLayout();
			exerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel = new JPanel();
			exerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel.setLayout(gridLayout13);
			gridLayout13.setRows(1);
			exerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel.add(getExerciseTotalTimeEvolutionDoseAwayFromShelterValue(), null);
		}
		return exerciseTotalTimeEvolutionDoseAwayFromShelterValuePanel;
	}
 
	private JPanel getExerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel() {
		if (exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel == null) {
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabel = new JLabel();
			GridLayout gridLayout31 = new GridLayout();
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel = new JPanel();
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel.setLayout(gridLayout31);
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabel.setText("Compared to an astronaut that stayed under shelter:");
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabel.setPreferredSize(new java.awt.Dimension(250,15));
			gridLayout31.setRows(1);
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel.add(exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabel, null);
		}
		return exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseLabelPanel;
	}

	private JPanel getExerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel() {
		if (exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel == null) {
			GridLayout gridLayout21 = new GridLayout();
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel = new JPanel();
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel.setLayout(gridLayout21);
			gridLayout21.setRows(1);
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel.add(getExerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue(), null);
		}
		return exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValuePanel;
	}

	private JTextField getExerciseTotalTimeEvolutionDoseAwayFromShelterValue() {
		if (exerciseTotalTimeEvolutionDoseAwayFromShelterValue == null) {
			exerciseTotalTimeEvolutionDoseAwayFromShelterValue = new JTextField();
			exerciseTotalTimeEvolutionDoseAwayFromShelterValue.setBackground(this.getBackground());
			exerciseTotalTimeEvolutionDoseAwayFromShelterValue.setPreferredSize(new java.awt.Dimension(10,15));
			exerciseTotalTimeEvolutionDoseAwayFromShelterValue.setEditable(false);
			exerciseTotalTimeEvolutionDoseAwayFromShelterValue.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
		}
		return exerciseTotalTimeEvolutionDoseAwayFromShelterValue;
	}

	private JTextField getExerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue() {
		if (exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue == null) {
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue = new JTextField();
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue.setBackground(this.getBackground());
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue.setPreferredSize(new java.awt.Dimension(10,15));
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue.setEditable(false);
			exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
		}
		return exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue;
	}

	private JButton getExerciseCalculateButton() {
		if (exerciseCalculateButton == null) {
			exerciseCalculateButton = new JButton();
			exerciseCalculateButton.setText("Calculate");
			exerciseCalculateButton.setLocation(15, 360);
			exerciseCalculateButton.setSize(136, 46);
			exerciseCalculateButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					doEverything();
				}
			});
		}
		return exerciseCalculateButton;
	}
  
	private JPanel getExerciseSkinEyeOrBFOPanel() {
		if (exerciseSkinEyeOrBFOPanel == null) {
			exerciseSkinEyeOrBFOPanel = new JPanel();
			exerciseSkinEyeOrBFOPanel.setLayout(new BoxLayout(exerciseSkinEyeOrBFOPanel, BoxLayout.X_AXIS));
			exerciseSkinEyeOrBFOPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
			exerciseSkinEyeOrBFOPanel.setPreferredSize(new java.awt.Dimension(70,80));
			exerciseSkinEyeOrBFOPanel.setLocation(15, 150);
			exerciseSkinEyeOrBFOPanel.setSize(286, 31);
			exerciseSkinEyeOrBFOPanel.add(getExerciseSkinPanel(), null);
			exerciseSkinEyeOrBFOPanel.add(getExerciseEyePanel(), null);
			exerciseSkinEyeOrBFOPanel.add(getExerciseBFOPanel(), null);
		}
		return exerciseSkinEyeOrBFOPanel;
	}
  
	private JPanel getExerciseSkinPanel() {
		if (exerciseSkinPanel == null) {
			exerciseSkinPanel = new JPanel();
			exerciseSkinPanel.setLayout(new BoxLayout(exerciseSkinPanel, BoxLayout.X_AXIS));
			exerciseSkinPanel.setPreferredSize(new java.awt.Dimension(40,10));
			exerciseSkinPanel.add(getExerciseSkinRadioButtonPanel(), null);
			exerciseSkinPanel.add(getExerciseSkinLabelPanel(), null);
		}
		return exerciseSkinPanel;
	}
  
	private JPanel getExerciseEyePanel() {
		if (exerciseEyePanel == null) {
			exerciseEyePanel = new JPanel();
			exerciseEyePanel.setLayout(new BoxLayout(exerciseEyePanel, BoxLayout.X_AXIS));
			exerciseEyePanel.setPreferredSize(new java.awt.Dimension(40,10));
			exerciseEyePanel.add(getExerciseEyeRadioButtonPanel(), null);
			exerciseEyePanel.add(getExerciseEyeLabel(), null);
		}
		return exerciseEyePanel;
	}
  
	private JPanel getExerciseBFOPanel() {
		if (exerciseBFOPanel == null) {
			exerciseBFOPanel = new JPanel();
			exerciseBFOPanel.setLayout(new BoxLayout(exerciseBFOPanel, BoxLayout.X_AXIS));
			exerciseBFOPanel.setPreferredSize(new java.awt.Dimension(40,10));
			exerciseBFOPanel.add(getExerciseBFORadioButtonPanel(), null);
			exerciseBFOPanel.add(getExerciseBFOLabelPanel(), null);
		}
		return exerciseBFOPanel;
	}
  
	private JPanel getExerciseSkinLabelPanel() {
		if (exerciseSkinLabelPanel == null) {
			GridLayout gridLayout43 = new GridLayout();
			exerciseSkinLabel = new JLabel();
			exerciseSkinLabelPanel = new JPanel();
			exerciseSkinLabelPanel.setLayout(gridLayout43);
			exerciseSkinLabel.setText("Skin");
			exerciseSkinLabelPanel.setPreferredSize(new java.awt.Dimension(20,10));
			gridLayout43.setRows(1);
			exerciseSkinLabelPanel.add(exerciseSkinLabel, null);
		}
		return exerciseSkinLabelPanel;
	}

	private JPanel getExerciseSkinRadioButtonPanel() {
		if (exerciseSkinRadioButtonPanel == null) {
			exerciseSkinRadioButtonPanel = new JPanel();
			exerciseSkinRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseSkinRadioButtonPanel.add(getSkinRadioButton(), null);
		}
		return exerciseSkinRadioButtonPanel;
	}
  
	private JPanel getExerciseEyeLabel() {
		if (exerciseEyeLabelPanel == null) {
			GridLayout gridLayout52 = new GridLayout();
			exerciseEyeLabel = new JLabel();
			exerciseEyeLabelPanel = new JPanel();
			exerciseEyeLabelPanel.setLayout(gridLayout52);
			exerciseEyeLabel.setText("Eye");
			exerciseEyeLabel.setPreferredSize(new java.awt.Dimension(25,16));
			exerciseEyeLabelPanel.setPreferredSize(new java.awt.Dimension(20,10));
			gridLayout52.setRows(1);
			exerciseEyeLabelPanel.add(exerciseEyeLabel, null);
		}
		return exerciseEyeLabelPanel;
	}
 
	private JPanel getExerciseEyeRadioButtonPanel() {
		if (exerciseEyeRadioButtonPanel == null) {
			exerciseEyeRadioButtonPanel = new JPanel();
			exerciseEyeRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseEyeRadioButtonPanel.add(getEyeRadioButton(), null);
		}
		return exerciseEyeRadioButtonPanel;
	}

	private JPanel getExerciseBFOLabelPanel() {
		if (exerciseBFOLabelPanel == null) {
			GridLayout gridLayout16 = new GridLayout();
			exerciseBFOLabel = new JLabel();
			exerciseBFOLabelPanel = new JPanel();
			exerciseBFOLabelPanel.setLayout(gridLayout16);
			exerciseBFOLabel.setText("BFO");
			exerciseBFOLabel.setPreferredSize(new java.awt.Dimension(25,16));
			exerciseBFOLabelPanel.setPreferredSize(new java.awt.Dimension(20,10));
			gridLayout16.setRows(1);
			exerciseBFOLabelPanel.add(exerciseBFOLabel, null);
		}
		return exerciseBFOLabelPanel;
	}

	private JPanel getExerciseBFORadioButtonPanel() {
		if (exerciseBFORadioButtonPanel == null) {
			exerciseBFORadioButtonPanel = new JPanel();
			exerciseBFORadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseBFORadioButtonPanel.add(getBFORadioButton(), null);
		}
		return exerciseBFORadioButtonPanel;
	}

	private JRadioButton getSkinRadioButton() {
		if (skinRadioButton == null) {
			skinRadioButton = new JRadioButton();
			skinRadioButton.setSelected(false);
			skinRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (skinRadioButton.isSelected()) 
						doEverything();
				}
			});
		}
		return skinRadioButton;
	}
   
	private JRadioButton getEyeRadioButton() {
		if (eyeRadioButton == null) {
			eyeRadioButton = new JRadioButton();
			eyeRadioButton.setSelected(false);
			eyeRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (eyeRadioButton.isSelected()) 
						doEverything();
				}
			});
		}
		return eyeRadioButton;
	}
   
	private JRadioButton getBFORadioButton() {
		if (BFORadioButton == null) {
			BFORadioButton = new JRadioButton();
			BFORadioButton.setSelected(true);
			BFORadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (BFORadioButton.isSelected()) 
						doEverything();
				}
			});
		}
		return BFORadioButton;
	}
   
	private JPanel getExerciseTimeSelectionInBaseHoursRadioButtonPanel() {
		if (exerciseTimeSelectionInBaseHoursRadioButtonPanel == null) {
			exerciseTimeSelectionInBaseHoursRadioButtonPanel = new JPanel();
			exerciseTimeSelectionInBaseHoursRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			exerciseTimeSelectionInBaseHoursRadioButtonPanel.add(getInBaseHoursRadioButton(), null);
		}
		return exerciseTimeSelectionInBaseHoursRadioButtonPanel;
	}
  
	private JRadioButton getInBaseHoursRadioButton() {
		if (inBaseHoursRadioButton == null) {
			inBaseHoursRadioButton = new JRadioButton();
			inBaseHoursRadioButton.setEnabled(false);
			inBaseHoursRadioButton.setSelected(true);
		}
		return inBaseHoursRadioButton;
	}
  
	private JScrollPane getClassExerciseDescriptionScrollPane() {
		if (classExerciseDescriptionScrollPane == null) {
			classExerciseDescriptionScrollPane = new JScrollPane();
			classExerciseDescriptionScrollPane.setViewportView(getClassExerciseDescriptionPane());
			classExerciseDescriptionScrollPane.setSize(320, 170);
			classExerciseDescriptionScrollPane.setLocation(315, 11);
		}
		return classExerciseDescriptionScrollPane;
	}

	private JEditorPane getClassExerciseDescriptionPane() {
		if (classExerciseDescriptionPane == null) {
			classExerciseDescriptionPane = new JEditorPane();
			classExerciseDescriptionPane.setBackground(this.getBackground());
			classExerciseDescriptionPane.setEditable(false);
		}
		return classExerciseDescriptionPane;
	}
	
	private JButton getSetUpButton() {
		if (setUpButton == null) {
			setUpButton = new JButton();
			setUpButton.setText("Set Up");
			setUpButton.setSize(106, 31);
			setUpButton.setLocation(525, 420);
			setUpButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					setUpDialog.setVisible(true);
				}
			});
		}
		return setUpButton;
	}

	private JPanel getSetUpContentPane() {
		if (setUpContentPane == null) {
			setUpTitleLabel = new JLabel();
			setUpContentPane = new JPanel();
			setUpContentPane.setLayout(null);
			setUpTitleLabel.setText("<html>Select Aluminum Sheilding thickness (g/cm<sup>2</sup>)</html>");
			setUpTitleLabel.setBounds(21, 18, 321, 24);
			setUpContentPane.add(setUpTitleLabel, null);
			setUpContentPane.add(setUpThicknessTablePanel(), null);
			setUpContentPane.add(getSetUpCloseButton(), null);
		}
		return setUpContentPane;
	}

	private JDialog getSetUpDialog() {
		if (setUpDialog == null) {
			setUpDialog = new JDialog();
			setUpDialog.setContentPane(getSetUpContentPane());
			setUpDialog.setSize(374, 252);
			setUpDialog.setTitle("Set Up");
		}
		return setUpDialog;
	}
  
	private JPanel setUpThicknessTablePanel() {
		if (setUpThicknessTablePanel == null) {
			setUpThicknessTablePanel = new JPanel();
			setUpThicknessTablePanel.setLayout(new BoxLayout(setUpThicknessTablePanel, BoxLayout.Y_AXIS));
			setUpThicknessTablePanel.setBounds(23, 50, 319, 117);
			setUpThicknessTablePanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
			setUpThicknessTablePanel.add(getSetUpThicknessTableThicknessLabelsPanel(), null);
			setUpThicknessTablePanel.add(getSetUpThicknessTabelSpaceSuitPanel(), null);
			setUpThicknessTablePanel.add(getSetUpThicknessTabelRoverPanel(), null);
			setUpThicknessTablePanel.add(getSetUpThicknessTabelBasePanel(), null);
		}
		return setUpThicknessTablePanel;
	}

	private JPanel getSetUpThicknessTabelSpaceSuitPanel() {
		if (setUpThicknessTabelSpaceSuitPanel == null) {
			setUpThicknessTabelSpaceSuitPanel = new JPanel();
			setUpThicknessTabelSpaceSuitPanel.setLayout(new BoxLayout(setUpThicknessTabelSpaceSuitPanel, BoxLayout.X_AXIS));
			setUpThicknessTabelSpaceSuitPanel.add(getSetUpThicknessTabelSpaceSuitLabelPanel(), null);
			setUpThicknessTabelSpaceSuitPanel.add(getSetUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel(), null);
			setUpThicknessTabelSpaceSuitPanel.add(getSetUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel(), null);
			setUpThicknessTabelSpaceSuitPanel.add(getSetUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel(), null);
			setUpThicknessTabelSpaceSuitPanel.add(getSetUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel(), null);
			setUpThicknessTabelSpaceSuitPanel.add(getSetUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel(), null);
		}
		return setUpThicknessTabelSpaceSuitPanel;
	}

	private JPanel getSetUpThicknessTabelRoverPanel() {
		if (setUpThicknessTabelRoverPanel == null) {
			setUpThicknessTabelRoverPanel = new JPanel();
			setUpThicknessTabelRoverPanel.setLayout(new BoxLayout(setUpThicknessTabelRoverPanel, BoxLayout.X_AXIS));
			setUpThicknessTabelRoverPanel.add(getSetUpThicknessTableRoverLabelPanel(), null);
			setUpThicknessTabelRoverPanel.add(getSetUpThicknessTableRoverThicknessPointThreeRadioButtonPanel(), null);
			setUpThicknessTabelRoverPanel.add(getSetUpThicknessTableRoverThicknessOneRadioButtonPanel(), null);
			setUpThicknessTabelRoverPanel.add(getSetUpThicknessTableRoverThicknessFiveRadioButtonPanel(), null);
			setUpThicknessTabelRoverPanel.add(getSetUpThicknessTableRoverThicknessTenRadioButtonPanel(), null);
			setUpThicknessTabelRoverPanel.add(getSetUpThicknessTableRoverThicknessThirtyRadioButtonPanel(), null);
		}
		return setUpThicknessTabelRoverPanel;
	}
 
	private JPanel getSetUpThicknessTabelBasePanel() {
		if (setUpThicknessTabelBasePanel == null) {
			setUpThicknessTabelBasePanel = new JPanel();
			setUpThicknessTabelBasePanel.setLayout(new BoxLayout(setUpThicknessTabelBasePanel, BoxLayout.X_AXIS));
			setUpThicknessTabelBasePanel.add(getSetUpThicknessTableBaseLabelPanel(), null);
			setUpThicknessTabelBasePanel.add(getSetUpThicknessTableBaseThicknessPointThreeRadioButtonPanel(), null);
			setUpThicknessTabelBasePanel.add(getSetUpThicknessTableBaseThicknessOneRadioButtonPanel(), null);
			setUpThicknessTabelBasePanel.add(getSetUpThicknessTableBaseThicknessFiveRadioButtonPanel(), null);
			setUpThicknessTabelBasePanel.add(getSetUpThicknessTableBaseThicknessTenRadioButtonPanel(), null);
			setUpThicknessTabelBasePanel.add(getSetUpThicknessTableBaseThicknessThirtyRadioButtonPanel(), null);
		}
		return setUpThicknessTabelBasePanel;
	}

	private JPanel getSetUpThicknessTabelSpaceSuitLabelPanel() {
		if (setUpThicknessTabelSpaceSuitLabelPanel == null) {
			setUpThicknessTabelSpaceSuitLabel = new JLabel();
			setUpThicknessTabelSpaceSuitLabelPanel = new JPanel();
			setUpThicknessTabelSpaceSuitLabel.setText("Space Suit");
			setUpThicknessTabelSpaceSuitLabelPanel.setPreferredSize(new java.awt.Dimension(70,10));
			setUpThicknessTabelSpaceSuitLabelPanel.add(setUpThicknessTabelSpaceSuitLabel, null);
		}
		return setUpThicknessTabelSpaceSuitLabelPanel;
	}

	private JPanel getSetUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel() {
		if (setUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel == null) {
			setUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel = new JPanel();
			setUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel.add(getSpaceSuitThicknessPointThreeRadioButton(), null);
		}
		return setUpThicknessTabelSpaceSuitThicknessPointThreeRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel() {
		if (setUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel == null) {
			setUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel = new JPanel();
			setUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel.add(getSpaceSuitThicknessOneRadioButton(), null);
		}
		return setUpThicknessTabelSpaceSuitThicknessOneRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel() {
		if (setUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel == null) {
			setUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel = new JPanel();
			setUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel.add(getSpaceSuitThicknessFiveRadioButton(), null);
		}
		return setUpThicknessTabelSpaceSuitThicknessFiveRadioButtonPanel;
	}
  
	private JPanel getSetUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel() {
		if (setUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel == null) {
			setUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel = new JPanel();
			setUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel.add(getSpaceSuitThicknessTenRadioButton(), null);
		}
		return setUpThicknessTabelSpaceSuitThicknessTenRadioButtonPanel;
	}
 
	private JPanel getSetUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel() {
		if (setUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel == null) {
			setUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel = new JPanel();
			setUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel.add(getSpaceSuitThicknessThirtyRadioButton(), null);
		}
		return setUpThicknessTabelSpaceSuitThicknessThirtyRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTableRoverLabelPanel() {
		if (setUpThicknessTableRoverLabelPanel == null) {
			setUpThicknessTableRoverLabel = new JLabel();
			setUpThicknessTableRoverLabelPanel = new JPanel();
			setUpThicknessTableRoverLabel.setText("Lunar Rover");
			setUpThicknessTableRoverLabelPanel.setPreferredSize(new java.awt.Dimension(70,10));
			setUpThicknessTableRoverLabelPanel.add(setUpThicknessTableRoverLabel, null);
		}
		return setUpThicknessTableRoverLabelPanel;
	}
 
	private JPanel getSetUpThicknessTableRoverThicknessPointThreeRadioButtonPanel() {
		if (setUpThicknessTableRoverThicknessPointThreeRadioButtonPanel == null) {
			setUpThicknessTableRoverThicknessPointThreeRadioButtonPanel = new JPanel();
			setUpThicknessTableRoverThicknessPointThreeRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableRoverThicknessPointThreeRadioButtonPanel.add(getRoverThicknessPointThreeRadioButton(), null);
		}
		return setUpThicknessTableRoverThicknessPointThreeRadioButtonPanel;
	}
 
	private JPanel getSetUpThicknessTableRoverThicknessOneRadioButtonPanel() {
		if (setUpThicknessTableRoverThicknessOneRadioButtonPanel == null) {
			setUpThicknessTableRoverThicknessOneRadioButtonPanel = new JPanel();
			setUpThicknessTableRoverThicknessOneRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableRoverThicknessOneRadioButtonPanel.add(getRoverThicknessOneRadioButton(), null);
		}
		return setUpThicknessTableRoverThicknessOneRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTableRoverThicknessFiveRadioButtonPanel() {
		if (setUpThicknessTableRoverThicknessFiveRadioButtonPanel == null) {
			setUpThicknessTableRoverThicknessFiveRadioButtonPanel = new JPanel();
			setUpThicknessTableRoverThicknessFiveRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableRoverThicknessFiveRadioButtonPanel.add(getRoverThicknessFiveRadioButton(), null);
		}
		return setUpThicknessTableRoverThicknessFiveRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTableRoverThicknessTenRadioButtonPanel() {
		if (setUpThicknessTableRoverThicknessTenRadioButtonPanel == null) {
			setUpThicknessTableRoverThicknessTenRadioButtonPanel = new JPanel();
			setUpThicknessTableRoverThicknessTenRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableRoverThicknessTenRadioButtonPanel.add(getRoverThicknessTenRadioButton(), null);
		}
		return setUpThicknessTableRoverThicknessTenRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTableRoverThicknessThirtyRadioButtonPanel() {
		if (setUpThicknessTableRoverThicknessThirtyRadioButtonPanel == null) {
			setUpThicknessTableRoverThicknessThirtyRadioButtonPanel = new JPanel();
			setUpThicknessTableRoverThicknessThirtyRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableRoverThicknessThirtyRadioButtonPanel.add(getRoverThicknessThirtyRadioButton(), null);
		}
		return setUpThicknessTableRoverThicknessThirtyRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTableBaseLabelPanel() {
		if (setUpThicknessTableBaseLabelPanel == null) {
			setUpThicknessTableBaseLabel = new JLabel();
			setUpThicknessTableBaseLabelPanel = new JPanel();
			setUpThicknessTableBaseLabel.setText("Moon Base");
			setUpThicknessTableBaseLabelPanel.setPreferredSize(new java.awt.Dimension(70,10));
			setUpThicknessTableBaseLabelPanel.add(setUpThicknessTableBaseLabel, null);
		}
		return setUpThicknessTableBaseLabelPanel;
	}

	private JPanel getSetUpThicknessTableBaseThicknessPointThreeRadioButtonPanel() {
		if (setUpThicknessTableBaseThicknessPointThreeRadioButtonPanel == null) {
			setUpThicknessTableBaseThicknessPointThreeRadioButtonPanel = new JPanel();
			setUpThicknessTableBaseThicknessPointThreeRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableBaseThicknessPointThreeRadioButtonPanel.add(getBaseThicknessPointThreeRadioButton(), null);
		}
		return setUpThicknessTableBaseThicknessPointThreeRadioButtonPanel;
	}
  
	private JPanel getSetUpThicknessTableBaseThicknessOneRadioButtonPanel() {
		if (setUpThicknessTableBaseThicknessOneRadioButtonPanel == null) {
			setUpThicknessTableBaseThicknessOneRadioButtonPanel = new JPanel();
			setUpThicknessTableBaseThicknessOneRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableBaseThicknessOneRadioButtonPanel.add(getBaseThicknessOneRadioButton(), null);
		}
		return setUpThicknessTableBaseThicknessOneRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTableBaseThicknessFiveRadioButtonPanel() {
		if (setUpThicknessTableBaseThicknessFiveRadioButtonPanel == null) {
			setUpThicknessTableBaseThicknessFiveRadioButtonPanel = new JPanel();
			setUpThicknessTableBaseThicknessFiveRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableBaseThicknessFiveRadioButtonPanel.add(getBaseThicknessFiveRadioButton(), null);
		}
		return setUpThicknessTableBaseThicknessFiveRadioButtonPanel;
	}

	private JPanel getSetUpThicknessTableBaseThicknessTenRadioButtonPanel() {
		if (setUpThicknessTableBaseThicknessTenRadioButtonPanel == null) {
			setUpThicknessTableBaseThicknessTenRadioButtonPanel = new JPanel();
			setUpThicknessTableBaseThicknessTenRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableBaseThicknessTenRadioButtonPanel.add(getBaseThicknessTenRadioButton(), null);
		}
		return setUpThicknessTableBaseThicknessTenRadioButtonPanel;
	}
 
	private JPanel getSetUpThicknessTableBaseThicknessThirtyRadioButtonPanel() {
		if (setUpThicknessTableBaseThicknessThirtyRadioButtonPanel == null) {
			setUpThicknessTableBaseThicknessThirtyRadioButtonPanel = new JPanel();
			setUpThicknessTableBaseThicknessThirtyRadioButtonPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableBaseThicknessThirtyRadioButtonPanel.add(getBaseThicknessThirtyRadioButton(), null);
		}
		return setUpThicknessTableBaseThicknessThirtyRadioButtonPanel;
	}
   
	private JRadioButton getSpaceSuitThicknessPointThreeRadioButton() {
		if (spaceSuitThicknessPointThreeRadioButton == null) {
			spaceSuitThicknessPointThreeRadioButton = new JRadioButton();
			spaceSuitThicknessPointThreeRadioButton.setSelected(true);
			spaceSuitThicknessPointThreeRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (spaceSuitThicknessPointThreeRadioButton.isSelected())
					  doEverything();
				}
			});
		}
		return spaceSuitThicknessPointThreeRadioButton;
	}
   
	private JRadioButton getSpaceSuitThicknessOneRadioButton() {
		if (spaceSuitThicknessOneRadioButton == null) {
			spaceSuitThicknessOneRadioButton = new JRadioButton();
			spaceSuitThicknessOneRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (spaceSuitThicknessOneRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return spaceSuitThicknessOneRadioButton;
	}
  
	private JRadioButton getSpaceSuitThicknessFiveRadioButton() {
		if (spaceSuitThicknessFiveRadioButton == null) {
			spaceSuitThicknessFiveRadioButton = new JRadioButton();
			spaceSuitThicknessFiveRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (spaceSuitThicknessFiveRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return spaceSuitThicknessFiveRadioButton;
	}

	private JRadioButton getSpaceSuitThicknessTenRadioButton() {
		if (spaceSuitThicknessTenRadioButton == null) {
			spaceSuitThicknessTenRadioButton = new JRadioButton();
			spaceSuitThicknessTenRadioButton.setEnabled(false);
			spaceSuitThicknessTenRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (spaceSuitThicknessTenRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return spaceSuitThicknessTenRadioButton;
	}

	private JRadioButton getSpaceSuitThicknessThirtyRadioButton() {
		if (spaceSuitThicknessThirtyRadioButton == null) {
			spaceSuitThicknessThirtyRadioButton = new JRadioButton();
			spaceSuitThicknessThirtyRadioButton.setEnabled(false);
			spaceSuitThicknessThirtyRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (spaceSuitThicknessThirtyRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return spaceSuitThicknessThirtyRadioButton;
	}
 
	private JRadioButton getRoverThicknessPointThreeRadioButton() {
		if (roverThicknessPointThreeRadioButton == null) {
			roverThicknessPointThreeRadioButton = new JRadioButton();
			roverThicknessPointThreeRadioButton.setEnabled(false);
			roverThicknessPointThreeRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (roverThicknessPointThreeRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return roverThicknessPointThreeRadioButton;
	}
  
	private JRadioButton getRoverThicknessOneRadioButton() {
		if (roverThicknessOneRadioButton == null) {
			roverThicknessOneRadioButton = new JRadioButton();
			roverThicknessOneRadioButton.setBackground(new java.awt.Color(238,238,238));
			roverThicknessOneRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {      
					if (roverThicknessOneRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return roverThicknessOneRadioButton;
	}
 
	private JRadioButton getRoverThicknessFiveRadioButton() {
		if (roverThicknessFiveRadioButton == null) {
			roverThicknessFiveRadioButton = new JRadioButton();
			roverThicknessFiveRadioButton.setSelected(true);
			roverThicknessFiveRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (roverThicknessFiveRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return roverThicknessFiveRadioButton;
	}

	private JRadioButton getRoverThicknessTenRadioButton() {
		if (roverThicknessTenRadioButton == null) {
			roverThicknessTenRadioButton = new JRadioButton();
			roverThicknessTenRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (roverThicknessTenRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return roverThicknessTenRadioButton;
	}
    
	private JRadioButton getRoverThicknessThirtyRadioButton() {
		if (roverThicknessThirtyRadioButton == null) {
			roverThicknessThirtyRadioButton = new JRadioButton();
			roverThicknessThirtyRadioButton.setEnabled(false);
			roverThicknessThirtyRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (roverThicknessThirtyRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return roverThicknessThirtyRadioButton;
	}
 
	private JRadioButton getBaseThicknessPointThreeRadioButton() {
		if (baseThicknessPointThreeRadioButton == null) {
			baseThicknessPointThreeRadioButton = new JRadioButton();
			baseThicknessPointThreeRadioButton.setEnabled(false);
			baseThicknessPointThreeRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (baseThicknessPointThreeRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return baseThicknessPointThreeRadioButton;
	}
  
	private JRadioButton getBaseThicknessOneRadioButton() {
		if (baseThicknessOneRadioButton == null) {
			baseThicknessOneRadioButton = new JRadioButton();
			baseThicknessOneRadioButton.setEnabled(false);
			baseThicknessOneRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (baseThicknessOneRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return baseThicknessOneRadioButton;
	}

	private JRadioButton getBaseThicknessFiveRadioButton() {
		if (baseThicknessFiveRadioButton == null) {
			baseThicknessFiveRadioButton = new JRadioButton();
			baseThicknessFiveRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (baseThicknessFiveRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return baseThicknessFiveRadioButton;
	}
  
	private JRadioButton getBaseThicknessTenRadioButton() {
		if (baseThicknessTenRadioButton == null) {
			baseThicknessTenRadioButton = new JRadioButton();
			baseThicknessTenRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (baseThicknessTenRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return baseThicknessTenRadioButton;
	}

	private JRadioButton getBaseThicknessThirtyRadioButton() {
		if (baseThicknessThirtyRadioButton == null) {
			baseThicknessThirtyRadioButton = new JRadioButton();
			baseThicknessThirtyRadioButton.setSelected(true);
			baseThicknessThirtyRadioButton.addItemListener(new java.awt.event.ItemListener() { 
				public void itemStateChanged(java.awt.event.ItemEvent e) {    
					if (baseThicknessThirtyRadioButton.isSelected())
						doEverything();
				}
			});
		}
		return baseThicknessThirtyRadioButton;
	}
 
	private JPanel getSetUpThicknessTableThicknessLabelsPanel() {
		if (setUpThicknessTableThicknessLabelsPanel == null) {
			setUpThicknessTableThicknessLabelsPanel = new JPanel();
			setUpThicknessTableThicknessLabelsPanel.setLayout(new BoxLayout(setUpThicknessTableThicknessLabelsPanel, BoxLayout.X_AXIS));
			setUpThicknessTableThicknessLabelsPanel.add(getSetUpThicknessTableCornerPanel(), null);
			setUpThicknessTableThicknessLabelsPanel.add(getSetUpThicknessTableThicknessPointThreeLabelPanel(), null);
			setUpThicknessTableThicknessLabelsPanel.add(getSetUpThicknessTableThicknessOneLabelPanel(), null);
			setUpThicknessTableThicknessLabelsPanel.add(getSetUpThicknessTableThicknessFiveLabelPanel(), null);
			setUpThicknessTableThicknessLabelsPanel.add(getSetUpThicknessTabelThicknessTenLabelPanel(), null);
			setUpThicknessTableThicknessLabelsPanel.add(getSetUpThicknessTabelThicknessThirtyLabelPanel(), null);
		}
		return setUpThicknessTableThicknessLabelsPanel;
	}

	private JPanel getSetUpThicknessTableCornerPanel() {
		if (setUpThicknessTableCornerPanel == null) {
			setUpThicknessTableCornerPanel = new JPanel();
			setUpThicknessTableCornerPanel.setPreferredSize(new java.awt.Dimension(70,10));
		}
		return setUpThicknessTableCornerPanel;
	}

	private JPanel getSetUpThicknessTableThicknessPointThreeLabelPanel() {
		if (setUpThicknessTableThicknessPointThreeLabelPanel == null) {
			setUpThicknessTableThicknessPointThreeLabel = new JLabel();
			setUpThicknessTableThicknessPointThreeLabelPanel = new JPanel();
			setUpThicknessTableThicknessPointThreeLabel.setText("0.3");
			setUpThicknessTableThicknessPointThreeLabelPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableThicknessPointThreeLabelPanel.add(setUpThicknessTableThicknessPointThreeLabel, null);
		}
		return setUpThicknessTableThicknessPointThreeLabelPanel;
	}

	private JPanel getSetUpThicknessTableThicknessOneLabelPanel() {
		if (setUpThicknessTableThicknessOneLabelPanel == null) {
			setUpThicknessTableThicknessOneLabel = new JLabel();
			setUpThicknessTableThicknessOneLabelPanel = new JPanel();
			setUpThicknessTableThicknessOneLabel.setText("1");
			setUpThicknessTableThicknessOneLabelPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableThicknessOneLabelPanel.add(setUpThicknessTableThicknessOneLabel, null);
		}
		return setUpThicknessTableThicknessOneLabelPanel;
	}

	private JPanel getSetUpThicknessTableThicknessFiveLabelPanel() {
		if (setUpThicknessTableThicknessFiveLabelPanel == null) {
			setUpThicknessTableThicknessFiveLabel = new JLabel();
			setUpThicknessTableThicknessFiveLabelPanel = new JPanel();
			setUpThicknessTableThicknessFiveLabel.setText("5");
			setUpThicknessTableThicknessFiveLabelPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTableThicknessFiveLabelPanel.add(setUpThicknessTableThicknessFiveLabel, null);
		}
		return setUpThicknessTableThicknessFiveLabelPanel;
	}

	private JPanel getSetUpThicknessTabelThicknessTenLabelPanel() {
		if (setUpThicknessTabelThicknessTenLabelPanel == null) {
			setUpThicknessTabelThicknessTenLabel = new JLabel();
			setUpThicknessTabelThicknessTenLabelPanel = new JPanel();
			setUpThicknessTabelThicknessTenLabel.setText("10");
			setUpThicknessTabelThicknessTenLabelPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTabelThicknessTenLabelPanel.add(setUpThicknessTabelThicknessTenLabel, null);
		}
		return setUpThicknessTabelThicknessTenLabelPanel;
	}

	private JPanel getSetUpThicknessTabelThicknessThirtyLabelPanel() {
		if (setUpThicknessTabelThicknessThirtyLabelPanel == null) {
			setUpThicknessTabelThicknessThirtyLabel = new JLabel();
			setUpThicknessTabelThicknessThirtyLabelPanel = new JPanel();
			setUpThicknessTabelThicknessThirtyLabel.setText("30");
			setUpThicknessTabelThicknessThirtyLabelPanel.setPreferredSize(new java.awt.Dimension(10,10));
			setUpThicknessTabelThicknessThirtyLabelPanel.add(setUpThicknessTabelThicknessThirtyLabel, null);
		}
		return setUpThicknessTabelThicknessThirtyLabelPanel;
	}

	private JButton getSetUpCloseButton() {
		if (setUpCloseButton == null) {
			setUpCloseButton = new JButton();
			setUpCloseButton.setBounds(232, 177, 110, 27);
			setUpCloseButton.setText("Close");
			setUpCloseButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					setUpDialog.setVisible(false);
				}
			});
		}
		return setUpCloseButton;
	}
 
	private JPanel getIntegraFluencePanel() {
		if (integraFluencePanel == null) {
			integraFluencePanel = new JPanel();
			integraFluencePanel.setLayout(new BoxLayout(integraFluencePanel, BoxLayout.X_AXIS));
			integraFluencePanel.setPreferredSize(new java.awt.Dimension(75,25));
			integraFluencePanel.add(getIntegralFluenceLabelPanel(), null);
			integraFluencePanel.add(getIntegralFluenceInputPanel_1(), null);
			integraFluencePanel.add(getIntegralFluenceInputPanel_2(), null);
		}
		return integraFluencePanel;
	}

	private JTextField getIntegralFluenceInput_1() {
		if (integralFluenceInput_1 == null) {
			integralFluenceInput_1 = new JTextField();
			integralFluenceInput_1.setPreferredSize(new java.awt.Dimension(20,16));
			integralFluenceInput_1.addKeyListener(new java.awt.event.KeyAdapter() { 
				public void keyTyped(java.awt.event.KeyEvent e) {    
					KInput_1.setText("");
					KInput_2.setText("");
				}
			});
			integralFluenceInput_1.addFocusListener(new java.awt.event.FocusAdapter() { 
				public void focusGained(java.awt.event.FocusEvent e) { 
					integralFluenceInput_1.setEditable(true); 
					integralFluenceInput_2.setEditable(true);
					KInput_1.setText("");
					KInput_2.setText("");
					KInput_1.setEditable(false);	
					KInput_2.setEditable(false);						
					KInput_1.setBackground(background); 			
					KInput_2.setBackground(background); 
					integralFluenceInput_1.setBackground(Color.WHITE);
				  	integralFluenceInput_2.setBackground(Color.WHITE);						
					// so a tab from Emin input will now jump to the integral fluence
					E0Input_2.setNextFocusableComponent(integralFluenceInput_1);
				}
			});
			integralFluenceInput_1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					integralFluenceInput_2.requestFocus();
				}
			});
		}
		return integralFluenceInput_1;
	}
    
	
	private javax.swing.JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new javax.swing.JMenuBar();
			jJMenuBar.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			jJMenuBar.add(getFileMenu());
			jJMenuBar.add(getHelpMenu());
		}
		return jJMenuBar;
	}
 
	private javax.swing.JMenu getFileMenu() {
		if (fileMenu == null) {
			fileMenu = new javax.swing.JMenu();
			fileMenu.setText("File");
			fileMenu.add(getExitMenuItem());
		}
		return fileMenu;
	}
  
	private javax.swing.JMenu getHelpMenu() {
		if (helpMenu == null) {
			helpMenu = new javax.swing.JMenu();
			helpMenu.setText("Help");
			helpMenu.add(getAboutMenuItem());
		}
		return helpMenu;
	}
 
	private javax.swing.JMenuItem getExitMenuItem() {
		if (exitMenuItem == null) {
			exitMenuItem = new javax.swing.JMenuItem();
			exitMenuItem.setText("Exit");
			exitMenuItem.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					System.exit(0);
				}
			});
		}
		return exitMenuItem;
	}

	private JMenuItem getAboutMenuItem() {
		if (aboutMenuItem == null) {
			aboutMenuItem = new JMenuItem();
			aboutMenuItem.setText("About");
			aboutMenuItem.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					aboutDialog.setVisible(true);
				}
			});
		}
		return aboutMenuItem;
	}

	private JPanel getAboutContentPane() {
		if (aboutContentPane == null) {
			GridLayout gridLayout15 = new GridLayout();
			aboutContentPane = new JPanel();
			aboutContentPane.setLayout(gridLayout15);
			gridLayout15.setRows(1);
			aboutContentPane.add(getAboutEditorPane(), null);
		}
		return aboutContentPane;
	}

	private JDialog getAboutDialog() {
		if (aboutDialog == null) {
			aboutDialog = new JDialog();
			aboutDialog.setContentPane(getAboutContentPane());
			aboutDialog.setSize(300, 300);
			aboutDialog.setTitle("About");
		}
		return aboutDialog;
	}

	private JEditorPane getAboutEditorPane() {
		if (aboutEditorPane == null) {
			aboutEditorPane = new JEditorPane();
			aboutEditorPane.setBackground(this.getBackground());
		}
		return aboutEditorPane;
	}

	private JTextField getGammaInput_2() {
		if (gammaInput_2 == null) {
			gammaInput_2 = new JTextField();
			gammaInput_2.setPreferredSize(new java.awt.Dimension(20,16));
			gammaInput_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					E0Input_1.requestFocus();
				}
			});
		}
		return gammaInput_2;
	}

	private JTextField getE0Input_2() {
		if (E0Input_2 == null) {
			E0Input_2 = new JTextField();
			E0Input_2.setPreferredSize(new java.awt.Dimension(20,16));
			E0Input_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (KInput_1.isEditable()) KInput_1.requestFocus();
					if (integralFluenceInput_1.isEditable()) integralFluenceInput_1.requestFocus();
				}
			});
		}
		return E0Input_2;
	}

	private JTextField getKInput_2() {
		if (KInput_2 == null) {
			KInput_2 = new JTextField();
			KInput_2.setNextFocusableComponent(EminInput);
			KInput_2.setPreferredSize(new java.awt.Dimension(20,16));
			KInput_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					EminInput.requestFocus();
				}
			});
			KInput_2.addKeyListener(new java.awt.event.KeyAdapter() {
				public void keyTyped(java.awt.event.KeyEvent e) {
					integralFluenceInput_1.setText("");
					integralFluenceInput_2.setText("");
				}
			});
			KInput_2.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusGained(java.awt.event.FocusEvent e) {
					KInput_1.setEditable(true); 
					KInput_2.setEditable(true);
					integralFluenceInput_1.setEditable(false);
					integralFluenceInput_2.setEditable(false);
					integralFluenceInput_1.setText("");
					integralFluenceInput_2.setText("");
					KInput_1.setBackground(Color.WHITE);
					KInput_2.setBackground(Color.WHITE);
					integralFluenceInput_1.setBackground(background); 
					integralFluenceInput_2.setBackground(background); 
					// so a tab from Emin input will now jump to the K
					E0Input_2.setNextFocusableComponent(KInput_1);
				}
			});
		}
		return KInput_2;
	}
	private JTextField getIntegralFluenceInput_2() {
		if (integralFluenceInput_2 == null) {
			integralFluenceInput_2 = new JTextField();
			integralFluenceInput_2.setPreferredSize(new java.awt.Dimension(20,16));
			integralFluenceInput_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					EminInput.requestFocus();
				}
			});
			integralFluenceInput_2.addKeyListener(new java.awt.event.KeyAdapter() {
				public void keyTyped(java.awt.event.KeyEvent e) {
					KInput_1.setText("");
					KInput_2.setText("");
				}
			});
			integralFluenceInput_2.addFocusListener(new java.awt.event.FocusAdapter() {
				public void focusGained(java.awt.event.FocusEvent e) {
					integralFluenceInput_1.setEditable(true); 
					integralFluenceInput_2.setEditable(true);
					KInput_1.setText("");
					KInput_2.setText("");
					KInput_1.setEditable(false);	
					KInput_2.setEditable(false);						
					KInput_1.setBackground(background); 			
					KInput_2.setBackground(background); 
					integralFluenceInput_1.setBackground(Color.WHITE);
				  	integralFluenceInput_2.setBackground(Color.WHITE);						
					// so a tab from Emin input will now jump to the integral fluence
					E0Input_2.setNextFocusableComponent(integralFluenceInput_1);
				}
			});
		}
		return integralFluenceInput_2;
	}

	private JPanel getAInputValuePanel_2() {
		if (AInputValuePanel_2 == null) {
			AInputValuePanel_2 = new JPanel();
			AInputValuePanel_2.setLayout(new BoxLayout(getAInputValuePanel_2(), BoxLayout.Y_AXIS));
			AInputValuePanel_2.add(getAInput_2(), null);
		}
		return AInputValuePanel_2;
	}

	private JTextField getAInput_2() {
		if (AInput_2 == null) {
			AInput_2 = new JTextField();
			AInput_2.setPreferredSize(new java.awt.Dimension(30,25));
			AInput_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					B1Input_1.requestFocus();
				}
			});
		}
		return AInput_2;
	}

	private JPanel getB1InputValuePanel_2() {
		if (B1InputValuePanel_2 == null) {
			B1InputValuePanel_2 = new JPanel();
			B1InputValuePanel_2.setLayout(new BoxLayout(getB1InputValuePanel_2(), BoxLayout.Y_AXIS));
			B1InputValuePanel_2.add(getB1Input_2(), null);
		}
		return B1InputValuePanel_2;
	}

	private JPanel getB2InputValuePanel_2() {
		if (B2InputValuePanel_2 == null) {
			B2InputValuePanel_2 = new JPanel();
			B2InputValuePanel_2.setLayout(new BoxLayout(getB2InputValuePanel_2(), BoxLayout.Y_AXIS));
			B2InputValuePanel_2.add(getB2Input_2(), null);
		}
		return B2InputValuePanel_2;
	}

	private JPanel getCNotInputValuePanel_2() {
		if (CNotInputValuePanel_2 == null) {
			CNotInputValuePanel_2 = new JPanel();
			CNotInputValuePanel_2.setLayout(new BoxLayout(getCNotInputValuePanel_2(), BoxLayout.Y_AXIS));
			CNotInputValuePanel_2.add(getCNotInput_2(), null);
		}
		return CNotInputValuePanel_2;
	}

	private JTextField getB1Input_2() {
		if (B1Input_2 == null) {
			B1Input_2 = new JTextField();
			B1Input_2.setPreferredSize(new java.awt.Dimension(30,25));
			B1Input_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					B2Input_1.requestFocus();
				}
			});
		}
		return B1Input_2;
	}

	private JTextField getB2Input_2() {
		if (B2Input_2 == null) {
			B2Input_2 = new JTextField();
			B2Input_2.setPreferredSize(new java.awt.Dimension(30,25));
			B2Input_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					timeDelayBetweenEventsInput.requestFocus();
				}
			});
		}
		return B2Input_2;
	}

	private JTextField getCNotInput_2() {
		if (CNotInput_2 == null) {
			CNotInput_2 = new JTextField();
			CNotInput_2.setEditable(false);
			CNotInput_2.setPreferredSize(new java.awt.Dimension(30,25));
			CNotInput_2.setBackground(this.getBackground());
		}
		return CNotInput_2;
	}

	private JPanel getGammaLabelPanel() {
		if (gammaLabelPanel == null) {
			jLabel = new JLabel();
			jLabel.setText("\u03b3");
			gammaLabelPanel = new JPanel();
			gammaLabelPanel.setLayout(new BoxLayout(getGammaLabelPanel(), BoxLayout.Y_AXIS));
			gammaLabelPanel.setPreferredSize(new java.awt.Dimension(95,16));
			gammaLabelPanel.add(jLabel, null);
		}
		return gammaLabelPanel;
	}

	private JPanel getGammaInputPanel_1() {
		if (gammaInputPanel_1 == null) {
			gammaInputPanel_1 = new JPanel();
			gammaInputPanel_1.setLayout(new BoxLayout(getGammaInputPanel_1(), BoxLayout.Y_AXIS));
			gammaInputPanel_1.add(getGammaInput_1(), null);
		}
		return gammaInputPanel_1;
	}

	private JPanel getGammaInputPanel_2() {
		if (gammaInputPanel_2 == null) {
			gammaInputPanel_2 = new JPanel();
			gammaInputPanel_2.setLayout(new BoxLayout(getGammaInputPanel_2(), BoxLayout.Y_AXIS));
			gammaInputPanel_2.add(getGammaInput_2(), null);
		}
		return gammaInputPanel_2;
	}

	private JPanel getE0LabelPanel() {
		if (E0LabelPanel == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("Eo");
			E0LabelPanel = new JPanel();
			E0LabelPanel.setLayout(new BoxLayout(getE0LabelPanel(), BoxLayout.Y_AXIS));
			E0LabelPanel.setPreferredSize(new java.awt.Dimension(95,16));
			E0LabelPanel.add(jLabel1, null);
		}
		return E0LabelPanel;
	}

	private JPanel getE0InputPanel_1() {
		if (E0InputPanel_1 == null) {
			E0InputPanel_1 = new JPanel();
			E0InputPanel_1.setLayout(new BoxLayout(getE0InputPanel_1(), BoxLayout.Y_AXIS));
			E0InputPanel_1.add(getE0Input_1(), null);
		}
		return E0InputPanel_1;
	}

	private JPanel getE0InputPanel_2() {
		if (E0InputPanel_2 == null) {
			E0InputPanel_2 = new JPanel();
			E0InputPanel_2.setLayout(new BoxLayout(getE0InputPanel_2(), BoxLayout.Y_AXIS));
			E0InputPanel_2.add(getE0Input_2(), null);
		}
		return E0InputPanel_2;
	}

	private JPanel getEminLabelPanel() {
		if (EminLabelPanel == null) {
			EminLabel = new JLabel();
			EminLabel.setText("Emin");
			EminLabel.setPreferredSize(new java.awt.Dimension(35,16));
			EminLabelPanel = new JPanel();
			EminLabelPanel.setLayout(new BoxLayout(getEminLabelPanel(), BoxLayout.Y_AXIS));
			EminLabelPanel.setPreferredSize(new java.awt.Dimension(35,16));
			EminLabelPanel.add(EminLabel, null);
		}
		return EminLabelPanel;
	}

	private JPanel getEminInputPanel_1() {
		if (EminInputPanel_1 == null) {
			EminInputPanel_1 = new JPanel();
			EminInputPanel_1.setLayout(new BoxLayout(getEminInputPanel_1(), BoxLayout.Y_AXIS));
			EminInputPanel_1.add(getEminInput(), null);
		}
		return EminInputPanel_1;
	}

	private JPanel getKLabelPanel() {
		if (KLabelPanel == null) {
			jLabel3 = new JLabel();
			jLabel3.setText("k");
			KLabelPanel = new JPanel();
			KLabelPanel.setLayout(new BoxLayout(getKLabelPanel(), BoxLayout.Y_AXIS));
			KLabelPanel.setPreferredSize(new java.awt.Dimension(95,16));
			KLabelPanel.add(jLabel3, null);
		}
		return KLabelPanel;
	}

	private JPanel getKInputPanel_1() {
		if (KInputPanel_1 == null) {
			KInputPanel_1 = new JPanel();
			KInputPanel_1.setLayout(new BoxLayout(getKInputPanel_1(), BoxLayout.Y_AXIS));
			KInputPanel_1.add(getKInput_1(), null);
		}
		return KInputPanel_1;
	}

	private JPanel getKInputPanel_2() {
		if (KInputPanel_2 == null) {
			KInputPanel_2 = new JPanel();
			KInputPanel_2.setLayout(new BoxLayout(getKInputPanel_2(), BoxLayout.Y_AXIS));
			KInputPanel_2.add(getKInput_2(), null);
		}
		return KInputPanel_2;
	}

	private JPanel getIntegralFluenceLabelPanel() {
		if (integralFluenceLabelPanel == null) {
			jLabel4 = new JLabel();
			jLabel4.setText("Integral Fluence");
			jLabel4.setPreferredSize(new java.awt.Dimension(95,16));
			integralFluenceLabelPanel = new JPanel();
			integralFluenceLabelPanel.setLayout(new BoxLayout(getIntegralFluenceLabelPanel(), BoxLayout.Y_AXIS));
			integralFluenceLabelPanel.add(jLabel4, null);
		}
		return integralFluenceLabelPanel;
	}

	private JPanel getIntegralFluenceInputPanel_1() {
		if (integralFluenceInputPanel_1 == null) {
			integralFluenceInputPanel_1 = new JPanel();
			integralFluenceInputPanel_1.setLayout(new BoxLayout(getIntegralFluenceInputPanel_1(), BoxLayout.Y_AXIS));
			integralFluenceInputPanel_1.add(getIntegralFluenceInput_1(), null);
		}
		return integralFluenceInputPanel_1;
	}

	private JPanel getIntegralFluenceInputPanel_2() {
		if (integralFluenceInputPanel_2 == null) {
			integralFluenceInputPanel_2 = new JPanel();
			integralFluenceInputPanel_2.setLayout(new BoxLayout(getIntegralFluenceInputPanel_2(), BoxLayout.Y_AXIS));
			integralFluenceInputPanel_2.add(getIntegralFluenceInput_2(), null);
		}
		return integralFluenceInputPanel_2;
	}

	private JPanel getTimeDelayBetweenEventsPanel() {
		if (timeDelayBetweenEventsPanel == null) {
			timeDelayBetweenEventsPanel = new JPanel();
			timeDelayBetweenEventsPanel.setLayout(new BoxLayout(getTimeDelayBetweenEventsPanel(), BoxLayout.X_AXIS));
			timeDelayBetweenEventsPanel.setBounds(new java.awt.Rectangle(15,195,271,31));
			timeDelayBetweenEventsPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
			timeDelayBetweenEventsPanel.add(getTimeDelayBetweenEventsLabelPanel(), null);
			timeDelayBetweenEventsPanel.add(getTimeDelayBetweenEventsInputPanel(), null);
		}
		return timeDelayBetweenEventsPanel;
	}

	private JPanel getTimeDelayBetweenEventsLabelPanel() {
		if (timeDelayBetweenEventsLabelPanel == null) {
			timeDelayBetweenEventsLabel = new JLabel();
			timeDelayBetweenEventsLabel.setText("Delay Between Events");
			timeDelayBetweenEventsLabel.setPreferredSize(new java.awt.Dimension(160,16));
			timeDelayBetweenEventsLabelPanel = new JPanel();
			timeDelayBetweenEventsLabelPanel.setLayout(new BoxLayout(getTimeDelayBetweenEventsLabelPanel(), BoxLayout.Y_AXIS));
			timeDelayBetweenEventsLabelPanel.add(timeDelayBetweenEventsLabel, null);
		}
		return timeDelayBetweenEventsLabelPanel;
	}

	private JPanel getTimeDelayBetweenEventsInputPanel() {
		if (timeDelayBetweenEventsInputPanel == null) {
			timeDelayBetweenEventsInputPanel = new JPanel();
			timeDelayBetweenEventsInputPanel.setLayout(new BoxLayout(getTimeDelayBetweenEventsInputPanel(), BoxLayout.Y_AXIS));
			timeDelayBetweenEventsInputPanel.add(getTimeDelayBetweenEventsInput(), null);
		}
		return timeDelayBetweenEventsInputPanel;
	}

	private JTextField getTimeDelayBetweenEventsInput() {
		if (timeDelayBetweenEventsInput == null) {
			timeDelayBetweenEventsInput = new JTextField();
			timeDelayBetweenEventsInput
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							timeEvolutionCalculateButton.requestFocus();
						}
					});
		}
		return timeDelayBetweenEventsInput;
	}

	private JPanel getTimeEvolutionInputLabelPanel() {
		if (timeEvolutionInputLabelPanel == null) {
			timeEvolutionInputLabelPanel = new JPanel();
			timeEvolutionInputLabelPanel.setLayout(new BoxLayout(getTimeEvolutionInputLabelPanel(), BoxLayout.X_AXIS));
			timeEvolutionInputLabelPanel.add(getTimeEvolutionInputCornerPanel(), null);
			timeEvolutionInputLabelPanel.add(getTimeEvolutionInputEventOnePanel(), null);
			timeEvolutionInputLabelPanel.add(getTimeEvolutionInputEventTwoPanel(), null);
		}
		return timeEvolutionInputLabelPanel;
	}

	private JPanel getTimeEvolutionInputCornerPanel() {
		if (timeEvolutionInputCornerPanel == null) {
			timeEvolutioNInputCornerLabel = new JLabel();
			timeEvolutioNInputCornerLabel.setText("");
			timeEvolutionInputCornerPanel = new JPanel();
			timeEvolutionInputCornerPanel.setPreferredSize(new java.awt.Dimension(30,25));
			timeEvolutionInputCornerPanel.add(timeEvolutioNInputCornerLabel, null);
		}
		return timeEvolutionInputCornerPanel;
	}

	private JPanel getTimeEvolutionInputEventOnePanel() {
		if (timeEvolutionInputEventOnePanel == null) {
			timeEvolutionInputEventOnePanel = new JPanel();
			timeEvolutionInputEventOnePanel.setLayout(new BoxLayout(getTimeEvolutionInputEventOnePanel(), BoxLayout.Y_AXIS));
			timeEvolutionInputEventOnePanel.setPreferredSize(new java.awt.Dimension(30,25));
			timeEvolutionInputEventOnePanel.add(getTimeEvolutionInputEventOneLabel(), null);
		}
		return timeEvolutionInputEventOnePanel;
	}

	private JPanel getTimeEvolutionInputEventTwoPanel() {
		if (timeEvolutionInputEventTwoPanel == null) {
			timeEvolutionInputEventTwoPanel = new JPanel();
			timeEvolutionInputEventTwoPanel.setLayout(new BoxLayout(getTimeEvolutionInputEventTwoPanel(), BoxLayout.Y_AXIS));
			timeEvolutionInputEventTwoPanel.setPreferredSize(new java.awt.Dimension(30,25));
			timeEvolutionInputEventTwoPanel.add(getTimeEvolutionInputEventTwoLabel(), null);
		}
		return timeEvolutionInputEventTwoPanel;
	}

	private JTextField getTimeEvolutionInputEventOneLabel() {
		if (timeEvolutionInputEventOneLabel == null) {
			timeEvolutionInputEventOneLabel = new JTextField();
			timeEvolutionInputEventOneLabel.setBackground(background);
			timeEvolutionInputEventOneLabel.setText("Event 1");
			timeEvolutionInputEventOneLabel.setEditable(false);
			timeEvolutionInputEventOneLabel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
		}
		return timeEvolutionInputEventOneLabel;
	}

	private JTextField getTimeEvolutionInputEventTwoLabel() {
		if (timeEvolutionInputEventTwoLabel == null) {
			timeEvolutionInputEventTwoLabel = new JTextField();
			timeEvolutionInputEventTwoLabel.setBackground(background);
			timeEvolutionInputEventTwoLabel.setText("Event 2");
			timeEvolutionInputEventTwoLabel.setEditable(false);
			timeEvolutionInputEventTwoLabel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
		}
		return timeEvolutionInputEventTwoLabel;
	}

	private JPanel getEnergySpectrumLabelPanel() {
		if (energySpectrumLabelPanel == null) {
			energySpectrumLabelPanel = new JPanel();
			energySpectrumLabelPanel.setLayout(new BoxLayout(getEnergySpectrumLabelPanel(), BoxLayout.X_AXIS));
			energySpectrumLabelPanel.setPreferredSize(new java.awt.Dimension(75,25));
			energySpectrumLabelPanel.add(getEnergySpectrumCornerLabelPanel(), null);
			energySpectrumLabelPanel.add(getEnergySpectrumEventOnePanel(), null);
			energySpectrumLabelPanel.add(getEnergySpectrumEventTwoPanel(), null);
		}
		return energySpectrumLabelPanel;
	}

	private JPanel getEnergySpectrumCornerLabelPanel() {
		if (energySpectrumCornerLabelPanel == null) {
			energySpectrumCornerLabel = new JLabel();
			energySpectrumCornerLabel.setText("");
			energySpectrumCornerLabelPanel = new JPanel();
			energySpectrumCornerLabelPanel.setPreferredSize(new java.awt.Dimension(95,16));
			energySpectrumCornerLabelPanel.add(energySpectrumCornerLabel, null);
		}
		return energySpectrumCornerLabelPanel;
	}

	private JPanel getEnergySpectrumEventOnePanel() {
		if (energySpectrumEventOnePanel == null) {
			energySpectrumEventOnePanel = new JPanel();
			energySpectrumEventOnePanel.setLayout(new BoxLayout(getEnergySpectrumEventOnePanel(), BoxLayout.Y_AXIS));
			energySpectrumEventOnePanel.setPreferredSize(new java.awt.Dimension(20,16));
			energySpectrumEventOnePanel.add(getEnergySpectrumEventOneLabel(), null);
		}
		return energySpectrumEventOnePanel;
	}

	private JPanel getEnergySpectrumEventTwoPanel() {
		if (energySpectrumEventTwoPanel == null) {
			energySpectrumEventTwoPanel = new JPanel();
			energySpectrumEventTwoPanel.setLayout(new BoxLayout(getEnergySpectrumEventTwoPanel(), BoxLayout.Y_AXIS));
			energySpectrumEventTwoPanel.setPreferredSize(new java.awt.Dimension(20,16));
			energySpectrumEventTwoPanel.add(getEnergySpectrumEventTwoLabel(), null);
		}
		return energySpectrumEventTwoPanel;
	}

	private JTextField getEnergySpectrumEventOneLabel() {
		if (energySpectrumEventOneLabel == null) {
			energySpectrumEventOneLabel = new JTextField();
			energySpectrumEventOneLabel.setEditable(false);
			energySpectrumEventOneLabel.setBackground(background);
			energySpectrumEventOneLabel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
			energySpectrumEventOneLabel.setText("Event 1");
			energySpectrumEventOneLabel.setBorder(null);
		}
		return energySpectrumEventOneLabel;
	}

	private JTextField getEnergySpectrumEventTwoLabel() {
		if (energySpectrumEventTwoLabel == null) {
			energySpectrumEventTwoLabel = new JTextField();
			energySpectrumEventTwoLabel.setEditable(false);
			energySpectrumEventTwoLabel.setBackground(background);
			energySpectrumEventTwoLabel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
			energySpectrumEventTwoLabel.setText("Event 2");
			energySpectrumEventTwoLabel.setBorder(null);
		}
		return energySpectrumEventTwoLabel;
	}

	private JEditorPane getCreatedByEditorPane() {
		if (coverPanelEditorPane == null) {
			coverPanelEditorPane = new JEditorPane();
			coverPanelEditorPane.setEditable(false);
			coverPanelEditorPane.setEnabled(true);
			coverPanelEditorPane.setBackground(background);
			coverPanelEditorPane.setBounds(new java.awt.Rectangle(15,75,631,616));
		}
		return coverPanelEditorPane;
	}

	/** 
	 * This is where the program is created. 
	 * @param args
	 */
	public static void main(String[] args) {
		SStoRMv2 application = new SStoRMv2();
		application.setDefaultCloseOperation(EXIT_ON_CLOSE);
		application.setVisible(true);
	}
	
	/**
	 * This is the constructor which creates the GUI application by calling {@link #initialize}.
	 */
	public SStoRMv2() {
		super();
		initialize();
	}

	/**
	 * This is the method that initializes the SPE. It does so by setting up the content pane with
	 * {@link #getJTabbedPane}. It then runs all the functions that initialize the pages.
	 * It places all the default values in the SPE simulation and runs
	 * the simulation for the first time.
	 */
	private void initialize() {
		background = this.getBackground();
		this.setContentPane(getJTabbedPane());
		this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
		this.setJMenuBar(getJJMenuBar());
		this.setSize(670, 705);
		this.setTitle("SStoRMv2");
		
		initializeCoverPanel();		
		initializeEnergySpectrumPanel(); 
		initializeTimeEvolutionPanel();
		initializeEstimatedDosePanel();
		initializeExercisePanel();

		// set up the dialog boxes
		setUpDialog = getSetUpDialog();
		setUpDialog.setSize(new java.awt.Dimension(372,238));
		aboutDialog = getAboutDialog();
		initializeSetUpDialog(); 
		initializeAboutEditorPane();
		
		// now put in the default values
		integralFluenceInput_1.setText("1E9");
		gammaInput_1.setText("4");
		E0Input_1.setText("10");
		AInput_1.setText("0.5");
		B1Input_1.setText("2");
		B2Input_1.setText("1.5");
		
		EminInput.setText("10");

		integralFluenceInput_2.setText("1E9");
		gammaInput_2.setText("0");
		E0Input_2.setText("500");
		AInput_2.setText("0.5");
		B1Input_2.setText("2");
		B2Input_2.setText("1.5");
		
		timeDelayBetweenEventsInput.setText("2.5");
		
		exerciseTimeSelectionPriorToOnsetInput.setText("-30");
		exerciseTimeSelectionPackingUpInput.setText("120");
		exerciseTimeSelectionTransitInput.setText("8");
		
		// default the energy spectrum panel so that K is editable and the integral fluence is calculated.
		KInput_1.setEditable(false);
		KInput_2.setEditable(false);
		KInput_1.setBackground(background);
		KInput_2.setBackground(background);
		integralFluenceInput_1.setEditable(true);
		integralFluenceInput_2.setEditable(false);
		integralFluenceInput_1.setBackground(Color.WHITE);
		integralFluenceInput_2.setBackground(Color.WHITE);
		E0Input_2.setNextFocusableComponent(integralFluenceInput_1); // emin starts by pointing at K b/c integral flux is not editable

		KInput_2.setNextFocusableComponent(EminInput);
		
		
		doEverything(); // Run simulation for the first time with default values already set.
	}

	/**
	 * Initialzies {@link #coverPanel} by adding an image (the ANSER logo) to {@link #anserLogoLabel}.
	 * If the function fails to add the picture, nothing happens and the function returns normally.
	 */
	private void initializeCoverPanel() {
		try {
        	URL imageURL = Thread.currentThread().getContextClassLoader() 
				.getResource("SStoRM/ANSER_Logo.gif");
	    	ImageIcon icon = new ImageIcon(imageURL); // get the icon from the URL.
	    	anserLogoLabel.setIcon(icon); // put the icon in a label.
        } catch (Exception exception) {
        } // image failed to load, do nothing.		

		try {
        	URL sourceURL = Thread.currentThread().getContextClassLoader().getResource("SStoRM/SStoRMv2CoverPage.html");
        	coverPanelEditorPane.setContentType("text/html; charset=UTF-8");
        	coverPanelEditorPane.setPage(sourceURL);
        } 
        catch (Exception e) {
        }
	
	}
	
	/**
	 * Initialzies {@link #energySpectrumPanel} by creating {@link #yourSPE}
	 * and the 7 other historical events. It then creates a chart of energy spectrums and
	 * places all of the historical events on it. The chart is then placed in {@link #energySpectrumPanel}.
	 */
	private void initializeEnergySpectrumPanel() {
		if (energySpectrumPanel == null) return; // do nothing if the panel has not been created yet.
		
		yourSPE=new DoubleEvent("Your SPE"); // make your SPE
		allSPEs = new SolarParticleEventInterface[] { // make all historical SPEs
			yourSPE,
			new DoubleEvent(8.8e7,0,24.74,  2.04e6,.08999,339.2,  "Feb 56") ,
			new DoubleEvent(1.5e9,.016972,12.13,  1.71e7,.001191,80.03,  "Nov 60"),
			new SolarParticleEvent(9.24E08,0,26.5,"Aug 72a"),
			new DoubleEvent(2.98e10,1.3,28.0,  1.0e6,0.0,47.0,  "Aug 89"),
			new SolarParticleEvent(1.4E10,1.55,96.,"Sept 89"),
			new SolarParticleEvent(4.28E10,1.542,80.7,"Oct 89")
		};
				
		energySpectrumFluxGraph=new EnergySpectrumGraph(yourSPE);
		energySpectrumChartPanel=energySpectrumFluxGraph.getChartPanel();
		energySpectrumChartPanel.setBounds(15,285,620,305);
		energySpectrumChartPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
		
		// Set all SPEs but yourSPE (which is heild in allSPEs[0]). That is why loop starts at 1.
		for (int loop=1;loop<allSPEs.length;loop++) energySpectrumFluxGraph.addOtherSPE(allSPEs[loop]);
		energySpectrumPanel.add(energySpectrumChartPanel); // put the chart in the panel.
		
	}

	/**
	 * Initializes {@link #timeEvolutionPanel} by creating a time evolution chart
	 * and placing that chart in the panel. This method also reads in an HTML file with a description of what
	 * this tab does and puts it in {@link #timeEvolutionDescriptionPane}.
	 */
	private void initializeTimeEvolutionPanel() {
		if (timeEvolutionPanel == null) return; // do nothing if the panel has not been created yet.
		
		timeEvolutionFluxGraph=new TimeEvolutionGraph(yourSPE);
		timeEvolutionChartPanel=timeEvolutionFluxGraph.getChartPanel();
		timeEvolutionChartPanel.setBounds(15,285,620,305);
		timeEvolutionChartPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
		timeEvolutionPanel.add(timeEvolutionChartPanel);
	
		// add the HTML file TimeEvolutionDescription2.html to description panel in the time evolution tab
		try {
        	URL sourceURL = Thread.currentThread().getContextClassLoader().getResource("SStoRM/TimeEvolutionDescription2.html");
        	timeEvolutionDescriptionPane.setContentType("text/html; charset=UTF-8");
        	timeEvolutionDescriptionPane.setPage(sourceURL);
        } 
        catch (Exception e) {
        }
	}
	
	/**
	 * Initializes {@link #estimatedDosePanel} by adding a chart to 
	 * the panel and  making button groups for the rem/rad and free space/lunar surface
	 * radio buttons. 
	 */
	private void initializeEstimatedDosePanel() {
		if (estimatedDosePanel == null) return; // do nothing if the panel has not been created yet.
		
		radiationDoseGraph=new RadiationDoseGraph(); // make the radiation chart
		radiationDoseChartPanel=radiationDoseGraph.getChartPanel();
		radiationDoseChartPanel.setBounds(15,255,620,335);
		radiationDoseChartPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
		estimatedDosePanel.add(radiationDoseChartPanel);
		
	    freeSpaceLunarOrLunarSurfaceButtonGroup = new ButtonGroup();
	    freeSpaceLunarOrLunarSurfaceButtonGroup.add(freeSpaceRadioButton);
	    freeSpaceLunarOrLunarSurfaceButtonGroup.add(lunarSurfaceRadioButton);
	    
	    remOrRadButtonGroup = new ButtonGroup();
	    remOrRadButtonGroup.add(remRadioButton);
	    remOrRadButtonGroup.add(radRadioButton);
	}

	/**
	 * Initializes {@link #exercisePanel} by grouping all the sets
	 * of radio buttons on the panel. This
	 * method also reads in an outside HTML file to put a description of the exercise in 
	 * {@link #classExerciseDescriptionPane}.
	 */
	private void initializeExercisePanel() {
		if (exercisePanel == null) return; // do nothing if the panel has not been created yet.
		
	    skinEyeOrBFOButtonGroup = new ButtonGroup();
	    skinEyeOrBFOButtonGroup.add(skinRadioButton);
	    skinEyeOrBFOButtonGroup.add(eyeRadioButton);
	    skinEyeOrBFOButtonGroup.add(BFORadioButton);
	    
	    priorToOnsetMinutesOrHoursButtonGroup=new ButtonGroup();
	    priorToOnsetMinutesOrHoursButtonGroup.add(priorToOnsetMinutesRadioButton);
	    priorToOnsetMinutesOrHoursButtonGroup.add(priorToOnsetHoursRadioButton);
	    
	    packingUpMinutesOrHoursButtonGroup=new ButtonGroup();
	    packingUpMinutesOrHoursButtonGroup.add(packingUpMinutesRadioButton);
	    packingUpMinutesOrHoursButtonGroup.add(packingUpHoursRadioButton);
	    
	    transitMinutesOrHoursButtonGroup=new ButtonGroup();
	    transitMinutesOrHoursButtonGroup.add(transitMinutesRadioButton);
	    transitMinutesOrHoursButtonGroup.add(transitHoursRadioButton);
	    
	    inBaseMinutesOrHoursButtonGroup=new ButtonGroup();
	    inBaseMinutesOrHoursButtonGroup.add(inBaseMinutesRadioButton);
	    inBaseMinutesOrHoursButtonGroup.add(inBaseHoursRadioButton);
	    
	    cumulativeDoseGraph = new CumulativeDoseGraph();
	    cumulativeDoseChartPanel = cumulativeDoseGraph.getChartPanel();
	    cumulativeDoseChartPanel.setBounds(15, 415, 485, 175);
	    cumulativeDoseChartPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
	    exercisePanel.add(cumulativeDoseChartPanel);

		// add the HTML file ExerciseDescription2.html to description panel in the exercise tab
		try {
        	URL sourceURL = Thread.currentThread().getContextClassLoader().getResource("SStoRM/ExerciseDescription2.html");
        	classExerciseDescriptionPane.setContentType("text/html; charset=UTF-8");
        	classExerciseDescriptionPane.setPage(sourceURL);
        } 
        catch (Exception e) { // if text does not load, do nothing
        }
	}
	
	/**
	 * Performs custom initialization of {@link #setUpDialog} by grouping all the radio buttons on
	 * the panel.
	 */
	private void initializeSetUpDialog() {
		if (setUpDialog==null) return;
		
		spaceSuitThicknessButtonGroup = new ButtonGroup();
		spaceSuitThicknessButtonGroup.add(spaceSuitThicknessPointThreeRadioButton);
		spaceSuitThicknessButtonGroup.add(spaceSuitThicknessOneRadioButton);
		spaceSuitThicknessButtonGroup.add(spaceSuitThicknessFiveRadioButton);
		spaceSuitThicknessButtonGroup.add(spaceSuitThicknessTenRadioButton);
		spaceSuitThicknessButtonGroup.add(spaceSuitThicknessThirtyRadioButton);
		
		roverThicknessButtonGroup = new ButtonGroup();
		roverThicknessButtonGroup.add(roverThicknessPointThreeRadioButton);
		roverThicknessButtonGroup.add(roverThicknessOneRadioButton);
		roverThicknessButtonGroup.add(roverThicknessFiveRadioButton);
		roverThicknessButtonGroup.add(roverThicknessTenRadioButton);
		roverThicknessButtonGroup.add(roverThicknessThirtyRadioButton);
		
		baseThicknessButtonGroup = new ButtonGroup();
		baseThicknessButtonGroup.add(baseThicknessPointThreeRadioButton);
		baseThicknessButtonGroup.add(baseThicknessOneRadioButton);
		baseThicknessButtonGroup.add(baseThicknessFiveRadioButton);
		baseThicknessButtonGroup.add(baseThicknessTenRadioButton);
		baseThicknessButtonGroup.add(baseThicknessThirtyRadioButton);
	}
	

	/**
	 * Initialize the about editor pane by reading in the file About2.html and placing it's contents in the pane.
	 */
	public void initializeAboutEditorPane() {
		try { // Add the HTML file about2.html to the panel
        	URL sourceURL = Thread.currentThread().getContextClassLoader().getResource("SStoRM/About2.html");
        	aboutEditorPane.setContentType("text/html; charset=UTF-8");
        	aboutEditorPane.setPage(sourceURL);
        } 
        catch (Exception e) {} // if text does not load, do nothing
	}
	
	/**
	 * Calls {@link #doEverything(WarningStage)} in such a way that no warnings occure.
	 */
	private void doEverything() {
		doEverything(WarningStage.NO_WARNING);
	}
	
	/**
	 * This method performs the refreshing of the entire program. It does so by calling:
	 * <ul>
	 * <li>{@link #doEnergySpectrumCalculations}</li>
	 * <li>{@link #doTimeEvolutionCalculations}</li>
	 * <li>{@link #doRadiationDoseCalculations}</li>
	 * <li>and {@link #doExerciseCalculations}</li>
	 * </ul>
	 * @param warningStage What state of warnings it should be used. If this function
	 * is passed {@link WarningStage#ENERGY_SPECTRUM_WARNING}, it will warn if K is too small (the
	 * warning in {@link #doEnergySpectrumCalculations}). If {@link WarningStage#TIME_EVOLUTION_WARNING} is
	 * passed, it will warn if K is too small or if the event dose not decay 
	 * to background fast enough (the warnings in {@link #doTimeEvolutionCalculations}.
	 * If this function is passed {@link WarningStage#NO_WARNING}, no warnings are given at all.
	 * Regardless of what WARNINGS are requested, all errors are still properly displayed no
	 * matter how this program is called. This is useful because recalculating at different stages of the program 
	 * should be more or less picky about how much warning to give.  For example, if you are happy with your time evolution and
	 * are looking at radiation dose, the program should not keep warning you on other pages that the time evolution does not
	 * decay fast enough.
	 */
	private void doEverything(WarningStage warningStage) {
		setCursorWait();
		try {
			doEnergySpectrumCalculations(warningStage);
			doTimeEvolutionCalculations(warningStage);
			doRadiationDoseCalculations();
			doExerciseCalculations();
		} catch(Exception exception) { // if an error occurred, show message.
	    	JFrame frame=new JFrame(); 
	    	javax.swing.JOptionPane.showMessageDialog(frame,
	    			exception.getMessage(),
					"Error!",
					javax.swing.JOptionPane.ERROR_MESSAGE
			);
	    	
	    } finally {
	    	setCursorNormal();
	    }
	}
	
	/**
	 * Sets the cursor to an hour glass.
	 */
	private void setCursorWait() {
		Cursor hourglassCursor = new Cursor(Cursor.WAIT_CURSOR);
		this.setCursor(hourglassCursor);
	}
	
	/**
	 * Sets the cursor to normal.
	 */
	private void setCursorNormal() {
		Cursor normalCursor = new Cursor(Cursor.DEFAULT_CURSOR);
		this.setCursor(normalCursor);
	}
	
	/**
	 * Refreshes {@link #energySpectrumPanel} by reading the gamma, E0, Emin values for both 
	 * events. It then reads in
	 * either K or the integral flux (whichever is selected) and places all these values
	 * in your SPE. It then sorts your SPE in relation to all other SPEs and places
	 * them in sorted order in the panel to the right of the input. 
	 * The energy spectrum graph is then refreshed with the new SPE.
	 * @param warningStage If the value is {@link WarningStage#ENERGY_SPECTRUM_WARNING}, show any warnings that might have arose.
	 * @throws Exception If any of the energy spectrum parameters are not valid.
	 */
	private void doEnergySpectrumCalculations(WarningStage warningStage) throws Exception {
        // add the new values to the SPE
        yourSPE.setGamma_1( Convert.parseDouble(gammaInput_1.getText(),"\u03B3 1") );
        yourSPE.setGamma_2( Convert.parseDouble(gammaInput_2.getText(),"\u03B3 2") );
        yourSPE.setE0_1( Convert.parseDouble(E0Input_1.getText(),"E0 1") );
        yourSPE.setE0_2( Convert.parseDouble(E0Input_2.getText(),"E0 2") );
        
        
        
        yourSPE.setEmin( Convert.parseDouble(EminInput.getText(),"Emin") );
        
        integralFluenceTitleLabel.setText("> "+yourSPE.getEmin()+ " MeV Integral Fluence");
        
        // set either K or the integral fluence depending on which input is given
        if (KInput_1.isEditable()) {
        	yourSPE.setK_1(Convert.parseDouble(KInput_1.getText(),"K 1"));
        	yourSPE.setK_2(Convert.parseDouble(KInput_2.getText(),"K 2"));
        	
        	integralFluenceInput_1.setText(Convert.toStringScientificNotation(yourSPE.getEnergySpectrumIntegralFluence_1()));
        	integralFluenceInput_2.setText(Convert.toStringScientificNotation(yourSPE.getEnergySpectrumIntegralFluence_2()));
        	
        } else if (integralFluenceInput_1.isEditable()) {
        	yourSPE.setEnergySpectrumIntegralFluence_1(Convert.parseDouble(integralFluenceInput_1.getText(),"The first integral fluence"));
        	yourSPE.setEnergySpectrumIntegralFluence_2(Convert.parseDouble(integralFluenceInput_2.getText(),"The second integral fluence"));
        	KInput_1.setText(Convert.toStringScientificNotation(yourSPE.getK_1()));
        	KInput_2.setText(Convert.toStringScientificNotation(yourSPE.getK_2()));
        } else throw new IllegalArgumentException("Either K or the integral fluence must be specified");
        
        for(int loop=0;loop<allSPEs.length;loop++) // set Emin of all the SPEs
        	allSPEs[loop].setEmin( Convert.parseDouble(EminInput.getText(),"Emin") ); 
        
		energySpectrumFluxGraph.changeYourSPE(yourSPE); // change your SPE.
                
        java.util.Arrays.sort(allSPEs); // sort the SPEs (including yours) in ascending order
        java.util.Collections.reverse(java.util.Arrays.asList(allSPEs)); // sort into descending order

        // display the integral fluences on the panel in descending order.
        for (int loop=0;loop<allSPEs.length; loop++ ) {        
        	integraFluenceNameLabel[loop].setText(allSPEs[loop].getName());
            integraFluenceValueLabel[loop].setText(
            	Convert.toStringScientificNotation(allSPEs[loop].getEnergySpectrumIntegralFluence())
    		);
            if (allSPEs[loop].getName().equals("Your SPE")){
            	integraFluenceNameLabel[loop].setForeground(Color.red); 
            	integraFluenceValueLabel[loop].setForeground(Color.red);
            } else {
            	integraFluenceNameLabel[loop].setForeground(Color.black); 
            	integraFluenceValueLabel[loop].setForeground(Color.black);
            }
        }
        
        /*
         * This might throw an error b/c A, B1, & B2 re not defined yet.
         * if so, assume the event is large enough and ignore the problem
         */
        try { 
        	if (!yourSPE.isEventLargeEnough() && warningStage==WarningStage.ENERGY_SPECTRUM_WARNING) {
    			JFrame frame=new JFrame();
    			javax.swing.JOptionPane.showMessageDialog(frame,
    			    "<html>Your selection for K does not produce an event that would be above GCR background. <br><br>You should consider increasing K by a factor of 100 or more.</html>",
    			    "Warning!",
    			    javax.swing.JOptionPane.WARNING_MESSAGE
    			);
        	}
        } catch (Exception exception) {} // otherwise, don't show any error or warning or throw anything
	}

	/**
	 * Refreshes {@link #timeEvolutionPanel} by getting time evolution parameters and placing them in the SPE.
	 * The new C values are then shown to the user. The time evolution graph is then redrawn with the changed SPE.
	 * @param warningStage If passed {@link WarningStage#TIME_EVOLUTION_WARNING}, this method will show a warning if K is too small or
	 * if the event does not die down fast enough. 
	 * @throws Exception The time evolution is not valid.
	 */	
	private void doTimeEvolutionCalculations(WarningStage warningStage) throws Exception {
		
		yourSPE.setA_1(Convert.parseDouble(AInput_1.getText(),"A"));
		yourSPE.setA_2(Convert.parseDouble(AInput_2.getText(),"A"));
		yourSPE.setB1_1(Convert.parseDouble(B1Input_1.getText(),"B1"));
		yourSPE.setB1_2(Convert.parseDouble(B1Input_2.getText(),"B1"));
		yourSPE.setB2_1(Convert.parseDouble(B2Input_1.getText(),"B2")); 
		yourSPE.setB2_2(Convert.parseDouble(B2Input_2.getText(),"B2")); 

		yourSPE.setTimeDelayBetweenEvents(
			Time.inDays(
				Convert.parseDouble(timeDelayBetweenEventsInput.getText(),"time delay between events")
			)
		);
		
		CNotInput_1.setText(Convert.toStringScientificNotation(yourSPE.getC_1())); // get new C value
		CNotInput_2.setText(Convert.toStringScientificNotation(yourSPE.getC_2())); // get new C value
		timeEvolutionFluxGraph.changeYourSPE(yourSPE); // reset graph
			
		// Warn if the flux does not decrease fast enough or K is not big enough
		if (!yourSPE.isEventLargeEnough() && warningStage == WarningStage.TIME_EVOLUTION_WARNING) {
			JFrame frame=new JFrame();
			javax.swing.JOptionPane.showMessageDialog(frame,
			    "<html>Your selection for K does not produce an event that would be above GCR background. <br><br>You should consider increasing K by a factor of 100 or more.</html>",
			    "Warning!",
			    javax.swing.JOptionPane.WARNING_MESSAGE
			);
    	} else if (yourSPE.doesTimeEvolutionIntegralFluxDecreaseFastEnough()==false && warningStage == WarningStage.TIME_EVOLUTION_WARNING) {
			JFrame frame=new JFrame();
			javax.swing.JOptionPane.showMessageDialog(frame,
			    "<html>Your set of A, B1, and B2 does not decay to background in a reasonable time (5 days).<br><br>You should pick a new set of parameters.</html>",
			    "Warning!",
			    javax.swing.JOptionPane.WARNING_MESSAGE
			);
		}
	}
	
	/**
	 * Refreshes {@link #estimatedDosePanel} by placing new radiation dose values in the chart. It gets
	 * special doses depending on whether the user desires dose equivalent or absorbed dose, and if then want it on
	 * the lunar surface or in free space. The graph of radiation doses is also refreshed with this new
	 * information.
	 * @throws Exception Probably never, but if the SPE is not set up right or if no radio button is selected.
	 */
	private void doRadiationDoseCalculations() throws Exception {
        RadiationType remOrRad;
        if (remRadioButton.isSelected()) {
        	remOrRad=RadiationType.REM;
        }
        else if (radRadioButton.isSelected()) {
        	remOrRad=RadiationType.RAD;
        }
        else throw new IllegalArgumentException("Absorbed Dose or Dose equivalent must be selected");

        DoseLocation lunarSurfaceOrFreeSpace;
        if (lunarSurfaceRadioButton.isSelected()) {
        	lunarSurfaceOrFreeSpace=DoseLocation.LUNAR_SURFACE;
        } else if (freeSpaceRadioButton.isSelected()) {
        	lunarSurfaceOrFreeSpace=DoseLocation.FREE_SPACE;
        } else throw new IllegalArgumentException("Free space or lunar surface must be selected");
         
        // set the labels on the total dose chart
        estimatedDoseLabel.setText(
        	"<html><h2>Total "+remOrRad.toString()+" under a variety of shielding depths ("+remOrRad.getUnits()+")</h2></html>" 
        );
        doseDataTableTitleLabel.setText(
        		"Estimated "+remOrRad.toString()+ " "+lunarSurfaceOrFreeSpace.whereItIs()+" ("+remOrRad.getUnits()+")"
		);
        
        doseDataAluminumSheildingLabel.setText("g/cm2 Al shielding ("+remOrRad.getUnits()+")");
		
        // set the data table of radiation doses
        skinPointThreeLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.POINT_THREE,remOrRad,BodyPart.SKIN,lunarSurfaceOrFreeSpace)));
        skinOneLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.ONE,remOrRad,BodyPart.SKIN,lunarSurfaceOrFreeSpace)));
        skinFiveLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.FIVE,remOrRad,BodyPart.SKIN,lunarSurfaceOrFreeSpace)));
        skinTenLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.TEN,remOrRad,BodyPart.SKIN,lunarSurfaceOrFreeSpace)));
        skinThirtyLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.THIRTY,remOrRad,BodyPart.SKIN,lunarSurfaceOrFreeSpace)));

        // set the data table of radiation doses
        eyePointThreeLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.POINT_THREE,remOrRad,BodyPart.EYE,lunarSurfaceOrFreeSpace)));
        eyeOneLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.ONE,remOrRad,BodyPart.EYE,lunarSurfaceOrFreeSpace)));
        eyeFiveLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.FIVE,remOrRad,BodyPart.EYE,lunarSurfaceOrFreeSpace)));
        eyeTenLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.TEN,remOrRad,BodyPart.EYE,lunarSurfaceOrFreeSpace)));
        eyeThirtyLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.THIRTY,remOrRad,BodyPart.EYE,lunarSurfaceOrFreeSpace)));
        
        // set the data table of radiation doses
        BFOPointThreeLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.POINT_THREE,remOrRad,BodyPart.BFO,lunarSurfaceOrFreeSpace)));
        BFOOneLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.ONE,remOrRad,BodyPart.BFO,lunarSurfaceOrFreeSpace)));
        BFOFiveLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.FIVE,remOrRad,BodyPart.BFO,lunarSurfaceOrFreeSpace)));
        BFOTenLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.TEN,remOrRad,BodyPart.BFO,lunarSurfaceOrFreeSpace)));
        BFOThirtyLabel.setText(
        		Convert.toStringScientificNotation(yourSPE.getDose(
        		Thickness.THIRTY,remOrRad,BodyPart.BFO,lunarSurfaceOrFreeSpace)));
      
        radiationDoseGraph.setDoses(yourSPE,remOrRad,lunarSurfaceOrFreeSpace);  
	}
	
	/**
	 * Refreshes {@link #exercisePanel} by getting the selected values from the panel and sending them 
	 * to {@link SolarParticleEvent#simulateAstronautOnTheMoon}. Times for before the astronaut is
	 * warned, how long it takes them to pack up, and how long it takes them to enter the base must
	 * be inputted. This is done through {@link #exerciseTimeSelectionPriorToOnsetInput},
	 * {@link #exerciseTimeSelectionPackingUpInput}, {@link #exerciseTimeSelectionTransitInput}
	 * and the corresponding radio buttons that tell weather the input is in minutes or hours. The
	 * thicknesses during each stage of the event are found in the radio buttons on {@link #setUpDialog}.
	 * Once the results are obtained, they
	 * are placed in the panel for display by the user.
	 * @throws Exception If the SPE is not set up or the time values are not valid.
	 */
	private void doExerciseCalculations() throws Exception {
		BodyPart skinEyeOrBFO;
		if (skinRadioButton.isSelected()) 
			skinEyeOrBFO=BodyPart.SKIN;
		else if (eyeRadioButton.isSelected())
			skinEyeOrBFO=BodyPart.EYE;
		else if (BFORadioButton.isSelected()) 
			skinEyeOrBFO=BodyPart.BFO;
		else throw new IllegalArgumentException("You must select a body part (skin, eye, or BFO)");
		
		RadiationType remOrRad;
		if (remRadioButton.isSelected()) {
			remOrRad=RadiationType.REM;
		} else if (radRadioButton.isSelected()) {
			remOrRad=RadiationType.RAD;
		} else throw new IllegalArgumentException("You must select dose equivalent or absorbed dose");

		exerciseDoseLabel.setText("Cumulative "+skinEyeOrBFO.toString()+" "+remOrRad.toString()+ " ("+remOrRad.getUnits()+")");
		exerciseTimeSelectionDoseValue.setText("Dose ("+remOrRad.getUnits()+")");
		exerciseTotalTimeEvolutionDoseAwayFromShelterLabel.setText("Total "+skinEyeOrBFO.toString()+" "+remOrRad.toString()+ " ("+remOrRad.getUnits()+")");

		
		
		// display radiation doses on the upper left part of the panel.
		exerciseDoseSummaryThicknessPointThreeValue.setText(
    		Convert.toStringScientificNotation(yourSPE.getDose(
    		Thickness.POINT_THREE,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE))
		);
		exerciseDoseSummaryThicknessOneValue.setText(
        	Convert.toStringScientificNotation(yourSPE.getDose(
        	Thickness.ONE,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE))
		);
		exerciseDoseSummaryThicknessFiveValue.setText(
        	Convert.toStringScientificNotation(yourSPE.getDose(
        	Thickness.FIVE,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE))
		);
		exerciseDoseSummaryThicknessTenValue.setText(
        	Convert.toStringScientificNotation(yourSPE.getDose(
        	Thickness.TEN,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE))
		);
		exerciseDoseSummaryThicknessThirtyValue.setText(
        	Convert.toStringScientificNotation(yourSPE.getDose(
        	Thickness.THIRTY,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE))
		);
		
		// get time periods from the panel
		Time priorToOnset;
		if (priorToOnsetMinutesRadioButton.isSelected()) 
			priorToOnset=Time.inMinutes(
					Convert.parseDouble(
							exerciseTimeSelectionPriorToOnsetInput.getText(),"The time prior to the onset of the event"
			));
		else if (priorToOnsetHoursRadioButton.isSelected()) 
			priorToOnset=Time.inHours(
					Convert.parseDouble(
							exerciseTimeSelectionPriorToOnsetInput.getText(),"The time prior to the onset of the event"
			));
		else throw new IllegalArgumentException("The time prior to the onset of the event's unit (minutes or hours) must be selected");
		
		Time packingUp;
		if (packingUpMinutesRadioButton.isSelected()) 
			packingUp=Time.inMinutes(
					Convert.parseDouble(
							exerciseTimeSelectionPackingUpInput.getText(),"The time to pack up and enter the rover"
			));
		else if (packingUpHoursRadioButton.isSelected()) 
			packingUp=Time.inHours(
					Convert.parseDouble(
							exerciseTimeSelectionPackingUpInput.getText(),"The time to pack up and enter the rover"
			));
		else throw new IllegalArgumentException("The time to pack up and enter the rover's unit (minutes or hours) must be selected");
		
		Time transit;
		if (transitMinutesRadioButton.isSelected()) 
			transit=Time.inMinutes(
					Convert.parseDouble(
							exerciseTimeSelectionTransitInput.getText(),"The time in transit"
			));
		else if (transitHoursRadioButton.isSelected()) 
			transit=Time.inHours(
					Convert.parseDouble(
							exerciseTimeSelectionTransitInput.getText(),"The time in transit"
			));
		else throw new IllegalArgumentException("The time in transit's unit (minutes or hours) must be selected");
		
		// get the thicknesses from the setUpPanel.
		Thickness thicknessInSpaceSuit;
		if (spaceSuitThicknessPointThreeRadioButton.isSelected()) {
			thicknessInSpaceSuit=Thickness.POINT_THREE;
		} else if (spaceSuitThicknessOneRadioButton.isSelected()) {
			thicknessInSpaceSuit=Thickness.ONE;
		} else if (spaceSuitThicknessFiveRadioButton.isSelected()) {
			thicknessInSpaceSuit=Thickness.FIVE;
		} else throw new IllegalArgumentException("The thickness of the space suit must be specified");
		
		Thickness thicknessInRover;
		if (roverThicknessOneRadioButton.isSelected()) {
			thicknessInRover=Thickness.ONE;
		} else if (roverThicknessFiveRadioButton.isSelected()) {
			thicknessInRover=Thickness.FIVE;
		} else if (roverThicknessTenRadioButton.isSelected()) {
			thicknessInRover=Thickness.TEN;
		} else throw new IllegalArgumentException("The thickness of the rover must be specified"); 
		
		Thickness thicknessAtBase;
		if (baseThicknessFiveRadioButton.isSelected()) {
			thicknessAtBase=Thickness.FIVE;
		} else if (baseThicknessTenRadioButton.isSelected()) {
			thicknessAtBase=Thickness.TEN;
		} else if (baseThicknessThirtyRadioButton.isSelected()) {
			thicknessAtBase=Thickness.THIRTY;
		} else throw new IllegalArgumentException("The thickness of the base must be specified"); 
		
		// do the simulation
		DoseInformation doseInformation = yourSPE.simulateAstronautOnTheMoon(remOrRad,skinEyeOrBFO,
		 		priorToOnset,thicknessInSpaceSuit,packingUp,thicknessInSpaceSuit,transit,
				thicknessInRover,thicknessAtBase,cumulativeDoseGraph);
		
		// display the results in the proper place in the panel.
		exerciseTotalTimeEvolutionDoseAwayFromShelterValue.setText(
			Convert.toStringScientificNotation(doseInformation.totalDoseAwayFromShelter)
		);
		exerciseTotalTimeEvolutionRatioHigherThenAlwaysAtBaseValue.setText(
			Convert.toStringTwoDecimal(doseInformation.ratioHigherThenAlwaysAtBase)
		);
		
		exerciseTimeSelectionPriorToOnsetDoseValue.setText(
			Convert.toStringScientificNotation(doseInformation.dosePriorToWarning)
		);
		exerciseTimeSelectionPriorToOnsetPercentOfTotalValue.setText(
			Convert.toStringTwoDecimal(doseInformation.percentOfTotalPriorToWarning)
		);
		
		exerciseTimeSelectionPackingUpDoseValue.setText(
			Convert.toStringScientificNotation(doseInformation.doseWhilePackingUp)
		);
		exerciseTimeSelectionPackingUpPercentOfTotalValue.setText(
			Convert.toStringTwoDecimal(doseInformation.percentOfTotalWhilePackingUp)
		);
		
		exerciseTimeSelectionTransitDoseValue.setText(
			Convert.toStringScientificNotation(doseInformation.doseDuringTransit)
		);
		exerciseTimeSelectionTransitPercentOfTotalValue.setText(
			Convert.toStringTwoDecimal(doseInformation.percentOfTotalDuringTransit)
		);
		
		exerciseTimeSelectionInBaseDoseValue.setText(
			Convert.toStringScientificNotation(doseInformation.doseAtBase)
		);
		exerciseTimeSelectionInBasePercentOfTotalValue.setText(
			Convert.toStringTwoDecimal(doseInformation.percentOfTotalAtBase)
		);
		
		if (inBaseMinutesRadioButton.isSelected()) 
			exerciseTimeSelectionInBaseNotInput.setText(
				Convert.toStringTwoDecimal(doseInformation.timeExposedInBase.getMinutes()));
		else if (inBaseHoursRadioButton.isSelected()) 
			exerciseTimeSelectionInBaseNotInput.setText(
				Convert.toStringTwoDecimal(doseInformation.timeExposedInBase.getHours()));

	}
		
}  //  @jve:decl-index=0:visual-constraint="11,15"
