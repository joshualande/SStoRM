package SStoRM;

import org.apache.commons.math.analysis.RombergIntegrator;
import org.apache.commons.math.analysis.UnivariateRealFunction;
/**
 * 
 * This class represents a Solar Particle Event's energy spectrum. It uses the
 * exponential curve <i>Fluence</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>
 * E/Eo</sup> to represent the energy spectrum. The energy spectrum
 * represents the total number of particles at an energy value as a function
 * of that energy value. 
 * 
 * The integral of the energy spectrum is the
 * total number of particles of the SPE. The lower bounds of the integral 
 * (Emin) allows for the calculation of the total number of particles
 * above a certain energy value. 
 * <p>
 * The integral fluence is calculated using the formula
 * <pre>
 * ?<sub>Emin</sub><sup>?</sup>k*E<sup>-gamma</sup><i>e</i><sup>E/Eo</sup>dE
 * </pre>
 * The energy spectrum integral fluence and the K constant are intimately related. 
 * You can show that:
 * <pre>
 * K = (> Emin) ? fluence / (>Emin) ? fluence w/o K
 * </pre>
 * Here, the total ? fluence is passed to the program. 
 * Then the energy spectrum integral fluence without K is found using E0 and gamma and Emin. 
 * This means that if the (>Emin) integral fluence ( K) is specified, K can be found from it. This class
 * allows for either K or integral fluence to be specified, and the other is found when needed. 
 * This can be done entirely for you by the program. All you have to do is specify the values that you want.
 * <p>
 *  
 * <p>
 * <b>Usage:</b>
 * <p>
 * You can create a energy spectrum by saying:
 * <pre>
 * 	EnergySpectrum spectrum=new EnergySpectrum();
 * </pre>
 * You can then specify the shape of the energy spectrum by
 * setting the K, gamma, and E0 values.
 * <pre>
 * 	spectrum.setK(1e9);
 * 	spectrum.setGamma(0);
 * 	spectrum.setE0(30);
 * 	spectrum.setEmin(50);
 * </pre>
 * Alternatively, you can say
 * <pre>
 *  EnergySpectrum spectrum=new EnergySpectrum(1e9,0,30,50);
 *  // or
 *  EnergySpectrum spectrum=new EnergySpectrum(1e9,0,30);
 *  spectrum.setEmin(50);
 * </pre>
 * This sets the energy spectrum of the event. The integral fluence above
 * Emin can be calculated by saying:
 * <pre>
 * 	integralFluence=SPE.getIntergralFluence(); // computed automatically based on the energy spectrum
 * </pre>
 * If you know what the integral fluence should be and know what the spectral shape of the event is,
 * you can specify the SPE without giving a K, and K is automatically calculated so that the integral fluence
 * is correct.
 * <pre>
 * 	EnergySpectrum spectrum=new EnergySpectrum();
 * 	SPE.setGamma(0);
 *	SPE.setE0(30);
 * 	SPE.setEmin(30);
 * 	SPE.setIntegralFluence(1.88E10); 
 *	K = SPE.getK(); // calculates K based on the integral flux and spectral shape
 * </pre>
 * As a note, the following constraints are enforced:
 * <p>
 * K must be greater then 0. Emin must be at least 10 and at most 1500. Gamma must be at least 0 and at most
 * 4.125. E0 must be at least 10 and at most 1500. If the energy spectrum integral fluence is requested, it must
 * be at least 0.
 * <p>
 * 
 * @author Joshua Lande
 */
public class EnergySpectrum implements UnivariateRealFunction {

	/**
     * One of the parameters of the energy spectrum.
     * <p>
     * To access, see {@link #setE0} and {@link #getE0}.
     */    
    private double E0=Double.NaN;
    
    /**
     * One of the parameters of the energy spectrum.
     * <p>
     * To access, see {@link #setGamma} and {@link #getGamma}.
     */
    private double gamma=Double.NaN;
   
    /**
     * The starting energy value used by {@link #getIntegralFluence}
     * when calculating the integral fluence. 
     * <p>
     * To access, see {@link #setEmin} and {@link #getEmin}.
     */
    private double Emin=Double.NaN;

	/**
	 * One of the parameters of the energy spectrum. This is where the explicit 
	 * value of K is stored when it is specified by a call to {@link #setK}. When the energy spectrum
	 * is explicitly set with {@link #setIntegralFluence}, the K value is instead calculated and
	 * automatically and placed in {@link #CACHED_K}.
	 * <p>
	 * To access, see {@link #setK} and {@link #getK}.
	 */	
    private double K=Double.NaN;
    
    /**
     * The cached value of K, or a cache of the value of K calculated automatically when 
     * the integral fluence is explicitly set. When K is explicitly set with {@link #setK}, 
     * K's value is instead placed in {@link #K}.
     * <p>
     * CACHED_K is reset whenever {@link #setK}, {@link #setGamma}, {@link #setE0}, {@link #setEmin} or  
     * {@link #setIntegralFluence} is used to change the energy spectrum.
	 * <p>
	 * To access, see {@link #setK} and {@link #getK}.
     */
    private double CACHED_K=Double.NaN;
    
    /**
     * The cached value of the integralFluence. It is created automatically when K is explicitly set
     * using the {@link #setK} function. When the energy spectrum integral fluence is set explicitly with
     * {@link #setIntegralFluence(double)}, the fluence is instead placed inside 
     * {@link #integralFluence}.
     * <p>CACHED_integralFluence is reset
     * whenever {@link #setK}, {@link #setGamma}, {@link #setE0}, {@link #setEmin} or  
     * {@link #setIntegralFluence} and {@link #getIntegralFluence()} is used to change the energy spectrum.
     */
    private double CACHED_integralFluence=Double.NaN;
    
    /**
     * The integral of the energy spectrum. This is where the explicit 
	 * value of the integral is stored when it is specified by a call to {@link #setIntegralFluence}. 
	 * When the energy spectrum is instead explicitly set with {@link #setIntegralFluence}, 
	 * the K value is calculated and automatically placed in {@link #CACHED_K}.
	 * <p>
	 * To access, see {@link #setK} and {@link #getK}.
     */
    private double integralFluence=Double.NaN;

    /**
     * Removes all cached values. This should be called whenever a parameter is changed that
     * can possibly make the cache become out of data.
     */
    private void clearCachedValues() {
    	CACHED_integralFluence=Double.NaN;
   		CACHED_K=Double.NaN;
    }

	/**
	 * Tests weather 2 SPEs are equal. They are only equal if gamma, E0
	 * K, Emin, are defined and set to the same value.
	 */
	public boolean equals(Object anObject){
		if (anObject instanceof EnergySpectrum) {
			try {
				EnergySpectrum otherSpectrum = (EnergySpectrum)anObject;
		    	return  (
		    			(this.getGamma()== otherSpectrum.getGamma()) && 
						(this.getE0() 	== otherSpectrum.getE0()	) &&
						(this.getK() 	== otherSpectrum.getK()	) 
		    	);
			} catch (Exception exception) {
				return false;
			}
		}	
		return false;
	}

	/**
	 * Performs the expected clone of a EnergySpectrum.
	 */
	public Object clone() {   
       	try {
       		EnergySpectrum newSpectrum = new EnergySpectrum();
       		newSpectrum.setGamma(this.getGamma());
       		newSpectrum.setE0(this.getE0());
       		newSpectrum.setEmin(this.getEmin());
       		
       		/* 
       		 * place in either the actual integral fluence or K value, so that when changing Emin in the future, 
       		 * the cloned class will act the same.
       		 * This is because when the user enters an integral fluence and then changes Emin, 
       		 * the integral fluence for the new Emin is the same as the integral fluence for the old Emin. 
       		 * But, if K is specified as a constant, the integral fluence for a new Emin will be different,
       		 * and the integral fluence will always be calculated on the fly. 
       		 * Because of these dissimilarities, it is necessary to have the clone know how K/Integral fluence 
       		 * is stored in this class, and make it stored the same way in its clone. A bit kludge, but it works.
       		 */
       		if (!Double.isNaN(integralFluence))
       			newSpectrum.setIntegralFluence(this.getIntegralFluence());
       		else if (!Double.isNaN(K))
       			newSpectrum.setK(this.getK());
       		else throw new Exception();
       					
       		return (newSpectrum);
       		
       	} catch (Exception exception) {
			return null;
		}
    }

	/**
	 * Default constructor which does nothing.
	 */
	public EnergySpectrum() {
	}

    /**
     * Constructor that sets the energy spectrum but not Emin.
     * @param KInput The K parameter.
     * @param gammaInput The gamma parameter.
     * @param E0Input The E0 parameter.
     * @throws 	IllegalArgumentException if KInput, gammaInput, or E0Input are not valid.
     */
    public EnergySpectrum(double KInput,double gammaInput, double E0Input) throws IllegalArgumentException {
    	setEnergySpectrum(KInput,gammaInput,E0Input);
    }

    /**
     * Sets the energy spectrum but not emin.
     * @param KInput The K parameter.
     * @param gammaInput The gamma parameter.
     * @param E0Input The E0 parameter.
     * @throws 	IllegalArgumentException if KInput, gammaInput, or E0Input are not valid.
     */
    public void setEnergySpectrum(double KInput,double gammaInput, double E0Input) throws IllegalArgumentException {
        setK(KInput);
        setGamma(gammaInput);
        setE0(E0Input);
    }
    

    /**
     * Constructor that sets the energy spectrum and Emin.
     * @param KInput The K parameter.
     * @param gammaInput The gamma parameter.
     * @param E0Input The E0 parameter.
	 * @param Emin The Emin parameter.
     * @throws 	IllegalArgumentException if KInput, gammaInput, or E0Input are not valid.
     */
    public EnergySpectrum(double KInput,double gammaInput, double E0Input, double Emin) throws IllegalArgumentException {
    	setEnergySpectrum(KInput,gammaInput,E0Input,Emin);
    }

    /**
     * Sets the energy spectrum and Emin.
     * @param KInput The K parameter.
     * @param gammaInput The gamma parameter.
     * @param E0Input The E0 parameter.
	 * @param Emin The Emin parameter.
     * @throws 	IllegalArgumentException if KInput, gammaInput, or E0Input are not valid.
     */
    public void setEnergySpectrum(double KInput,double gammaInput, double E0Input, double Emin) throws IllegalArgumentException {
        setK(KInput);
        setGamma(gammaInput);
        setE0(E0Input);
        setEmin(Emin);
    }
    
    /**
     * Sets the Emin value. Emin is the lower bounds of the integral used to integral the energy 
     * spectrum. Emin will only be set if
     * it is at least 10 and at most 1500. While Emin is set, this function removes caches of the 
     * integralFluence and K so that
     * they can be recalculated with a new Emin when a call to {@link #getK} or 
     * {@link #getIntegralFluence} is issued.
     * @param EminInput The new minimum energy value to integrate from.
     * @throws IllegalArgumentException If EminInput is smaller then 10, larger then 1500, or not a number.
     */
    public void setEmin(double EminInput) throws IllegalArgumentException {
        if (Double.isNaN(EminInput)) 
            throw new IllegalArgumentException("Emin must be a number");
        if (EminInput <10)
            throw new IllegalArgumentException("Emin must be >=10. Emin is currently "+EminInput);
        if (EminInput >1500)
            throw new IllegalArgumentException("Emin must be <1500. Emin is currently "+EminInput);
        if (Emin == EminInput) return; // don't do anything if values are the same.
        
        clearCachedValues();
        Emin = EminInput; // set Emin
    }

    /** 
     * Sets the E0 parameter of the energy spectrum to E0Input. It is set only if
     * E0Input is at least 10 and at most 500. 
     * @param E0Input
     * @throws IllegalArgumentException If E0Input is less 10 or greater then 500.
     */
    public void setE0(double E0Input) throws IllegalArgumentException {
        if (Double.isNaN(E0Input)) 
            throw new IllegalArgumentException("E0 must be a number");
        if (E0Input<10)
            throw new IllegalArgumentException("E0 must be >= 10. E0 is currently "+E0Input);
        if (E0Input>500)
            throw new IllegalArgumentException("E0 must be <= 500. E0 is currently "+E0Input);
        
        if (E0 == E0Input) return; // don't do anything if values are the same.
        clearCachedValues();
        E0=E0Input; // set E0
    }

    /** 
     * Sets the gamma parameter of the energy spectrum. It is set only if
     * gammaInput is at least 0 and at most 4.125. 
     * @param gammaInput
     * @throws IllegalArgumentException If gammaInput is less 0 or greater then 4.125.
     */
    public void setGamma(double gammaInput) throws IllegalArgumentException { 
        if (Double.isNaN(gammaInput)) 
            throw new IllegalArgumentException("\u03B3 must be a number");
        if (gammaInput<0)
            throw new IllegalArgumentException("\u03B3 must be >= 0. \u03B3 is currently "+gammaInput);
        if (gammaInput>4.125)
            throw new IllegalArgumentException("\u03B3 must be <= 4.125. \u03B3 is currently "+gammaInput); 
        if (gamma == gammaInput) return; // don't do anything if values are the same.
        
        clearCachedValues();
        gamma=gammaInput; // set gamma       
    }    

    /** 
     * Sets the K parameter of the energy spectrum. K is only set if it is at least 0.
     * By setting K, it is assumed that the energy spectrum integral fluence should be 
     * calculated automatically.
     * @param KInput The K value to set
     * @throws IllegalArgumentException If KInput is less then 0 or not a number.
     */
    public void setK(double KInput) throws IllegalArgumentException {
        if (Double.isNaN(KInput)) 
            throw new IllegalArgumentException("K must be a number");
        if (Double.isInfinite(KInput)) 
            throw new IllegalArgumentException("K must not be infinite");
        if (KInput < 0.0) 
            throw new IllegalArgumentException("K must be >= 0. K is currently "+KInput);
        if (K == KInput) return; // don't do anything if values are the same.

        clearCachedValues();
        integralFluence=Double.NaN; // remove previously set value of integral fluence (it is now set automatically).
        K = KInput; // set K.
        
    }	
    
    /**
     * Sets the > Emin integralFluence. When this is set, K is assumed to be calculated
     * automatically.
     * @param integralFluenceInput
     * @throws IllegalArgumentException If the integral fluence is smaller then 0 or not a number.
     */
    public void setIntegralFluence(double integralFluenceInput) throws IllegalArgumentException {
        if (Double.isNaN(integralFluenceInput)) 
            throw new IllegalArgumentException("The integral fluence must be a number");
        if (Double.isInfinite(integralFluenceInput)) 
            throw new IllegalArgumentException("The integral fluence must not be infinite");
        if (integralFluenceInput < 0.0) 
            throw new IllegalArgumentException("The integral fluence must be >= 0. Integral fluence is currently "+integralFluence);
        if (integralFluence == integralFluenceInput) return; // don't do anything if values are the same.
        
        clearCachedValues();
        K = Double.NaN; // remove previously set value of K (it is now set automatically).
        integralFluence=integralFluenceInput; // set the fluence.
    }	

    /**
     * Calculates the energy spectrum fluence for the SPE at any given
     * energy value over 0. It calculates fluence using the formula:
     * <p>
     * <i>Fluence</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>E/Eo</sup>
     * <p>
     * <b>Where K is assumed to equal 1.</b>
     * @param EInput The energy value.
     * @return The fluence value for a given energy value.
     * @throws IllegalArgumentException If gamma, E0, or K are not defined or
     * if E is less then or equal to 0.
     */
    public double getFluenceWithoutK(double EInput) throws IllegalArgumentException {
        if (EInput <= 0.0)
            throw new IllegalArgumentException("E must be greater then 0. E is currently "+EInput);

        return Math.pow(EInput,-getGamma())*Math.exp(-EInput/getE0());
    }
 
    /**
     * Calculates the energy spectrum fluence for the SPE at any given
     * energy value over 0. But now K is used as it is set by either {@link #setK} or
     * {@link #setIntegralFluence} (which automatically creates a K. 
     * This function calculates fluence using the formula:
     * <p>
     * <i>Fluence</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>E/Eo</sup>
     * <p>
     * <b>Where K has previously been inputted from the user.</b>
     * @param EInput The energy value.
     * @return The fluence value for a given energy value.
     * @throws IllegalArgumentException If gamma, E0, or K are not defined or
     * if E is less then or equal to 0.
     */
    public double getFluence(double EInput) throws IllegalArgumentException {
        return getK()*getFluenceWithoutK(EInput);
    }
    
    /**
     * Method used so that the integral can be calculated by RombergIntegrator. It returns the fluence of the event without K.
     * @param EInput The energy value
     * @return The Fluence at that energy value (without K).
     */
    public double value(double EInput) {
    	return getFluenceWithoutK(EInput);
    }
   
  	/**
  	 * If the energy spectrum integral fluence is set explicity by the user, that value is returned.
  	 * <p>
  	 * Otherwise, this function calculates the energy spectrum integral fluence from Emin to 
  	 * 1500 (infinity). Here, Emin must have been previously set by an explicity call to {@link #setEmin}. 
  	 * <p>
  	 * What is returned is the total number of particles with energy values
  	 * above Emin (the integral fluence).
  	 * <p>
  	 * If the integral needs to be calculated, it is cached for later us. So this function should run fast once
  	 * the value is calculated once.
  	 * @return The energy spectrum integral fluence.
  	 * @throws IllegalArgumentException If any of the parameters of the energy spectrum are 
  	 * not specified.
  	 */
    public double getIntegralFluence() throws IllegalArgumentException {
    	// if the user has set the integral fluence, return it
    	if (!Double.isNaN(integralFluence)) return integralFluence;
    	
    	if (Double.isNaN(K))
    		throw new IllegalArgumentException("Either the energy spectrum integral fluence or K must be set before the can be retrieved");
		
    	// otherwise, if a cache of the integral fluence has been calculated, return it.
        if (!Double.isNaN(CACHED_integralFluence))
        	return CACHED_integralFluence;

		// Otherwise, calculate value and cache it.
		this.CACHED_integralFluence=getIntegralFluence(this.getEmin());
		return this.CACHED_integralFluence;
    }
    
    /**
     * Does the actual numeric integration of the energy spectrum integral 
     * fluence with an Emin value passed as an argument and <b>K assumed to be 1</b>. The integral fluence is 
     * calculated using trapezoid approximations. The
     * lower bounds is EminInput and the upper bounds are 3000 (basically 
     * infinity)
     * @param EminInput The lower bound of the integral.
     * @return The energy spectrum integral fluence.
     * @throws IllegalArgumentException If EminInput is less then 10, or if E0 is not defined.
     */
    public double getIntegralFluenceWithoutK(double EminInput) throws IllegalArgumentException {
        if (EminInput<10) throw new IllegalArgumentException("EminInput must be >= 10. It is currently "+Emin);
        
        double Emax=3000;
		if (EminInput>=Emax) return 0;		
		RombergIntegrator integrator = new RombergIntegrator(this);
		try{
			return integrator.integrate(EminInput,Emax);
		} catch (Exception e) {
			throw new IllegalArgumentException("Function not integratable"+e.getMessage());
		}
    }
    
    /**
     * Performs the same integral calculation as {@link #getIntegralFluenceWithoutK}, but
     * with the class's K value.
     * @param EminInput
     * @return The integral fluence 
     * @throws IllegalArgumentExceptionIf EminInput is less then 10, or if E0, 
     * gamma, or K are not defined.
     */
    public double getIntegralFluence(double EminInput) throws IllegalArgumentException {
    	return getK()*getIntegralFluenceWithoutK(EminInput);
    }
    
    /**
     * Gets the K parameter of the energy spectrum of the SPE. If K has been set explicitly,
     * that value is returned. Otherwise, K is calculated automatically using the formula
     * <pre>
     * 	K = inputted integral fluence / calculated integral fluence without K
     * </pre> 
  	 * If K needs be calculated, it is cached for later use. So this function should run fast once
  	 * the value is calculated.
     * @return K
     * @throws IllegalArgumentException If K is not defined.
     */
    public double getK() throws IllegalArgumentException {
    	if (!Double.isNaN(K)) return K; // if K has been specified by the user, return it.
    	if (Double.isNaN(integralFluence))
    		throw new IllegalArgumentException("Either the energy spectrum integral flux or K must be set before the can be retrieved");
		if (!Double.isNaN(CACHED_K)) return CACHED_K; 
    	CACHED_K = getIntegralFluence()/getIntegralFluenceWithoutK(getEmin());
    	return CACHED_K;
    }
      
    

	/**
	 * Gets the Emin value of the SPE.
	 * @return Emin
	 * @throws IllegalArgumentException If Emin is not defined.
	 */
    public double getEmin() throws IllegalArgumentException {
        if (Double.isNaN(Emin))	throw new IllegalArgumentException("Emin is not defined");
    	return Emin;
    }
    
    /**
     * Gets the gamma parameter of the energy spectrum of the SPE.
     * @return gamma
     * @throws IllegalArgumentException If gamma is not defined.
     */
    public double getGamma() throws IllegalArgumentException {
        if (Double.isNaN(gamma)) throw new IllegalArgumentException("Gamma is not defined");
        return gamma;
    }    
    
    /**
     * Gets the E0 paramter of the energy spectrum of the SPE.
     * @return E0
     * @throws IllegalArgumentException If E0 is not defined.
     */
    public double getE0() throws IllegalArgumentException {
    	if (Double.isNaN(E0)) throw new IllegalArgumentException("E0 is not defined");
        return E0;
    }
  
	
}
