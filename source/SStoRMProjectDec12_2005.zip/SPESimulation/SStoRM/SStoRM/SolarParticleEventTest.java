package SStoRM;

import junit.framework.TestCase;

public class SolarParticleEventTest extends TestCase {

	private static final double MAX_EXACT_PERCENT_ERROR = .00000000000000000000001;

	private static final double MAX_CALCULATED_PERCENT_ERROR = .00001;
	
	public void testEquals() {

		SolarParticleEvent event1 = new SolarParticleEvent( 1.0e9, 0, 30, "SPE");
		event1.setA(1);
		event1.setB1(2);
		event1.setB2(2);
		event1.setEmin(20);
		SolarParticleEvent event2 = new SolarParticleEvent( 1.0e9, 0, 30, "SPE");
		event2.setA(1);
		event2.setB1(2);
		event2.setB2(2);
		event2.setEmin(20);
		AssertMore.assertEquals(event1,event2);
		event2.setB2(0);
		AssertMore.assertNotEquals(event1,event2);
		event2.setB2(2);
		AssertMore.assertEquals(event1,event2);
		event1.setEmin(100);
		AssertMore.assertEquals(event1,event2);
		event2.setEmin(100);
		AssertMore.assertEquals(event1,event2);
		event2.setGamma(2);
		AssertMore.assertNotEquals(event1,event2);
	}
	
	public void testClone() {
		SolarParticleEvent event1 = new SolarParticleEvent( 1.0e9, 0, 30, "SPE");
		event1.setA(1);
		event1.setB1(2);
		event1.setB2(2);
		event1.setEmin(20);
	
		SolarParticleEvent event2 = (SolarParticleEvent)event1.clone();
		AssertMore.assertEquals(event1,event2);
		
		event2.setA(2);
		AssertMore.assertNotEquals(event1,event2);
		AssertMore.assertEquals(event2,(SolarParticleEvent)event2.clone());
		event1.setA(1);
		AssertMore.assertNotEquals(event1,event2);
	
	
	}
	
	public void testCompareTo() {
		SolarParticleEvent event1 = new SolarParticleEvent( 1.0e9, 0, 30, "SPE");
		SolarParticleEvent event2 = new SolarParticleEvent( 0.5e9, 0, 30 ,"SPE");
		event1.setEmin(10);
		event2.setEmin(10);
		AssertMore.assertEquals(21495939317.214, event1.getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(10747969658.607, event2.getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
	
		AssertMore.assertEquals( 1, event1.compareTo(event2));
		AssertMore.assertEquals(-1, event2.compareTo(event1));
		AssertMore.assertEquals(0, event1.compareTo(event1));
		
		
		event1 = new SolarParticleEvent( 1.0e09, 0, 30, "SPE");
		event2 = new SolarParticleEvent( 5.0e10, 1, 80 ,"SPE");
		event1.setEmin(10);
		event2.setEmin(10);
		AssertMore.assertEquals(21495939317.214, event1.getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(81171282029.725, event2.getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(-1, event1.compareTo(event2));
		AssertMore.assertEquals( 1, event2.compareTo(event1));
		AssertMore.assertEquals( 0, event1.compareTo(event1));
		AssertMore.assertEquals( 0, event2.compareTo(event2));
		
		SolarParticleEvent events[] = new SolarParticleEvent[] {
				new SolarParticleEvent( 1.0e09, 0.0, 30, "SPE"), // fluence = 21495939317.2140 w/ Emin = 10
				new SolarParticleEvent( 0.5e09, 0.0, 30, "SPE"), // fluence = 10747969658.6070 w/ Emin = 10
				new SolarParticleEvent( 5.0e10, 1.0, 80, "SPE"), // fluence = 81171282029.7250 w/ Emin = 10
				new SolarParticleEvent( 5.0e10, 1.9, 30, "SPE"), // fluence =  2920940200.9011 w/ Emin = 10
				new SolarParticleEvent( 5.0e12, 1.9, 30, "SPE"), // fluence = 87101648877.7450 w/ Emin = 20
				new SolarParticleEvent( 5.0e11, 1.9, 30, "SPE"), // fluence = 03599796711.3095 w/ Emin = 30
		};
		events[0].setEmin(10);
		events[1].setEmin(10); 
		events[2].setEmin(10);
		events[3].setEmin(10);
		events[4].setEmin(20);
		events[5].setEmin(30);

        java.util.Arrays.sort(events); // sort the SPEs into ascending order
		AssertMore.assertEquals(02920940200.9011, events[0].getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(03599796711.3095, events[1].getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(10747969658.6070, events[2].getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(21495939317.2140, events[3].getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(81171282029.7250, events[4].getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(87101648877.7450, events[5].getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		
		
		
	}

	public void testSolarParticleEvent() {

		SolarParticleEvent event = new SolarParticleEvent();
		AssertMore.assertEquals(event.getName(),"");
		event.setName("blah");
		AssertMore.assertEquals(event.getName(),"blah");
		event.setName("");
		AssertMore.assertEquals(event.getName(),"");
		
		
		event = new SolarParticleEvent("test spe");
		AssertMore.assertEquals(event.getName(),"test spe");

		// make sure g, gamma, and E0 are not defined yet.
		try { 
			event.getK();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.getGamma();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getE0();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
	}

	public void testSolarParticleEventdoubledoubledoubleString() {
		SolarParticleEvent event = new SolarParticleEvent(1e9,0,30,"test spe");
		AssertMore.assertEquals("test spe",	event.getName());
		AssertMore.assertEquals(1e9,		event.getK(),		MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(0,			event.getGamma(),	MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(30,			event.getE0(),		MAX_EXACT_PERCENT_ERROR);

		try { 
			event.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	
	}

	public void testSetSPE() {
		SolarParticleEvent event = new SolarParticleEvent("a");
		event.setSPE(1e9,0,30,"test spe");
		
		AssertMore.assertEquals("test spe", event.getName());
		AssertMore.assertEquals(1e9, 		event.getK(),   	MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(0, 			event.getGamma(),  	MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(30,	 		event.getE0(),     	MAX_EXACT_PERCENT_ERROR);

		event.setSPE(1.0,2,230.5,"another name");
		AssertMore.assertEquals("another name",	event.getName());
		AssertMore.assertEquals(1.0, 			event.getK(),       MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(2,   			event.getGamma(),   MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(230.5, 			event.getE0(),    	MAX_EXACT_PERCENT_ERROR);

		event.setSPE(.0001,4.111,499.4,"a third one");
		AssertMore.assertEquals("a third one",	event.getName());
		AssertMore.assertEquals(0.0001, 		event.getK(),      	MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(4.111,  		event.getGamma(),  	MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(499.4,    		event.getE0(), 		MAX_EXACT_PERCENT_ERROR);

		try { 
			event.setSPE(-1.0,2,230.5,"another name");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setSPE(1.0,-.01,230.5,"another name");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setSPE(1.0,1,500.1,"another name");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setSPE(1.0,1,Double.POSITIVE_INFINITY,"another name");
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		
		
		
		try { 
			event.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.getA();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.getB1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.getB2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.getEnergySpectrumIntegralFluence();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0), Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testGetSetEmin() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		try { 
			event.getE0();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setEmin(111);
		AssertMore.assertEquals(111.0,     	event.getEmin(), 	MAX_EXACT_PERCENT_ERROR);
		event.setEmin(112);
		AssertMore.assertEquals(112.0,     	event.getEmin(),	MAX_EXACT_PERCENT_ERROR);
		event.setEmin(10.0);
		AssertMore.assertEquals(10.0, 		event.getEmin(),	MAX_EXACT_PERCENT_ERROR);

		try {
			event.setEmin(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setEmin(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setEmin(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setEmin(9.9);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setEmin(1600);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testGetSetK() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		try { 
			event.getK();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setK(10);
		AssertMore.assertEquals(10,     	event.getK(), 	MAX_EXACT_PERCENT_ERROR);
		event.setK(9999);
		AssertMore.assertEquals(9999,     	event.getK(), 	MAX_EXACT_PERCENT_ERROR);
		event.setK(99.000001);
		AssertMore.assertEquals(99.000001,  event.getK(), 	MAX_EXACT_PERCENT_ERROR);
		event.setK(0);
		AssertMore.assertEquals(0,  event.getK(), 	MAX_EXACT_PERCENT_ERROR);
		try { 
			event.setK(-1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setK(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setK(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

	}

	public void testGetSetE0() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		try { 
			event.getE0();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setE0(100);
		AssertMore.assertEquals(100,     	event.getE0(), 	MAX_EXACT_PERCENT_ERROR);
		event.setE0(500);
		AssertMore.assertEquals(500,     	event.getE0(), 	MAX_EXACT_PERCENT_ERROR);
		

		try { 
			event.setE0(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setE0(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setE0(9.9);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setE0(500.1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testGetSetGamma() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		try { 
			event.getGamma();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setGamma(2.08);
		AssertMore.assertEquals(2.08,  event.getGamma(), MAX_EXACT_PERCENT_ERROR);
		event.setGamma(3.1249);
		AssertMore.assertEquals(3.1249,  event.getGamma(), MAX_EXACT_PERCENT_ERROR);
		try { 
			event.setGamma(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setGamma(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setGamma(4.126);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setGamma(-.0001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testGetSetName() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		AssertMore.assertEquals("test spe",  event.getName());
		event.setName("new name");
		AssertMore.assertEquals("new name",  event.getName());
		try { 
			event.setName(null);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
	}

	public void testGetSetA() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		try { 
			event.getA();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setA(10.1);
		AssertMore.assertEquals(10.1,  event.getA(), MAX_EXACT_PERCENT_ERROR);
		try { 
			event.setA(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setA(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setA(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
			
	}

	public void testGetSetB1() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		try { 
			event.getB1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setB1(10.1);
		AssertMore.assertEquals(10.1,  event.getB1(), MAX_EXACT_PERCENT_ERROR);
		try { 
			event.setB1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setB1(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testGetSetB2() {
		SolarParticleEvent event = new SolarParticleEvent("test spe");
		try { 
			event.getB2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setB2(10.1);
		AssertMore.assertEquals(10.1,  event.getB2(), MAX_EXACT_PERCENT_ERROR);
		try { 
			event.setB2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			event.setB2(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testGetSetEnergySpectrum() {
		SolarParticleEvent event = new SolarParticleEvent(1e9,0,30,"test spe");
		AssertMore.assertEquals(716531310.57379 , event.getEnergySpectrumFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(2.149593931714e10, 	event.getEnergySpectrumIntegralFluence(10),			MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(1.1036383235144e10, event.getEnergySpectrumIntegralFluence(30),			MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(4.0600584970986e9,  event.getEnergySpectrumIntegralFluence(60),			MAX_CALCULATED_PERCENT_ERROR);
	
		try { 
			event.getEnergySpectrumIntegralFluence();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setEmin(10);
		AssertMore.assertEquals(2.149593931714e10, 	event.getEnergySpectrumIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		
		event.setEmin(30); // set emin
		AssertMore.assertEquals(1.1036383235144e10, event.getEnergySpectrumIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		
		event.setK(2.2e7); // change k
		AssertMore.assertEquals(242800431.17315, event.getEnergySpectrumIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(472910664.97871, event.getEnergySpectrumIntegralFluence(10),	MAX_CALCULATED_PERCENT_ERROR);
		
		event.setEmin(10);// change emin
		event.setGamma(3.01); // chang gamma
		AssertMore.assertEquals(61025.805350301, event.getEnergySpectrumIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		
		event.setE0(112); // change E0
		AssertMore.assertEquals(90782.963349881, event.getEnergySpectrumIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		// second statment to check caching mechanism.
		AssertMore.assertEquals(90782.963349881, event.getEnergySpectrumIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		
		
		// when we set the energy spectrum, k should be calculated automatically.
		event.setEnergySpectrumIntegralFluence(1.02e10);
		AssertMore.assertEquals(2471829423932.3,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2471829423932.3,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setK(2471829423932.3);
		AssertMore.assertEquals(2471829423932.3,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.02e10,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setK(1111.111);
		event.setEmin(30);
		event.setGamma(1.99);
		event.setE0(202.2);
		AssertMore.assertEquals(1111.111,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(24.814069093002,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.8710442609193,event.getEnergySpectrumIntegralFluence(66),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(66);
		AssertMore.assertEquals(7.8710442609193,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		event.setEnergySpectrumIntegralFluence(666);
		AssertMore.assertEquals(666, event.getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(94015.470053217, event.getK(), MAX_CALCULATED_PERCENT_ERROR);
		
		event.setEmin(30); // change Emin
		AssertMore.assertEquals(666, event.getEnergySpectrumIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(29821.788729068, event.getK(), MAX_CALCULATED_PERCENT_ERROR);
	
		AssertMore.assertEquals( 290.43919751046 , event.getEnergySpectrumFluence(10), MAX_CALCULATED_PERCENT_ERROR);
	
	
		event = new SolarParticleEvent(1e9,0,30,"test spe");
		event.setEnergySpectrumIntegralFluence(1000);
		AssertMore.assertEquals(1000,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		try {
			event.getK(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		
		
		event = new SolarParticleEvent(1e9,0,30,"test spe");
		try {
			event.getEnergySpectrumIntegralFluence(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	
		
		
		
		event = new SolarParticleEvent("SPE");
		AssertMore.assertEquals("SPE", event.getName());
		try {
			event.getEnergySpectrumIntegralFluence(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getK(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getE0(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setE0(80);
		AssertMore.assertEquals(80,event.getE0(),MAX_CALCULATED_PERCENT_ERROR);
		event.setGamma(1);
		AssertMore.assertEquals(1,event.getGamma(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence(1);
		try {
			event.getK();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setK(10);
		try {
			event.getEnergySpectrumIntegralFluence();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setEmin(22);
		AssertMore.assertEquals(22,event.getEmin(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence(1);
		AssertMore.assertEquals(1,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0299079093937, event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK(1.0299079093937);
		AssertMore.assertEquals(1.0299079093937, event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK(5e9);
		AssertMore.assertEquals(4854802991.9913,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5e9,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence(999);
		AssertMore.assertEquals(1028.8780014843,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(999,event.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		
	}

	public void testGetDose() {
		
	SolarParticleEvent event= new SolarParticleEvent("SPE");	
	try {
		event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE);
		AssertMore.fail("Error should have been thrown");
	} catch (Exception e) {}
	event.setE0(10);
	try {
		event.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE);
		AssertMore.fail("Error should have been thrown");
	} catch (Exception e) {}
	
	event.setGamma(0);
	event.setE0(10);
	event.setEmin(10);
	event.setEnergySpectrumIntegralFluence(3.6787944117144);
	// here, k is calculated automatically
	AssertMore.assertEquals(0.00000070403064,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	AssertMore.assertEquals(1,      event.getK(),  MAX_CALCULATED_PERCENT_ERROR);
	
	AssertMore.assertEquals(0.00000070403064/2,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	

	
	
	event.setSPE(1, 0,      10);
	AssertMore.assertEquals(0.00000070403064,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	AssertMore.assertEquals(0.00000070403064/2,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	event.setSPE(1, 0,      10);	
	AssertMore.assertEquals(0.00000022281255,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	AssertMore.assertEquals(0.00000022281255/2,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	event.setSPE(1, 0,      10);	
	AssertMore.assertEquals(0.0000000015429306,    event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	AssertMore.assertEquals(0.0000000015429306/2,    event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	event.setSPE(1, 0.75,  450);	
	AssertMore.assertEquals(0.00000047012099,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	AssertMore.assertEquals(0.00000047012099/2,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	event.setSPE(1, 0.75,  450);	
	AssertMore.assertNotEquals(0.00000047013,      event.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // this is not true
	
	event.setSPE(1, 0.625, 480);	
	AssertMore.assertEquals(0.00000094430027,      event.getDose(Thickness.ONE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0.375, 470);	
	AssertMore.assertEquals(0.0000084493395,       event.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0.375, 470);	
	AssertMore.assertNotEquals(0.0000074493395,    event.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	event.setSPE(1, 0.75,  470);	
	AssertMore.assertEquals(0.000001346395,        event.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4,     260);	
	AssertMore.assertEquals(0.0000000000024499285, event.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125,  10);	
	AssertMore.assertEquals(4.2875497E-14,         event.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125, 500);	
	AssertMore.assertEquals(0.000000000001669283,  event.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,     500);	
	AssertMore.assertEquals(0.000060348026,        event.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0.125, 500);	
	AssertMore.assertEquals(0.000015740048,        event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0.125, 500);	
	AssertMore.assertEquals(0.000017522505,        event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0.125, 500);	
	AssertMore.assertEquals(0.000017317887,        event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.625,  20);	
	AssertMore.assertEquals(0.000000000082150911,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.625,  20);	
	AssertMore.assertEquals(0.000000000063298734,  event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.625,  20);	
	AssertMore.assertEquals(0.0000000000045508042, event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.625,  20);	
	AssertMore.assertEquals(0.00000000012973093,   event.getDose(Thickness.FIVE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.625,  20);	
	AssertMore.assertEquals(0.000000000095237367,  event.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.625,  20);	
	AssertMore.assertEquals(0.0000000000073112939, event.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,      10);	
	AssertMore.assertEquals(0.0000000014003176,    event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,     500);	
	AssertMore.assertEquals(0.000035926314,        event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125,  10);	
	AssertMore.assertEquals(3.953479E-17,          event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125, 500);	
	AssertMore.assertEquals(6.1047718E-14 ,        event.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,      10);	
	AssertMore.assertEquals(0.0000000000027777104, event.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125,  10);	
	AssertMore.assertEquals(2.1689817E-17,         event.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,     500);	
	AssertMore.assertEquals(0.000025157018,        event.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125, 500);	
	AssertMore.assertEquals(8.357322E-16,          event.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.125, 290);	
	AssertMore.assertEquals(0.000000016980616,     event.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 2.5,   440);	
	AssertMore.assertEquals(0.0000000000099093563, event.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 2.625, 440);	
	AssertMore.assertEquals(0.0000000000049200609, event.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.5,   380);	
	AssertMore.assertEquals(0.0000000025662568,    event.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375, 100);	
	AssertMore.assertEquals(0.00000011206039,      event.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .125, 270);	
	AssertMore.assertEquals(0.0000089299137,       event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);   
	event.setSPE(1,  .25,  270);	
	AssertMore.assertEquals(0.0000042227257,       event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  260);	
	AssertMore.assertEquals(0.0000039604151,       event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.125,  90);	
	AssertMore.assertEquals(0.0000000029764826,    event.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.125, 100);	
	AssertMore.assertEquals(0.0000000039450558,    event.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.5,   270);	
	AssertMore.assertEquals(0.0000000022628353,    event.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,      10);	
	AssertMore.assertEquals(0.00000000018974713,   event.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125,  10);	
	AssertMore.assertEquals(4.2578434E-17,         event.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,     500);	
	AssertMore.assertEquals(0.000060006791,        event.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125, 500);	
	AssertMore.assertEquals(0.0000000000000235696, event.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,      10);	
	AssertMore.assertEquals(0.000000000074961412,  event.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125,  10);	
	AssertMore.assertEquals(1.7230071E-17,         event.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 0,     500);	
	AssertMore.assertEquals(0.000033056775,        event.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 4.125, 500);	
	AssertMore.assertEquals(1.6004745E-14,         event.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.375, 320);	
	AssertMore.assertEquals(0.000000011797018,     event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.5,   320);	
	AssertMore.assertEquals(0.0000000061652372,    event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.375, 500);	
	AssertMore.assertEquals(0.00000001526657,      event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.125, 480);	
	AssertMore.assertEquals(0.000000067081778,     event.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 2.25,  330);	
	AssertMore.assertEquals(0.00000000019645702,   event.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.75,  390);	
	AssertMore.assertEquals(0.0000000011387776,    event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.5,   390);	
	AssertMore.assertEquals(0.0000000044591548,    event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	// make sure k scaling works
	event.setSPE(1e1,     0,     500);	
	AssertMore.assertEquals(0.000033056775*1e1,         event.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(43,      4.125, 500);	
	AssertMore.assertEquals(1.6004745E-14*43,           event.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(111,     1.375, 320);	
	AssertMore.assertEquals(0.000000011797018*111,      event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(.001,    1.5,   320);	
	AssertMore.assertEquals(0.0000000061652372*.001,    event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(666,     1.375, 500);	
	AssertMore.assertEquals(0.00000001526657*666,       event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1e9,     1.125, 480);	
	AssertMore.assertEquals(0.000000067081778*1e9,      event.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(4.3e13,  2.25,  330);	
	AssertMore.assertEquals(0.00000000019645702*4.3e13, event.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(.223213, 1.75,  390);	
	AssertMore.assertEquals(0.0000000011387776*.223213, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(4e-21,   1.5,   390);	
	AssertMore.assertEquals(0.0000000044591548*4e-21,   event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(    0,   1.5,   390);	
	AssertMore.assertEquals(0.0,                        event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	

	// test single interpolation b/n gamma 1.75 to 1.5 w/ E0=390
	event.setSPE(1, 1.75,  390);	
	AssertMore.assertEquals(0.0000000011387776,  event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1, 1.725, 390);	
	AssertMore.assertEquals(0.00000000136093178, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.7,   390);	
	AssertMore.assertEquals(0.00000000158308596, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.675, 390);	
	AssertMore.assertEquals(0.00000000180524014, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.65,  390);	
	AssertMore.assertEquals(0.00000000202739432, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
	event.setSPE(1, 1.625, 390);	
	AssertMore.assertEquals(0.0000000022495485,  event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1, 1.6,   390);	
	AssertMore.assertEquals(0.00000000269146976, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.575, 390);	
	AssertMore.assertEquals(0.00000000313339102, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.55,  390);	
	AssertMore.assertEquals(0.00000000357531228, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.525, 390);	
	AssertMore.assertEquals(0.00000000401723354, event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1, 1.5,   390);	
	AssertMore.assertEquals(0.0000000044591548,  event.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	// test single interpolation b/n E0=260 to 270 w/ gamma = .25
	event.setSPE(1,  .25,  260);	
	AssertMore.assertEquals(0.0000039604151,     event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1,  .25,  261);	
	AssertMore.assertEquals(0.00000398664616,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  262);	
	AssertMore.assertEquals(0.00000401287722,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  263);	
	AssertMore.assertEquals(0.00000403910828,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  264);	
	AssertMore.assertEquals(0.00000406533934,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  265);	
	AssertMore.assertEquals(0.0000040915704,     event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  266);	
	AssertMore.assertEquals(0.00000411780146,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  267);	
	AssertMore.assertEquals(0.00000414403252,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  268);	
	AssertMore.assertEquals(0.00000417026358,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  269);	
	AssertMore.assertEquals(0.00000419649464,    event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .25,  270);	
	AssertMore.assertEquals(0.0000042227257,     event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	// test single interpolation b/n Eo=260 & 270 w/ gamma = .375
	event.setSPE(1,  .375,  260);	
	AssertMore.assertEquals(0.0000018842788,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1,  .375,  261);	
	AssertMore.assertEquals(0.00000189633192, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  262);	
	AssertMore.assertEquals(0.00000190838504, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  263);	
	AssertMore.assertEquals(0.00000192043816, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  264);	
	AssertMore.assertEquals(0.00000193249128, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  265);	
	AssertMore.assertEquals(0.0000019445444,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  266);	
	AssertMore.assertEquals(0.00000195659752, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  267);	
	AssertMore.assertEquals(0.00000196865064, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  268);	
	AssertMore.assertEquals(0.00000198070376, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  269);	
	AssertMore.assertEquals(0.00000199275688, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,  270);	
	AssertMore.assertEquals(0.000002004813,   event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	// test double interpolation (interpolate b/n interpolated values) for gamma=.25 to .375 w/ E0=262
	event.setSPE(1,  .25,    262);	
	AssertMore.assertEquals(0.00000401287722,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .2625,  262);	
	AssertMore.assertEquals(0.000003802428002, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .275,   262);	
	AssertMore.assertEquals(0.000003591978784, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .2875,  262);	
	AssertMore.assertEquals(0.000003381529566, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3,     262);	
	AssertMore.assertEquals(0.000003171080348, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3125,  262);	
	AssertMore.assertEquals(0.00000296063113,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .325,   262);	
	AssertMore.assertEquals(0.000002750181912, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3375,  262);	
	AssertMore.assertEquals(0.000002539732694, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .35,    262);	
	AssertMore.assertEquals(0.000002329283476, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3625,  262);	
	AssertMore.assertEquals(0.000002118834258, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,   262);	
	AssertMore.assertEquals(0.00000190838504,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	// test double interpolation (interpolate b/n interpolated values) for gamma=.25 to .375 w/ E0=266
	event.setSPE(1,  .25,    266);	
	AssertMore.assertEquals(0.00000411780146,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .2625,  266);	
	AssertMore.assertEquals(0.000003901681066, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .275,   266);	
	AssertMore.assertEquals(0.000003685560672, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .2875,  266);	
	AssertMore.assertEquals(0.000003469440278, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3,     266 );	
	AssertMore.assertEquals(0.000003253319884, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3125,  266);	
	AssertMore.assertEquals(0.00000303719949,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .325,   266);	
	AssertMore.assertEquals(0.000002821079096, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3375,  266);	
	AssertMore.assertEquals(0.000002604958702, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .35,    266);	
	AssertMore.assertEquals(0.000002388838308, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3625,  266);	
	AssertMore.assertEquals(0.000002172717914, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,   266);	
	AssertMore.assertEquals(0.00000195659752,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	// test double interpolation (interpolate b/n interpolated values) for gamma=.25 to .375 w/ E0=261
	event.setSPE(1,  .25,    261);	
	AssertMore.assertEquals(0.00000398664616,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .2625,  261);	
	AssertMore.assertEquals(0.000003777614736, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .275,   261);	
	AssertMore.assertEquals(0.000003568583312, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .2875,  261);	
	AssertMore.assertEquals(0.000003359551888, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3,     261);	
	AssertMore.assertEquals(0.000003150520464, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3125,  261);	
	AssertMore.assertEquals(0.00000294148904,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .325,   261);	
	AssertMore.assertEquals(0.000002732457616, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3375,  261);	
	AssertMore.assertEquals(0.000002523426192, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .35,    261);	
	AssertMore.assertEquals(0.000002314394768, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .3625,  261);	
	AssertMore.assertEquals(0.000002105363344, event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  .375,   261);	
	AssertMore.assertEquals(0.00000189633192,  event.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	
	// test single interpolation b/n gamma 2 to 2.125 w/ E0=200
	event.setSPE(1,  2,            200);	
	AssertMore.assertEquals(0.0000000007390083,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1,  2.0125,       200);	
	AssertMore.assertEquals(0.000000000706360565, event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        200);	
	AssertMore.assertEquals(0.00000000067371283,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0375,       200);	
	AssertMore.assertEquals(0.000000000641065095, event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.05,         200);	
	AssertMore.assertEquals(0.00000000060841736,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0625,       200);	
	AssertMore.assertEquals(0.000000000575769625, event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.075,        200);	
	AssertMore.assertEquals(0.00000000054312189,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,       200);	
	AssertMore.assertEquals(0.000000000510474155, event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.1,          200);	
	AssertMore.assertEquals(0.00000000047782642,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.1125,       200);	
	AssertMore.assertEquals(0.000000000445178685, event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.125,        200);	
	AssertMore.assertEquals(0.00000000041253095,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	// test single interpolation b/n gamma 2 to 2.125 w/ E0=210
	event.setSPE(1,  2,            210);	
	AssertMore.assertEquals(0.00000000076027212,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1,  2.0125,       210);	
	AssertMore.assertEquals(0.000000000726657592,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        210);	
	AssertMore.assertEquals(0.000000000693043064,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0375,       210);	
	AssertMore.assertEquals(0.000000000659428536,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.05,         210);	
	AssertMore.assertEquals(6.25814008000001E-10,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0625,       210);	
	AssertMore.assertEquals(0.00000000059219948,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.075,        210);	
	AssertMore.assertEquals(0.000000000558584952,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,       210);	
	AssertMore.assertEquals(0.000000000524970424,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.1,          210);	
	AssertMore.assertEquals(0.000000000491355896,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.1125,       210);	
	AssertMore.assertEquals(0.000000000457741368,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.125,        210);	
	AssertMore.assertEquals(0.00000000042412684,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	// test double interpolation (interpolate b/n interpolated values) for E0 200 to 210 & gamma = 2.025
	event.setSPE(1,  2.025,        200);	
	AssertMore.assertEquals(0.00000000067371283,    event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        201);	
	AssertMore.assertEquals(0.0000000006756458534,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        202);	
	AssertMore.assertEquals(0.0000000006775788768,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        203);	
	AssertMore.assertEquals(0.0000000006795119002,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        204);	
	AssertMore.assertEquals(0.0000000006814449236,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        205);	
	AssertMore.assertEquals(0.000000000683377947,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        206);	
	AssertMore.assertEquals(0.0000000006853109704,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        207);	
	AssertMore.assertEquals(0.0000000006872439938,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        208);	
	AssertMore.assertEquals(0.0000000006891770172,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        209);	
	AssertMore.assertEquals(0.0000000006911100406,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.025,        210);	
	AssertMore.assertEquals(0.000000000693043064,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	// test double interpolation (interpolate b/n interpolated values) for E0 200 to 210 & gamma = 2.0875
	event.setSPE(1,  2.0875,        200);	
	AssertMore.assertEquals(0.000000000510474155,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        201);	
	AssertMore.assertEquals(0.0000000005119237819,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        202);	
	AssertMore.assertEquals(0.0000000005133734088,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        203);	
	AssertMore.assertEquals(0.0000000005148230357,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        204);	
	AssertMore.assertEquals(0.0000000005162726626,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        205);	
	AssertMore.assertEquals(0.0000000005177222895,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        206);	
	AssertMore.assertEquals(0.0000000005191719164,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        207);	
	AssertMore.assertEquals(0.0000000005206215433,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        208);	
	AssertMore.assertEquals(0.0000000005220711702,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        209);	
	AssertMore.assertEquals(0.0000000005235207971,  event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  2.0875,        210);	
	AssertMore.assertEquals(0.000000000524970424,   event.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	
	// test single interpolation b/n E0=490 to 500 w/ gamma = 4
	event.setSPE(1,  4,        490);	
	AssertMore.assertEquals(1.1153167E-13,     		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1,  4,        491);	
	AssertMore.assertEquals(1.11572213E-13,    		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        492);	
	AssertMore.assertEquals(1.11612756E-13,   		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        493);	
	AssertMore.assertEquals(1.11653299E-13,    		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        494);	
	AssertMore.assertEquals(1.11693842E-13,    		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        495);	
	AssertMore.assertEquals(1.11734385E-13,    		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        496);	
	AssertMore.assertEquals(1.11774928E-13,    		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        497);	
	AssertMore.assertEquals(1.11815471E-13,    		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        498);	
	AssertMore.assertEquals(1.11856014E-13,         event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        499);	
	AssertMore.assertEquals(1.11896557E-13,   		event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4,        500);	
	AssertMore.assertEquals(0.0000000000001119371,  event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
	//		 test single interpolation b/n E0=490 to 500 w/ gamma = 4.125
	event.setSPE(1,  4.125,    490);	
	AssertMore.assertEquals(6.4644762E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); // exact
	event.setSPE(1,  4.125,    491);	
	AssertMore.assertEquals(6.46676122E-14,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    492);	
	AssertMore.assertEquals(6.46904624E-14,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    493);	
	AssertMore.assertEquals(6.47133126E-14,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    494);	
	AssertMore.assertEquals(6.47361628E-14,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    495);	
	AssertMore.assertEquals(6.4759013E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    496);	
	AssertMore.assertEquals(6.47818632E-14,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    497);	
	AssertMore.assertEquals(6.48047134E-14,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    498);	
	AssertMore.assertEquals(6.48275636E-14 ,  event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    499);	
	AssertMore.assertEquals(6.48504138E-14 ,  event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,    500);	
	AssertMore.assertEquals(6.4873264E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); // exact
	//		 test double interpolation (interpolate b/n interpolated values) for gamma=4 to 4.125 w/ E0 = 499
	event.setSPE(1,  4,          499);	
	AssertMore.assertEquals(1.11896557E-13,          event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0125,     499);	
	AssertMore.assertEquals(1.0719194268E-13,        event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.025,      499);	
	AssertMore.assertEquals(1.0248732836E-13,        event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0375,     499);	
	AssertMore.assertEquals(9.77827140400001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.05,       499);	
	AssertMore.assertEquals(9.30780997200001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0625,     499);	
	AssertMore.assertEquals(8.83734854E-14,          event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.075,      499);	
	AssertMore.assertEquals(8.36688710799999E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0875,     499);	
	AssertMore.assertEquals(7.89642567599999E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.1,        499);	
	AssertMore.assertEquals(7.42596424400001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.1125,     499);	
	AssertMore.assertEquals(6.95550281200001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,      499);	
	AssertMore.assertEquals(6.48504138E-14,          event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	// test double interpolation (interpolate b/n interpolated values) for gamma=4 to 4.125 w/ E0 = 492
	event.setSPE(1,  4,          492);	
	AssertMore.assertEquals(1.11612756E-13,          event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0125,     492);	
	AssertMore.assertEquals(1.0692052664E-13,        event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.025,      492);	
	AssertMore.assertEquals(1.0222829728E-13,        event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0375,     492);	
	AssertMore.assertEquals(9.75360679200001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.05,       492);	
	AssertMore.assertEquals(9.28438385600001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0625,     492);	
	AssertMore.assertEquals(8.81516092E-14,          event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.075,      492);	
	AssertMore.assertEquals(8.34593798399999E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0875,     492);	
	AssertMore.assertEquals(7.87671504799999E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.1,        492);	
	AssertMore.assertEquals(7.40749211200001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.1125,     492);	
	AssertMore.assertEquals(6.93826917600001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,      492);	
	AssertMore.assertEquals(6.46904624E-14,          event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	// test double interpolation (interpolate b/n interpolated values) for gamma=4 to 4.125 w/ E0 = 495
	event.setSPE(1,  4,          495);	
	AssertMore.assertEquals(1.11734385E-13,          event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0125,     495);	
	AssertMore.assertEquals(1.070368478E-13,         event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.025,      495);	
	AssertMore.assertEquals(1.023393106E-13,         event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0375,     495);	
	AssertMore.assertEquals(9.76417734000001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.05,       495);	
	AssertMore.assertEquals(9.29442362000001E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0625,     495);	
	AssertMore.assertEquals(8.8246699E-14,           event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.075,      495);	
	AssertMore.assertEquals(8.35491617999999E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.0875,     495);	
	AssertMore.assertEquals(7.88516245999999E-14,    event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.1,        495);	
	AssertMore.assertEquals(7.41540874000001E-14 ,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.1125,     495);	
	AssertMore.assertEquals(6.94565502000001E-14 ,   event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	event.setSPE(1,  4.125,      495);	
	AssertMore.assertEquals(6.4759013E-14,           event.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	
	
	
	
	}
	
	public void testTimeEvolutionFlux() {
		SolarParticleEvent event = new SolarParticleEvent("SPE");
		event.setA(.5);
		try {
			event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		event.setB1(1);
		try {
			event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		
		event.setB2(1);
		
		// test getting flux
		AssertMore.assertEquals(.073262555554936,   event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(2)),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.0011106882367801,  event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(4.5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.7413963540483e-7, event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(9)),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.49999997835788, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.4346314830038e-4,  event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(7)),  MAX_CALCULATED_PERCENT_ERROR);

		
		
		event.setA(.3);
		event.setB1(2);
		event.setB2(1.2);
		
		AssertMore.assertEquals(1.7012058568079e-23, 	event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(9)),  					MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.4385450841903,      	event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(.5)), 					MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.3323350970449, 		event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), 	MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8.1943550490753e-12,  	event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(7)),  	MAX_CALCULATED_PERCENT_ERROR);


		event.setA(1);
		event.setB1(21);
		event.setB2(.999);
		AssertMore.assertEquals(13209725352.455, event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(3.6)),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.050343,         event.getTimeEvolutionFluxWithoutCWithoutGCR(Time.inDays(100.2)), MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals( 3.649483097353e16, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( .017479624785935,  event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(1)),  MAX_CALCULATED_PERCENT_ERROR);


		
		event = new SolarParticleEvent("SPE"); // this one does decrease to background fast enough.
		event.setA(1);
		event.setB1(2);
		event.setB2(2);
		AssertMore.assertEquals(.44311346269104, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.5400423403186e-11,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertTrue(event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		
		event = new SolarParticleEvent("SPE"); // this one dosn't decrease to background fast enough.
		event.setA(10);
		event.setB1(2);
		event.setB2(2);
		AssertMore.assertEquals(.35940307438545, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.22333558144185,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertFalse(event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

		event = new SolarParticleEvent("SPE"); // this one dosn't decrease to background fast enough.
		event.setA(2);
		event.setB1(2);
		event.setB2(2);
		AssertMore.assertEquals(.88104013827695, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.0047969805702995,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertTrue(event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		
		event = new SolarParticleEvent("SPE"); // this one dosn't decrease to background fast enough.
		event.setA(3);
		event.setB1(2);
		event.setB2(2);
		AssertMore.assertEquals(1.1494098027217, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.11876536675582,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertFalse(event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		
		
		
		event.setEnergySpectrumIntegralFluence(1E10);
		event.setGamma(2);
		event.setE0(100);
		event.setEmin(10);

		event.setA(3);
		event.setB1(4);
		event.setB2(2);
				
		AssertMore.assertEquals(1.29233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.390142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.29233*.01>0.390142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2(1);
		AssertMore.assertEquals(1.98311,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.8079,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.98311*.01>1.8079,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA(.5);
		AssertMore.assertEquals(11.649,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.259828,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(11.649*.01>0.259828,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	
		event.setA(.25);
		AssertMore.assertEquals(5.9999,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000979444,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.9999*.01>0.0000979444,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB1(10);
		AssertMore.assertEquals(897392.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8824.08,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(897392.*.01>8824.08,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1(11);
		AssertMore.assertEquals(9.76578E6,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(188235.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.76578E6*.01>188235.,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2(.9);
		AssertMore.assertEquals(2.12754E8,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.67902E7,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.12754E8*.01>5.67902E7,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1(.5);
		event.setB2(.5);
		AssertMore.assertEquals(0.823263,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0433142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.823263*.01>0.0433142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1(1);
		AssertMore.assertEquals(1.95894,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.202575,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.95894*.01>0.202575,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA(.5);
		event.setB1(1);
		event.setB2(1);
		
		AssertMore.assertEquals(0.49975,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000209762,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.49975*.01>0.000209762,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA(2);

		AssertMore.assertEquals(1.42541,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.176298,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.42541*.01>0.176298,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA(1.7);

		AssertMore.assertEquals(1.34622,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.128003,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.34622*.01>0.128003,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA(1.8);

		AssertMore.assertEquals(1.3772,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.144543,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3772*.01>0.144543,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA(1.75);

		AssertMore.assertEquals(1.36233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.136313,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36233*.01>0.136313,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	
		event.setA(1.78);

		AssertMore.assertEquals(1.3714,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.141262,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3714*.01>0.141262,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	
	}	

	public void testIsEventLargeEnough() {
		SolarParticleEvent event = new SolarParticleEvent();
		event.setGamma(0.222);
		event.setE0(333.0);
		
		
		event.setEmin(10);
		
		event.setEnergySpectrumIntegralFluence(1E6);
		event.setGamma(1);
		event.setE0(10);
		event.setA(2);
		event.setB1(2);
		event.setB2(2);
		AssertMore.assertEquals(1.0392773271962623,event.getC(),MAX_CALCULATED_PERCENT_ERROR);
		//maximum at t=2
		
		/*
		 * Mathematica code to te
		 * totalfluence = 1*10^6
		 * gamma = 1
		 * E0 = 10
		 * Emin = 10
		 * A = 2
		 * B1 = 2
		 * B2 = 2
		 * Cee = CalculateC[CalculateK[totalfluence, gamma, E0, Emin], gamma, E0, A, B1, B2]
		 * FindMaximum[Flux[Cee, A, B1, B2, t], {t, .01}]
		 *
		 * Prints out: {0.382329, {t -> 2.}}, which is larger then .1, so it is good enough.
		 */
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		

		event.setEnergySpectrumIntegralFluence(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
	
		event.setB1(3);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence(3.1E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setGamma(4);
		event.setB2(6);
		event.setEnergySpectrumIntegralFluence(1.25E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		event.setEnergySpectrumIntegralFluence(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence(0);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
	}
	
	public void testGetC() {
		SolarParticleEvent event = new SolarParticleEvent("SPE");
		double C;
		
		event.setA(3);
		event.setB1(2);
		event.setB2(2);
		AssertMore.assertEquals(1.3292624332267, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);

		try {
			event.getC();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		event.setK(1.0e10);
		event.setGamma(0.222);
		event.setE0(333.0);
		
		AssertMore.assertEquals(1015263290938.5,event.getEnergySpectrumIntegralFluence(10.0),.01);
		 C=1015263290938.5/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC(),.01);
		AssertMore.assertTrue( event.isEventLargeEnough());
		
		event.setK(1);
		AssertMore.assertEquals(101.52632909385,event.getEnergySpectrumIntegralFluence(10.0),.01);
		C=101.52632909385/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC(),.01);
		AssertMore.assertFalse( event.isEventLargeEnough());
		

		event = new SolarParticleEvent(1,3.3,10,"SPE");
		event.setA(.6);
		event.setB1(2);
		event.setB2(1);
		AssertMore.assertEquals(1.1999891455365, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.0843356362992e-4,event.getEnergySpectrumIntegralFluence(10.0),.01);
		C=5.0843356362992e-4/(1.1999891455365*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC(),.01);
		
		event.setK(1e10);
		AssertMore.assertEquals(5084335.6362992,event.getEnergySpectrumIntegralFluence(10.0),.01);
		C=5084335.6362992/(1.1999891455365*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC(),.01);
		
	}

	public void testSimulateAstronautOnTheMoon() {
		
		SolarParticleEvent event;
		double K = 1e10;
		event = new SolarParticleEvent(K,3,10,"SPE");
		event.setA(.6);
		event.setB1(2);
		event.setB2(1);
		
		double timeEvolutionIntegralFlux = 1.1999891455365;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		double energySpectrumIntegralFlux = 10969196.719763;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0),.01);
		
		// the doses
		double totalDoseSuit = 1.5713174E-14*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.BFO,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		double totalDoseRover = 3.5777372E-16*K/2;
		AssertMore.assertEquals(totalDoseRover,   event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.BFO,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		double totalDoseBase = 1.4173827E-16*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.BFO,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		Time time1=Time.inHours(-1);
		Time time2=Time.inHours(1);
		Time time3=Time.inHours(1); 
		DoseInformation results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.BFO,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.FIVE,Thickness.THIRTY, new CumulativeDoseGraph());
		
		Time remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		double dosePriorToWarning = 6.3586136305558e-5 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		double doseWhilePackingUp = 4.194190460278e-4 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		double doseDuringTransit = .0010651172181945 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		double doseAtBase=1.1984410231359 * (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		double totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);


		
		
		
		
		
		/* AGAIN */
		K = 5e9;
		event = new SolarParticleEvent(K,1,80,"SPE");
		event.setA(.5);
		event.setB1(1);
		event.setB2(1);
		
		timeEvolutionIntegralFlux = .49999997835788;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 8117128202.9725;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		// the doses
		totalDoseSuit =0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseRover = 0.00000012680532*K/2;
		AssertMore.assertEquals(totalDoseRover,   event.getDose(Thickness.ONE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.000000034415528*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(1);
		time2=Time.inHours(5);
		time3=Time.inHours(5); 
		results = event.simulateAstronautOnTheMoon(RadiationType.RAD,BodyPart.SKIN,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.ONE,Thickness.FIVE,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = 0 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp =  .022312459617474* (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .064366806734138 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .41332071200624* (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		

		
		
		
		/* AGAIN */
		K = 5e9;
		event = new SolarParticleEvent(K,1,80,"SPE");
		event.setA(.5);
		event.setB1(1);
		event.setB2(1);
		
		timeEvolutionIntegralFlux = .49999997835788;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 8117128202.9725;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		// the doses
		totalDoseSuit =0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseRover = 0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.00000026306802*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(-5);
		time2=Time.inHours(5);
		time3=Time.inHours(5); 
		results = event.simulateAstronautOnTheMoon(RadiationType.RAD,BodyPart.SKIN,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.POINT_THREE,Thickness.POINT_THREE,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = .033037886941352 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp =  .068580421927162 * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .076063794663774 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .32231787482556* (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals( totalDoseSuit, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		

		
		
		
		/* AGAIN */
		K = 7e9;
		event = new SolarParticleEvent(K,.5,40,"SPE");
		event.setA(.8);
		event.setB1(5);
		event.setB2(2);
		
		timeEvolutionIntegralFlux = .8;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 37626315626.873 ;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		
		double totalDoseBefore =0.00000081004993*K/2;
		AssertMore.assertEquals(totalDoseBefore,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseSuit =0.00000049260291*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.ONE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		
		totalDoseRover = 0.000000121331*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.0000000038056167*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(2);
		time2=Time.inHours(24);
		time3=Time.inHours(10); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = 0 * (totalDoseBefore)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp = .11670110228596  * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .30348477319373 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .37981412452039 * (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		
		
		
		
		
		/* AGAIN */
		K = 1;
		event = new SolarParticleEvent(K,.5,40,"SPE");
		event.setA(.8);
		event.setB1(5);
		event.setB2(2);
		
		timeEvolutionIntegralFlux = .8;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 5.3751879466961 ;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		
		totalDoseBefore =0.00000081004993*K/2;
		AssertMore.assertEquals(totalDoseBefore,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseSuit =0.00000049260291*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.ONE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		
		totalDoseRover = 0.000000121331*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.0000000038056167*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(2);
		time2=Time.inHours(24);
		time3=Time.inHours(10); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		
		remaningTime=Time.inDays(10);
		remaningTime.subtract(Time.negative(time1)); // add b/c t1 is opposite.
		remaningTime.subtract(time2);
		remaningTime.subtract(time3);
		
		// the specific integrals from times to other times, etc
		dosePriorToWarning = 0 * (totalDoseBefore)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(dosePriorToWarning, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		doseWhilePackingUp = .11670110228596  * (totalDoseSuit)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseWhilePackingUp, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		
		doseDuringTransit = .30348477319373 * (totalDoseRover)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseDuringTransit, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		doseAtBase= .37981412452039 * (totalDoseBase)/timeEvolutionIntegralFlux;
		AssertMore.assertEquals(doseAtBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter=dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals( totalDoseAwayFromShelter, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 100*dosePriorToWarning/totalDoseAwayFromShelter, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseWhilePackingUp/totalDoseAwayFromShelter, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseDuringTransit/totalDoseAwayFromShelter, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100*doseAtBase/totalDoseAwayFromShelter, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(remaningTime.getHours() , results.timeExposedInBase.getHours(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		
		
		

		
		/* AGAIN */
		K = 1;
		event = new SolarParticleEvent(K,.5,40,"SPE");
		event.setA(.8);
		event.setB1(5);
		event.setB2(2);
		
		timeEvolutionIntegralFlux = .8;
		AssertMore.assertEquals(timeEvolutionIntegralFlux, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		
		energySpectrumIntegralFlux = 5.3751879466961 ;
		AssertMore.assertEquals(energySpectrumIntegralFlux,event.getEnergySpectrumIntegralFluence(10.0), .01);
		
		
		totalDoseBefore =0.00000081004993*K/2;
		AssertMore.assertEquals(totalDoseBefore,   event.getDose(Thickness.POINT_THREE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseSuit =0.00000049260291*K/2;
		AssertMore.assertEquals(totalDoseSuit,   event.getDose(Thickness.ONE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		
		totalDoseRover = 0.000000121331*K/2;
		AssertMore.assertEquals(totalDoseRover,  event.getDose(Thickness.FIVE,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE ), MAX_CALCULATED_PERCENT_ERROR);
		totalDoseBase = 0.0000000038056167*K/2;
		AssertMore.assertEquals(totalDoseBase,   event.getDose(Thickness.THIRTY,RadiationType.REM,BodyPart.EYE,DoseLocation.LUNAR_SURFACE), MAX_CALCULATED_PERCENT_ERROR);
		
		// The times
		time1=Time.inHours(7);
		time2=Time.inHours(24);
		time3=Time.inHours(10); 
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.POINT_THREE,time3,Thickness.POINT_THREE,Thickness.POINT_THREE,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBefore, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.ONE,time2,Thickness.ONE,time3,Thickness.ONE,Thickness.ONE,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseSuit, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.FIVE,time2,Thickness.FIVE,time3,Thickness.FIVE,Thickness.FIVE,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseRover, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.THIRTY,time2,Thickness.THIRTY,time3,Thickness.THIRTY,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBase, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 1, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);


		
		/* AGAIN */
		
		time1=Time.inDays(0);
		time2=Time.inDays(10);
		time3=Time.inDays(0); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseSuit, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseSuit/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		

		time1=Time.inDays(-10);
		time2=Time.inDays(0);
		time3=Time.inDays(0); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBefore, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBefore/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
	
		
		time1=Time.inDays(0);
		time2=Time.inDays(0);
		time3=Time.inDays(10); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseRover, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseRover/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseRover, results.doseDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		time1=Time.inDays(0);
		time2=Time.inDays(0);
		time3=Time.inDays(0); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( totalDoseBase, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBase/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		

		time1=Time.inDays(10);
		time2=Time.inDays(5);
		time3=Time.inDays(5); 
		results = event.simulateAstronautOnTheMoon(RadiationType.REM,BodyPart.EYE,time1,Thickness.POINT_THREE,time2,Thickness.ONE,time3,Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalPriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( totalDoseBase, results.totalDoseAwayFromShelter, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( totalDoseBase/totalDoseBase, results.ratioHigherThenAlwaysAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( totalDoseBase, results.doseAtBase, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 100, results.percentOfTotalAtBase, MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 0, results.dosePriorToWarning, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.doseWhilePackingUp, MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0, results.percentOfTotalDuringTransit, MAX_CALCULATED_PERCENT_ERROR);
		
		
	}

}
