package SStoRM;
import java.text.*;

/**
 * This object provides convenient methods for converting between
 * types.
 * @author Joshua Lande
 */
public class Convert {
	
	public static String toStringScientificNotation(double number) {
		// get a decimal format object, return the number
		if (Double.isNaN(number)) throw new IllegalArgumentException("A number must be passed as a parameter");
		return (new DecimalFormat("0.00E0")).format(number);
	}

	public static String toStringTwoDecimal(double number) {
		if (Double.isNaN(number)) throw new IllegalArgumentException("A number must be passed as a parameter");
		return (new DecimalFormat("0.00")).format(number);
	}
	
	
	/**
	 * This method provides better throw messages but the same functionality to
	 * {@link Double#parseDouble(java.lang.String)}. This might seem a little bit anal, 
	 * but I didn't like the way
	 * that {@link Double#parseDouble(java.lang.String)} handled the messages
	 * of the errors it throw. 
	 * <p>
	 * {@link Double#parseDouble(java.lang.String)} would throw: 'For input string: "1a"'
	 * <p> 
	 * When I wanted it to throw: 'Gamma is currently set to "1a". This is not a valid number.'
	 * <p>
	 * {@link Double#parseDouble(java.lang.String)} will throw: 'empty String'
	 * <p>
	 * When I wanted it to throw: 'Please specify a value for Gamma.'
	 * <p>
	 * This might seem petty, but I wanted it to print the throw message to the user in an intuitive format. 
	 * I also wanted it to 'know' what is the number we are converting. It needed to know 
	 * if we are finding Gamma, E0, or whatever else. So 2 strings should be passed, 
	 * to this method. One for the number to find and the
	 * second one for the name of the quantity we are converting.
	 * <p>
	 * And finally, It can identify between  "the" or "The".
	 * <p>It say: '<b>The</b> integral flux is currently set to "1a". This is not a valid number.'
	 * <p>But also: 'Please specify a value for <b>the</b> integral flux.'
	 * @param text The string containing the number to parse.
	 * @param name Then name of the value we are getting (useful for user output).
	 * @return The string text parsed as a double.
	 * @throws IllegalArgumentException If the string is not a proper number.
	 */
	public static double parseDouble(String text, String name) throws IllegalArgumentException {
		double parse=0;
		
		try {
			 parse = Double.parseDouble(text);
		} catch(NumberFormatException exception) {
			if (exception.getMessage().toLowerCase().matches(".*empty.*")) {
				if(name.trim().length()>3 && name.trim().substring(0,4).matches("The ")) 
					name = "the "+name.trim().substring(4);
				throw new NumberFormatException("Please specify a value for "+name+".");
			
			} else if (exception.getMessage().toLowerCase().matches(".*for input string.*")) {
				if(name.trim().length()>3 && name.trim().substring(0,4).matches("the ")) 
					name = "The "+name.trim().substring(4);
				throw new NumberFormatException(name+" is currently set to \""+text+"\". This is not a valid number.");
			
			} else throw exception;
		}
		
		return parse;
		
		
	}
	
	
}
