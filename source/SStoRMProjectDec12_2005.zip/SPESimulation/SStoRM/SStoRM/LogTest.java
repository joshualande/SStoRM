package SStoRM;

import junit.framework.TestCase;

public class LogTest extends TestCase {
	
	private static final double MAX_PERCENT_ERROR = .0000000000001; // a really small percent error
	
	public void testBase10() {
	
		
		AssertMore.assertEquals(3, 				Log.base10(1000), 	 MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.301029995664, Log.base10(20),		 MAX_PERCENT_ERROR); 
		AssertMore.assertEquals(4, 				Log.base10(10000),	 MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0,				Log.base10(1),		 MAX_PERCENT_ERROR );
		AssertMore.assertEquals(1.698970004336, Log.base10(50), 	 MAX_PERCENT_ERROR);

		try { 
			Log.base10(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Log.base10(-20);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testRoundDownOrderOfMagnitude() {
		AssertMore.assertEquals(100.0,          Log.roundDownOrderOfMagnitude(555),            MAX_PERCENT_ERROR);
		AssertMore.assertNotEquals(1000.0,      Log.roundDownOrderOfMagnitude(555),            MAX_PERCENT_ERROR );
		
		AssertMore.assertEquals(10,             Log.roundDownOrderOfMagnitude(99.99),          MAX_PERCENT_ERROR);
		
		AssertMore.assertEquals(.001,           Log.roundDownOrderOfMagnitude(.0011),          MAX_PERCENT_ERROR);
		AssertMore.assertEquals(100000000.0,    Log.roundDownOrderOfMagnitude(100000000.0001), MAX_PERCENT_ERROR);
	
		AssertMore.assertEquals(1, Log.roundDownOrderOfMagnitude(9.9),MAX_PERCENT_ERROR);

		AssertMore.assertEquals(0,             Log.roundDownOrderOfMagnitude(0),       	   	   MAX_PERCENT_ERROR);
		AssertMore.assertEquals(-10,           Log.roundDownOrderOfMagnitude(-1.2),    	   	   MAX_PERCENT_ERROR);
		AssertMore.assertEquals(-100,          Log.roundDownOrderOfMagnitude(-11),   	   	   MAX_PERCENT_ERROR);
		AssertMore.assertEquals(-1000,          Log.roundDownOrderOfMagnitude(-111),   	   	   MAX_PERCENT_ERROR);

		try { 
			Log.roundDownOrderOfMagnitude(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Log.roundDownOrderOfMagnitude(Double.NEGATIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Log.roundDownOrderOfMagnitude(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	
	}

	public void testRoundUpOrderOfMagnitude() {
		AssertMore.assertEquals(1000,           Log.roundUpOrderOfMagnitude(555),               MAX_PERCENT_ERROR);
		AssertMore.assertEquals(100,            Log.roundUpOrderOfMagnitude(99.99),             MAX_PERCENT_ERROR);
		
		AssertMore.assertEquals(.01,            Log.roundUpOrderOfMagnitude(.0011),             MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1000000000.0,   Log.roundUpOrderOfMagnitude(100000000.0001),    MAX_PERCENT_ERROR);
	

		AssertMore.assertEquals(0,             Log.roundDownOrderOfMagnitude(0),       	   	   MAX_PERCENT_ERROR);
		AssertMore.assertEquals(-1,           Log.roundDownOrderOfMagnitude(-1.2),    	   	   MAX_PERCENT_ERROR);
		AssertMore.assertEquals(-10,          Log.roundDownOrderOfMagnitude(-11),   	   	   MAX_PERCENT_ERROR);
		AssertMore.assertEquals(-100,          Log.roundDownOrderOfMagnitude(-111),   	   	   MAX_PERCENT_ERROR);

		try { 
			Log.roundDownOrderOfMagnitude(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Log.roundDownOrderOfMagnitude(Double.NEGATIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try { 
			Log.roundDownOrderOfMagnitude(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	
	
	}

}
