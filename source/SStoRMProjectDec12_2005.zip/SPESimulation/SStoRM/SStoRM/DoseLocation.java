package SStoRM;

public enum DoseLocation {
	FREE_SPACE,
	LUNAR_SURFACE;
	
	public String toString() {
		switch(this) {
		case FREE_SPACE:
			return "Free Space";
		case LUNAR_SURFACE:
			return "Lunar Surface";
		}
		return "";
	}
	
	public String whereItIs() {
		switch(this) {
		case FREE_SPACE:
			return "in Free Space";
		case LUNAR_SURFACE:
			return "on the Lunar Surface";
		}
		return "";
	}
}
