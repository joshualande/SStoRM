package SStoRM;

/**
 * This object has functions for interpolation between points.
 * @author Joshua Lande
 */
import SStoRM.Point;

public class Interpolation {
	
	/**
	 * This function takes 2 three dimensional points. It assumes that the y-coordinates are the same.
	 * It then does a linear interpolation to a new point on the XZ plane. The x-value is specified
	 * and a new Point who's x-value is the input, y-value is the same as that of the two points and who's
	 * Z value is interpolated between them.
	 * <p>
	 * The formula used for the interpolation is:
	 * <pre>
	 * alpha =  (x - x0)/(x1 - x0);
	 * z = z0 + alpha*(z1-z0);
	 * </pre>This algorithm was taken from http://en.wikipedia.org/wiki/Linear_interpolation with slight change
	 * because we are interpolating a new value on the z-axis, not the y-axis.
	 * @param xValue Value of point on x-axis to interpolate to.
	 * @param P0 1st point
	 * @param P1 2nd point
	 * @return The interpolated point.
	 */
	public static Point linearXValueKnown(double xValue, Point P0, Point P1) {	
		// all numbers must be defined
		if (P0 == null || P1 == null) return null;		
		if (Double.isNaN(P0.x) || Double.isNaN(P0.y) || Double.isNaN(P0.z) || 
			Double.isNaN(P1.x) || Double.isNaN(P1.y) || Double.isNaN(P1.z)) 
			throw new IllegalArgumentException("Parameters must be numbers");
		if (P0.x == P1.x) {
			/* If the 2 x-values are the same, we can't interpolate. 
			 * If the 2 points are the same and their x-value is the same
			 * as xValue, return a clone. Otherwise, return null.
			 */
			if (xValue == P1.x && P0.equals(P1)) return (Point)P0.clone(); 
			
			throw new IllegalArgumentException("Interpolation not possible");
		}
		
		if (P0.y != P1.y)// y-values must be the same
			throw new IllegalArgumentException("The two points must have the same Y coordinate in order to interpolate the X coordinate"); 
		
		double alpha=(xValue-P0.x)/(P1.x-P0.x); // find alpha 
		return new Point(xValue,P0.y,P0.z+alpha*(P1.z-P0.z)); // do the linear interpolation 
	}
	
	
	/**
	 * This is very similar to {@link #linearYValueKnown} but interpolates along the YZ axis.
	 * <p>
	 * The formula we use is slightly different.
	 * <pre>
	 * alpha =  (y - y0)/(y1 - y0);
	 * z = z0 + alpha*(z1-z0);
	 * @param yValue
	 * @param P0
	 * @param P1
	 * @return The interpolated point.
	 */
	public static Point linearYValueKnown(double yValue, Point P0, Point P1) {
		// all numbers must be defined
		if (P0 == null || P1 == null) return null;		
		if (Double.isNaN(P0.x) || Double.isNaN(P0.y) || Double.isNaN(P0.z) || 
			Double.isNaN(P1.x) || Double.isNaN(P1.y) || Double.isNaN(P1.z)) 
			throw new IllegalArgumentException("Parameters must be numbers");
		
		if (P0.y == P1.y) {
			/* If the 2 y-values are the same, we can't interpolate. 
			 * If the 2 points are the same and their y-value is the same
			 * as yValue, return a clone. Otherwise, return null.
			 */
			if (yValue == P1.y && P0.equals(P1)) return (Point)P0.clone(); 
			
			throw new IllegalArgumentException("Interpolation not possible");
		}		
		
		if (P0.x != P1.x)  // x-values must be the same.
			throw new IllegalArgumentException("The two points must have the same X coordinate in order to interpolate the Y coordinate"); 
		
		double alpha=(yValue-P0.y)/(P1.y-P0.y); // find alpha
		return new Point(P0.x,yValue,P0.z+alpha*(P1.z-P0.z)); // do the linear interpolation
	}
	
	/**
	 * Performs a bilinear interpolation to the point (xValue, yValue, someZValueToBeCalculated).
	 * It does so by first interpolating the top and bottom into 2 middle 
	 * points and then interpolating those 2 points into a new middle one.
	 * @param xValue
	 * @param yValue
	 * @param upperLeft
	 * @param upperRight
	 * @param lowerLeft
	 * @param lowerRight
	 * @return The point that is the bilinear interpolation of the 4 passed points.
	 */
	public static Point bilinear(double xValue, double yValue, Point upperLeft, Point upperRight, 
			Point lowerLeft, Point lowerRight) {
		// Interpolate the the lower upper and lower middle
		Point upperMiddle=Interpolation.linearXValueKnown(xValue, upperLeft, upperRight);
		Point lowerMiddle=Interpolation.linearXValueKnown(xValue, lowerLeft, lowerRight);
	
		// now interpolate between the upper middle and lower middle to find the true middle
		return Interpolation.linearYValueKnown(yValue, lowerMiddle, upperMiddle);
	}
	
	

}
