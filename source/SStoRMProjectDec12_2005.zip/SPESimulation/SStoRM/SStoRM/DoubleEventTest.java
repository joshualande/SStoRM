package SStoRM;

import junit.framework.TestCase;

public class DoubleEventTest extends TestCase {

	public static double MAX_EXACT_PERCENT_ERROR=.0000000000000000000001;
	public static double MAX_CALCULATED_PERCENT_ERROR = .00001;
	public static double MAX_WEAKER_CALCULATED_PERCENT_ERROR = .0001;
	public static double MAX_AWEFUL_CALCULATED_PERCENT_ERROR = .015;
	public static double MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR = 0005;
	
	public void testEqualsObject() {
		DoubleEvent doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
	
		AssertMore.assertEquals("test if an object equals itself",doubleEvent,doubleEvent);
		AssertMore.assertEquals(
				new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE"),
				new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE"));
		
		AssertMore.assertEquals( // names are different
				new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE"),
				new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"OTHER SPE"));
		
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1.1,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0.1,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10.1,2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2.1,3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3.1,40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40.1,50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1.1,2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2.1,3,  4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3.1,4,  5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4.1,5,  6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5.1,6,  Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6.1,Time.inDays(1  ),"SPE"));
		AssertMore.assertNotEquals(
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1  ),"SPE"),
				new DoubleEvent(1  ,0  ,10,  2,  3,  40,  50,  1,  2,  3,  4,  5,  6,  Time.inDays(1.1),"SPE"));
	}

	public void testClone() {

		DoubleEvent doubleEvent1 = new DoubleEvent(1,2,10,2,4,400,50,6,5,4,3,2,1,Time.inDays(5),"An SPE");
		DoubleEvent doubleEvent2 = (DoubleEvent)doubleEvent1.clone();
		
		AssertMore.assertEquals(doubleEvent1,doubleEvent2);

		doubleEvent1.setA_1(2);
		AssertMore.assertNotEquals(doubleEvent1,doubleEvent2);
		doubleEvent2.setA_1(2);
		AssertMore.assertEquals(doubleEvent1,doubleEvent2);
		
		doubleEvent1.setGamma_2(2.5);
		AssertMore.assertNotEquals(doubleEvent1,doubleEvent2);
		doubleEvent2.setGamma_2(2.5);
		AssertMore.assertEquals(doubleEvent1,doubleEvent2);

		doubleEvent2.setE0_1(30);
		AssertMore.assertNotEquals(doubleEvent1,doubleEvent2);
		
		doubleEvent1 = (DoubleEvent)doubleEvent2.clone();
		AssertMore.assertEquals(doubleEvent1,doubleEvent2);


		doubleEvent1 = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		doubleEvent2 = (DoubleEvent)doubleEvent1.clone();
		AssertMore.assertEquals(doubleEvent1,doubleEvent2);
		doubleEvent2.setA_1(10.5);
		AssertMore.assertNotEquals(doubleEvent1,doubleEvent2);
		
		
	}

	public void testCompareTo() {
		
		
	}

	public void testDoubleEvent() {
		DoubleEvent doubleEvent;
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getA_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB1_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB2_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getC_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getA_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB1_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB2_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getC_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getE0_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getE0_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEnergySpectrumFluence(100);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEnergySpectrumIntegralFluence();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEnergySpectrumIntegralFluence(100);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getGamma_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getGamma_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getK_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getK_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getTimeEvolutionFluxWithCWithGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getTimeEvolutionFluxWithCWithoutGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		

		doubleEvent = new DoubleEvent("SPE name");
		AssertMore.assertEquals("SPE name",doubleEvent.getName());
		try {
			doubleEvent.getA_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB1_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB2_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getC_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getA_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB1_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getB2_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getC_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getE0_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getE0_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEnergySpectrumFluence(100);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEnergySpectrumIntegralFluence();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getEnergySpectrumIntegralFluence(100);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getGamma_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getGamma_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getK_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getK_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};

		try {
			doubleEvent.getTimeEvolutionFluxWithCWithGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		try {
			doubleEvent.getTimeEvolutionFluxWithCWithoutGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception E) {};
		
		doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals(1,doubleEvent.getK_1());
		AssertMore.assertEquals(0,doubleEvent.getGamma_1());
		AssertMore.assertEquals(10,doubleEvent.getE0_1());
		AssertMore.assertEquals(2,doubleEvent.getK_2());
		AssertMore.assertEquals(3,doubleEvent.getGamma_2());
		AssertMore.assertEquals(40,doubleEvent.getE0_2());
		AssertMore.assertEquals(50,doubleEvent.getEmin());
		
		AssertMore.assertEquals(1,doubleEvent.getA_1());
		AssertMore.assertEquals(2,doubleEvent.getB1_1());
		AssertMore.assertEquals(3,doubleEvent.getB2_1());
		AssertMore.assertEquals(4,doubleEvent.getA_2());
		AssertMore.assertEquals(5,doubleEvent.getB1_2());
		AssertMore.assertEquals(6,doubleEvent.getB2_2());
		
		AssertMore.assertEquals(Time.inDays(1),doubleEvent.getTimeDelayBetweenEvents());
		AssertMore.assertEquals("SPE",doubleEvent.getName());
	}

	public void testSetDoubleEvent() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setDoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals(1,doubleEvent.getK_1());
		AssertMore.assertEquals(0,doubleEvent.getGamma_1());
		AssertMore.assertEquals(10,doubleEvent.getE0_1());
		AssertMore.assertEquals(2,doubleEvent.getK_2());
		AssertMore.assertEquals(3,doubleEvent.getGamma_2());
		AssertMore.assertEquals(40,doubleEvent.getE0_2());
		AssertMore.assertEquals(50,doubleEvent.getEmin());
		AssertMore.assertEquals(1,doubleEvent.getA_1());
		AssertMore.assertEquals(2,doubleEvent.getB1_1());
		AssertMore.assertEquals(3,doubleEvent.getB2_1());
		AssertMore.assertEquals(4,doubleEvent.getA_2());
		AssertMore.assertEquals(5,doubleEvent.getB1_2());
		AssertMore.assertEquals(6,doubleEvent.getB2_2());
		AssertMore.assertEquals(Time.inDays(1),doubleEvent.getTimeDelayBetweenEvents());
		AssertMore.assertEquals("SPE",doubleEvent.getName());
		
		doubleEvent = new DoubleEvent();
		doubleEvent.setDoubleEvent(1e9,1.1,55,2e3,3.3,400,500,6,5,4,3,2,1,Time.inDays(0),"S  PE");
		AssertMore.assertEquals(1e9,doubleEvent.getK_1());
		AssertMore.assertEquals(1.1,doubleEvent.getGamma_1());
		AssertMore.assertEquals(55,doubleEvent.getE0_1());
		AssertMore.assertEquals(2e3,doubleEvent.getK_2());
		AssertMore.assertEquals(3.3,doubleEvent.getGamma_2());
		AssertMore.assertEquals(400,doubleEvent.getE0_2());
		AssertMore.assertEquals(500,doubleEvent.getEmin());
		AssertMore.assertEquals(6,doubleEvent.getA_1());
		AssertMore.assertEquals(5,doubleEvent.getB1_1());
		AssertMore.assertEquals(4,doubleEvent.getB2_1());
		AssertMore.assertEquals(3,doubleEvent.getA_2());
		AssertMore.assertEquals(2,doubleEvent.getB1_2());
		AssertMore.assertEquals(1,doubleEvent.getB2_2());
		AssertMore.assertEquals(Time.inDays(0),doubleEvent.getTimeDelayBetweenEvents());
		AssertMore.assertEquals("S  PE",doubleEvent.getName());		
	}

	public void testGetSetEmin() {

		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(10,doubleEvent.getEmin(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setEmin(20);
		AssertMore.assertEquals(20,doubleEvent.getEmin(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setEmin(1500);
		AssertMore.assertEquals(1500,doubleEvent.getEmin(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setEmin(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try {
			doubleEvent.setEmin(9.999);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setEmin(1500.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		// Emin hasn't changed
		AssertMore.assertEquals(1500,doubleEvent.getEmin(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setEmin(100);
		AssertMore.assertEquals(100,doubleEvent.getEmin(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(4,doubleEvent.getEmin(),MAX_EXACT_PERCENT_ERROR);

		doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals(50,doubleEvent.getEmin(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
	}

	public void testGetSetE0_1() {
		DoubleEvent doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals(10, doubleEvent.getE0_1(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent.setE0_1(100);
		AssertMore.assertEquals(100, doubleEvent.getE0_1(),MAX_EXACT_PERCENT_ERROR);

		doubleEvent.setE0_1(10);
		AssertMore.assertEquals(10, doubleEvent.getE0_1(),MAX_EXACT_PERCENT_ERROR);

		doubleEvent.setE0_1(500);
		AssertMore.assertEquals(500, doubleEvent.getE0_1(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getE0_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setE0_1(33);
		AssertMore.assertEquals(33, doubleEvent.getE0_1(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setE0_1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setE0_1(9.999);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try {
			doubleEvent.setE0_1(500.0001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(33, doubleEvent.getE0_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(4,doubleEvent.getE0_1(),MAX_EXACT_PERCENT_ERROR);		
	}

	public void testGetSetE0_2() {
		DoubleEvent doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals(40, doubleEvent.getE0_2(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setE0_2(100);
		AssertMore.assertEquals(100, doubleEvent.getE0_2(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setE0_2(10);
		AssertMore.assertEquals(10, doubleEvent.getE0_2(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setE0_2(500);
		AssertMore.assertEquals(500, doubleEvent.getE0_2(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getE0_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		doubleEvent.setE0_2(33);
		AssertMore.assertEquals(33, doubleEvent.getE0_2(),MAX_EXACT_PERCENT_ERROR);
		try {
			doubleEvent.setE0_2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setE0_2(9.999);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setE0_2(500.0001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(33, doubleEvent.getE0_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(4,doubleEvent.getE0_2(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetGamma_1() {		
		DoubleEvent doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals(0, doubleEvent.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setGamma_1(0);
		AssertMore.assertEquals(0, doubleEvent.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setGamma_1(4.125);
		AssertMore.assertEquals(4.125, doubleEvent.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent.setGamma_1(3);
		AssertMore.assertEquals(3, doubleEvent.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getGamma_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setGamma_1(2.2);
		AssertMore.assertEquals(2.2, doubleEvent.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setGamma_1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setGamma_1(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try {
			doubleEvent.setGamma_1(4.12500001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(2.2, doubleEvent.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(4,doubleEvent.getGamma_1(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetGamma_2() {
		DoubleEvent doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals(3, doubleEvent.getGamma_2(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setGamma_2(0);
		AssertMore.assertEquals(0, doubleEvent.getGamma_2(),MAX_EXACT_PERCENT_ERROR);
		doubleEvent.setGamma_2(4.125);
		AssertMore.assertEquals(4.125, doubleEvent.getGamma_2(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent.setGamma_2(2.2);
		AssertMore.assertEquals(2.2, doubleEvent.getGamma_2(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getGamma_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setGamma_2(4.125);
		AssertMore.assertEquals(4.125, doubleEvent.getGamma_2(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setGamma_2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setGamma_2(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		try {
			doubleEvent.setGamma_2(4.12500001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(4.125, doubleEvent.getGamma_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(4,doubleEvent.getGamma_2(),MAX_EXACT_PERCENT_ERROR);
	
	}
	

	public void testGetSetName() {
		DoubleEvent doubleEvent=new DoubleEvent();
		AssertMore.assertEquals("",doubleEvent.getName());
		doubleEvent.setName("BOB");
		AssertMore.assertEquals("BOB",doubleEvent.getName());
		
		doubleEvent = new DoubleEvent(1,0,10,2,3,40,50,1,2,3,4,5,6,Time.inDays(1),"SPE");
		AssertMore.assertEquals("SPE",doubleEvent.getName());
		
		doubleEvent = new DoubleEvent("Name");
		AssertMore.assertEquals("Name",doubleEvent.getName());
		
		try {
			doubleEvent.setName(null);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		
		doubleEvent.setName("");
		AssertMore.assertEquals("",doubleEvent.getName());
		doubleEvent.setName("Ken");
		AssertMore.assertEquals("Ken",doubleEvent.getName());
	}

	public void testGetSetK_1andEnergySpectrumIntegralFluence_1() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setK_1(0);
		AssertMore.assertEquals(0,doubleEvent.getK_1());
		doubleEvent.setK_1(1);
		AssertMore.assertEquals(1,doubleEvent.getK_1());
		doubleEvent.setK_1(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getK_1());
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getK_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setK_1(4.125);
		AssertMore.assertEquals(4.125, doubleEvent.getK_1(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setK_1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setK_1(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		AssertMore.assertEquals(4.125, doubleEvent.getK_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(4,doubleEvent.getK_1(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent.setK_1(100.0);
		doubleEvent.setGamma_1(2.0);
		doubleEvent.setE0_1(10.0);
		try {
			doubleEvent.getEnergySpectrumIntegralFluence_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setEmin(10);
		AssertMore.assertEquals(1.4849550701716,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
	
	
		doubleEvent.setEnergySpectrumIntegralFluence_1(1.4849550701716);
		AssertMore.assertEquals(100,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
	

		doubleEvent.setK_1(1000000.0);
		AssertMore.assertEquals(14849.550701716,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEmin(50);
		doubleEvent.setGamma_1(4);

		AssertMore.assertEquals(0.0062638467614913,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);

		doubleEvent.setEnergySpectrumIntegralFluence_1(0.0062638467614913);
		AssertMore.assertEquals(1000000.0,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 36.787944117144 , doubleEvent.getEnergySpectrumFluence_1(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0.0010780715198537 , doubleEvent.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 3.0859997567422e-27 , doubleEvent.getEnergySpectrumFluence_1(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 3.7200759760209e-50, doubleEvent.getEnergySpectrumFluence_1(1000),MAX_CALCULATED_PERCENT_ERROR);
		
		
		doubleEvent.setGamma_1(2.66);
		doubleEvent.setE0_1(333);
		doubleEvent.setEmin(45);
		doubleEvent.setEnergySpectrumIntegralFluence_1(10);
		AssertMore.assertEquals(10 , doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(12132.641391552, doubleEvent.getK_1(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEmin(80);
		AssertMore.assertEquals(37991.900592191, doubleEvent.getK_1(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(37991.900592191);
		AssertMore.assertEquals(10 , doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
			
		// code taken & slightly modified from test of EnergySpectrum
		
		doubleEvent = new DoubleEvent();
		doubleEvent.setK_1(1);
		doubleEvent.setGamma_1(3);
		doubleEvent.setE0_1(50);
		doubleEvent.setEmin(500);
		
		AssertMore.assertEquals(1,doubleEvent.getK_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(2.9430355293715e-6,doubleEvent.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.631994380988e-13,doubleEvent.getEnergySpectrumFluence_1(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.4195050212441e-11,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(1000);
		AssertMore.assertEquals(9.0091168133463e-17,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(666);
		AssertMore.assertEquals(2.2909144215819e-13,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(.0035194531243864,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEnergySpectrumIntegralFluence_1(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(284135052991.89,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(836219.55609498,doubleEvent.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10319769159113,doubleEvent.getEnergySpectrumFluence_1(500),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(284135052991.89);
		AssertMore.assertEquals(1e9,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(284135052991.89,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(836219.55609498,doubleEvent.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10319769159113,doubleEvent.getEnergySpectrumFluence_1(500),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEnergySpectrumIntegralFluence_1(5);
		doubleEvent.setEmin(500);
		AssertMore.assertEquals(352235457090.38,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(1036641.4649214,doubleEvent.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(50);
		doubleEvent.setE0_1(500);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(50,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.24048414540948,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(0.24048414540948,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEmin(50);
		AssertMore.assertEquals(0.008325829170022,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		
		doubleEvent.setEnergySpectrumIntegralFluence_1(30);
		doubleEvent.setGamma_1(2);
		doubleEvent.setE0_1(50);
		doubleEvent.setEmin(60);
		AssertMore.assertEquals(16201.024079494,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(50);
		AssertMore.assertEquals(10101.315724163,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setGamma_1(2.5);
		AssertMore.assertEquals(83854.728083211,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setE0_1(101);
		doubleEvent.setEnergySpectrumIntegralFluence_1(60);
		AssertMore.assertEquals(79389.538225372,doubleEvent.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(79389.538225372);
		AssertMore.assertEquals(79389.538225372,doubleEvent.getK_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(60,doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		// code copied from test of SolarParticleEvent test.
		DoubleEvent event = new DoubleEvent();
		event.setK_1(1e9);
		event.setGamma_1(0);
		event.setE0_1(30);
		try { 
			event.getEnergySpectrumIntegralFluence_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		AssertMore.assertEquals(716531310.57379 , event.getEnergySpectrumFluence_1(10),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setEmin(10);
		AssertMore.assertEquals(2.149593931714e10, 	event.getEnergySpectrumIntegralFluence_1(),			MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30);
		AssertMore.assertEquals(1.1036383235144e10, event.getEnergySpectrumIntegralFluence_1(),			MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(60);
		AssertMore.assertEquals(4.0600584970986e9,  event.getEnergySpectrumIntegralFluence_1(),			MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(10);
		AssertMore.assertEquals(2.149593931714e10, 	event.getEnergySpectrumIntegralFluence_1(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30); // set emin
		AssertMore.assertEquals(1.1036383235144e10, event.getEnergySpectrumIntegralFluence_1(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setK_1(2.2e7); // change k
		AssertMore.assertEquals(242800431.17315, event.getEnergySpectrumIntegralFluence_1(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(10);
		AssertMore.assertEquals(472910664.97871, event.getEnergySpectrumIntegralFluence_1(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(10);// change emin
		event.setGamma_1(3.01); // change gamma
		AssertMore.assertEquals(61025.805350301, event.getEnergySpectrumIntegralFluence_1(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setE0_1(112); // change E0
		AssertMore.assertEquals(90782.963349881, event.getEnergySpectrumIntegralFluence_1(),	MAX_CALCULATED_PERCENT_ERROR);
		// second statment to check caching mechanism.
		AssertMore.assertEquals(90782.963349881, event.getEnergySpectrumIntegralFluence_1(),	MAX_CALCULATED_PERCENT_ERROR);
		// when we set the energy doubleEvent, k should be calculated automatically.
		event.setEnergySpectrumIntegralFluence_1(1.02e10);
		AssertMore.assertEquals(2471829423932.3,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2471829423932.3,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_1(2471829423932.3);
		AssertMore.assertEquals(2471829423932.3,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.02e10,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_1(1111.111);
		event.setEmin(30);
		event.setGamma_1(1.99);
		event.setE0_1(202.2);
		AssertMore.assertEquals(1111.111,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(24.814069093002,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(66);
		AssertMore.assertEquals(7.8710442609193,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(66);
		AssertMore.assertEquals(7.8710442609193,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_1(666);
		AssertMore.assertEquals(666, event.getEnergySpectrumIntegralFluence_1(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(94015.470053217, event.getK_1(), MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30); // change Emin
		AssertMore.assertEquals(666, event.getEnergySpectrumIntegralFluence_1(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(29821.788729068, event.getK_1(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 290.43919751046 , event.getEnergySpectrumFluence_1(10), MAX_CALCULATED_PERCENT_ERROR);
		event = new DoubleEvent();
		event.setK_1(1e9);
		event.setGamma_1(0);
		event.setE0_1(30);
		event.setEnergySpectrumIntegralFluence_1(1000);
		AssertMore.assertEquals(1000,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		try {
			event.getK_1(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		event = new DoubleEvent();
		event.setK_1(1e9);
		event.setGamma_1(0);
		event.setE0_1(30);
		try {
			event.getEnergySpectrumIntegralFluence_1(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event = new DoubleEvent();
		try {
			event.getEnergySpectrumIntegralFluence_1(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getK_1(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getE0_1(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setE0_1(80);
		AssertMore.assertEquals(80,event.getE0_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setGamma_1(1);
		AssertMore.assertEquals(1,event.getGamma_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_1(1);
		try {
			event.getK_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setK_1(10);
		try {
			event.getEnergySpectrumIntegralFluence_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setEmin(22);
		AssertMore.assertEquals(22,event.getEmin(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_1(1);
		AssertMore.assertEquals(1,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0299079093937, event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_1(1.0299079093937);
		AssertMore.assertEquals(1.0299079093937, event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_1(5e9);
		AssertMore.assertEquals(4854802991.9913,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5e9,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_1(999);
		AssertMore.assertEquals(1028.8780014843,event.getK_1(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(999,event.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
	}
	
		
	public void testGetSetK_2andEnergySpectrumIntegralFluence_1() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setK_2(0);
		AssertMore.assertEquals(0,doubleEvent.getK_2());
		doubleEvent.setK_2(1);
		AssertMore.assertEquals(1,doubleEvent.getK_2());
		doubleEvent.setK_2(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getK_2());
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getK_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setK_2(4.125);
		AssertMore.assertEquals(4.125, doubleEvent.getK_2(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setK_2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setK_2(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		AssertMore.assertEquals(4.125, doubleEvent.getK_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(4,doubleEvent.getK_2(),MAX_EXACT_PERCENT_ERROR);
		
		doubleEvent.setK_2(100.0);
		doubleEvent.setGamma_2(2.0);
		doubleEvent.setE0_2(10.0);
		try {
			doubleEvent.getEnergySpectrumIntegralFluence_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setEmin(10);
		AssertMore.assertEquals(1.4849550701716,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
	
	
		doubleEvent.setEnergySpectrumIntegralFluence_2(1.4849550701716);
		AssertMore.assertEquals(100,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
	

		doubleEvent.setK_2(1000000.0);
		AssertMore.assertEquals(14849.550701716,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEmin(50);
		doubleEvent.setGamma_2(4);

		AssertMore.assertEquals(0.0062638467614913,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);

		doubleEvent.setEnergySpectrumIntegralFluence_2(0.0062638467614913);
		AssertMore.assertEquals(1000000.0,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals( 36.787944117144 , doubleEvent.getEnergySpectrumFluence_2(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 0.0010780715198537 , doubleEvent.getEnergySpectrumFluence_2(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 3.0859997567422e-27 , doubleEvent.getEnergySpectrumFluence_2(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 3.7200759760209e-50, doubleEvent.getEnergySpectrumFluence_2(1000),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setGamma_2(2.66);
		doubleEvent.setE0_2(333);
		doubleEvent.setEmin(45);
		doubleEvent.setEnergySpectrumIntegralFluence_2(10);
		AssertMore.assertEquals(10 , doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(12132.641391552, doubleEvent.getK_2(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEmin(80);
		AssertMore.assertEquals(37991.900592191, doubleEvent.getK_2(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(37991.900592191);
		AssertMore.assertEquals(10 , doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		
		// code taken & slightly modified from test of EnergySpectrum
		
		doubleEvent = new DoubleEvent();
		doubleEvent.setK_2(1);
		doubleEvent.setGamma_2(3);
		doubleEvent.setE0_2(50);
		doubleEvent.setEmin(500);
		
		AssertMore.assertEquals(1,doubleEvent.getK_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(2.9430355293715e-6,doubleEvent.getEnergySpectrumFluence_2(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.631994380988e-13,doubleEvent.getEnergySpectrumFluence_2(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.4195050212441e-11,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(1000);
		AssertMore.assertEquals(9.0091168133463e-17,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(666);
		AssertMore.assertEquals(2.2909144215819e-13,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(.0035194531243864,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEnergySpectrumIntegralFluence_2(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(284135052991.89,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(836219.55609498,doubleEvent.getEnergySpectrumFluence_2(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10319769159113,doubleEvent.getEnergySpectrumFluence_2(500),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(284135052991.89);
		AssertMore.assertEquals(1e9,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(284135052991.89,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(836219.55609498,doubleEvent.getEnergySpectrumFluence_2(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10319769159113,doubleEvent.getEnergySpectrumFluence_2(500),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEnergySpectrumIntegralFluence_2(5);
		doubleEvent.setEmin(500);
		AssertMore.assertEquals(352235457090.38,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(1036641.4649214,doubleEvent.getEnergySpectrumFluence_2(50),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(50);
		doubleEvent.setE0_2(500);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(50,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.24048414540948,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(0.24048414540948,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setEmin(50);
		AssertMore.assertEquals(0.008325829170022,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		
		doubleEvent.setEnergySpectrumIntegralFluence_2(30);
		doubleEvent.setGamma_2(2);
		doubleEvent.setE0_2(50);
		doubleEvent.setEmin(60);
		AssertMore.assertEquals(16201.024079494,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(50);
		AssertMore.assertEquals(10101.315724163,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setGamma_2(2.5);
		AssertMore.assertEquals(83854.728083211,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setE0_2(101);
		doubleEvent.setEnergySpectrumIntegralFluence_2(60);
		AssertMore.assertEquals(79389.538225372,doubleEvent.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(79389.538225372);
		AssertMore.assertEquals(79389.538225372,doubleEvent.getK_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(60,doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		
			
		
		// code copied from test of SolarParticleEvent Test.
		DoubleEvent event = new DoubleEvent();
		event.setK_2(1e9);
		event.setGamma_2(0);
		event.setE0_2(30);
		try { 
			event.getEnergySpectrumIntegralFluence_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		AssertMore.assertEquals(716531310.57379 , event.getEnergySpectrumFluence_2(10),MAX_CALCULATED_PERCENT_ERROR);
		
		event.setEmin(10);
		AssertMore.assertEquals(2.149593931714e10, 	event.getEnergySpectrumIntegralFluence_2(),			MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30);
		AssertMore.assertEquals(1.1036383235144e10, event.getEnergySpectrumIntegralFluence_2(),			MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(60);
		AssertMore.assertEquals(4.0600584970986e9,  event.getEnergySpectrumIntegralFluence_2(),			MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(10);
		AssertMore.assertEquals(2.149593931714e10, 	event.getEnergySpectrumIntegralFluence_2(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30); // set emin
		AssertMore.assertEquals(1.1036383235144e10, event.getEnergySpectrumIntegralFluence_2(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setK_2(2.2e7); // change k
		AssertMore.assertEquals(242800431.17315, event.getEnergySpectrumIntegralFluence_2(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(10);
		AssertMore.assertEquals(472910664.97871, event.getEnergySpectrumIntegralFluence_2(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(10);// change emin
		event.setGamma_2(3.01); // change gamma
		AssertMore.assertEquals(61025.805350301, event.getEnergySpectrumIntegralFluence_2(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setE0_2(112); // change E0
		AssertMore.assertEquals(90782.963349881, event.getEnergySpectrumIntegralFluence_2(),	MAX_CALCULATED_PERCENT_ERROR);
		// second statment to check caching mechanism.
		AssertMore.assertEquals(90782.963349881, event.getEnergySpectrumIntegralFluence_2(),	MAX_CALCULATED_PERCENT_ERROR);
		// when we set the energy doubleEvent, k should be calculated automatically.
		event.setEnergySpectrumIntegralFluence_2(1.02e10);
		AssertMore.assertEquals(2471829423932.3,event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2471829423932.3,event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_2(2471829423932.3);
		AssertMore.assertEquals(2471829423932.3,event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.02e10,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_2(1111.111);
		event.setEmin(30);
		event.setGamma_2(1.99);
		event.setE0_2(202.2);
		AssertMore.assertEquals(1111.111,event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(24.814069093002,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(66);
		AssertMore.assertEquals(7.8710442609193,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(66);
		AssertMore.assertEquals(7.8710442609193,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_2(666);
		AssertMore.assertEquals(666, event.getEnergySpectrumIntegralFluence_2(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(94015.470053217, event.getK_2(), MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30); // change Emin
		AssertMore.assertEquals(666, event.getEnergySpectrumIntegralFluence_2(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(29821.788729068, event.getK_2(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 290.43919751046 , event.getEnergySpectrumFluence_2(10), MAX_CALCULATED_PERCENT_ERROR);
		event = new DoubleEvent();
		event.setK_2(1e9);
		event.setGamma_2(0);
		event.setE0_2(30);
		event.setEnergySpectrumIntegralFluence_2(1000);
		AssertMore.assertEquals(1000,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		try {
			event.getK_2(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		event = new DoubleEvent();
		event.setK_2(1e9);
		event.setGamma_2(0);
		event.setE0_2(30);
		try {
			event.getEnergySpectrumIntegralFluence_2(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event = new DoubleEvent();
		try {
			event.getEnergySpectrumIntegralFluence_2(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getK_2(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getE0_2(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setE0_2(80);
		AssertMore.assertEquals(80,event.getE0_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setGamma_2(1);
		AssertMore.assertEquals(1,event.getGamma_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_2(1);
		try {
			event.getK_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setK_2(10);
		try {
			event.getEnergySpectrumIntegralFluence_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setEmin(22);
		AssertMore.assertEquals(22,event.getEmin(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_2(1);
		AssertMore.assertEquals(1,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0299079093937, event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_2(1.0299079093937);
		AssertMore.assertEquals(1.0299079093937, event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_2(5e9);
		AssertMore.assertEquals(4854802991.9913,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5e9,event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setEnergySpectrumIntegralFluence_2(999);
		AssertMore.assertEquals(1028.8780014843,event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(999,event.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
	}

	public void testGetSetFluences() {
		DoubleEvent doubleEvent = new DoubleEvent();
		
		doubleEvent.setEmin(50);
		
		doubleEvent.setK_1(1e9);
		doubleEvent.setGamma_1(0);
		doubleEvent.setE0_1(30);
		AssertMore.assertEquals(5.66627e9, doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(1e10);
		doubleEvent.setGamma_2(2);
		doubleEvent.setE0_2(20);
		AssertMore.assertEquals(0.000395954e10, doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(5.66627e9+0.000395954e10,doubleEvent.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.66627e9+0.000395954e10,doubleEvent.getEnergySpectrumIntegralFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(1733.32+0.0000103139,doubleEvent.getEnergySpectrumIntegralFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(500);
		AssertMore.assertEquals(1733.32+0.0000103139,doubleEvent.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(2.149593931721358e10+3.26643862324553e8,doubleEvent.getEnergySpectrumIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(2.149593931721358e10+3.26643862324553e8,doubleEvent.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(3.3382377953649984e-6, doubleEvent.getEnergySpectrumFluence_1(1000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.9287498479639176e-18, doubleEvent.getEnergySpectrumFluence_2(1000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.3382377953649984e-6+1.9287498479639176e-18, doubleEvent.getEnergySpectrumFluence(1000),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(7.165313105737892e8, doubleEvent.getEnergySpectrumFluence_1(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.065306597126334e7, doubleEvent.getEnergySpectrumFluence_2(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.165313105737892e8+6.065306597126334e7, doubleEvent.getEnergySpectrumFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(1.8887560283756182e8, doubleEvent.getEnergySpectrumFluence_1(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(328340., doubleEvent.getEnergySpectrumFluence_2(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.8887560283756182e8+328340.0, doubleEvent.getEnergySpectrumFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(6.737946999085467e6, doubleEvent.getEnergySpectrumFluence_1(150),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(245.815, doubleEvent.getEnergySpectrumFluence_2(150),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.737946999085467e6+245.815, doubleEvent.getEnergySpectrumFluence(150),MAX_CALCULATED_PERCENT_ERROR);


		doubleEvent.setEmin(500);
		doubleEvent.setK_1(2.25e2);
		doubleEvent.setGamma_1(1.11);
		doubleEvent.setE0_1(400);
		AssertMore.assertEquals(15.9374, doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_AWEFUL_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(6.5e2);
		doubleEvent.setGamma_2(3.21);
		doubleEvent.setE0_2(44);
		AssertMore.assertEquals(5.69429e-10, doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);

		AssertMore.assertEquals(15.9374+5.69429e-10, doubleEvent.getEnergySpectrumIntegralFluence(),MAX_AWEFUL_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(453.165+1.24579, doubleEvent.getEnergySpectrumIntegralFluence(10),MAX_AWEFUL_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(10);
		AssertMore.assertEquals(453.165+1.24579, doubleEvent.getEnergySpectrumIntegralFluence(),MAX_AWEFUL_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(340.712+0.191518, doubleEvent.getEnergySpectrumIntegralFluence(20),MAX_AWEFUL_CALCULATED_PERCENT_ERROR);
		doubleEvent.setEmin(20);
		AssertMore.assertEquals(340.712+0.191518, doubleEvent.getEnergySpectrumIntegralFluence(),MAX_AWEFUL_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals(128.976+0.000511166, doubleEvent.getEnergySpectrumIntegralFluence(100),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		
		doubleEvent.setEmin(70);
		doubleEvent.setK_1(2e2);
		doubleEvent.setGamma_1(1);
		doubleEvent.setE0_1(400);
		AssertMore.assertEquals(266.677, doubleEvent.getEnergySpectrumIntegralFluence_1(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(6e8);
		doubleEvent.setGamma_2(3);
		doubleEvent.setE0_2(47);
		AssertMore.assertEquals(7043.61, doubleEvent.getEnergySpectrumIntegralFluence_2(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(266.677+7043.61, doubleEvent.getEnergySpectrumIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(266.677+7043.61, doubleEvent.getEnergySpectrumIntegralFluence(70),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(125.066+62.3048, doubleEvent.getEnergySpectrumIntegralFluence(180),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(255.165+5352.32, doubleEvent.getEnergySpectrumIntegralFluence(75),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(9.51229, doubleEvent.getEnergySpectrumFluence_1(20),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(49006.7, doubleEvent.getEnergySpectrumFluence_2(20),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.51229+49006.7, doubleEvent.getEnergySpectrumFluence(20),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(2.86903, doubleEvent.getEnergySpectrumFluence_1(60),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(774.96, doubleEvent.getEnergySpectrumFluence_2(60),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.86903+774.96, doubleEvent.getEnergySpectrumFluence(60),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(0.0743767, doubleEvent.getEnergySpectrumFluence_1(600),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.93437e-6, doubleEvent.getEnergySpectrumFluence_2(600),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0743767+7.93437e-6, doubleEvent.getEnergySpectrumFluence(600),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(1.0196744016727526e-8, doubleEvent.getEnergySpectrumFluence_1(6000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.00427e-58, doubleEvent.getEnergySpectrumFluence_2(6000),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0196744016727526e-8+1.00427e-58, doubleEvent.getEnergySpectrumFluence(6000),MAX_CALCULATED_PERCENT_ERROR);
		
	}

	public void testGetSetA_1() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setA_1(1);
		AssertMore.assertEquals(1,doubleEvent.getA_1());
		doubleEvent.setA_1(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getA_1());
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getA_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setA_1(400.125);
		AssertMore.assertEquals(400.125, doubleEvent.getA_1(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setA_1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setA_1(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		AssertMore.assertEquals(400.125, doubleEvent.getA_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(400,doubleEvent.getA_1(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetA_2() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setA_2(1);
		AssertMore.assertEquals(1,doubleEvent.getA_2());
		doubleEvent.setA_2(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getA_2());
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getA_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setA_2(400.125);
		AssertMore.assertEquals(400.125, doubleEvent.getA_2(),MAX_EXACT_PERCENT_ERROR);
		
		try {
			doubleEvent.setA_2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			doubleEvent.setA_2(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		AssertMore.assertEquals(400.125, doubleEvent.getA_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(400,doubleEvent.getA_2(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetB1_1() {

		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setB1_1(1);
		AssertMore.assertEquals(1,doubleEvent.getB1_1());
		doubleEvent.setB1_1(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getB1_1());
		
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getB1_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		doubleEvent.setB1_1(400.125);
		AssertMore.assertEquals(400.125, doubleEvent.getB1_1(),MAX_EXACT_PERCENT_ERROR);
		try {
			doubleEvent.setB1_1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(400.125, doubleEvent.getB1_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(400,doubleEvent.getB1_1(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetB1_2() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setB1_2(1);
		AssertMore.assertEquals(1,doubleEvent.getB1_2());
		doubleEvent.setB1_2(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getB1_2());
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getB1_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		doubleEvent.setB1_2(400.125);
		AssertMore.assertEquals(400.125, doubleEvent.getB1_2(),MAX_EXACT_PERCENT_ERROR);
		try {
			doubleEvent.setB1_2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		AssertMore.assertEquals(400.125, doubleEvent.getB1_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(400,doubleEvent.getB1_2(),MAX_EXACT_PERCENT_ERROR);	
	}

	public void testGetSetB2_1() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setB2_1(1);
		AssertMore.assertEquals(1,doubleEvent.getB2_1());
		doubleEvent.setB2_1(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getB2_1());
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getB2_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		doubleEvent.setB2_1(400.125);
		AssertMore.assertEquals(400.125, doubleEvent.getB2_1(),MAX_EXACT_PERCENT_ERROR);
		try {
			doubleEvent.setB2_1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(400.125, doubleEvent.getB2_1(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(400,doubleEvent.getB2_1(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetB2_2() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setB2_2(1);
		AssertMore.assertEquals(1,doubleEvent.getB2_2());
		doubleEvent.setB2_2(1e9);
		AssertMore.assertEquals(1e9,doubleEvent.getB2_2());
		doubleEvent = new DoubleEvent();
		try {
			doubleEvent.getB2_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		doubleEvent.setB2_2(400.125);
		AssertMore.assertEquals(400.125, doubleEvent.getB2_2(),MAX_EXACT_PERCENT_ERROR);
		try {
			doubleEvent.setB2_2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(400.125, doubleEvent.getB2_2(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(400,doubleEvent.getB2_2(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetC_1() {
		
	}

	public void testGetC_2() {
		
	}

	public void testGetSetTimeDelayBetweenEvents() {
		DoubleEvent doubleEvent = new DoubleEvent();
		doubleEvent.setTimeDelayBetweenEvents(Time.inDays(1));
		
		AssertMore.assertEquals(Time.inDays(1),doubleEvent.getTimeDelayBetweenEvents());
		doubleEvent.setTimeDelayBetweenEvents(Time.inDays(2));
		
		AssertMore.assertEquals(Time.inDays(2),doubleEvent.getTimeDelayBetweenEvents());
		try {
			doubleEvent.setTimeDelayBetweenEvents(Time.inDays(-1));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		AssertMore.assertEquals(Time.inDays(2),doubleEvent.getTimeDelayBetweenEvents());		
	}

	public void testGetTimeEvolutionFluxAndIntegralFlux(){
	}

	public void testIsEventLargeEnough() { /* ABC */
		DoubleEvent event = new DoubleEvent();
		
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_2(0);
		event.setE0_2(10);
		event.setGamma_2(0);
		event.setA_2(1);
		event.setB1_2(1);
		event.setB2_2(1);
		
		double C;
		
		event.setA_1(3);
		event.setB1_1(2);
		event.setB2_1(2);
		AssertMore.assertEquals(1.3292624332267, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);

		try {
			event.getC_1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		event.setGamma_1(0.222);
		event.setE0_1(333.0);
		
		event.setEnergySpectrumIntegralFluence_1(1.0152632909385885E12);
		AssertMore.assertEquals(1E10,event.getK_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0152632909385885E12,event.getEnergySpectrumIntegralFluence(10.0),MAX_CALCULATED_PERCENT_ERROR);
		 C=1015263290938.5/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertTrue( event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(101.52632909385885);
		AssertMore.assertEquals(1,event.getK_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101.52632909385885,event.getEnergySpectrumIntegralFluence(10.0),MAX_CALCULATED_PERCENT_ERROR);
		C=101.52632909385/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC_1(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertFalse( event.isEventLargeEnough());

		
		event.setEmin(10);
		
		event.setEnergySpectrumIntegralFluence_1(1E6);
		event.setGamma_1(1);
		event.setE0_1(10);
		event.setA_1(2);
		event.setB1_1(2);
		event.setB2_1(2);
		AssertMore.assertEquals(1.0392773271962623,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);
		//maximum at t=2
		
		/*
		 * Mathematica code to te
		 * totalfluence = 1*10^6
		 * gamma = 1
		 * E0 = 10
		 * Emin = 10
		 * A = 2
		 * B1 = 2
		 * B2 = 2
		 * Cee = CalculateC[CalculateK[totalfluence, gamma, E0, Emin], gamma, E0, A, B1, B2]
		 * FindMaximum[Flux[Cee, A, B1, B2, t], {t, .01}]
		 *
		 * Prints out: {0.382329, {t -> 2.}}, which is larger then .1, so it is good enough.
		 */
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		

		event.setEnergySpectrumIntegralFluence_1(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
	
		event.setB1_1(3);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_1(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(3.1E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setGamma_1(4);
		event.setB2_1(6);
		event.setEnergySpectrumIntegralFluence_1(1.25E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		event.setEnergySpectrumIntegralFluence_1(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_1(0);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		
	}

	
	public void testIsEventLargeEnough_2() {

		DoubleEvent event = new DoubleEvent();
		
		event.setEmin(10);
		event.setEnergySpectrumIntegralFluence_1(0);
		event.setE0_1(10);
		event.setGamma_1(0);
		event.setA_1(1);
		event.setB1_1(1);
		event.setB2_1(1);
		
		double C;
		
		event.setA_2(3);
		event.setB1_2(2);
		event.setB2_2(2);
		AssertMore.assertEquals(1.3292624332267, event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);

		try {
			event.getC_2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		event.setGamma_2(0.222);
		event.setE0_2(333.0);
		
		event.setEnergySpectrumIntegralFluence_2(1.0152632909385885E12);
		AssertMore.assertEquals(1E10,event.getK_2(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0152632909385885E12,event.getEnergySpectrumIntegralFluence(10.0),MAX_CALCULATED_PERCENT_ERROR);
		 C=1015263290938.5/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC_2(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertTrue( event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_2(101.52632909385885);
		AssertMore.assertEquals(1,event.getK_2(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(101.52632909385885,event.getEnergySpectrumIntegralFluence(10.0),MAX_CALCULATED_PERCENT_ERROR);
		C=101.52632909385/(1.3292624332267*4*Math.PI*24*3600);
		AssertMore.assertEquals( C, event.getC_2(),MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertFalse( event.isEventLargeEnough());

		
		event.setEmin(10);
		
		event.setEnergySpectrumIntegralFluence_2(1E6);
		event.setGamma_2(1);
		event.setE0_2(10);
		event.setA_2(2);
		event.setB1_2(2);
		event.setB2_2(2);
		AssertMore.assertEquals(1.0392773271962623,event.getC_2(),MAX_CALCULATED_PERCENT_ERROR);
		//maximum at t=2
		
		/*
		 * Mathematica code to te
		 * totalfluence = 1*10^6
		 * gamma = 1
		 * E0 = 10
		 * Emin = 10
		 * A = 2
		 * B1 = 2
		 * B2 = 2
		 * Cee = CalculateC[CalculateK[totalfluence, gamma, E0, Emin], gamma, E0, A, B1, B2]
		 * FindMaximum[Flux[Cee, A, B1, B2, t], {t, .01}]
		 *
		 * Prints out: {0.382329, {t -> 2.}}, which is larger then .1, so it is good enough.
		 */
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_2(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		

		event.setEnergySpectrumIntegralFluence_2(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
	
		event.setB1_2(3);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		
		event.setEnergySpectrumIntegralFluence_2(2.7E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_2(3.1E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());
		
		event.setGamma_2(4);
		event.setB2_2(6);
		event.setEnergySpectrumIntegralFluence_2(1.25E5);
		AssertMore.assertEquals(false,event.isEventLargeEnough());
		event.setEnergySpectrumIntegralFluence_2(3E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_2(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_2(1.26E5);
		AssertMore.assertEquals(true,event.isEventLargeEnough());

		event.setEnergySpectrumIntegralFluence_2(0);
		AssertMore.assertEquals(false,event.isEventLargeEnough());			
	}
		
	public void testGetDose_firstEventIndividually() {
		
		
		// test the first event's doses

		DoubleEvent doubleEvent= new DoubleEvent("SPE");	
		
		try {
			doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		doubleEvent.setE0_1(10);
		try {
			doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		// set the second event's dose to always be 0 (K=0)
		doubleEvent.setGamma_2(0);
		doubleEvent.setE0_2(10);
		doubleEvent.setK_2(0);	
		
		
		doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10); doubleEvent.setEmin(10);
		doubleEvent.setEnergySpectrumIntegralFluence_1(3.6787944117144);
		// here, k is calculated automatically
		AssertMore.assertEquals(0.00000070403064,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1,      doubleEvent.getK_1(),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10); 
		AssertMore.assertEquals(0.00000070403064,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(0.00000022281255,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000022281255/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(0.0000000015429306,    doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000015429306/2,    doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.75); doubleEvent.setE0_1(450);	
		AssertMore.assertEquals(0.00000047012099,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000047012099/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.75); doubleEvent.setE0_1(450);		
		AssertMore.assertNotEquals(0.00000047013,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.625); doubleEvent.setE0_1(480);	
		AssertMore.assertEquals(0.00000094430027,      doubleEvent.getDose(Thickness.ONE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(470);	
		AssertMore.assertEquals(0.0000084493395,       doubleEvent.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(470);	
		AssertMore.assertNotEquals(0.0000074493395,    doubleEvent.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0.75); doubleEvent.setE0_1(470);	
		AssertMore.assertEquals(0.000001346395,        doubleEvent.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(260);	
		AssertMore.assertEquals(0.0000000000024499285, doubleEvent.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(4.2875497E-14,         doubleEvent.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000000000001669283,  doubleEvent.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000060348026,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000015740048,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000017522505,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000017317887,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(20);	
		AssertMore.assertEquals(0.000000000082150911,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(20);	
		AssertMore.assertEquals(0.000000000063298734,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(20);	
		AssertMore.assertEquals(0.0000000000045508042, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(20);	
		AssertMore.assertEquals(0.00000000012973093,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(20);	
		AssertMore.assertEquals(0.000000000095237367,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(20);	
		AssertMore.assertEquals(0.0000000000073112939, doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(0.0000000014003176,    doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000035926314,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(3.953479E-17,          doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(6.1047718E-14 ,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(0.0000000000027777104, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(2.1689817E-17,         doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000025157018,        doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(8.357322E-16,          doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.125); doubleEvent.setE0_1(290);	
		AssertMore.assertEquals(0.000000016980616,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.5); doubleEvent.setE0_1(440);	
		AssertMore.assertEquals(0.0000000000099093563, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.625); doubleEvent.setE0_1(440);	
		AssertMore.assertEquals(0.0000000000049200609, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(380);	
		AssertMore.assertEquals(0.0000000025662568,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(100);	
		AssertMore.assertEquals(0.00000011206039,      doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.125); doubleEvent.setE0_1(270);	
		AssertMore.assertEquals(0.0000089299137,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);   
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(270);	
		AssertMore.assertEquals(0.0000042227257,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(260);	
		AssertMore.assertEquals(0.0000039604151,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.125); doubleEvent.setE0_1(90);	
		AssertMore.assertEquals(0.0000000029764826,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.125); doubleEvent.setE0_1(100);	
		AssertMore.assertEquals(0.0000000039450558,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(270);	
		AssertMore.assertEquals(0.0000000022628353,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(0.00000000018974713,   doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(4.2578434E-17,         doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000060006791,        doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.0000000000000235696, doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(0.000000000074961412,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(1.7230071E-17,         doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000033056775,        doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(1.6004745E-14,         doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.375); doubleEvent.setE0_1(320);	
		AssertMore.assertEquals(0.000000011797018,     doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(320);	
		AssertMore.assertEquals(0.0000000061652372,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.375); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.00000001526657,      doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.125); doubleEvent.setE0_1(480);	
		AssertMore.assertEquals(0.000000067081778,     doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.25); doubleEvent.setE0_1(330);	
		AssertMore.assertEquals(0.00000000019645702,   doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.75); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000011387776,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000044591548,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1e1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000033056775*1e1,         doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(43); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(1.6004745E-14*43,           doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(111); doubleEvent.setGamma_1(1.375); doubleEvent.setE0_1(320);	
		AssertMore.assertEquals(0.000000011797018*111,      doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(.001); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(320);	
		AssertMore.assertEquals(0.0000000061652372*.001,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(666); doubleEvent.setGamma_1(1.375); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.00000001526657*666,       doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
		doubleEvent.setK_1(1e9); doubleEvent.setGamma_1(1.125); doubleEvent.setE0_1(480);	
		AssertMore.assertEquals(0.000000067081778*1e9,      doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
		doubleEvent.setK_1(4.3e13); doubleEvent.setGamma_1(2.25); doubleEvent.setE0_1(330);	
		AssertMore.assertEquals(0.00000000019645702*4.3e13, doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(.223213); doubleEvent.setGamma_1(1.75); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000011387776*.223213, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);				
		doubleEvent.setK_1(4e-21); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000044591548*4e-21,   doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);				
		doubleEvent.setK_1(0); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0,                        doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.75); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000011387776,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.725); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000136093178, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.7); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000158308596, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.675); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000180524014, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.65); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000202739432, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000022495485,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.6); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000269146976, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.575); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000313339102, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.55); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000357531228, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.525); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000401723354, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000044591548,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(260);	
		AssertMore.assertEquals(0.0000039604151,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.00000398664616,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000401287722,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(263);	
		AssertMore.assertEquals(0.00000403910828,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(264);	
		AssertMore.assertEquals(0.00000406533934,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(265);	
		AssertMore.assertEquals(0.0000040915704,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000411780146,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(267);	
		AssertMore.assertEquals(0.00000414403252,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(268);	
		AssertMore.assertEquals(0.00000417026358,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(269);	
		AssertMore.assertEquals(0.00000419649464,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(270);	
		AssertMore.assertEquals(0.0000042227257,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(260);	
		AssertMore.assertEquals(0.0000018842788,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.00000189633192, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000190838504, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(263);	
		AssertMore.assertEquals(0.00000192043816, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(264);	
		AssertMore.assertEquals(0.00000193249128, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(265);	
		AssertMore.assertEquals(0.0000019445444,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000195659752, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(267);	
		AssertMore.assertEquals(0.00000196865064, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(268);	
		AssertMore.assertEquals(0.00000198070376, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(269);	
		AssertMore.assertEquals(0.00000199275688, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(270);	
		AssertMore.assertEquals(0.000002004813,   doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000401287722,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2625); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000003802428002, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.275); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000003591978784, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2875); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000003381529566, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000003171080348, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3125); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000296063113,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.325); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000002750181912, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3375); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000002539732694, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.35); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000002329283476, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3625); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000002118834258, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000190838504,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000411780146,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2625); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000003901681066, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.275); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000003685560672, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2875); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000003469440278, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000003253319884, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3125); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000303719949,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.325); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000002821079096, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3375); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000002604958702, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.35); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000002388838308, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3625); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000002172717914, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000195659752,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.00000398664616,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2625); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000003777614736, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.275); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000003568583312, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2875); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000003359551888, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000003150520464, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3125); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.00000294148904,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.325); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000002732457616, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3375); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000002523426192, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.35); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000002314394768, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3625); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000002105363344, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.00000189633192,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.0000000007390083,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0125); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.000000000706360565, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000067371283,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0375); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.000000000641065095, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.05); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000060841736,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0625); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.000000000575769625, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.075); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000054312189,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.000000000510474155, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.1); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000047782642,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.1125); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.000000000445178685, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.125); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000041253095,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.00000000076027212,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0125); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000726657592,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000693043064,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0375); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000659428536,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.05); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(6.25814008000001E-10,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0625); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.00000000059219948,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.075); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000558584952,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000524970424,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.1); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000491355896,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.1125); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000457741368,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.125); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.00000000042412684,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000067371283,    doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(201);	
		AssertMore.assertEquals(0.0000000006756458534,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(202);	
		AssertMore.assertEquals(0.0000000006775788768,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(203);	
		AssertMore.assertEquals(0.0000000006795119002,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(204);	
		AssertMore.assertEquals(0.0000000006814449236,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(205);	
		AssertMore.assertEquals(0.000000000683377947,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(206);	
		AssertMore.assertEquals(0.0000000006853109704,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(207);	
		AssertMore.assertEquals(0.0000000006872439938,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(208);	
		AssertMore.assertEquals(0.0000000006891770172,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(209);	
		AssertMore.assertEquals(0.0000000006911100406,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000693043064,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.000000000510474155,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(201);	
		AssertMore.assertEquals(0.0000000005119237819,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(202);	
		AssertMore.assertEquals(0.0000000005133734088,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(203);	
		AssertMore.assertEquals(0.0000000005148230357,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(204);	
		AssertMore.assertEquals(0.0000000005162726626,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(205);	
		AssertMore.assertEquals(0.0000000005177222895,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(206);	
		AssertMore.assertEquals(0.0000000005191719164,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(207);	
		AssertMore.assertEquals(0.0000000005206215433,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(208);	
		AssertMore.assertEquals(0.0000000005220711702,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(209);	
		AssertMore.assertEquals(0.0000000005235207971,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000524970424,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(490);	
		AssertMore.assertEquals(1.1153167E-13,     		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(491);	
		AssertMore.assertEquals(1.11572213E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(1.11612756E-13,   		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(493);	
		AssertMore.assertEquals(1.11653299E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(494);	
		AssertMore.assertEquals(1.11693842E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(1.11734385E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(496);	
		AssertMore.assertEquals(1.11774928E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(497);	
		AssertMore.assertEquals(1.11815471E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(498);	
		AssertMore.assertEquals(1.11856014E-13,         doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(1.11896557E-13,   		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.0000000000001119371,  doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(490);	
		AssertMore.assertEquals(6.4644762E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(491);	
		AssertMore.assertEquals(6.46676122E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(6.46904624E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(493);	
		AssertMore.assertEquals(6.47133126E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(494);	
		AssertMore.assertEquals(6.47361628E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(6.4759013E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(496);	
		AssertMore.assertEquals(6.47818632E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(497);	
		AssertMore.assertEquals(6.48047134E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(498);	
		AssertMore.assertEquals(6.48275636E-14 ,  doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(6.48504138E-14 ,  doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(6.4873264E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(1.11896557E-13,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0125); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(1.0719194268E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.025); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(1.0248732836E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0375); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(9.77827140400001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.05); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(9.30780997200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0625); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(8.83734854E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.075); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(8.36688710799999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0875); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(7.89642567599999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(7.42596424400001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1125); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(6.95550281200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(6.48504138E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(1.11612756E-13,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0125); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(1.0692052664E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.025); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(1.0222829728E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0375); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(9.75360679200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.05); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(9.28438385600001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0625); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(8.81516092E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.075); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(8.34593798399999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0875); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(7.87671504799999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(7.40749211200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1125); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(6.93826917600001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(6.46904624E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(1.11734385E-13,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0125); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(1.070368478E-13,         doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.025); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(1.023393106E-13,         doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0375); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(9.76417734000001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.05); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(9.29442362000001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0625); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(8.8246699E-14,           doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.075); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(8.35491617999999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0875); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(7.88516245999999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(7.41540874000001E-14 ,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1125); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(6.94565502000001E-14 ,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(6.4759013E-14,           doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
	}
	
	
		
	public void testGetDose_secondEventIndividually() {
		// test the second event individually.
		DoubleEvent doubleEvent= new DoubleEvent("SPE");	
		try {
			doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		doubleEvent.setE0_2(10);
		try {
			doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}

		// set the first event's dose to always be 0 (K=0)
		doubleEvent.setGamma_1(0);
		doubleEvent.setE0_1(10);
		doubleEvent.setK_1(0);
		doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10); doubleEvent.setEmin(10);
		doubleEvent.setEnergySpectrumIntegralFluence_2(3.6787944117144);
		// here, k is calculated automatically
		AssertMore.assertEquals(0.00000070403064,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1,      doubleEvent.getK_2(),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10); 
		AssertMore.assertEquals(0.00000070403064,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000070403064/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD, BodyPart.SKIN,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.00000022281255,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000022281255/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.EYE,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.0000000015429306,    doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000015429306/2,    doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.75); doubleEvent.setE0_2(450);	
		AssertMore.assertEquals(0.00000047012099,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000047012099/2,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.75); doubleEvent.setE0_2(450);		
		AssertMore.assertNotEquals(0.00000047013,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.625); doubleEvent.setE0_2(480);	
		AssertMore.assertEquals(0.00000094430027,      doubleEvent.getDose(Thickness.ONE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(470);	
		AssertMore.assertEquals(0.0000084493395,       doubleEvent.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(470);	
		AssertMore.assertNotEquals(0.0000074493395,    doubleEvent.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0.75); doubleEvent.setE0_2(470);	
		AssertMore.assertEquals(0.000001346395,        doubleEvent.getDose(Thickness.ONE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(260);	
		AssertMore.assertEquals(0.0000000000024499285, doubleEvent.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(4.2875497E-14,         doubleEvent.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000000000001669283,  doubleEvent.getDose(Thickness.ONE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000060348026,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000015740048,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000017522505,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000017317887,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.625); doubleEvent.setE0_2(20);	
		AssertMore.assertEquals(0.000000000082150911,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.625); doubleEvent.setE0_2(20);	
		AssertMore.assertEquals(0.000000000063298734,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.625); doubleEvent.setE0_2(20);	
		AssertMore.assertEquals(0.0000000000045508042, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.625); doubleEvent.setE0_2(20);	
		AssertMore.assertEquals(0.00000000012973093,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.625); doubleEvent.setE0_2(20);	
		AssertMore.assertEquals(0.000000000095237367,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.625); doubleEvent.setE0_2(20);	
		AssertMore.assertEquals(0.0000000000073112939, doubleEvent.getDose(Thickness.FIVE,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.0000000014003176,    doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000035926314,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(3.953479E-17,          doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(6.1047718E-14 ,        doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.0000000000027777104, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(2.1689817E-17,         doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000025157018,        doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(8.357322E-16,          doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.125); doubleEvent.setE0_2(290);	
		AssertMore.assertEquals(0.000000016980616,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.5); doubleEvent.setE0_2(440);	
		AssertMore.assertEquals(0.0000000000099093563, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.625); doubleEvent.setE0_2(440);	
		AssertMore.assertEquals(0.0000000000049200609, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(380);	
		AssertMore.assertEquals(0.0000000025662568,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(100);	
		AssertMore.assertEquals(0.00000011206039,      doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.125); doubleEvent.setE0_2(270);	
		AssertMore.assertEquals(0.0000089299137,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);   
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(270);	
		AssertMore.assertEquals(0.0000042227257,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(260);	
		AssertMore.assertEquals(0.0000039604151,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.125); doubleEvent.setE0_2(90);	
		AssertMore.assertEquals(0.0000000029764826,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.125); doubleEvent.setE0_2(100);	
		AssertMore.assertEquals(0.0000000039450558,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(270);	
		AssertMore.assertEquals(0.0000000022628353,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.00000000018974713,   doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(4.2578434E-17,         doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000060006791,        doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.0000000000000235696, doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.000000000074961412,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(1.7230071E-17,         doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000033056775,        doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(1.6004745E-14,         doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.375); doubleEvent.setE0_2(320);	
		AssertMore.assertEquals(0.000000011797018,     doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(320);	
		AssertMore.assertEquals(0.0000000061652372,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.375); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.00000001526657,      doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.125); doubleEvent.setE0_2(480);	
		AssertMore.assertEquals(0.000000067081778,     doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.25); doubleEvent.setE0_2(330);	
		AssertMore.assertEquals(0.00000000019645702,   doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.75); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000011387776,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000044591548,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1e1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000033056775*1e1,         doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(43); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(1.6004745E-14*43,           doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(111); doubleEvent.setGamma_2(1.375); doubleEvent.setE0_2(320);	
		AssertMore.assertEquals(0.000000011797018*111,      doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(.001); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(320);	
		AssertMore.assertEquals(0.0000000061652372*.001,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(666); doubleEvent.setGamma_2(1.375); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.00000001526657*666,       doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1e9); doubleEvent.setGamma_2(1.125); doubleEvent.setE0_2(480);	
		AssertMore.assertEquals(0.000000067081778*1e9,      doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(4.3e13); doubleEvent.setGamma_2(2.25); doubleEvent.setE0_2(330);	
		AssertMore.assertEquals(0.00000000019645702*4.3e13, doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(.223213); doubleEvent.setGamma_2(1.75); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000011387776*.223213, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(4e-21); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000044591548*4e-21,   doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(0); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.75); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000011387776,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.725); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000136093178, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.7); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000158308596, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.675); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000180524014, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.65); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000202739432, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.625); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000022495485,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.6); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000269146976, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.575); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000313339102, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.55); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000357531228, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.525); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000401723354, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000044591548,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(260);	
		AssertMore.assertEquals(0.0000039604151,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000398664616,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.00000401287722,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(263);	
		AssertMore.assertEquals(0.00000403910828,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(264);	
		AssertMore.assertEquals(0.00000406533934,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(265);	
		AssertMore.assertEquals(0.0000040915704,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.00000411780146,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(267);	
		AssertMore.assertEquals(0.00000414403252,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(268);	
		AssertMore.assertEquals(0.00000417026358,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(269);	
		AssertMore.assertEquals(0.00000419649464,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(270);	
		AssertMore.assertEquals(0.0000042227257,     doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(260);	
		AssertMore.assertEquals(0.0000018842788,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000189633192, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.00000190838504, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(263);	
		AssertMore.assertEquals(0.00000192043816, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(264);	
		AssertMore.assertEquals(0.00000193249128, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(265);	
		AssertMore.assertEquals(0.0000019445444,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.00000195659752, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(267);	
		AssertMore.assertEquals(0.00000196865064, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(268);	
		AssertMore.assertEquals(0.00000198070376, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(269);	
		AssertMore.assertEquals(0.00000199275688, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(270);	
		AssertMore.assertEquals(0.000002004813,   doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.00000401287722,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2625); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000003802428002, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.275); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000003591978784, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2875); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000003381529566, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000003171080348, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3125); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.00000296063113,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.325); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000002750181912, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3375); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000002539732694, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.35); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000002329283476, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3625); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000002118834258, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.00000190838504,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.00000411780146,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2625); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000003901681066, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.275); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000003685560672, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2875); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000003469440278, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000003253319884, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3125); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.00000303719949,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.325); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000002821079096, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3375); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000002604958702, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.35); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000002388838308, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3625); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000002172717914, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.00000195659752,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000398664616,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2625); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000003777614736, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.275); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000003568583312, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2875); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000003359551888, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000003150520464, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3125); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000294148904,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.325); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000002732457616, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3375); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000002523426192, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.35); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000002314394768, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3625); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000002105363344, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000189633192,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.0000000007390083,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0125); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000706360565, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.00000000067371283,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0375); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000641065095, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.05); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.00000000060841736,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0625); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000575769625, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.075); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.00000000054312189,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000510474155, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.1); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.00000000047782642,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.1125); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000445178685, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.125); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.00000000041253095,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.00000000076027212,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0125); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000726657592,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000693043064,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0375); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000659428536,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.05); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(6.25814008000001E-10,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0625); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.00000000059219948,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.075); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000558584952,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000524970424,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.1); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000491355896,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.1125); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000457741368,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.125); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.00000000042412684,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.00000000067371283,    doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(201);	
		AssertMore.assertEquals(0.0000000006756458534,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(202);	
		AssertMore.assertEquals(0.0000000006775788768,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(203);	
		AssertMore.assertEquals(0.0000000006795119002,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(204);	
		AssertMore.assertEquals(0.0000000006814449236,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(205);	
		AssertMore.assertEquals(0.000000000683377947,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(206);	
		AssertMore.assertEquals(0.0000000006853109704,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(207);	
		AssertMore.assertEquals(0.0000000006872439938,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(208);	
		AssertMore.assertEquals(0.0000000006891770172,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(209);	
		AssertMore.assertEquals(0.0000000006911100406,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000693043064,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000510474155,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(201);	
		AssertMore.assertEquals(0.0000000005119237819,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(202);	
		AssertMore.assertEquals(0.0000000005133734088,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(203);	
		AssertMore.assertEquals(0.0000000005148230357,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(204);	
		AssertMore.assertEquals(0.0000000005162726626,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(205);	
		AssertMore.assertEquals(0.0000000005177222895,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(206);	
		AssertMore.assertEquals(0.0000000005191719164,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(207);	
		AssertMore.assertEquals(0.0000000005206215433,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(208);	
		AssertMore.assertEquals(0.0000000005220711702,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(209);	
		AssertMore.assertEquals(0.0000000005235207971,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000524970424,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(490);	
		AssertMore.assertEquals(1.1153167E-13,     		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(491);	
		AssertMore.assertEquals(1.11572213E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(1.11612756E-13,   		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(493);	
		AssertMore.assertEquals(1.11653299E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(494);	
		AssertMore.assertEquals(1.11693842E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(1.11734385E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(496);	
		AssertMore.assertEquals(1.11774928E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(497);	
		AssertMore.assertEquals(1.11815471E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(498);	
		AssertMore.assertEquals(1.11856014E-13,         doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(1.11896557E-13,   		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.0000000000001119371,  doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(490);	
		AssertMore.assertEquals(6.4644762E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(491);	
		AssertMore.assertEquals(6.46676122E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(6.46904624E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(493);	
		AssertMore.assertEquals(6.47133126E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(494);	
		AssertMore.assertEquals(6.47361628E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(6.4759013E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(496);	
		AssertMore.assertEquals(6.47818632E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(497);	
		AssertMore.assertEquals(6.48047134E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(498);	
		AssertMore.assertEquals(6.48275636E-14 ,  doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(6.48504138E-14 ,  doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(6.4873264E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(1.11896557E-13,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0125); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(1.0719194268E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.025); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(1.0248732836E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0375); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(9.77827140400001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.05); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(9.30780997200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0625); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(8.83734854E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.075); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(8.36688710799999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0875); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(7.89642567599999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(7.42596424400001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1125); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(6.95550281200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(6.48504138E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(1.11612756E-13,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0125); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(1.0692052664E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.025); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(1.0222829728E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0375); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(9.75360679200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.05); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(9.28438385600001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0625); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(8.81516092E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.075); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(8.34593798399999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0875); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(7.87671504799999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(7.40749211200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1125); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(6.93826917600001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(6.46904624E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(1.11734385E-13,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0125); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(1.070368478E-13,         doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.025); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(1.023393106E-13,         doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0375); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(9.76417734000001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.05); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(9.29442362000001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0625); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(8.8246699E-14,           doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.075); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(8.35491617999999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0875); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(7.88516245999999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(7.41540874000001E-14 ,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1125); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(6.94565502000001E-14 ,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(6.4759013E-14,           doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
	}

	

	
	public void testGetDose() {	
		DoubleEvent doubleEvent= new DoubleEvent("SPE");	

		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.75); doubleEvent.setE0_2(450);	
		AssertMore.assertEquals(0.0000000015429306+0.00000047012099,    doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000015429306/2+0.00000047012099/2,    doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.LUNAR_SURFACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.75); doubleEvent.setE0_1(450);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.625); doubleEvent.setE0_2(480);		
		AssertMore.assertNotEquals(0.00000047013+0.00000094430027,      doubleEvent.getDose(Thickness.POINT_THREE, RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // this is not true
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000025157018+8.357322E-16,        doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.0000000000027777104+2.1689817E-17, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(500);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(3.953479E-17+6.1047718E-14,          doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.0000000014003176+0.000035926314,    doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(500);	
		doubleEvent.setK_2(1e8); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.000060006791+0.0000000000000235696*1e8,        doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.75); doubleEvent.setE0_1(390);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.5); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.000000001138777+0.0000000044591548,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(320);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.375); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.0000000061652372+0.00000001526657,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(10);	
		doubleEvent.setK_2(1e7); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.000000000074961412+(1.7230071E-17)*1e7,  doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(320);
		doubleEvent.setK_2(666); doubleEvent.setGamma_2(1.375); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(0.0000000061652372+0.00000001526657*666,    doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		  		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(270);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(260);	
		AssertMore.assertEquals(0.0000042227257+0.0000039604151,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.5); doubleEvent.setE0_1(440);	
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.625); doubleEvent.setE0_2(440);	
		AssertMore.assertEquals(0.0000000000099093563+0.0000000000049200609, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.125); doubleEvent.setE0_1(90);	
		AssertMore.assertEquals(0.0000000029764826,    doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.125); doubleEvent.setE0_2(100);	
		AssertMore.assertEquals(0.0000000039450558,    doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000029764826+0.0000000039450558,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(0); doubleEvent.setE0_2(10);	
		AssertMore.assertEquals(0.00000000018974713,   doubleEvent.getDose_2(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(10);	
		AssertMore.assertEquals(4.2578434E-17,         doubleEvent.getDose_1(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000018974713+4.2578434E-17,         doubleEvent.getDose(Thickness.TEN,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);

		doubleEvent.setK_1(1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000033056775, doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(1.6004745E-14, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000033056775+1.6004745E-14, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);

		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.625); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000022495485,  doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.6); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000269146976, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000022495485+0.00000000269146976, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1e1); doubleEvent.setGamma_1(0); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.000033056775*10,         doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(43); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(1.6004745E-14*43,           doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000033056775*10+1.6004745E-14*43, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.7); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000158308596, doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.675); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000180524014, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000158308596+0.00000000180524014, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);

		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.65); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000202739432, doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.575); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000313339102, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000202739432+0.00000000313339102, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(1.55); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.00000000357531228, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.525); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.00000000401723354, doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000357531228+0.00000000401723354, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.5); doubleEvent.setE0_1(390);	
		AssertMore.assertEquals(0.0000000044591548,  doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(.223213); doubleEvent.setGamma_2(1.75); doubleEvent.setE0_2(390);	
		AssertMore.assertEquals(0.0000000011387776*.223213, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000044591548+0.0000000011387776*.223213, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);

		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(260);	
		AssertMore.assertEquals(0.0000039604151,     doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000398664616,    doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000039604151+0.00000398664616,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000401287722,    doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(263);	
		AssertMore.assertEquals(0.00000403910828,    doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000401287722+0.00000403910828,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(264);	
		AssertMore.assertEquals(0.00000406533934, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(265);	
		AssertMore.assertEquals(0.0000040915704, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000406533934+0.0000040915704, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000411780146,    doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(267);	
		AssertMore.assertEquals(0.00000414403252,    doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000411780146+0.00000414403252,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
					
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(268);	
		AssertMore.assertEquals(0.00000417026358,    doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(269);	
		AssertMore.assertEquals(0.00000419649464,    doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000417026358+0.00000419649464,    doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(270);	
		AssertMore.assertEquals(0.0000042227257,     doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.125); doubleEvent.setE0_2(270);	
		AssertMore.assertEquals(0.0000089299137,       doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		AssertMore.assertEquals(0.0000042227257+0.0000089299137,       doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 


		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(260);	
		AssertMore.assertEquals(0.0000018842788,  doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); // exact
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000189633192, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000018842788+0.00000189633192, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000190838504, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(263);	
		AssertMore.assertEquals(0.00000192043816, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000190838504+0.00000192043816, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(264);	
		AssertMore.assertEquals(0.00000193249128, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(265);	
		AssertMore.assertEquals(0.0000019445444,  doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000193249128+0.0000019445444,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000195659752, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(267);	
		AssertMore.assertEquals(0.00000196865064, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000195659752+0.00000196865064, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(268);	
		AssertMore.assertEquals(0.00000198070376, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(269);	
		AssertMore.assertEquals(0.00000199275688, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000198070376+0.00000199275688, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(270);	
		AssertMore.assertEquals(0.000002004813,   doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.00000401287722,  doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000002004813+0.00000401287722,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2625); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000003802428002, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.275); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000003591978784, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000003802428002+0.000003591978784, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2875); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000003381529566, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000003171080348, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000003381529566+0.000003171080348, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3125); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.00000296063113,  doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.325); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000002750181912, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000296063113+0.000002750181912, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3375); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000002539732694, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.35); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.000002329283476, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000002539732694+0.000002329283476, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3625); doubleEvent.setE0_1(262);	
		AssertMore.assertEquals(0.000002118834258, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(262);	
		AssertMore.assertEquals(0.00000190838504,  doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000002118834258+0.00000190838504,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.25); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000411780146,  doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2625); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000003901681066, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000411780146+0.000003901681066, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.275); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000003685560672, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.2875); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000003469440278, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000003685560672+0.000003469440278, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000003253319884, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3125); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.00000303719949,  doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000003253319884+0.00000303719949,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.325); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000002821079096, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3375); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000002604958702, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000002821079096+0.000002604958702, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.35); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.000002388838308, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3625); doubleEvent.setE0_2(266);	
		AssertMore.assertEquals(0.000002172717914, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000002388838308+0.000002172717914, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.375); doubleEvent.setE0_1(266);	
		AssertMore.assertEquals(0.00000195659752,  doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.25); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000398664616,  doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000195659752+0.00000398664616,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2625); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000003777614736, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.275); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000003568583312, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000003777614736+0.000003568583312, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.2875); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000003359551888, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.3); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000003150520464, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000003359551888+0.000003150520464, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3125); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.00000294148904,  doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.325); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000002732457616, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000294148904+0.000002732457616, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3375); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000002523426192, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.35); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.000002314394768, doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000002523426192+0.000002314394768, doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(.3625); doubleEvent.setE0_1(261);	
		AssertMore.assertEquals(0.000002105363344, doubleEvent.getDose_1(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(.375); doubleEvent.setE0_2(261);	
		AssertMore.assertEquals(0.00000189633192,  doubleEvent.getDose_2(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000002105363344+0.00000189633192,  doubleEvent.getDose(Thickness.THIRTY,  RadiationType.REM, BodyPart.SKIN,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.0000000007390083,   doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0125); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000706360565, doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000007390083+0.000000000706360565, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000067371283,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0375); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000641065095, doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000067371283+0.000000000641065095, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.05); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000060841736,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0625); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000575769625, doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000060841736+0.000000000575769625, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.075); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000054312189,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000510474155, doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000054312189+0.000000000510474155, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.1); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000047782642,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.1125); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000445178685, doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000047782642+0.000000000445178685, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.125); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000041253095,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.00000000076027212,   doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000041253095+0.00000000076027212,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0125); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000726657592,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000693043064,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000726657592+0.000000000693043064,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0375); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000659428536,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.05); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(6.25814008000001E-10,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000659428536+6.25814008000001E-10,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0625); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.00000000059219948,   doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.075); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000558584952,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000059219948+0.000000000558584952,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000524970424,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.1); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000491355896,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000524970424+0.000000000491355896,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.1125); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000457741368,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.125); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.00000000042412684,   doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		AssertMore.assertEquals(0.000000000457741368+0.00000000042412684,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(200);	
		AssertMore.assertEquals(0.00000000067371283,    doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(201);	
		AssertMore.assertEquals(0.0000000006756458534,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000067371283+0.0000000006756458534,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(202);	
		AssertMore.assertEquals(0.0000000006775788768,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(203);	
		AssertMore.assertEquals(0.0000000006795119002,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000006775788768+0.0000000006795119002,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(204);	
		AssertMore.assertEquals(0.0000000006814449236, doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(205);	
		AssertMore.assertEquals(0.000000000683377947, doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000006814449236+0.000000000683377947, doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(206);	
		AssertMore.assertEquals(0.0000000006853109704,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(207);	
		AssertMore.assertEquals(0.0000000006872439938,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000006853109704+0.0000000006872439938,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(208);	
		AssertMore.assertEquals(0.0000000006891770172,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.025); doubleEvent.setE0_2(209);	
		AssertMore.assertEquals(0.0000000006911100406,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000006891770172+0.0000000006911100406,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.025); doubleEvent.setE0_1(210);	
		AssertMore.assertEquals(0.000000000693043064,   doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(200);	
		AssertMore.assertEquals(0.000000000510474155,   doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000000693043064+0.000000000510474155,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(201);	
		AssertMore.assertEquals(0.0000000005119237819,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(202);	
		AssertMore.assertEquals(0.0000000005133734088,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000005119237819+0.0000000005133734088,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(203);	
		AssertMore.assertEquals(0.0000000005148230357,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(204);	
		AssertMore.assertEquals(0.0000000005162726626,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000005148230357+0.0000000005162726626,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(205);	
		AssertMore.assertEquals(0.0000000005177222895,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(206);	
		AssertMore.assertEquals(0.0000000005191719164,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000005177222895+0.0000000005191719164,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(207);	
		AssertMore.assertEquals(0.0000000005206215433,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(208);	
		AssertMore.assertEquals(0.0000000005220711702,  doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000005206215433+0.0000000005220711702,  doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.0875); doubleEvent.setE0_1(209);	
		AssertMore.assertEquals(0.0000000005235207971,  doubleEvent.getDose_1(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(2.0875); doubleEvent.setE0_2(210);	
		AssertMore.assertEquals(0.000000000524970424,   doubleEvent.getDose_2(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000000005235207971+0.000000000524970424,   doubleEvent.getDose(Thickness.FIVE,  RadiationType.RAD, BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);

		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(490);	
		AssertMore.assertEquals(1.1153167E-13,     		doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(491);	
		AssertMore.assertEquals(1.11572213E-13,    		doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.1153167E-13+1.11572213E-13, doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(1.11612756E-13,   		doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(493);	
		AssertMore.assertEquals(1.11653299E-13,    		doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.11612756E-13+1.11653299E-13, doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(494);	
		AssertMore.assertEquals(1.11693842E-13,    		doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(1.11734385E-13,    		doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.11693842E-13+1.11734385E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(496);	
		AssertMore.assertEquals(1.11774928E-13,    		doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(497);	
		AssertMore.assertEquals(1.11815471E-13,    		doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.11774928E-13+1.11815471E-13,    		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(498);	
		AssertMore.assertEquals(1.11856014E-13,         doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(1.11896557E-13,   		doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.11856014E-13+1.11896557E-13,   		doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(500);	
		AssertMore.assertEquals(0.0000000000001119371,  doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR); 
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(490);	
		AssertMore.assertEquals(6.4644762E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); 
		AssertMore.assertEquals(0.0000000000001119371+6.4644762E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR); 
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(491);	
		AssertMore.assertEquals(6.46676122E-14,   doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(6.46904624E-14,   doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.46676122E-14+6.46904624E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(493);	
		AssertMore.assertEquals(6.47133126E-14,   doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(494);	
		AssertMore.assertEquals(6.47361628E-14,   doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.47133126E-14+6.47361628E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(6.4759013E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(496);	
		AssertMore.assertEquals(6.47818632E-14,   doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.4759013E-14+6.47818632E-14,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(497);	
		AssertMore.assertEquals(6.48047134E-14,   doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(498);	
		AssertMore.assertEquals(6.48275636E-14 ,  doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.48047134E-14+6.48275636E-14 ,  doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(6.48504138E-14 ,  doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(500);	
		AssertMore.assertEquals(6.4873264E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.48504138E-14+6.4873264E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(1.11896557E-13,          doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0125); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(1.0719194268E-13,        doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.11896557E-13+1.0719194268E-13,        doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.025); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(1.0248732836E-13,        doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0375); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(9.77827140400001E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0248732836E-13+9.77827140400001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.05); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(9.30780997200001E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0625); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(8.83734854E-14,          doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.30780997200001E-14+8.83734854E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.075); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(8.36688710799999E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0875); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(7.89642567599999E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8.36688710799999E-14+7.89642567599999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(7.42596424400001E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1125); doubleEvent.setE0_2(499);	
		AssertMore.assertEquals(6.95550281200001E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.42596424400001E-14+6.95550281200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.125); doubleEvent.setE0_1(499);	
		AssertMore.assertEquals(6.48504138E-14,          doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(1.11612756E-13,          doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.48504138E-14+1.11612756E-13,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0125); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(1.0692052664E-13, doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.025); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(1.0222829728E-13, doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0692052664E-13+1.0222829728E-13, doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0375); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(9.75360679200001E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.05); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(9.28438385600001E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.75360679200001E-14+9.28438385600001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0625); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(8.81516092E-14,          doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.075); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(8.34593798399999E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8.81516092E-14+8.34593798399999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.0875); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(7.87671504799999E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(7.40749211200001E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.87671504799999E-14+7.40749211200001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1125); doubleEvent.setE0_1(492);	
		AssertMore.assertEquals(6.93826917600001E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.125); doubleEvent.setE0_2(492);	
		AssertMore.assertEquals(6.46904624E-14,          doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.93826917600001E-14+6.46904624E-14,          doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(1.11734385E-13,          doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),   MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0125); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(1.070368478E-13,         doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.11734385E-13+1.070368478E-13,         doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.025); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(1.023393106E-13,         doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0375); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(9.76417734000001E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.023393106E-13+9.76417734000001E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.05); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(9.29442362000001E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0625); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(8.8246699E-14,           doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.29442362000001E-14+8.8246699E-14,           doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.075); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(8.35491617999999E-14,    doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.0875); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(7.88516245999999E-14,    doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8.35491617999999E-14+7.88516245999999E-14,    doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(4.1); doubleEvent.setE0_1(495);	
		AssertMore.assertEquals(7.41540874000001E-14 ,   doubleEvent.getDose_1(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1); doubleEvent.setGamma_2(4.1125); doubleEvent.setE0_2(495);	
		AssertMore.assertEquals(6.94565502000001E-14 ,   doubleEvent.getDose_2(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.41540874000001E-14+6.94565502000001E-14 ,   doubleEvent.getDose(Thickness.POINT_THREE,  RadiationType.REM, BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
				
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.375); doubleEvent.setE0_1(320);	
		AssertMore.assertEquals(0.000000011797018,     doubleEvent.getDose_1(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(111); doubleEvent.setGamma_2(1.375); doubleEvent.setE0_2(320);	
		AssertMore.assertEquals(0.000000011797018*111, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000011797018+0.000000011797018*111, doubleEvent.getDose(Thickness.TEN,  RadiationType.RAD,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(1.125); doubleEvent.setE0_1(480);	
		AssertMore.assertEquals(0.000000067081778,     doubleEvent.getDose_1(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(1e9); doubleEvent.setGamma_2(1.125); doubleEvent.setE0_2(480);	
		AssertMore.assertEquals(0.000000067081778*1e9,      doubleEvent.getDose_2(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000000067081778+0.000000067081778*1e9,      doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.BFO,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		
		doubleEvent.setK_1(1); doubleEvent.setGamma_1(2.25); doubleEvent.setE0_1(330);	
		AssertMore.assertEquals(0.00000000019645702,   doubleEvent.getDose_1(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		doubleEvent.setK_2(4.3e13); doubleEvent.setGamma_2(2.25); doubleEvent.setE0_2(330);	
		AssertMore.assertEquals(0.00000000019645702*4.3e13, doubleEvent.getDose_2(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00000000019645702+0.00000000019645702*4.3e13, doubleEvent.getDose(Thickness.TEN,  RadiationType.REM,  BodyPart.EYE,   DoseLocation.FREE_SPACE),  MAX_CALCULATED_PERCENT_ERROR);		
	}	
		
	
	

	public void testSimulateAstronautOnTheMoon_PART_1() {
		DoubleEvent event = new DoubleEvent();
		event.setName("Bob");
		AssertMore.assertEquals("Bob",event.getName());
		
		double K_1 = 1.1e9;
		event.setK_1( K_1);
		event.setGamma_1(.25);
		event.setE0_1(210);
		AssertMore.assertEquals(5.898098152606217e8,event.getEnergySpectrumFluence_1(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.16066e8,event.getEnergySpectrumFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.61638e10,event.getEnergySpectrumIntegralFluence_1(100),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.62784e10,event.getEnergySpectrumIntegralFluence_1(10),MAX_CALCULATED_PERCENT_ERROR);
		event.setA_1(.5);
		event.setB1_1(3.2);
		event.setB2_1(2.2);
		
		double timeEvolutionIntegralFluxWithoutCWithoutGCR_1 = 0.21929829295705;
		AssertMore.assertEquals(timeEvolutionIntegralFluxWithoutCWithoutGCR_1,
				event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)),
				MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(278364,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);

		event.setTimeDelayBetweenEvents(Time.inDays(2.5));
		AssertMore.assertEquals(Time.inDays(2.5),event.getTimeDelayBetweenEvents());
		
		event.setEmin(10);
		event.setGamma_2(0);
		event.setE0_2(250);
		event.setEnergySpectrumIntegralFluence_2(6.62784e10);
		double K_2 = 2.75933e8;
		AssertMore.assertEquals(K_2,event.getK_2(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK_2(K_2); // so that K is exact, not an aproximation
		
		event.setA_2(1);
		event.setB1_2(5);
		event.setB2_2(3);

		double timeEvolutionIntegralFluxWithoutCWithoutGCR_2 = 0.333333;
		AssertMore.assertEquals(timeEvolutionIntegralFluxWithoutCWithoutGCR_2,
				event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(10)),
				MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(183134.,event.getC_2(),MAX_CALCULATED_PERCENT_ERROR);
		
		/*
		 * Radiation doses: (RAD)!!!
		 * gamma: .25 E0: 210
		 * thickness .3 - skin: 0.0000067267238, eye: 0.0000060379275, bfo: 0.0000034403533
		 * thickness 5  - skin: 0.0000038907183, eye: 0.0000039236029, bfo: 0.0000028235427
		 * thickness 30 - skin: 0.0000016200581, eye: 0.0000016548087, bfo: 0.0000013796852
		 * 
		 * 
		 * Radiation doses: (RAD)!!!
		 * gamma: 0 E0: 250
		 * thickness .3 - skin: 0.000023490642, eye: 0.000022608139 , bfo: 0.000016328873
		 * thickness 5  - skin: 0.000017447674, eye: 0.000017671437 , bfo: 0.000014338673
		 * thickness 30 - skin: 0.0000095056384, eye: 0.0000096969015, bfo: 0.0000085091442 
		 */
		
		/*
		 * Doses from event 1.
		 */
		AssertMore.assertEquals(K_1*0.0000067267238,event.getDose_1(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000067267238/2,event.getDose_1(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000060379275,event.getDose_1(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000060379275/2,event.getDose_1(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000034403533,event.getDose_1(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000034403533/2,event.getDose_1(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		AssertMore.assertEquals(K_1*0.0000038907183,event.getDose_1(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000038907183/2,event.getDose_1(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000039236029,event.getDose_1(Thickness.FIVE,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000039236029/2,event.getDose_1(Thickness.FIVE,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000028235427,event.getDose_1(Thickness.FIVE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000028235427/2,event.getDose_1(Thickness.FIVE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		AssertMore.assertEquals(K_1*0.0000016200581,event.getDose_1(Thickness.THIRTY,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000016200581/2,event.getDose_1(Thickness.THIRTY,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000016548087,event.getDose_1(Thickness.THIRTY,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000016548087/2,event.getDose_1(Thickness.THIRTY,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000013796852,event.getDose_1(Thickness.THIRTY,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000013796852/2,event.getDose_1(Thickness.THIRTY,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));

		
		/*
		 * Doses from event 2.
		 */
		AssertMore.assertEquals(K_2*0.000023490642,event.getDose_2(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.000023490642/2,event.getDose_2(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_2*0.000022608139,event.getDose_2(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.000022608139/2,event.getDose_2(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_2*0.000016328873,event.getDose_2(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.000016328873/2,event.getDose_2(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		AssertMore.assertEquals(K_2*0.000017447674,event.getDose_2(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.000017447674/2,event.getDose_2(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_2*0.000017671437,event.getDose_2(Thickness.FIVE,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.000017671437/2,event.getDose_2(Thickness.FIVE,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_2*0.000014338673,event.getDose_2(Thickness.FIVE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.000014338673/2,event.getDose_2(Thickness.FIVE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		AssertMore.assertEquals(K_2*0.0000095056384,event.getDose_2(Thickness.THIRTY,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.0000095056384/2,event.getDose_2(Thickness.THIRTY,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_2*0.0000096969015,event.getDose_2(Thickness.THIRTY,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.0000096969015/2,event.getDose_2(Thickness.THIRTY,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_2*0.0000085091442,event.getDose_2(Thickness.THIRTY,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_2*0.0000085091442/2,event.getDose_2(Thickness.THIRTY,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		/*
		 * Now cumulative doses  
		 */
		AssertMore.assertEquals(K_1*0.0000067267238+K_2*0.000023490642,event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000067267238/2+K_2*0.000023490642/2,event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000060379275+K_2*0.000022608139,event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000060379275/2+K_2*0.000022608139/2,event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000034403533+K_2*0.000016328873,event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000034403533/2+K_2*0.000016328873/2,event.getDose(Thickness.POINT_THREE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		AssertMore.assertEquals(K_1*0.0000038907183+K_2*0.000017447674,event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000038907183/2+K_2*0.000017447674/2,event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000039236029+K_2*0.000017671437,event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000039236029/2+K_2*0.000017671437/2,event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000028235427+K_2*0.000014338673,event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000028235427/2+K_2*0.000014338673/2,event.getDose(Thickness.FIVE,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		AssertMore.assertEquals(K_1*0.0000016200581+K_2*0.0000095056384,event.getDose(Thickness.THIRTY,RadiationType.RAD,BodyPart.SKIN,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000016200581/2+K_2*0.0000095056384/2,event.getDose(Thickness.THIRTY,RadiationType.RAD,BodyPart.SKIN,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000016548087+K_2*0.0000096969015,event.getDose(Thickness.THIRTY,RadiationType.RAD,BodyPart.EYE,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000016548087/2+K_2*0.0000096969015/2,event.getDose(Thickness.THIRTY,RadiationType.RAD,BodyPart.EYE,DoseLocation.LUNAR_SURFACE));
		AssertMore.assertEquals(K_1*0.0000013796852+K_2*0.0000085091442,event.getDose(Thickness.THIRTY,RadiationType.RAD,BodyPart.BFO,DoseLocation.FREE_SPACE));
		AssertMore.assertEquals(K_1*0.0000013796852/2+K_2*0.0000085091442/2,event.getDose(Thickness.THIRTY,RadiationType.RAD,BodyPart.BFO,DoseLocation.LUNAR_SURFACE));
		
		/* simulation will be BFO and RAD
		 * 2.5 days after event begins, astronaut is warned <- .3 thickness
		 * .5 days to pack up <- .3 thickness
		 * 1 day in transit <- 5 thickness
		 * rest of event at base <- 30 thickness
		 *
		 * Remember, 2.5 days before second event begins.
		 * 			
		 * Radiation doses: (RAD)!!!
		 * gamma: .25 E0: 210 / A=.5, B1=3.2, B2=2.2
		 * thickness .3 - skin: 0.0000067267238, eye: 0.0000060379275, bfo: 0.0000034403533
		 * thickness 5  - skin: 0.0000038907183, eye: 0.0000039236029, bfo: 0.0000028235427
		 * thickness 30 - skin: 0.0000016200581, eye: 0.0000016548087, bfo: 0.0000013796852
		 * 
		 * 
		 * Radiation doses: (RAD)!!!
		 * gamma: 0 E0: 250 / A=1, B1=5, B2=3
		 * thickness .3 - skin: 0.000023490642, eye: 0.000022608139 , bfo: 0.000016328873
		 * thickness 5  - skin: 0.000017447674, eye: 0.000017671437 , bfo: 0.000014338673
		 * thickness 30 - skin: 0.0000095056384, eye: 0.0000096969015, bfo: 0.0000085091442 
		 */		
		DoseInformation information = event.simulateAstronautOnTheMoon(RadiationType.RAD,BodyPart.BFO,
				Time.inDays(-2.5),Thickness.POINT_THREE,Time.inDays(.5),Thickness.POINT_THREE,Time.inDays(1),
				Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
	
		double dosePriorToWarning = (K_1*0.0000034403533/2) * (0.219298 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1);
		AssertMore.assertEquals(dosePriorToWarning,information.dosePriorToWarning,MAX_CALCULATED_PERCENT_ERROR);
		
		
		double doseWhilePackingUp = (K_1*0.0000034403533/2) * (6.10284e-15 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
									(K_2*0.000016328873/2) * (0.00239699 / timeEvolutionIntegralFluxWithoutCWithoutGCR_2);
		
		AssertMore.assertEquals(doseWhilePackingUp,information.doseWhilePackingUp,MAX_CALCULATED_PERCENT_ERROR);

		double doseDuringTransit = 	(K_1*0.0000028235427/2) * (0 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
									(K_2*0.000014338673/2) * (0.281035/ timeEvolutionIntegralFluxWithoutCWithoutGCR_2);

		AssertMore.assertEquals(doseDuringTransit,information.doseDuringTransit,MAX_CALCULATED_PERCENT_ERROR);
			
		double doseAtBase = (K_1*0.0000013796852/2) * (0 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
							(K_2*0.0000085091442 /2) * ( 0.0499014 / timeEvolutionIntegralFluxWithoutCWithoutGCR_2);

		AssertMore.assertEquals(doseAtBase,information.doseAtBase,MAX_CALCULATED_PERCENT_ERROR);
		
		double totalDoseAwayFromShelter = dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals(totalDoseAwayFromShelter,information.totalDoseAwayFromShelter,MAX_CALCULATED_PERCENT_ERROR);
				
		AssertMore.assertEquals(totalDoseAwayFromShelter,information.totalDoseAwayFromShelter,MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(100*dosePriorToWarning/totalDoseAwayFromShelter,information.percentOfTotalPriorToWarning,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseWhilePackingUp/totalDoseAwayFromShelter,information.percentOfTotalWhilePackingUp,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseDuringTransit/totalDoseAwayFromShelter,information.percentOfTotalDuringTransit,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseAtBase/totalDoseAwayFromShelter,information.percentOfTotalAtBase,MAX_CALCULATED_PERCENT_ERROR);

		

		/* 
		 * AGAIN WITH EYE, ONLY DOSES CHANGE
		 */		
		information = event.simulateAstronautOnTheMoon(RadiationType.RAD,BodyPart.EYE,
				Time.inDays(-2.5),Thickness.POINT_THREE,Time.inDays(.5),Thickness.POINT_THREE,Time.inDays(1),
				Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
	
		dosePriorToWarning = (K_1*0.0000060379275/2) * (0.219298 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1);
		AssertMore.assertEquals(dosePriorToWarning,information.dosePriorToWarning,MAX_CALCULATED_PERCENT_ERROR);
		
		
		doseWhilePackingUp = (K_1*0.0000060379275/2) * (6.10284e-15 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
							 (K_2*0.000022608139/2) * (0.00239699 / timeEvolutionIntegralFluxWithoutCWithoutGCR_2);
		
		AssertMore.assertEquals(doseWhilePackingUp,information.doseWhilePackingUp,MAX_CALCULATED_PERCENT_ERROR);

		doseDuringTransit = (K_1*0.00000392360297/2) * (0 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
							(K_2*0.000017671437/2) * (0.281035/ timeEvolutionIntegralFluxWithoutCWithoutGCR_2);

		AssertMore.assertEquals(doseDuringTransit,information.doseDuringTransit,MAX_CALCULATED_PERCENT_ERROR);
			
		doseAtBase = (K_1*0.0000016548087/2) * (0 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
					 (K_2*0.0000096969015 /2) * ( 0.0499014 / timeEvolutionIntegralFluxWithoutCWithoutGCR_2);

		AssertMore.assertEquals(doseAtBase,information.doseAtBase,MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter = dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals(totalDoseAwayFromShelter,information.totalDoseAwayFromShelter,MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(totalDoseAwayFromShelter,information.totalDoseAwayFromShelter,MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(100*dosePriorToWarning/totalDoseAwayFromShelter,information.percentOfTotalPriorToWarning,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseWhilePackingUp/totalDoseAwayFromShelter,information.percentOfTotalWhilePackingUp,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseDuringTransit/totalDoseAwayFromShelter,information.percentOfTotalDuringTransit,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseAtBase/totalDoseAwayFromShelter,information.percentOfTotalAtBase,MAX_CALCULATED_PERCENT_ERROR);

		
		

		/* 
		 * AGAIN WITH SKIN, ONLY RADIATION DOSES CHANGE
		 */		
		information = event.simulateAstronautOnTheMoon(RadiationType.RAD,BodyPart.SKIN,
				Time.inDays(-2.5),Thickness.POINT_THREE,Time.inDays(.5),Thickness.POINT_THREE,Time.inDays(1),
				Thickness.FIVE,Thickness.THIRTY,new CumulativeDoseGraph());
	
		dosePriorToWarning = (K_1*0.0000067267238/2) * (0.219298 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1);
		AssertMore.assertEquals(dosePriorToWarning,information.dosePriorToWarning,MAX_CALCULATED_PERCENT_ERROR);
		
		
		doseWhilePackingUp = (K_1*0.0000067267238/2) * (6.10284e-15 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
							 (K_2*0.000023490642/2) * (0.00239699 / timeEvolutionIntegralFluxWithoutCWithoutGCR_2);
		
		AssertMore.assertEquals(doseWhilePackingUp,information.doseWhilePackingUp,MAX_CALCULATED_PERCENT_ERROR);

		doseDuringTransit = (K_1*0.0000038907183/2) * (0 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
							(K_2*0.000017447674/2) * (0.281035/ timeEvolutionIntegralFluxWithoutCWithoutGCR_2);

		AssertMore.assertEquals(doseDuringTransit,information.doseDuringTransit,MAX_CALCULATED_PERCENT_ERROR);
			
		doseAtBase = (K_1*0.0000016200581/2) * (0 / timeEvolutionIntegralFluxWithoutCWithoutGCR_1) +
					 (K_2*0.0000095056384/2) * ( 0.0499014 / timeEvolutionIntegralFluxWithoutCWithoutGCR_2);

		AssertMore.assertEquals(doseAtBase,information.doseAtBase,MAX_CALCULATED_PERCENT_ERROR);
		
		totalDoseAwayFromShelter = dosePriorToWarning+doseWhilePackingUp+doseDuringTransit+doseAtBase;
		AssertMore.assertEquals(totalDoseAwayFromShelter,information.totalDoseAwayFromShelter,MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(totalDoseAwayFromShelter,information.totalDoseAwayFromShelter,MAX_CALCULATED_PERCENT_ERROR);	

		AssertMore.assertEquals(100*dosePriorToWarning/totalDoseAwayFromShelter,information.percentOfTotalPriorToWarning,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseWhilePackingUp/totalDoseAwayFromShelter,information.percentOfTotalWhilePackingUp,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseDuringTransit/totalDoseAwayFromShelter,information.percentOfTotalDuringTransit,MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(100*doseAtBase/totalDoseAwayFromShelter,information.percentOfTotalAtBase,MAX_CALCULATED_PERCENT_ERROR);
	
		
	}


	public void testSimulateAnAstronautOnTheMoon_PART_2() {	
		Time timeDelayBetweenEvents = Time.inDays(1);    	
		double K_1 = 3.2E15;
		double gamma_1 = 4;
		double E0_1 = 10;
		double A_1 = .5;
		double B1_1 = 2;
		double B2_1 = 1.5;

		double K_2 = 3.75e8;
		double gamma_2 = 1;
		double E0_2 = 500;
		double A_2 = .5;
		double B1_2 = 3;
		double B2_2 = 3;
	
		/* Set the radiation type th at the astronaut receives */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.EYE;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.ONE;	
		Time timePriorToWarning = Time.inDays(-.5);	
		double totalEventDosePriorToWarning_1 = (K_1/2)*6.7018988E-14;
		double totalEventDosePriorToWarning_2 = (K_2/2)*0.00000038013937;
				
		Time timeToPackUp = Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.ONE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*6.7018988E-14;
		double totalEventDoseWhilePackingUp_2 = (K_2/2)*0.00000038013937;
				
		Time timeInTransit = Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.FIVE;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*1.2130223E-16;
		double totalEventDoseWhileInTransit_2 = (K_2/2)*0.00000023445476;
				
		Thickness thicknessAtBase = Thickness.TEN;
		double totalEventDoseAtBase_1 = (K_1/2)*5.5321661E-17;
		double totalEventDoseAtBase_2 = (K_2/2)*0.00000018136281;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 = 0.333333;
		double timeEvolutionFlux_2 = 0.14883;
		
		/* The integrated time evolution flux only during certain periods of the event */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 = 0.0880804;
		double timeEvolutionIntegralFluxPriorToWarning_2 = 0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 = 0.233815;
		double timeEvolutionIntegralFluxWhilePackingUp_2 = 0.073272;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 = 0.0104314;
		double timeEvolutionIntegralFluxWhileInTransit_2 = 0.0754418;
		
		double timeEvolutionIntegralFluxAtBase_1 = 0.00100639;
		double timeEvolutionIntegralFluxAtBase_2 = 0.000116154;
		testSimulateAstronautOnTheMoon_HELPER(timeDelayBetweenEvents, K_1, gamma_1, E0_1, A_1, B1_1,
			B2_1, K_2, gamma_2, E0_2, A_2, B1_2, B2_2, radiationType, bodyPart, thicknessPriorToWarning,
			timePriorToWarning, totalEventDosePriorToWarning_1, totalEventDosePriorToWarning_2, timeToPackUp,
			thicknessWhilePackingUp, totalEventDoseWhilePackingUp_1, totalEventDoseWhilePackingUp_2,
			timeInTransit, thicknessWhileInTransit, totalEventDoseWhileInTransit_1, totalEventDoseWhileInTransit_2,
			thicknessAtBase, totalEventDoseAtBase_1, totalEventDoseAtBase_2, timeEvolutionFlux_1,
			timeEvolutionFlux_2, timeEvolutionIntegralFluxPriorToWarning_1, timeEvolutionIntegralFluxPriorToWarning_2,
			timeEvolutionIntegralFluxWhilePackingUp_1, timeEvolutionIntegralFluxWhilePackingUp_2, timeEvolutionIntegralFluxWhileInTransit_1,
			timeEvolutionIntegralFluxWhileInTransit_2, timeEvolutionIntegralFluxAtBase_1,
			timeEvolutionIntegralFluxAtBase_2);				
	}
	
	

	public void testSimulateAnAstronautOnTheMoon_PART_3() {	

		Time timeDelayBetweenEvents = Time.inDays(.25);    	
		double K_1 = 1.32E12;
		double gamma_1 = 3.5;
		double E0_1 = 30;
		double A_1 = .5 ;
		double B1_1 = 2;
		double B2_1 = 2;

		double K_2 = 1.17E10;
		double gamma_2 = 2;
		double E0_2 = 250;
		double A_2 = .5;
		double B1_2 = 1.5;
		double B2_2 = 2;
	
		/* Set the radiation type th at the astronaut recieves */
		RadiationType radiationType = RadiationType.REM;
		BodyPart bodyPart = BodyPart.SKIN;
		
		/* 
		 * Set the thicknesses and get the total event doses, or the total event dose 
		 * if somebody was only doing that on thing during the entire event 
		 */
		Thickness thicknessPriorToWarning = Thickness.POINT_THREE;	
		Time timePriorToWarning =Time.inDays(.5);
		double totalEventDosePriorToWarning_1 = (K_1/2)*0.00000000027867408;
		double totalEventDosePriorToWarning_2 = (K_2/2)*0.00000003062495;
				
		Time timeToPackUp =Time.inDays(1);
		Thickness thicknessWhilePackingUp = Thickness.POINT_THREE;
		double totalEventDoseWhilePackingUp_1 = (K_1/2)*0.00000000027867408;
		double totalEventDoseWhilePackingUp_2 = (K_2/2)*0.00000003062495;
				
		Time timeInTransit =Time.inDays(.5);
		Thickness thicknessWhileInTransit = Thickness.THIRTY ;
		double totalEventDoseWhileInTransit_1 = (K_1/2)*9.2348275E-16;
		double totalEventDoseWhileInTransit_2 = (K_2/2)*0.00000000015628944;
				
		Thickness thicknessAtBase = Thickness.ONE;
		double totalEventDoseAtBase_1 = (K_1/2)*0.0000000000148706;
		double totalEventDoseAtBase_2 = (K_2/2)*0.0000000074871709;
		
		/* The total time evolution flux for each of the events */
		double timeEvolutionFlux_1 =0.221557;
		double timeEvolutionFlux_2 =0.226601;
		
		/* The integrated time evolution flux only during certain periods of the eventt */
		
		double timeEvolutionIntegralFluxPriorToWarning_1 =0;
		double timeEvolutionIntegralFluxPriorToWarning_2 =0;

		double timeEvolutionIntegralFluxWhilePackingUp_1 =0.0947362;
		double timeEvolutionIntegralFluxWhilePackingUp_2 =0.0308441;
		
		double timeEvolutionIntegralFluxWhileInTransit_1 =0.116626;
		double timeEvolutionIntegralFluxWhileInTransit_2 =0.160634;
		
		double timeEvolutionIntegralFluxAtBase_1 =0.0101942;
		double timeEvolutionIntegralFluxAtBase_2 =0.035123;
		
		testSimulateAstronautOnTheMoon_HELPER(timeDelayBetweenEvents, K_1, gamma_1, E0_1, A_1, B1_1,
			B2_1, K_2, gamma_2, E0_2, A_2, B1_2, B2_2, radiationType, bodyPart, thicknessPriorToWarning,
			timePriorToWarning, totalEventDosePriorToWarning_1, totalEventDosePriorToWarning_2, timeToPackUp,
			thicknessWhilePackingUp, totalEventDoseWhilePackingUp_1, totalEventDoseWhilePackingUp_2,
			timeInTransit, thicknessWhileInTransit, totalEventDoseWhileInTransit_1, totalEventDoseWhileInTransit_2,
			thicknessAtBase, totalEventDoseAtBase_1, totalEventDoseAtBase_2, timeEvolutionFlux_1,
			timeEvolutionFlux_2, timeEvolutionIntegralFluxPriorToWarning_1, timeEvolutionIntegralFluxPriorToWarning_2,
			timeEvolutionIntegralFluxWhilePackingUp_1, timeEvolutionIntegralFluxWhilePackingUp_2, timeEvolutionIntegralFluxWhileInTransit_1,
			timeEvolutionIntegralFluxWhileInTransit_2, timeEvolutionIntegralFluxAtBase_1,
			timeEvolutionIntegralFluxAtBase_2);				
	}
	
	
	
	
	private void testSimulateAstronautOnTheMoon_HELPER(
			Time timeDelayBetweenEvents,
			double K_1,
			double gamma_1,
			double E0_1,
			double A_1,
			double B1_1,
			double B2_1,
			double K_2,
			double gamma_2,
			double E0_2,
			double A_2,
			double B1_2,
			double B2_2,
			RadiationType radiationType,
			BodyPart bodyPart,
			Thickness thicknessPriorToWarning,
			Time timePriorToWarning,
			double totalEventDosePriorToWarning_1,
			double totalEventDosePriorToWarning_2,
			Time timeToPackUp,
			Thickness thicknessWhilePackingUp,
			double totalEventDoseWhilePackingUp_1,
			double totalEventDoseWhilePackingUp_2,					
			Time timeInTransit,
			Thickness thicknessWhileInTransit,
			double totalEventDoseWhileInTransit_1 ,
			double totalEventDoseWhileInTransit_2,					
			Thickness thicknessAtBase,
			double totalEventDoseAtBase_1,
			double totalEventDoseAtBase_2,
			double timeEvolutionFlux_1,
			double timeEvolutionFlux_2,
			double timeEvolutionIntegralFluxPriorToWarning_1,
			double timeEvolutionIntegralFluxPriorToWarning_2,
			double timeEvolutionIntegralFluxWhilePackingUp_1,
			double timeEvolutionIntegralFluxWhilePackingUp_2,			
			double timeEvolutionIntegralFluxWhileInTransit_1,
			double timeEvolutionIntegralFluxWhileInTransit_2,			
			double timeEvolutionIntegralFluxAtBase_1,
			double timeEvolutionIntegralFluxAtBase_2) {
		
		
		/* all parameters to do the test have been entered, run through and make sure everything is good */
		
		/* set event */
		DoubleEvent event = new DoubleEvent();
		event.setK_1(K_1);
		event.setGamma_1(gamma_1);
		event.setE0_1(E0_1);
		event.setA_1(A_1);
		event.setB1_1(B1_1);
		event.setB2_1(B2_1);
		event.setK_2(K_2);
		event.setGamma_2(gamma_2);
		event.setE0_2(E0_2);
		event.setA_2(A_2);
		event.setB1_2(B1_2);
		event.setB2_2(B2_2);		
		event.setTimeDelayBetweenEvents(timeDelayBetweenEvents);

		/* Run simulation */
		DoseInformation information = event.simulateAstronautOnTheMoon(radiationType, bodyPart,
			timePriorToWarning,thicknessPriorToWarning,timeToPackUp,thicknessWhilePackingUp,timeInTransit,
			thicknessWhileInTransit,thicknessAtBase,new CumulativeDoseGraph());
		
		/* Test that all the event radiation doses are correct */
		AssertMore.assertEquals(totalEventDosePriorToWarning_1,
			event.getDose_1(thicknessPriorToWarning,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhilePackingUp_1,
			event.getDose_1(thicknessWhilePackingUp,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhileInTransit_1,
			event.getDose_1(thicknessWhileInTransit,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseAtBase_1,
			event.getDose_1(thicknessAtBase,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDosePriorToWarning_2,
			event.getDose_2(thicknessPriorToWarning,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhilePackingUp_2,
			event.getDose_2(thicknessWhilePackingUp,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhileInTransit_2,
			event.getDose_2(thicknessWhileInTransit,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseAtBase_2,
			event.getDose_2(thicknessAtBase,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDosePriorToWarning_1+totalEventDosePriorToWarning_2,
			event.getDose(thicknessPriorToWarning,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhilePackingUp_1+totalEventDoseWhilePackingUp_2,
			event.getDose(thicknessWhilePackingUp,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseWhileInTransit_1+totalEventDoseWhileInTransit_2,
			event.getDose(thicknessWhileInTransit,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);
		AssertMore.assertEquals(totalEventDoseAtBase_1+totalEventDoseAtBase_2,
			event.getDose(thicknessAtBase,radiationType,bodyPart,DoseLocation.LUNAR_SURFACE),
			MAX_EXACT_PERCENT_ERROR
		);

		/* Test that the time evolution fluxes are correct */
		AssertMore.assertEquals(timeEvolutionFlux_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(10)),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionFlux_2,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(10)),
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Test that the fractions of time evolution fluxes are correct */
		AssertMore.assertEquals(timeEvolutionIntegralFluxPriorToWarning_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.negative(timePriorToWarning)),
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionIntegralFluxPriorToWarning_2,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.negative(timePriorToWarning)),
			MAX_CALCULATED_PERCENT_ERROR			
		);
		
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhilePackingUp_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(
				Time.negative(timePriorToWarning),
				Time.add(Time.negative(timePriorToWarning),timeToPackUp)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhilePackingUp_2,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(
				Time.negative(timePriorToWarning),
				Time.add(Time.negative(timePriorToWarning),timeToPackUp)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhileInTransit_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(
				Time.add(Time.negative(timePriorToWarning),timeToPackUp),
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionIntegralFluxWhileInTransit_2,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(
				Time.add(Time.negative(timePriorToWarning),timeToPackUp),
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit)
			), MAX_CALCULATED_PERCENT_ERROR
		);

		AssertMore.assertEquals(timeEvolutionIntegralFluxAtBase_1,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit),
				Time.inDays(10)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(timeEvolutionIntegralFluxAtBase_2,
			event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(
				Time.add(Time.add(Time.negative(timePriorToWarning),timeToPackUp),timeInTransit),
				Time.inDays(10)
			), MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Now, test to see if the simulation works right */
		double dosePriorToWarning = 
			totalEventDosePriorToWarning_1*
				(timeEvolutionIntegralFluxPriorToWarning_1/timeEvolutionFlux_1)+
			totalEventDosePriorToWarning_2*
				(timeEvolutionIntegralFluxPriorToWarning_2/timeEvolutionFlux_2);			
		AssertMore.assertEquals(
			dosePriorToWarning,
			information.dosePriorToWarning, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		double doseWhilePackingUp = 
			totalEventDoseWhilePackingUp_1*
			(timeEvolutionIntegralFluxWhilePackingUp_1/timeEvolutionFlux_1)+
			totalEventDoseWhilePackingUp_2*
			(timeEvolutionIntegralFluxWhilePackingUp_2/timeEvolutionFlux_2);		
		AssertMore.assertEquals(
			doseWhilePackingUp,
			information.doseWhilePackingUp, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		double doseWhileInTransit = 
			totalEventDoseWhileInTransit_1*
			(timeEvolutionIntegralFluxWhileInTransit_1/timeEvolutionFlux_1)+
			totalEventDoseWhileInTransit_2*
			(timeEvolutionIntegralFluxWhileInTransit_2/timeEvolutionFlux_2);
		AssertMore.assertEquals(
			doseWhileInTransit,
			information.doseDuringTransit, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		double doseAtBase=
			totalEventDoseAtBase_1*
			(timeEvolutionIntegralFluxAtBase_1/timeEvolutionFlux_1)+
			totalEventDoseAtBase_2*
			(timeEvolutionIntegralFluxAtBase_2/timeEvolutionFlux_2);
		AssertMore.assertEquals(
			doseAtBase,
			information.doseAtBase, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Make sure total is correct */
		double totalDose=dosePriorToWarning+doseWhilePackingUp+doseWhileInTransit+doseAtBase;
		AssertMore.assertEquals(
				totalDose,
			information.totalDoseAwayFromShelter, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		
		/* Make sure percentages are right */
		AssertMore.assertEquals(
			100*dosePriorToWarning/totalDose,
			information.percentOfTotalPriorToWarning, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseWhilePackingUp/totalDose,
			information.percentOfTotalWhilePackingUp, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseWhilePackingUp/totalDose,
			information.percentOfTotalWhilePackingUp, 
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseWhileInTransit/totalDose,
			information.percentOfTotalDuringTransit,
			MAX_CALCULATED_PERCENT_ERROR
		);
		AssertMore.assertEquals(
			100*doseAtBase/totalDose,
			information.percentOfTotalAtBase,
			MAX_CALCULATED_PERCENT_ERROR
		);
		
	}
	
	public void testDoesTimeEvolutionIntegralFluxDecreaseFastEnough() {
		DoubleEvent event = new DoubleEvent();
		
		event.setEnergySpectrumIntegralFluence_1(1E10);
		event.setGamma_1(2);
		event.setE0_1(100);
		event.setEmin(10);

		event.setA_1(3);
		event.setB1_1(4);
		event.setB2_1(2);
		

		event.setEnergySpectrumIntegralFluence_2(0);
		event.setGamma_2(2);
		event.setE0_2(100);

		event.setA_2(3);
		event.setB1_2(4);
		event.setB2_2(2);
		
		
		
		AssertMore.assertEquals(1.29233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.390142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.29233*.01>0.390142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2_1(1);
		AssertMore.assertEquals(1.98311,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.8079,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.98311*.01>1.8079,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		
		event.setA_1(.5);
		AssertMore.assertEquals(11.649,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.259828,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(11.649*.01>0.259828,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

		event.setA_1(.25);
		AssertMore.assertEquals(5.9999,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000979444,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.9999*.01>0.0000979444,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB1_1(10);
		AssertMore.assertEquals(897392.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8824.08,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(897392.*.01>8824.08,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_1(11);
		AssertMore.assertEquals(9.76578E6,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(188235.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.76578E6*.01>188235.,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2_1(.9);
		AssertMore.assertEquals(2.12754E8,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.67902E7,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.12754E8*.01>5.67902E7,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_1(.5);
		event.setB2_1(.5);
		AssertMore.assertEquals(0.823263,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0433142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.823263*.01>0.0433142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_1(1);
		AssertMore.assertEquals(1.95894,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.202575,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.95894*.01>0.202575,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_1(.5);
		event.setB1_1(1);
		event.setB2_1(1);		
		AssertMore.assertEquals(0.49975,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000209762,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.49975*.01>0.000209762,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_1(2);
		AssertMore.assertEquals(1.42541,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.176298,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.42541*.01>0.176298,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_1(1.7);
		AssertMore.assertEquals(1.34622,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.128003,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.34622*.01>0.128003,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_1(1.8);
		AssertMore.assertEquals(1.3772,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.144543,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3772*.01>0.144543,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_1(1.75);
		AssertMore.assertEquals(1.36233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.136313,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36233*.01>0.136313,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	
		event.setA_1(1.78);
		AssertMore.assertEquals(1.3714,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.141262,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3714*.01>0.141262,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	

		// repeat with the second event only
		
		event.setEnergySpectrumIntegralFluence_2(1E10);
		event.setGamma_2(2);
		event.setE0_2(100);
		event.setA_2(3);
		event.setB1_2(4);
		event.setB2_2(2);		

		event.setEmin(10);

		event.setTimeDelayBetweenEvents(Time.inDays(0));

		event.setEnergySpectrumIntegralFluence_1(0);		
		AssertMore.assertEquals(0,event.getC_1(),MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(1.29233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.390142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.29233*.01>0.390142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2_2(1);
		AssertMore.assertEquals(1.98311,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.8079,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.98311*.01>1.8079,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		
		event.setA_2(.5);
		AssertMore.assertEquals(11.649,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.259828,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(11.649*.01>0.259828,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

		event.setA_2(.25);
		AssertMore.assertEquals(5.9999,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000979444,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.9999*.01>0.0000979444,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB1_2(10);
		AssertMore.assertEquals(897392.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8824.08,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(897392.*.01>8824.08,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_2(11);
		AssertMore.assertEquals(9.76578E6,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(188235.,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.76578E6*.01>188235.,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setB2_2(.9);
		AssertMore.assertEquals(2.12754E8,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5.67902E7,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.12754E8*.01>5.67902E7,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_2(.5);
		event.setB2_2(.5);
		AssertMore.assertEquals(0.823263,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0433142,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.823263*.01>0.0433142,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setB1_2(1);
		AssertMore.assertEquals(1.95894,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.202575,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.95894*.01>0.202575,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_2(.5);
		event.setB1_2(1);
		event.setB2_2(1);		
		AssertMore.assertEquals(0.49975,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.000209762,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.49975*.01>0.000209762,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_2(2);
		AssertMore.assertEquals(1.42541,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.176298,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.42541*.01>0.176298,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_2(1.7);
		AssertMore.assertEquals(1.34622,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.128003,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.34622*.01>0.128003,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_2(1.8);
		AssertMore.assertEquals(1.3772,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.144543,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3772*.01>0.144543,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setA_2(1.75);
		AssertMore.assertEquals(1.36233,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.136313,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.36233*.01>0.136313,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
	
		event.setA_2(1.78);
		AssertMore.assertEquals(1.3714,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.141262,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.3714*.01>0.141262,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

		event.setA_2(.5);
		event.setB1_2(2);
		event.setB2_2(1);
		event.setTimeDelayBetweenEvents(Time.inDays(1));
		AssertMore.assertEquals(0.986246,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0109846,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.986246*.01>0.0109846,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		
		event.setA_2(1);
		AssertMore.assertEquals(1.52379,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.226903,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.52379*.01>0.226903,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

		event.setTimeDelayBetweenEvents(Time.inDays(2.5));
		AssertMore.assertEquals(0.912374,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.445932,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.912374*.01>0.445932,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setTimeDelayBetweenEvents(Time.inDays(2.6));
		AssertMore.assertEquals(0.860583,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.459938,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.860583*.01>0.459938,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

		event.setTimeDelayBetweenEvents(Time.inDays(1));
		event.setA_2(.3);
		AssertMore.assertEquals(0.5999,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0000948798,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.5999*.01>0.0000948798,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());

		event.setTimeDelayBetweenEvents(Time.inDays(1));
		event.setA_2(.45);
		AssertMore.assertEquals(0.893869,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.00513779,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.893869*.01>0.00513779,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(true,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

		event.setTimeDelayBetweenEvents(Time.inDays(1));
		event.setA_2(.5);
		AssertMore.assertEquals(0.986246,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.0109846,event.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6)),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.986246*.01>0.0109846,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		AssertMore.assertEquals(false,event.doesTimeEvolutionIntegralFluxDecreaseFastEnough());
		

	}
}
