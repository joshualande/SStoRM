package SStoRM;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static void main(String[] args) {
		junit.swingui.TestRunner.run(AllTests.class);
	}

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for SStoRMv1");
		//$JUnit-BEGIN$
		suite.addTestSuite(CompareTest.class);
		suite.addTestSuite(ConvertTest.class);
		suite.addTestSuite(SolarParticleEventInterfaceTest.class);
		suite.addTestSuite(EnergySpectrumTest.class);
		suite.addTestSuite(TimeTest.class);
		suite.addTestSuite(SolarParticleEventTest.class);
		suite.addTestSuite(InterpolationTest.class);
		suite.addTestSuite(EventWithShockEnhancedPeakTest.class);
		suite.addTestSuite(ShockEnhancedPeakTimeEvolutionTest.class);
		suite.addTestSuite(RadiationDoseValuesTest.class);
		suite.addTestSuite(TimeEvolutionTest.class);
		suite.addTestSuite(DoubleEventTest.class);
		suite.addTestSuite(LogTest.class);
		//$JUnit-END$
		return suite;
	}
}
