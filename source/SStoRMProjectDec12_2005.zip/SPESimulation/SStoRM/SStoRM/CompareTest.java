package SStoRM;

import junit.framework.TestCase;

public class CompareTest extends TestCase {
	private static final double MAX_PERCENT_ERROR = .0000000000001; // a really small percent error
	
	public void testPercentError() {
		
		try { // Call should throw an error
			Compare.percentError(Double.NaN,Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			Compare.percentError(1,Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			Compare.percentError(Double.NaN,1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		
		
		AssertMore.assertEquals(0.50,              Compare.percentError(20.0,40.0), MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1.0,               Compare.percentError(40.0,20.0), MAX_PERCENT_ERROR);
		AssertMore.assertEquals(0.050420168067227, Compare.percentError(2.5,2.38),  MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.percentError(2.38,2.5),  0.048,             MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.percentError(11,10),     0.1,               MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.percentError(10,11),   1./11,               MAX_PERCENT_ERROR);
		
		// test really extreme cases
		AssertMore.assertEquals(Compare.percentError(1,1),       0.,                 MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.percentError(11,11),     0.,                 MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.percentError(0,1),       1.0,                MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.percentError(0,9),       1.0,                MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.percentError(0,0),       0.0,                MAX_PERCENT_ERROR);
		AssertMore.assertTrue(Double.isInfinite(Compare.percentError(1,0)));
	}
	
	public void testMaxPercentError() {
		AssertMore.assertEquals(Compare.maxPercentError(20,40),    1,                 MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.maxPercentError(40,20),    1,                 MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.maxPercentError(2.38,2.5), 0.050420168067227, MAX_PERCENT_ERROR);
		AssertMore.assertEquals(Compare.maxPercentError(10,11),    0.1,               MAX_PERCENT_ERROR);
		AssertMore.assertEquals(1,Compare.maxPercentError(0,1));	
		AssertMore.assertEquals(1,Compare.maxPercentError(1,0));	
		AssertMore.assertEquals(.1,Compare.maxPercentError(0,.1));
		AssertMore.assertEquals(100,Compare.maxPercentError(0,100));
		AssertMore.assertEquals(.0001,Compare.maxPercentError(.0001,0));		
		AssertMore.assertEquals(0,Compare.maxPercentError(0,0));
	}

}
