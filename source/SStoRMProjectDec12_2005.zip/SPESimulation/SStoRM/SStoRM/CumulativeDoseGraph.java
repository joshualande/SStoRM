package SStoRM;

import java.awt.Color;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleInsets;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.ui.LengthAdjustmentType;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.TextAnchor;

/**
 * This graph will graph cumulative dose during an "exercise". It does so by having the user keep track
 * of doses during the event and then passing successive cumulative dose values into {@link #addCumulativeDose(Time, double)}.
 * So to use this chart, you would say:
 * <pre>
 * 	
 * </pre>
 * @author Joshua.Lande
 */
public class CumulativeDoseGraph {

	private XYSeries yourDoseSeries=null;
    private XYSeriesCollection dataset=null;
    private JFreeChart chart=null;
    private XYPlot plot=null;
    private static final double LOWER_RANGE = .1;
	
    public CumulativeDoseGraph() {
        dataset = new XYSeriesCollection();
        chart = createChart(dataset);
        yourDoseSeries = new XYSeries("Cumulative Dose"); // store the series for safe keeping.
        dataset.addSeries(yourDoseSeries); // add series to data set 
        
    	plot = (XYPlot) chart.getPlot(); // set shapes of yourSPE to be visible.
    	XYLineAndShapeRenderer renderer=(XYLineAndShapeRenderer)plot.getRenderer();
    	 renderer.setSeriesPaint(0, Color.BLACK);
    }

    /**
     * This method puts the cumulative dose graph into a chart panel, 
     * disables zooming the graph, disables the right
     * click popup menu of the graph, and returns the panel for use.
     * @return A ChartPanel 
     */
    public ChartPanel getChartPanel() {
    	ChartPanel panel= new ChartPanel(chart);
    	panel.setDomainZoomable(false);
    	panel.setRangeZoomable(false);
    	panel.setPopupMenu(null); 
        return panel;
    }   
    
    public void addCumulativeDose(Time time, double dose) {    
    	if (dose<=0) return; // do not plot 0 dose values on a log graph.
    	if (time.getDays() < 0 || time.getDays()> 10) return; // only add values between 0 and 10 days.
        yourDoseSeries.add(time.getDays(),dose); // add dose
        if (dose > Math.max(LOWER_RANGE,plot.getRangeAxis().getUpperBound())) // set range to go from .1 to largest point found.
        	plot.getRangeAxis().setRange(LOWER_RANGE,Log.roundUpOrderOfMagnitude(dose));
    }
    
    /**
     * Clears all data , rewrites the labels and adds the correct limits to the graph.
     */
    public void reset(RadiationType remOrRad, BodyPart skinEyeOrBFO) {
		yourDoseSeries.clear();
		plot.getRangeAxis().setLabel(skinEyeOrBFO.toString()+" "+remOrRad.toString()+" ("+remOrRad.getUnits()+")");
		chart.setTitle("Cumulative "+skinEyeOrBFO.toString()+" "+remOrRad.toString()+" ("+remOrRad.getUnits()+")");
		
        plot.clearDomainMarkers(); // remove bad markers
        plot.clearRangeMarkers();
        double largestLimitAdded = Limits.addLimitsToAPlot(plot,skinEyeOrBFO,remOrRad,LeftOrRight.LEFT); // add limits
        if (!Double.isNaN(largestLimitAdded)) { // if a limit was added
        	double upperLimit = Math.max(LOWER_RANGE, Log.roundUpOrderOfMagnitude(largestLimitAdded)); 
        	plot.getRangeAxis().setRange(LOWER_RANGE,upperLimit); // set range to go to the upper limit
        }
    }    
    
    public void addTimeMarker(Time time, String label) {
    	Marker marker;
    	marker = new ValueMarker(time.getDays());
        marker.setLabelOffsetType(LengthAdjustmentType.EXPAND);
    	marker.setLabel(label);
    	marker.setLabelAnchor(RectangleAnchor.BOTTOM);
    	marker.setLabelTextAnchor(TextAnchor.BOTTOM_CENTER);
    	plot.addDomainMarker(marker);
    }

    /**
     * Creates a chart when given an XYDataset. It is given the proper title, x axis, y axis, 
     * and set to the correct domain and range.
     * @param dataset The data for the chart.
     * @return A chart.
     */
    private static JFreeChart createChart(XYDataset dataset) { 
        JFreeChart chart = ChartFactory.createXYLineChart(
            null,  // chart title
            "Time (days)", 					// x-axis label
            "",  							// y-axis label
            dataset,                 		// data
            PlotOrientation.VERTICAL,
            false,                     		// include legend
            true,                     		// Tooltips
            false                     		// Urls
        );
        chart.setBackgroundPaint(Color.white);
        XYPlot plot = (XYPlot) chart.getPlot();
        plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
        // remove gridlines (the dotted lines in the background of the graph)
        plot.setDomainGridlinesVisible(false);
        plot.setRangeGridlinesVisible(false);
        // set log axis for the domain & range
        LogarithmicAxis rangeAxis=new LogarithmicAxis("");
        rangeAxis.setLog10TickLabelsFlag(true);
        plot.setRangeAxis(rangeAxis);
                 
        LogarithmicAxis domainAxis= new LogarithmicAxis("Time (days)");
        domainAxis.setRange(0.01,10.0);
        plot.setDomainAxis(domainAxis);
        return chart;  
    }
    
 
}
