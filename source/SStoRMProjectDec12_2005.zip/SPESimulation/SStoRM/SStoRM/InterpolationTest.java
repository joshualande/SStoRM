package SStoRM;

import junit.framework.TestCase;

public class InterpolationTest extends TestCase {
	
	public void testLinearXValueKnown() {
		Point point1;
		Point point2;
		
		point1=new Point(0,5,0);
		point2=new Point(2,5,2);
		AssertMore.assertEquals(new Point(1,5,1), Interpolation.linearXValueKnown(1.,point1,point2));
	
		point1=new Point(0,2,0);
		point2=new Point(2,2,6);
		AssertMore.assertEquals(new Point(1,2,3), Interpolation.linearXValueKnown(1.,point1,point2));

		point1=new Point(0,0,0);
		point2=new Point(2,0,0);
		AssertMore.assertEquals(new Point(1,0,0), Interpolation.linearXValueKnown(1.,point1,point2));

		point1=new Point(0,1,0);
		point2=new Point(6,1,6);
		AssertMore.assertEquals(new Point(1,1,1),Interpolation.linearXValueKnown(1.,point1,point2));
		
		
		AssertMore.assertNotEquals(new Point(1,1,1.1),Interpolation.linearXValueKnown(1.,point1,point2));
		
		
		point1=new Point(0,1,0);

		try { // Call should throw an error
			Interpolation.linearXValueKnown(1.,point1,point1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		AssertMore.assertEquals(point1,Interpolation.linearXValueKnown(0.,point1,point1));
		
	}

	public void testLinearYValueKnown() {
		Point point1;
		Point point2;
		
		point1=new Point(1,0,0);
		point2=new Point(1,2,2);
		AssertMore.assertEquals(new Point(1,1,1),Interpolation.linearYValueKnown(1.,point1,point2));
	
		point1=new Point(1,0,0);
		point2=new Point(1,2,6);
		AssertMore.assertEquals(new Point(1,1,3),Interpolation.linearYValueKnown(1.,point1,point2));

		point1=new Point(1,0,0);
		point2=new Point(1,2,0);
		AssertMore.assertEquals(new Point(1,1,0), Interpolation.linearYValueKnown(1.,point1,point2));

		point1=new Point(1,0,0);
		point2=new Point(1,6,6);
		AssertMore.assertEquals(new Point(1,1,1), Interpolation.linearYValueKnown(1.,point1,point2));		
		AssertMore.assertNotEquals(new Point(1,1,1.1),Interpolation.linearYValueKnown(1.,point1,point2));
		
		point1=new Point(1,0,0);
		point2=new Point(1,0,0);
		
		try { // Call should throw an error
			Interpolation.linearXValueKnown(0.,point1,point2);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		
		AssertMore.assertEquals(point1,Interpolation.linearXValueKnown(1.,point1,point2));
	}

	public void testBilinear() {
		Point upperLeft;
		Point upperRight;
		Point lowerLeft;
		Point lowerRight;
		
		
		upperLeft = new Point(0,1,1); 	upperRight= new Point(1,1,1);
		lowerLeft = new Point(0,0,1);	lowerRight= new Point(1,0,1);
		AssertMore.assertEquals(new Point(.5,.5,1),
				Interpolation.bilinear(0.5,0.5,upperLeft,upperRight,lowerLeft,lowerRight));
		
		upperLeft = new Point(0,1,2); 	upperRight= new Point(1,1,0);
		lowerLeft = new Point(0,0,2);	lowerRight= new Point(1,0,0);
		AssertMore.assertEquals(new Point(.5,.5,1),
			Interpolation.bilinear(0.5,0.5,upperLeft,upperRight,lowerLeft,lowerRight));
		
		upperLeft = new Point(0,1,2); 	upperRight= new Point(1,1,2);
		lowerLeft = new Point(0,0,0);	lowerRight= new Point(1,0,0);
		AssertMore.assertEquals(new Point(.5,.5,1),
			Interpolation.bilinear(0.5,0.5,upperLeft,upperRight,lowerLeft,lowerRight));
		
		upperLeft = new Point(0,1,2); 	upperRight= new Point(1,1,0);
		lowerLeft = new Point(0,0,0);	lowerRight= new Point(1,0,0);
		AssertMore.assertEquals(new Point(.5,.5,.5),
			Interpolation.bilinear(0.5,0.5,upperLeft,upperRight,lowerLeft,lowerRight));

		upperLeft = new Point(0,1,4); 	upperRight= new Point(1,1,0);
		lowerLeft = new Point(0,0,0);	lowerRight= new Point(1,0,4);
		AssertMore.assertEquals(new Point(.5,.5,2),
			Interpolation.bilinear(0.5,0.5,upperLeft,upperRight,lowerLeft,lowerRight));
		AssertMore.assertEquals(new Point(.5,.25,2),
			Interpolation.bilinear(0.5,0.25,upperLeft,upperRight,lowerLeft,lowerRight));
		AssertMore.assertEquals(new Point(.25,.25,1.5),
			Interpolation.bilinear(0.25,0.25,upperLeft,upperRight,lowerLeft,lowerRight));
		AssertMore.assertEquals(new Point(.75,.25,2.5),
				Interpolation.bilinear(0.75,0.25,upperLeft,upperRight,lowerLeft,lowerRight));
		

		upperLeft = new Point(0,10,4); 	upperRight= new Point(10,10,4);
		lowerLeft = new Point(0, 0,0);	lowerRight= new Point(10, 0,0);
		AssertMore.assertEquals(new Point(1,1,.4),
			Interpolation.bilinear(1,1,upperLeft,upperRight,lowerLeft,lowerRight));
	}

}
