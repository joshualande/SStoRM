package SStoRM;
/**
 * Object holds a double event. A double event is similar to a single solar particle event but stores and simulates
 * two events happening simultaneously, with a time delay between them. The default time delay is 0, or the events both start immediately.
 * 
 * This class uses the exponential curve <i>Fluence</i>(E)=k*E<sup>-gamma</sup><i>e</i><sup>
 * E/Eo</sup> to represent each energy spectrum. The energy spectrum of a SPE
 * represents the total number of particles at a given energy value as a function
 * of that energy value. It is essentially a frequency distribution. 
 * The integral of the energy spectrum is the
 * total number of particles of the SPE. The lower bounds of the integral 
 * (Emin) allows for the calculation of the total number of particles
 * above a certain energy value. The energy spectrum is internally stored inside a {@link EnergySpectrum} object.
 * <p>
 * The energy spectrum integral fluence and the K constant are intimately related. We can show that:
 * <pre>
 * K = (> Emin) integral fluence / (>Emin) integral fluence without K
 * </pre>
 * Where the energy spectrum integral fluence without K is found using specific E0 and gamma values. This means that
 * if the (>Emin) integral fluence (with K) is specified, K can be found from it. This class
 * allows for either K or the integral fluence to be specified, and the other to be calculated automatically behind the scenes.
 * <p>
 * This class also uses the curve 
 * <i>Flux</i>=C(t/A)<sup>B1</sup><i>e</i><sup>-(t/A)^B2</sup>
 * to store the first time evolution and
 * <i>Flux</i>=C(t-delay/A)<sup>B1</sup><i>e</i><sup>-(t-delay/A)^B2</sup>
 * to store the second time evolution. The delay in the second event allows for the two events to be offset.
 * represent the time evolution of the each SPE. The time evolution 
 * is a function of the total number of particles over the duration of the event.
 * The time evolution is stored in a {@link TimeEvolution} object. 
 * The integral time evolution flux is also the total number of particles. 
 * So C can be set automatically (as this class automatically does)
 * so that the >10 MeV energy spectrum integral fluence equals the time evolution graph's
 * integral flux. This is done with the formula:
 * <pre>
 * C_1 = Event 1 (>10 MeV) energy spectrum integral fluence/(event 1 time evolution integral flux from 0 to 10 days * 24*3600*4*pi)
 * C_2 = Event 2 (>10 MeV) energy spectrum integral fluence/(event 2 time evolution integral flux from 0 to 10 days * 24*3600*4*pi)
 * </pre>
 * This formula can be derived by equating the two integrals. The 24*3600 accounts for a conversion from days to
 * seconds and the 4*pi accounts for 4*pi steradians in free space. 
 * <p> * 
 * <p>
 * <b>Usage:</b>
 * <p>
 * You can create SPEs by saying:
 * <pre>
 * 	DoubleEvent SPE=new DoubleEvent("SPE Name");
 * </pre>
 * You can then specify the shape of the energy spectrum by
 * setting the K, gamma, and E0 values for each curve.
 * <pre>
 * //curve 1
 * SPE.setK_1(1e9);
 * SPE.setGamma_1(0);
 * SPE.setE0_1(30);
 * 
 * SPE.setEmin(50);
 * //curve 2
 * SPE.setK_2(2e9);
 * SPE.setGamma_2(.1);
 * SPE.setE0_2(35);
 * 
 * //sets Emin for both events
 * SPE.setEmin(50);
 * </pre>
 * This sets the energy spectrum of the event. The integral fluence above
 * the Emin value for each event can be calculated by saying:
 * <pre>
 * integralFluence_1=SPE.getEnergySpectrumIntegralFluence_1();
 * integralFluence_2=SPE.getEnergySpectrumIntegralFluence_2();
 * // or the total
 * integralFluence=SPE.getEnergySpectrumIntegralFluence();
 * </pre>
 * If you know what the integral fluence should be and know what the spectral shape of the event is,
 * you can specify the SPE without giving a K and K is automatically calculated so that the integral fluence
 * is set right.
 * <pre>
 * SPE.setGamma_1(0);
 * SPE.setE0_1(30);
 * SPE.setEmin_1(50);
 * SPE.setEnergySpectrumIntegralFluence_1(1.88E10); 
 * K = SPE.getK_1(); 
 * </pre>
 * <p>You can then set the time evolution of the SPE by saying:
 * <pre>
 * SPE.setA_1(.15);
 * SPE.setB1_1(2);
 * SPE.setB2_1(1);
 * SPE.setA_2(.15);
 * SPE.setB1_2(2);
 * SPE.setB2_2(1);
 * 
 * // Sets the time delay before the second event begins.
 * SPE.setTimeDelayBetweenEvents(Time.inDays(1));
 * </pre>
 * <p>The scaling factor (C) can now automatically be retrieved by saying
 * <pre>
 * C_1=SPE.getC_1();
 * C_2=SPE.getC_2();
 * </pre>
 * As a note, the following constraints are enforced:
 * <p>
 * K_1 and K_2 must be at least 0. Emin must be at least 10 and at most 1500. Gamma_1 and Gamma_2 must be at least 0 and at most
 * 4.125. E0_1 and E0_2 must be at least 10 and at most 1500. If either energy spectrum integral fluence is set, it must
 * be at least 0.
 * @author Joshua Lande
 */
public class DoubleEvent implements Comparable, SolarParticleEventInterface  {

	
	/**
	 * Object that holds all of the radiation dose values for a solar particle event.
	 * We can call methods on it to get out the doses.
	 * 
	 * <b>This object is incredibly memory intensive
	 * because it has to read in and hold over 2 meg
	 * of information about the solar particle event radiation doses.
	 * So, it will only be created when you explicitly 
	 * ask for a solar particle event's radiation dose.
	 * That way, if doses are not desired, it will not
	 * be necessary to load one into memory.
	 * </b>
	 */
	private RadiationDoseValues radiationDoseValues;
	
    /**
     * The name of the solar particle event.
     * <p>
     * To modify, see {@link #setName} and {@link #getName}. 
     */
	private String name="";

	/**
	 * Holds the first time evolution of the solar particle event.
	 */
    private TimeEvolution timeEvolution_1 = new TimeEvolution();
    
	/**
	 * Holds the second time evolution of the solar particle event.
	 */
    private TimeEvolution timeEvolution_2 = new TimeEvolution();
    
    /**
     * Holds the first energy spectrum of the solar particle event.
     */
    private EnergySpectrum energySpectrum_1 = new EnergySpectrum();
    
    /**
     * Holds the second energy spectrum of the solar particle event.
     */
    private EnergySpectrum energySpectrum_2 = new EnergySpectrum();
    
    /**
     * Tries to set a value for the first C (C_1).
     * C_1 is calculated so that the integral fluence of the energy spectrum of the first event
     * equals the integral flux of the time evolution curve of the first event. 
     * <p>
     * C_1 is calculated this way so that the total number of particles
     * from the first energy spectrum (the integral fluence) and the total number of
     * particles from the first time evolution (the integral flux) are the same. 
     * This ensure that the 2 SPE curves are really talking
     * about the same event.
     * <p>
     * The formula used is C_1 = the >10 MeV integral fluence of the first energy spectrum divided
     * by the Integral flux of the first time evolution of the event (from 0 to 10 days)
     * and then again by 4 days worth of seconds * 4 pi steradians.
     * <p>
     * If C_1 cannot be set (for example, some parameters are not yet initialized), nothing happens
     * and the function returns with no change. C is not set and no errors are thrown
     */
    private void attemptToResetC_1() {
    	try {
    		timeEvolution_1.setC(
    				energySpectrum_1.getIntegralFluence(10.0) // Cache new C value
    				/(timeEvolution_1.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0.0),Time.inDays(10.0))*24*3600*4*Math.PI)
			);
    	} catch (Exception e) { }
    }

    /**
     * Tries to set a value for the second C (C_2).
     * C_2 is calculated so that the integral fluence of the energy spectrum of the second event
     * equals the integral flux of the time evolution curve of the second event. 
     * <p>
     * C_2 is calculated this way so that the total number of particles
     * from the second energy spectrum (the integral fluence) and the total number of
     * particles from the second time evolution (the integral flux) are the same. 
     * This ensure that the 2 SPE curves are really talking
     * about the same event.
     * <p>
     * The formula used is C_2 = the >10 MeV integral fluence of the second energy spectrum divided
     * by the Integral flux of the second time evolution of the event (from 0 to 10 days)
     * and then again by 4 days worth of seconds * 4 pi steradians.
     * <p>
     * If C_2 cannot be set (for example, some parameters are not yet initialized), nothing happens
     * and the function returns with no change. C is not set and no errors are thrown
     */
    private void attemptToResetC_2() {
    	try {
    		timeEvolution_2.setC(
    				energySpectrum_2.getIntegralFluence(10.0) // Cache new C value
    				/(timeEvolution_2.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0.0),Time.inDays(10.0))*24*3600*4*Math.PI)
			);
    	} catch (Exception e) { }
    }
    
    
	/**
	 * Tests weather two DoubleEvents are equal. They are equal only if each event
	 * has the same energy spectrum and time evolution.
	 * The name dose not matter in the comparison.
	 */
	public boolean equals(Object anObject){
		if (anObject instanceof DoubleEvent) {
			try {
				DoubleEvent otherEvent=(DoubleEvent)anObject;
				return  (
		    		this.timeEvolution_1.equals(otherEvent.timeEvolution_1) &&
		    		this.energySpectrum_1.equals(otherEvent.energySpectrum_1) &&
		    		this.timeEvolution_2.equals(otherEvent.timeEvolution_2) &&
		    		this.energySpectrum_2.equals(otherEvent.energySpectrum_2) 
				);
			} catch (Exception exception) { }
		}	
		return false;
	}
	
	/**
	 * Performs the expected clone of a DoubleEvent.
	 */
	public Object clone() {   
       	try {
            DoubleEvent newEvent = new DoubleEvent(this.getName());
       		newEvent.energySpectrum_1 = (EnergySpectrum)this.energySpectrum_1.clone();
       		newEvent.timeEvolution_1  = (TimeEvolution )this.timeEvolution_1.clone();
       		newEvent.energySpectrum_2 = (EnergySpectrum)this.energySpectrum_2.clone();
       		newEvent.timeEvolution_2  = (TimeEvolution )this.timeEvolution_2.clone();
       		return newEvent;
       	} catch (Exception exception) {
			return null;
		}
    }	
	    
    /** 
     * compares a SolarParticleEventInterface to another SolarParticleEventInterface
     * based on the value of their energy spectrum integral fluence of each event. The
     * integral fluence is calculated using {@link #getEnergySpectrumIntegralFluence()}
     * <p>
     * If, for any reason, the integral fluence cannot be calculated 
     * (for example any E,E0,gamma, or Emin is not defined for any of the energy spectrums) 0 is returned by default
     * <p>
     * This function is weird in how it sorts but
     *  useful because it lets you sort an array of DoubleEvents based on energy spectrum integral fluences.
     * All you have to say is:
     * <pre>
     * 	sort(SPEArray); // sorts in ascending order</pre> 
     * 
     * @param otherObject		Another object of the same type to compare
     * 
     * @return 
     * <p>
     * <code> 1</code> If the event of the current object has a higher
     * integral fluence then the Event of the inputted object.
     * <p>
     * <code>-1</code> If the event of the inputted object has a
     * higher integral fluence then the Event of the current object.
     * 			
     * <p><code> 0</code> If the two events have the same integral fluence,
     * or, for whatever reason, the integral fluence cannot be calculated.
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object) 
     */
    public int compareTo(Object otherObject) {
        SolarParticleEventInterface RHS=(SolarParticleEventInterface)otherObject;
        try{
        	if(this.getEnergySpectrumIntegralFluence()<RHS.getEnergySpectrumIntegralFluence())
        		return -1;
        	if (this.getEnergySpectrumIntegralFluence()>RHS.getEnergySpectrumIntegralFluence())
        		return 1;
        	return 0;
        } catch (IllegalArgumentException exception) {
        	return 0;// if the fluence cannot be calculated, return 0        	
        }
	}

    /**
     * Constructor that does nothing.
     */
    public DoubleEvent() {}
    
    /**
     * Constructor that sets the name of the DoubleEvent but nothing else.
     * @param name The name of the DoubleEvent.
     */
    public DoubleEvent(String name) {
    	this.setName(name);
    }
   
    /**
     * Constructor that sets the energy spectrum and time evolution of both events.
     * @param KInput_1 The K parameter of the first event.
     * @param gammaInput_1 The gamma parameter of the first event.
     * @param E0Input_1 The E0_1 parameter of the first event.
     * @param KInput_2 The K parameter of the second event.
     * @param gammaInput_2 The gamma parameter of the second event.
     * @param E0Input_2 The E0 parameter of the second event.
     * @param EminInput The Emin parameter of both events.
     * @param AInput_1 The A1 parameter of the first event.
     * @param B1Input_1 The B1 parameter of the first event.
     * @param B2Input_1 The B2 parameter of the first event.
     * @param AInput_2 The A parameter of the second event.
     * @param B1Input_2 The B1 parameter of the second event.
     * @param B2Input_2 The B2 parameter of the second event.
     * @param timeDelayBetweenEventsInput
     * @param nameInput The name parameter.
     * @throws 	IllegalArgumentException if KInput_1, gammaInput_1, E0Input_1, KInput_2, gammaInput_2, or E0Input_2 are not valid.
     */
    public DoubleEvent(double KInput_1,double gammaInput_1, double E0Input_1,
    		double KInput_2,double gammaInput_2, double E0Input_2, double EminInput, 			
			double AInput_1, double B1Input_1, double B2Input_1,
			double AInput_2, double B1Input_2, double B2Input_2,
			Time timeDelayBetweenEventsInput,
    		String nameInput) throws IllegalArgumentException {
    	this.setDoubleEvent(KInput_1,gammaInput_1,E0Input_1,KInput_2,
    			gammaInput_2,E0Input_2,EminInput, 
				AInput_1, B1Input_1, B2Input_1,
				AInput_2, B1Input_2, B2Input_2,		
				timeDelayBetweenEventsInput, nameInput);
    }

    /**
     * Constructor that sets the energy spectrum of both events.
     * @param KInput_1 The K parameter of the first event.
     * @param gammaInput_1 The gamma parameter of the first event.
     * @param E0Input_1 The E0_1 parameter of the first event.
     * @param KInput_2 The K parameter of the second event.
     * @param gammaInput_2 The gamma parameter of the second event.
     * @param E0Input_2 The E0 parameter of the second event.
     * @param nameInput The name parameter.
     * @throws 	IllegalArgumentException if KInput_1, gammaInput_1, E0Input_1, KInput_2, gammaInput_2, or E0Input_2 are not valid.
     */
    public DoubleEvent(double KInput_1,double gammaInput_1, double E0Input_1,
    		double KInput_2,double gammaInput_2, double E0Input_2, String nameInput) 
    throws IllegalArgumentException {
    	setK_1(false,KInput_1);
        setE0_1(false,E0Input_1);
        setGamma_1(false,gammaInput_1);
        setK_2(false,KInput_2);
        setE0_2(false,E0Input_2);
        setGamma_2(false,gammaInput_2);
        setName(nameInput);
        /* Don't attempt to reset The C's because the time evolution hasn't been defined yet. */
    }

    
    
    /**
     * Sets the energy spectrum and name of the DoubleEvent.
     * @param KInput_1 The K parameter of the first event.
     * @param gammaInput_1 The gamma parameter of the first event.
     * @param E0Input_1 The E0_1 parameter of the first event.
     * @param KInput_2 The K parameter of the second event.
     * @param gammaInput_2 The gamma parameter of the second event.
     * @param E0Input_2 The E0 parameter of the second event.
     * @param nameInput The name parameter.
     * @throws 	IllegalArgumentException if KInput, gammaInput, or E0Input are not valid.
     */
    public void setDoubleEvent(double KInput_1,double gammaInput_1, double E0Input_1,
    		double KInput_2,double gammaInput_2, double E0Input_2, double EminInput, 
			double AInput_1, double B1Input_1, double B2Input_1,
			double AInput_2, double B1Input_2, double B2Input_2,
			Time timeDelayBetweenEventsInput, String nameInput) throws IllegalArgumentException {
        setK_1(false,KInput_1);
        setE0_1(false,E0Input_1);
        setGamma_1(false,gammaInput_1);
        setK_2(false,KInput_2);
        setE0_2(false,E0Input_2);
        setGamma_2(false,gammaInput_2);
        setEmin(false,EminInput);
        setA_1(false,AInput_1);
        setB1_1(false,B1Input_1);
        setB2_1(false,B2Input_1);
        setA_2(false,AInput_2);
        setB1_2(false,B1Input_2);
        setB2_2(false,B2Input_2);
        
        // reset the Cs.
        attemptToResetC_1();
        attemptToResetC_2();
        
        setTimeDelayBetweenEvents(timeDelayBetweenEventsInput);
        setName(nameInput);
    }

    /**
     * Stores the time delay between the beginning of the first event and the beginning of the second event.
     * @param timeDelayBetweenEventsInput The time delay.
     * @throws IllegalArgumentException If the time delay is less then 0. 
     */
    public void setTimeDelayBetweenEvents(Time timeDelayBetweenEventsInput) throws IllegalArgumentException {
    	timeEvolution_2.setTimeDelay(timeDelayBetweenEventsInput);
    }
    
    

    public void setA_1(double AInput) throws IllegalArgumentException { setA_1(true,AInput); }    
    	
    /**
     * Sets the A parameter of the time evolution of the first event. It
     * cannot be 0 because this would lead to division by 0 (bad).
     * @param AInput The A parameter.
     * @throws IllegalArgumentException If A is not defined or 0.
     */
    private void setA_1(boolean fixC, double AInput) throws IllegalArgumentException {      
    	timeEvolution_1.setA(AInput);
    	if (fixC) attemptToResetC_1();
	}
    
    public void setA_2(double AInput) throws IllegalArgumentException { setA_2(true , AInput); }
    
    /**
     * Sets the A parameter of the time evolution of the second event. It
     * cannot be 0 because this would lead to division by 0 (bad).
     * @param AInput The A parameter.
     * @throws IllegalArgumentException If A is not defined or 0.
     */
    private void setA_2(boolean fixC, double AInput) throws IllegalArgumentException {      
    	timeEvolution_2.setA(AInput);
    	if (fixC) attemptToResetC_2();
	}

    public void setB1_1(double B1Input) { setB1_1(true,B1Input); }

    /** 
     * Sets the B1 parameter of the time evolution of the first event.
     * @param B1Input The B1 parameter. 
     */
    private void setB1_1(boolean fixC, double B1Input) {
		timeEvolution_1.setB1(B1Input);
		if (fixC) attemptToResetC_1();
	}
    
    public void setB1_2(double B1Input) { setB1_2(true,B1Input); }
    
	/** 
     * Sets the B1 parameter of the time evolution of the second event.
     * @param B1Input The B1 parameter. 
     */
    private void setB1_2(boolean fixC, double B1Input) {
		timeEvolution_2.setB1(B1Input);
		if (fixC) attemptToResetC_2();
	}

    public void setB2_1(double B2Input) { setB2_1(true,B2Input); }
	/**
	 * Sets the B2 parameter of the time evolution of the first event.
	 * @param B2Input The B2 parameter.
	 */
    private void setB2_1(boolean fixC, double B2Input) {
        timeEvolution_1.setB2(B2Input);
        if (fixC) attemptToResetC_1();
	} 

    public void setB2_2(double B2Input) { setB2_2(true,B2Input); }
    
	/**
	 * Sets the B2 parameter of the time evolution of the second event.
	 * @param B2Input The B2 parameter.
	 */
    private void setB2_2(boolean fixC, double B2Input) {
        timeEvolution_2.setB2(B2Input);
        if (fixC) attemptToResetC_2();
	} 
	
    public void setEmin(double EminInput) throws IllegalArgumentException { setEmin(true,EminInput); }
    
    /**
     * Sets the Emin value. Emin is the lower bounds of the integral of the energy 
     * spectrum. Emin will only be set if
     * it is at least 10 and at most 1500. 
     * @param EminInput The new minimum energy value to integrate from.
     * @throws IllegalArgumentException If EminInput is smaller then 10, larger then 1500, or not a number.
     */
    private void setEmin(boolean fixC, double EminInput) throws IllegalArgumentException {
    	energySpectrum_1.setEmin(EminInput); // set Emin
     	if (fixC) attemptToResetC_1();
        energySpectrum_2.setEmin(EminInput); // set Emin
        if (fixC) attemptToResetC_2();
        
    }

    public void setE0_1(double E0Input) throws IllegalArgumentException { setE0_1(true,E0Input); }
    
    /** 
     * Sets the E0 parameter of the first energy spectrum to E0Input. It is set only if
     * E0Input is at least 10 and at most 500. 
     * @param E0Input
     * @throws IllegalArgumentException If E0Input is less 10 or greater then 500.
     */
    private void setE0_1(boolean fixC, double E0Input) throws IllegalArgumentException {
       energySpectrum_1.setE0(E0Input);
       if (fixC) attemptToResetC_1();
    }
    
    public void setE0_2(double E0Input) throws IllegalArgumentException { setE0_2(true,E0Input); }
    
    /** 
     * Sets the E0 parameter of the second energy spectrum to E0Input. It is set only if
     * E0Input is at least 10 and at most 500. 
     * @param E0Input
     * @throws IllegalArgumentException If E0Input is less 10 or greater then 500.
     */
    private void setE0_2(boolean fixC, double E0Input) throws IllegalArgumentException {
       energySpectrum_2.setE0(E0Input);
       if (fixC) attemptToResetC_2();
    }
    
    public void setGamma_1(double gammaInput) throws IllegalArgumentException{ setGamma_1(true,gammaInput); }
    
    /** 
     * Sets the gamma parameter of the first energy spectrum to gammaInput. It is set only if
     * gammaInput is at least 0 and at most 4.125. 
     * @param gammaInput
     * @throws IllegalArgumentException If gammaInput is less 0 or greater then 4.125.
     */
    private void setGamma_1(boolean fixC, double gammaInput) throws IllegalArgumentException { 
        energySpectrum_1.setGamma(gammaInput);
        if (fixC) attemptToResetC_1();
    }    
    
    public void setGamma_2(double gammaInput) throws IllegalArgumentException { setGamma_2(true,gammaInput); }
    
    /** 
     * Sets the gamma parameter of the second energy spectrum to gammaInput. It is set only if
     * gammaInput is at least 0 and at most 4.125. 
     * @param gammaInput
     * @throws IllegalArgumentException If gammaInput is less 0 or greater then 4.125.
     */
    private void setGamma_2(boolean fixC, double gammaInput) throws IllegalArgumentException { 
        energySpectrum_2.setGamma(gammaInput);
        if (fixC) attemptToResetC_2();
    }    

    /** 
     * Sets the name of the DoubleEvent.
     * @param nameInput The name of the Event.
     */
    public void setName(String nameInput) throws IllegalArgumentException {
    	if (nameInput == null) throw new IllegalArgumentException("The name must not be null."); 
		name=nameInput;
    }
    
    public void setK_1(double KInput) throws IllegalArgumentException { setK_1(true,KInput); }
    
    /** 
     * Sets the K parameter of the first energy spectrum. K is only set if it is at least 0.
     * By setting K, it is assumed that the energy spectrum integral fluence should be 
     * calculated automatically.
     * @param KInput The K value to set
     * @throws IllegalArgumentException If KInput is less then 0.
     */
    private void setK_1(boolean fixC, double KInput) throws IllegalArgumentException {
    	energySpectrum_1.setK(KInput);        
    	if (fixC) attemptToResetC_1();
    }
    
    public void setK_2(double KInput) throws IllegalArgumentException { setK_2(true,KInput); }
    
    /** 
     * Sets the K parameter of the second energy spectrum. K is only set if it is at least 0.
     * By setting K, it is assumed that the energy spectrum integral fluence should be 
     * calculated automatically.
     * @param KInput The K value to set
     * @throws IllegalArgumentException If KInput is less then 0.
     */
    private void setK_2(boolean fixC, double KInput) throws IllegalArgumentException {
    	energySpectrum_2.setK(KInput);        
    	if (fixC) attemptToResetC_2();
    }	
    
    public void setEnergySpectrumIntegralFluence_1(double integralFluenceInput) throws IllegalArgumentException {
    	setEnergySpectrumIntegralFluence_1(true, integralFluenceInput);
    }
    
    /**
     * Sets the > Emin energySpectrumIntegralFluence of the first energy spectrum. When this is set, K is assumed to be calculated
     * automatically.
     * @param integralFluenceInput The integral fluence to set.
     * @throws IllegalArgumentException If the integral fluence is smaller then 0.
     */
    private void setEnergySpectrumIntegralFluence_1(boolean fixC, double integralFluenceInput) throws IllegalArgumentException {
        energySpectrum_1.setIntegralFluence(integralFluenceInput);
        if (fixC) attemptToResetC_1();
    }	
 
    public void setEnergySpectrumIntegralFluence_2(double integralFluenceInput) throws IllegalArgumentException {
    	setEnergySpectrumIntegralFluence_2(true, integralFluenceInput);
    }        
    
    /**
     * Sets the > Emin energySpectrumIntegralFluence of the second energy spectrum. When this is set, K is assumed to be calculated
     * automatically.
     * @param integralFluenceInput The integral fluence to set.
     * @throws IllegalArgumentException If the integral fluence is smaller then 0.
     */
    private void setEnergySpectrumIntegralFluence_2(boolean fixC, double integralFluenceInput) throws IllegalArgumentException {
        energySpectrum_2.setIntegralFluence(integralFluenceInput);
        if (fixC) attemptToResetC_2();
    }	
    
    /**
     * Calculates the energy spectrum fluence for the DoubleEvent at any given
     * energy value over 0. This is calculated by adding the energy spectrum of
     * the first and second event to get the total spectrum. It includes the K value. 
     * @param EInput The energy value.
     * @return The fluence at a given energy value of both energy spectrums added together.
     * @throws IllegalArgumentException If any of the parameters of the energy spectrums are 
  	 * not specified.
     */
    public double getEnergySpectrumFluence(double EInput) throws IllegalArgumentException {
        return energySpectrum_1.getFluence(EInput)+energySpectrum_2.getFluence(EInput);
    }
    /**
     * Calculates the energy spectrum fluence for the first event at a given energy value
     * @param EInput The energy value.
     * @return The fluence at the first event a given energy value of
     * @throws IllegalArgumentException If any of the parameters of the first energy spectrum are 
  	 * not specified.
     */
    public double getEnergySpectrumFluence_1(double EInput) throws IllegalArgumentException {
        return energySpectrum_1.getFluence(EInput);
    }
    
    /**
     * Calculates the energy spectrum fluence for the second event at a given energy value
     * @param EInput The energy value.
     * @return The fluence at the second event a given energy value of
     * @throws IllegalArgumentException If any of the parameters of the second energy spectrum are 
  	 * not specified.
     */
    public double getEnergySpectrumFluence_2(double EInput) throws IllegalArgumentException {
        return energySpectrum_2.getFluence(EInput);
    }
   
  	/**
  	 * Returns the energy spectrum integral fluence. This is calculated by adding the energy spectrum of
     * the first and second event to get the total spectrum.
  	 * If the energy spectrum integral fluence is set explicity for either spectrum, that value is used.
  	 * Otherwise, this function calculates the energy spectrum integral fluence numerically using the specified K value for each spectrum. 
  	 * Emin must have been previously set for the events by a call to {@link #setEmin}. 
  	 * <p>
  	 * What is returned is the total number of particles with energy values
  	 * above Emin from both energy spectrums.
  	 * @return The integral fluence of both spectrums added together.
  	 * @throws IllegalArgumentException If any of the parameters of the energy spectrums are 
  	 * not specified.
  	 */
    public double getEnergySpectrumIntegralFluence() throws IllegalArgumentException {
    	return energySpectrum_1.getIntegralFluence()+energySpectrum_2.getIntegralFluence();
    }
    public double getEnergySpectrumIntegralFluence_1() throws IllegalArgumentException {
    	return energySpectrum_1.getIntegralFluence();
    }
    public double getEnergySpectrumIntegralFluence_2() throws IllegalArgumentException {
    	return energySpectrum_2.getIntegralFluence();
    }
    
    /** 
     * Does the actual numeric integration of the energy spectrum integral 
     * fluence from the inputted Emin value to 1500 (basically infinity) for each energy spectrum. 
     * The result is the sum of both integral fluences.
     * @param EminInput The lower bound of the integral.
     * @return The integral fluence above Emin input of both spectrums added together.
     * @throws IllegalArgumentException If EminInput is less then 10 or if E0 is not defined.
     */
    public double getEnergySpectrumIntegralFluence(double EminInput) throws IllegalArgumentException {
    	return energySpectrum_1.getIntegralFluence(EminInput)+energySpectrum_2.getIntegralFluence(EminInput);
    }
    public double getEnergySpectrumIntegralFluence_1(double EminInput) throws IllegalArgumentException {
    	return energySpectrum_1.getIntegralFluence(EminInput);
    }
    public double getEnergySpectrumIntegralFluence_2(double EminInput) throws IllegalArgumentException {
    	return energySpectrum_2.getIntegralFluence(EminInput);
    }
    
    /**
     * Returns the K parameter of the energy spectrum of the first event. If K has been set explicitly,
     * that value is returned. Otherwise, K is calculated automatically using the formula
     * <pre>
     * 	K = inputted integral fluence / calculated integral fluence without K
     * </pre> 
     * @return The K parameter of the first event.
     * @throws IllegalArgumentException If K is not defined.
     */
    public double getK_1() throws IllegalArgumentException {
    	return energySpectrum_1.getK();
    }
    
    /**
     * Returns the K parameter of the energy spectrum of the second event. If K has been set explicitly,
     * that value is returned. Otherwise, K is calculated automatically using the formula
     * <pre>
     * 	K = inputted integral fluence / calculated integral fluence without K
     * </pre> 
     * @return The K parameter of the second event.
     * @throws IllegalArgumentException If K is not defined.
     */
    public double getK_2() throws IllegalArgumentException {
    	return energySpectrum_2.getK();
    }        
      
	/**
	 * Gets the A parameter of the time evolution curve of the first event. 
	 * @return The value of A.
	 * @throws IllegalArgumentException If A is not defined.
	 */
	public double getA_1() throws IllegalArgumentException {
		return timeEvolution_1.getA();
	}  
	
	/**
	 * Gets the A parameter of the time evolution curve of the second event. 
	 * @return The value of A.
	 * @throws IllegalArgumentException If A is not defined.
	 */
	public double getA_2() throws IllegalArgumentException {
		return timeEvolution_2.getA();
	}  

	/**
	 * Gets the B1 parameter of the time evolution curve of the first event. 
	 * @return The value of B1.
	 * @throws IllegalArgumentException If B1 is not defined.
	 */
	public double getB1_1() throws IllegalArgumentException {
		return timeEvolution_1.getB1();
	}
	
	/**
	 * Gets the B1 parameter of the time evolution curve of the second event. 
	 * @return The value of B1.
	 * @throws IllegalArgumentException If B1 is not defined.
	 */
	public double getB1_2() throws IllegalArgumentException {
		return timeEvolution_2.getB1();
	}
	
	/**
	 * Gets the B2 parameter of the time evolution curve of the first event. 
	 * @return The value of B2.
	 * @throws IllegalArgumentException If B2 is not defined.
	 */
	public double getB2_1() throws IllegalArgumentException {
		return timeEvolution_1.getB2();
	}
	
	/**
	 * Gets the B2 parameter of the time evolution curve of the second event. 
	 * @return The value of B2.
	 * @throws IllegalArgumentException If B2 is not defined.
	 */
	public double getB2_2() throws IllegalArgumentException {
		return timeEvolution_2.getB2();
	}	
		
	/**
	 * Gets the Emin value. Or, the minimum energy value to use when integrating the energy spectrum.
	 * @return The value of Emin.
	 * @throws IllegalArgumentException If Emin is not defined.
	 */
    public double getEmin() throws IllegalArgumentException {
    	double Emin=energySpectrum_1.getEmin();
    	if ( Emin != energySpectrum_2.getEmin())
    		throw new IllegalArgumentException("State of the object is not correct (Emin must be the same for both events).");
		
    	return Emin;
    }	
    
    /**
     * Gets the gamma parameter of the energy spectrum of the first event.
     * @return The gamma value.
     * @throws IllegalArgumentException If gamma is not defined.
     */
    public double getGamma_1() throws IllegalArgumentException {
        return energySpectrum_1.getGamma();
    }    
    
    /**
     * Gets the gamma parameter of the energy spectrum of the second event.
     * @return The gamma value.
     * @throws IllegalArgumentException If gamma is not defined.
     */
    public double getGamma_2() throws IllegalArgumentException {
        return energySpectrum_2.getGamma();
    }    

    /**
     * Gets the E0 parameter of the energy spectrum of the first event.
     * @return The E0 value.
     * @throws IllegalArgumentException If E0 is not defined.
     */
    public double getE0_1() throws IllegalArgumentException {
    	return energySpectrum_1.getE0();
    }    
    
    /**
     * Gets the E0 parameter of the energy spectrum of the second event.
     * @return The E0 value.
     * @throws IllegalArgumentException If E0 is not defined.
     */
    public double getE0_2() throws IllegalArgumentException {
    	return energySpectrum_2.getE0();
    }
    
    /**
     * Gets the name of the SPE.
     * @return the name of the SPE.
     */
    public String getName() {
        return name;
    }
    
    /**
     * Returns the value of C of the first event. 
     * It is calculated automatically so that the integral fluence of the energy spectrum
     * equals the integral flux of the time evolution curve. 
     * @return The value of C.
     * @throws IllegalArgumentException if gamma, E0, K, A, B1, B2, or C
     * are not defined.
     */
    public double getC_1() throws IllegalArgumentException {
    	attemptToResetC_1();
    	return timeEvolution_1.getC();
    }
    
    /**
     * Returns the value of C of the second event.
     * It is calculated automatically so that the integral fluence of the energy spectrum
     * equals the integral flux of the time evolution curve. 
     * @return The value of C.
     * @throws IllegalArgumentException if gamma, E0, K, A, B1, B2, or C
     * are not defined.
     */
    public double getC_2() throws IllegalArgumentException {
    	attemptToResetC_2();
    	return timeEvolution_2.getC();
    }

   /**
    * Returns the time delay between the beginning of the first event and the beginning of the second event.
    * @return The time delay.
    * @throws IllegalArgumentException If the time delay has not been defined yet.
    */    
    public Time getTimeDelayBetweenEvents() throws IllegalArgumentException {
    	return timeEvolution_2.getTimeDelay();
    }	
   
    /**
     * Calculates the flux of the time evolution of the SPE for a given
     * time value. The flux is calculated using the formula
     * <p><i>Flux</i>=C_1(t/A_1)<sup>B1_1</sup><i>e</i>-(t/A_1)^B2_1 +
     *  Flux</i>=C_2( (t-timeDelay) / A_2)<sup>B1_2</sup><i>e</i>-(t - timeDelay /A_2)^B2_2+<b>BACKGROUND</b>
     * <p>where C_1 is taken from the function {@link #getC_1} and C2 is taken from the function {@link #getC_2()}.
     * C_1 and C_2 are automatically such that the time evolution integral flux is equal to
     * the energy spectrum integral flux.  
     * C_1 and C_2 are calculated this way so that the total number of particles
     * from the energy spectrum (the integral fluence) and the total number of
     * particles from the time evolution (the integral flux) are the same. 
     * This ensure that the 2 separate SPE curves for each event are really talking about the same event.
     * Background is the background ever present GCR radiation. It's value is determined by {@link TimeEvolution#BACKGROUND}.
     *
     * @param timeInput The time to find the flux for.
     * @return the time evolution flux at a particular time.
     * @throws If any part of the energy spectrum or time evolution are not set correctally.
     */
    public double getTimeEvolutionFluxWithCWithGCR(Time timeInput) throws IllegalArgumentException {
    	return (this.getC_1()*timeEvolution_1.getFluxWithoutCWithoutGCR(timeInput)+
    			this.getC_2()*timeEvolution_2.getFluxWithoutCWithoutGCR(timeInput)+
    			TimeEvolution.BACKGROUND); // only add background once so we don't double count it. This is why we cant use the timeEvolutoin getFluxWithCWithGCR function.
    }    
    
    /**
     * Returns the time evolution flux for the two curves together, including the scaling C factor, 
     * but not including the background radiation.
     * @param timeInput
     * @return the time evolution flux at a particular time (including C_1 and C_2).
     * @throws If any part of the energy spectrum or time evolution are not set correctally.
     */
    public double getTimeEvolutionFluxWithCWithoutGCR(Time timeInput) throws IllegalArgumentException {
    	return this.getC_1()*timeEvolution_1.getFluxWithoutCWithoutGCR(timeInput)+
    	this.getC_2()*timeEvolution_2.getFluxWithoutCWithoutGCR(timeInput);
    }    
        
    /**
     * Returns the time evolution integral flux for the first event from timeMin to timeMax.
     * This function does <b>NOT</b> include the GCR background radiation {@link TimeEvolution#BACKGROUND} or C.
     * @param timeMin The lower bound on the integral.
     * @param timeMax The upper bound on the integral.
     * @return The time evolution integral flux.
     * @throws IllegalArgumentException If the first time evolution has not been properly defined.
     */
    public double getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time timeMin, Time timeMax)
    throws IllegalArgumentException {
    	return timeEvolution_1.getIntegralFluxWithoutCWithoutGCR(timeMin,timeMax);
    }   
    
    /**
     * Returns the time evolution integral flux for the second event from timeMin to timeMax.
     * This function does <b>NOT</b> include the GCR background radiation {@link TimeEvolution#BACKGROUND} or C.
     * @param timeMin The lower bound on the integral.
     * @param timeMax The upper bound on the integral.
     * @return The time evolution integral flux.
     * @throws IllegalArgumentException If the second time evolution has not been properly defined.
     */
    public double getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time timeMin, Time timeMax)
    throws IllegalArgumentException {
    	return timeEvolution_2.getIntegralFluxWithoutCWithoutGCR(timeMin,timeMax);
    }
    
    

    /** 
     * Decides weather or not the total time evolution integral flux decreases fast enough.
     * The time evolution is considered to decrease fast enough if the total number of
     * particles (time evolution integral flux)
     * during the 6th day is less then 1/100th of the total number of particles
     * from the first 5 days.
     * @return <code>true</code> if the number of particles from the sixth day is less then
     * 1/100th the number of particles from the first five days. <code>false</code> otherwise.
     */
    public boolean doesTimeEvolutionIntegralFluxDecreaseFastEnough() {
    	double firstFiveDays=getC_1()*getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),Time.inDays(5))+
    		getC_2()*getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),Time.inDays(5));
    	    	
    	double sixthDay=getC_1()*getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(5),Time.inDays(6))+
    		getC_2()*getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(5),Time.inDays(6));
    	if (sixthDay<.01*firstFiveDays) return true;
    	return false;
    }

    /**
     * This function decides if the SPE is sufficiently 'large'. The criteria for an SPE being
     * "large" is that at any point in time from 0 to 10 days the flux (including C)
     * is larger then the BACKGROUND radiation. If, at some point in time, the flux (including C)
     * is larger then the BACKGROUND radiation, true is returned. Otherwise, false is returned.
     * <p>
     * This is useful as a warning for the user. If this returns false, you know to warn the user
     * to make K_1, K_2 or the energy spectrum integral fluence of event 1 or event 2 bigger (to increase the size of the SPE).
     * @return <code>true</code> if the time evolution flux (including C) is larger then the BACKGROUND
     * radiation at any point in time during the SPE. <code>false</code> otherwise.
     */
    public boolean isEventLargeEnough() {
        Time timeMin=Time.inDays(0);
        Time timeMax=Time.inDays(10);
        Time timeStep=Time.inDays(0.1);
    	for(Time time=(Time)timeMin.clone();time.getDays()<timeMax.getDays();time.add(timeStep)) 
    		// use the total time evolution flux from both events.
		    if (this.getTimeEvolutionFluxWithCWithoutGCR(time) > TimeEvolution.BACKGROUND) return true;
		return false;
    }
 
    /**
     * Returns the cumulative dose that an astronaut would receive from both SPEs. The does is returned based on
     * an input thickness to the Skin Eye or BFO for each SPE. This method can return dose equivalent (RAD) or absorbed dose
     * (REM) in free space or lunar surface. Dose on the lunar surface is 1/2 the dose in free space
     * because the moon blocks out half the radiation dose.
     * @param thickness The thickness under which the dose is required.
     * @param remOrRad The type of radiation dose to return.
     * @param skinEyeOrBFO Where to return dose from.
     * @param lunarSurfaceOrFreeSpace Where the dose is received.
     * @return The desired dose.
     * @throws IllegalArgumentException If either of the events energy spectrum is not defined. 
     */
    public double getDose(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO,
			DoseLocation lunarSurfaceOrFreeSpace)  throws IllegalArgumentException {
		return( this.getDose_1(thickness, remOrRad,skinEyeOrBFO,lunarSurfaceOrFreeSpace)+
				getDose_2(thickness,remOrRad,skinEyeOrBFO,lunarSurfaceOrFreeSpace));		
    }

    /**
     * Returns the cumulative dose that an astronaut would receive from the first event.
     * @param thickness The thickness under which the dose is required.
     * @param remOrRad The type of radiation dose to return.
     * @param skinEyeOrBFO Where to return dose from.
     * @param lunarSurfaceOrFreeSpace Where the dose is received.
     * @return The desired dose.
     * @throws IllegalArgumentException If the first event's energy spectrum is not defined. 
     */
    public double getDose_1(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO,
			DoseLocation lunarSurfaceOrFreeSpace)  throws IllegalArgumentException {
    	if (radiationDoseValues==null) radiationDoseValues=new RadiationDoseValues();
    	double dose= radiationDoseValues.getDose(getK_1(),getGamma_1(),getE0_1(),thickness,remOrRad,skinEyeOrBFO);
    				
    	if (lunarSurfaceOrFreeSpace == DoseLocation.LUNAR_SURFACE) return dose/2;   	
    	return dose;
    }
    
    /**
     * Returns the cumulative dose that an astronaut would receive from the second event.
     * @param thickness The thickness under which the dose is required.
     * @param remOrRad The type of radiation dose to return.
     * @param skinEyeOrBFO Where to return dose from.
     * @param lunarSurfaceOrFreeSpace Where the dose is received.
     * @return The desired dose.
     * @throws IllegalArgumentException If the second event's energy spectrum is not defined. 
     */
    public double getDose_2(Thickness thickness, RadiationType remOrRad,BodyPart skinEyeOrBFO,
			DoseLocation lunarSurfaceOrFreeSpace)  throws IllegalArgumentException {
    	if (radiationDoseValues==null) radiationDoseValues=new RadiationDoseValues();
    	double dose= radiationDoseValues.getDose(getK_2(),getGamma_2(),getE0_2(),thickness,remOrRad,skinEyeOrBFO);
    		
    	if (lunarSurfaceOrFreeSpace == DoseLocation.LUNAR_SURFACE) return dose/2;   	
    	return dose;
    }

    /**
     * This method simulates a man on the moon during a solar particle event. To do this we must be able
     * to find the dose received by a person on the lunar surface during any period of time during the event.
     * To calculate the dose that a person received under a given thickness x with a given total dose Dose<sub>x</sub>,
     * we use the formula:
     * <pre>
     *	C<sub>x</sub> = Dose<sub>x</sub> / The integral of the time evolution flux from 0 to 10 days.
     * </pre>
     * This essentially creates a new C for the time evolution curve such that if we now integrate form 0 to 10 days,
     * we get the total dose. Now, the dose from T<sub>start</sub> to T<sub>stop</sub> is:
     * <pre>
     * 	Dose = C<sub>x</sub>*The integral of the time evolution flux without C from T<sub>start</sub> to T<sub>stop</sub>.
     * </pre>
     * Therefore, when we want to simulate an astronaut on the moon under different thicknesses, we first calculate
     * new Cs for all thicknesses desired. We then integrate for the desired time periods with the desired Cs to
     * figure out all the individual doses during the event. The sum of them is the total dose received by an
     * astronaut.     
     */
    
    /**
     * Like {@link SolarParticleEvent#simulateAstronautOnTheMoon},
     * this method simulates a man on the moon during a solar particle event. To do this we must be able
     * to find the dose received by a person on the lunar surface during any period of time during the event.
     * To calculate the dose that a person received under a given thickness x with a given total dose Dose<sub>x</sub>,
     * we use the formula:
     * <pre>
     *	C<sub>x</sub> = Dose<sub>x</sub> / The integral of the time evolution flux from 0 to 10 days.
     * </pre>
     * This essentially creates a new C for the time evolution curve such that if we now integrate form 0 to 10 days,
     * we get the total dose. Now, the dose from T<sub>start</sub> to T<sub>stop</sub> is:
     * <pre>
     * 	Dose = C<sub>x</sub>*The integral of the time evolution flux without C from T<sub>start</sub> to T<sub>stop</sub>.
     * </pre>
     * Therefore, when we want to simulate an astronaut on the moon under different thicknesses, we first calculate
     * new Cs for all thicknesses desired. We then integrate for the desired time periods with the desired Cs to
     * figure out all the individual doses during the event. The sum of them is the total dose received by an
     * astronaut.     
     * 
     * Unlike {@link SolarParticleEvent#simulateAstronautOnTheMoon}, this function operates differently because it
     * needs to deal with two seperate events. Thus, C values are created separately for each event
     * and doses are calculated individually for each event. Afterwards, the total dose is calculated as the sum of
     * each individual dose.
     * @param remOrRad rem (dose equivalent) or rad (absorbed dose).
     * @param skinEyeOrBFO Specifies dose to the skin, eye, or BFO.
     * @param priorToWarning The amount of time before the beginning of the SPE that the astronaut is given warning
     * that the event is about to happen. A negative value implies the time <b>AFTER</b> the event has begun
     * before he is given warning about the event.
     * @param thicknessPriorToWarning The thickness the astronaut is under during the time prior to warning.
     * @param packingUp The time it takes him to pack up and enter the rover.
     * @param thicknessPackingUp The thickness he is under when he packs up and enters the rover.
     * @param transitToBase The time it takes him to drive back to the base.
     * @param thicknessTransitToBase The thickness he is under when he drives back to the base.
     * @param thicknessAtBase The thickness he is under at the base until the end of the event (Until 10 days ends).
     * @param cumulativeDoseGraph A graph holding the cumulative dose over time.
     * @return An object holding all desired information. This includes doses and percents of total
     *  during different stages of the event. It also includes
     * the total dose the astronaut received and the ratio of total dose to dose under shelter the whole time.
     * @throws IllegalArgumentException If any of the SPE is undefined. If the time to pack up and enter the rover
     * or the time it takes to drive back to the base is less then 0 hours. If entire time it takes to get back
     * to the base is greater then 10 days.
     */
    public DoseInformation simulateAstronautOnTheMoon(RadiationType remOrRad,BodyPart skinEyeOrBFO,
    		Time priorToWarning, Thickness thicknessPriorToWarning, Time packingUp, Thickness thicknessPackingUp,
			Time transitToBase, Thickness thicknessTransitToBase, Thickness thicknessAtBase,
			CumulativeDoseGraph cumulativeDoseGraph) throws IllegalArgumentException {
    	    	
		if (packingUp.getDays() < 0)
			throw new IllegalArgumentException("The time it takes to pack up must be >= 0.");
		if (transitToBase.getDays() < 0) 
			throw new IllegalArgumentException("The time it takes to return to the base must be >= 0");
			
		Time lengthOfEvent = Time.inDays(10); 
		
		// total time of simulation must be less then or equal to 10 days.
    	if ((-1*priorToWarning.getDays()+packingUp.getDays()+transitToBase.getDays())> lengthOfEvent.getDays())
			throw new IllegalArgumentException("The arrival time at the base must be at most 10 days");
 
		// total time evolution flux is the time evolution flux without C from 0 to 10 days
    	double timeEvolutionIntegralFlux_1=this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),lengthOfEvent);
    	double timeEvolutionIntegralFlux_2=this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),lengthOfEvent);
    	    	
    	// calculate all the C values
    	double CPriorToOnset_1=this.getDose_1(thicknessPriorToWarning,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CPriorToOnset_2=this.getDose_2(thicknessPriorToWarning,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	double CPackingUp_1=this.getDose_1(thicknessPackingUp,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CPackingUp_2=this.getDose_2(thicknessPackingUp,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	double CTransitToBase_1=this.getDose_1(thicknessTransitToBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CTransitToBase_2=this.getDose_2(thicknessTransitToBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	double CAtBase_1=this.getDose_1(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_1;
    	double CAtBase_2=this.getDose_2(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE)/
			timeEvolutionIntegralFlux_2;
    	
    	DoseInformation doseInformation = new DoseInformation(); // throw all calculated values into an object to return.
    	
    	// the current time starts at the negative of the time prior to warning.
    	Time currentTime = Time.negative ((Time)priorToWarning.clone());
    	Time timeStepForGraph = Time.inDays(.1); // every twenty minutes
    	
    	cumulativeDoseGraph.reset(remOrRad, skinEyeOrBFO);
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Warning");
    	double dose;
    	double cumulativeDose = 0;
    	
    	
    	for (Time loop = Time.inDays(0); loop.getDays()< currentTime.getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > currentTime.getDays()) 
    			nextTimeInterval = (Time)currentTime.clone();
    		
			dose=CPriorToOnset_1*
				this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
				CPriorToOnset_2*
				this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(loop,nextTimeInterval);		
    		
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
    	// calculate the dose received by the astronaut prior to warning by integrating with the correct C from 0 to the current time.

		doseInformation.dosePriorToWarning=
    		CPriorToOnset_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(Time.inDays(0),currentTime)+
			CPriorToOnset_2*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(Time.inDays(0),currentTime);
    	    	
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.add(currentTime,packingUp).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.add(currentTime,packingUp).getDays()) 
    			nextTimeInterval = Time.add(currentTime,packingUp);
    		
			dose=CPackingUp_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
				 CPackingUp_2*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
		// calculate the dose received by the astronaut while packing up by integrating with the correct C from the current time for the amount of time packing up
    	doseInformation.doseWhilePackingUp=
    		CPackingUp_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(currentTime,Time.add(currentTime,packingUp))+
    		CPackingUp_2*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(currentTime,Time.add(currentTime,packingUp));
    	
    	currentTime.add(packingUp); // advance the current time
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Rover");
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.add(currentTime,transitToBase).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.add(currentTime,transitToBase).getDays()) 
    			nextTimeInterval = Time.add(currentTime,transitToBase);
    		
			dose= CTransitToBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
    			 CTransitToBase_2*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}   

		// Calculate the dose received by the astronaut while in transit by integrating with the correct C from an advanced current time for the amount of time in transit.
    	doseInformation.doseDuringTransit=
    		CTransitToBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(currentTime,Time.add(currentTime,transitToBase))+
    		CTransitToBase_2*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(currentTime,Time.add(currentTime,transitToBase));
    	
    	currentTime.add(transitToBase); // advance the current time
    	cumulativeDoseGraph.addTimeMarker(currentTime,"Base");
    	
    	
    	for (Time loop = (Time)currentTime.clone(); loop.getDays()<Time.inDays(10).getDays(); loop.add(timeStepForGraph) ) {
    		Time nextTimeInterval = Time.add(loop,timeStepForGraph);
    		if (nextTimeInterval.getDays() > Time.inDays(10).getDays())
    			nextTimeInterval = Time.inDays(10);
    		
			dose=CAtBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(loop,nextTimeInterval)+
    			 CAtBase_2*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(loop,nextTimeInterval);
    		cumulativeDose+=dose;
    		cumulativeDoseGraph.addCumulativeDose(nextTimeInterval,cumulativeDose);
    	}    		
		
    	// Calculate the dose received by the astronaut in base by integrating with the correct C from an advacned current time to the end of the even (10 days)
    	doseInformation.doseAtBase=
    		CAtBase_1*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_1(currentTime, lengthOfEvent)+
    		CAtBase_2*this.getTimeEvolutionIntegralFluxWithoutCWithoutGCR_2(currentTime, lengthOfEvent);
    	
    	// the total time exposed at the base is 10 - the current time (when you get to the base)
    	doseInformation.timeExposedInBase=Time.subtract( lengthOfEvent , currentTime);
    	
    	// the total dose is the sum of all other doses.
    	doseInformation.totalDoseAwayFromShelter=
    		doseInformation.dosePriorToWarning + doseInformation.doseWhilePackingUp +
			doseInformation.doseDuringTransit + doseInformation.doseAtBase;
    	
    	// the ratio higher then always at the base is the total dose away / the total dose at the base
    	doseInformation.ratioHigherThenAlwaysAtBase=doseInformation.totalDoseAwayFromShelter/
			this.getDose(thicknessAtBase,remOrRad,skinEyeOrBFO,DoseLocation.LUNAR_SURFACE);
    	
    	doseInformation.percentOfTotalPriorToWarning=
    		100*doseInformation.dosePriorToWarning/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalWhilePackingUp=
    		100*doseInformation.doseWhilePackingUp/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalDuringTransit=
    		100*doseInformation.doseDuringTransit/doseInformation.totalDoseAwayFromShelter;
    	doseInformation.percentOfTotalAtBase=
    		100*doseInformation.doseAtBase/doseInformation.totalDoseAwayFromShelter;
    	    	
    	return doseInformation; // return everything to the user
    }
}