package SStoRM;

public class TimeEvolutionTest extends junit.framework.TestCase {

	private static double MAX_EXACT_PERCENT_ERROR=.0000000000000000000001;
	private static final double MAX_CALCULATED_PERCENT_ERROR = .00001;
	private static final double MAX_WEAKER_CALCULATED_PERCENT_ERROR = .001;
	private static final double MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR=.03;
	
	public void testEquals() {
		AssertMore.assertNotEquals(new TimeEvolution(),new TimeEvolution());
		AssertMore.assertNotEquals(new TimeEvolution(1,1,1,1),new TimeEvolution(1,1,1,0));
		AssertMore.assertNotEquals(new TimeEvolution(0.1,1,1,1),new TimeEvolution(0.01,1,1,1));
		AssertMore.assertEquals(new TimeEvolution(0.01,1,1,1),new TimeEvolution(0.01,1,1,1));
		AssertMore.assertEquals(new TimeEvolution(0.01,1,11,1),new TimeEvolution(0.01,1,11,1));
		AssertMore.assertEquals(new TimeEvolution(0.01,1.2,11,1),new TimeEvolution(0.01,1.2,11,1));
	}

	public void testClone() {
		TimeEvolution evolution1 = new TimeEvolution(0.01,1.2,11,1);
		AssertMore.assertEquals(.01,   evolution1.getA(), MAX_EXACT_PERCENT_ERROR);
		TimeEvolution evolution2 = (TimeEvolution) evolution1.clone();
		AssertMore.assertEquals(evolution1,evolution2);		
		AssertMore.assertEquals(.01,   evolution2.getA(), MAX_EXACT_PERCENT_ERROR);
		evolution1.setA(5);
		AssertMore.assertEquals(5, evolution1.getA(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(.01, evolution2.getA(), MAX_EXACT_PERCENT_ERROR);

		AssertMore.assertNotEquals(evolution1,evolution2);		
		evolution2 = (TimeEvolution) evolution1.clone();
		AssertMore.assertEquals(evolution1,evolution2);		
		AssertMore.assertEquals(5, evolution1.getA(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(5, evolution2.getA(), MAX_EXACT_PERCENT_ERROR);
		
		evolution1.setC(0);
		AssertMore.assertEquals(0,evolution1.getC(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(1,evolution2.getC(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertNotEquals(evolution1,evolution2);		
		
	}

	public void testTimeEvolution() {
		TimeEvolution evolution = new TimeEvolution();
		try {
			evolution.getA();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getC();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		
		evolution = new TimeEvolution(.5,1,2,5);
		AssertMore.assertEquals(0.5, evolution.getA(),  MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(1,   evolution.getB1(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(2,   evolution.getB2(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(5,   evolution.getC(),  MAX_EXACT_PERCENT_ERROR);

		evolution = new TimeEvolution(9,9,9,9);
		AssertMore.assertEquals(9, evolution.getA(),  MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(9,   evolution.getB1(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(9,   evolution.getB2(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(9,   evolution.getC(),  MAX_EXACT_PERCENT_ERROR);
		
	}

	public void testSetTimeEvolution() {
		TimeEvolution evolution = new TimeEvolution();
		evolution.setTimeEvolution(6,1,88,9);
		AssertMore.assertEquals(6, evolution.getA(),  MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(1,   evolution.getB1(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(88,   evolution.getB2(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(9,   evolution.getC(),  MAX_EXACT_PERCENT_ERROR);

		evolution.setTimeEvolution(1,2,3,4);
		AssertMore.assertEquals(1, 	 evolution.getA(),  MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(2,   evolution.getB1(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(3,   evolution.getB2(), MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(4,   evolution.getC(),  MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetA() {
		TimeEvolution evolution = new TimeEvolution();
		evolution.setA(5);
		AssertMore.assertEquals(5, evolution.getA() , MAX_EXACT_PERCENT_ERROR);
		try {
			evolution.getB1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getC();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		
		try {
			evolution.setA(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setA(-.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setA(-1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setA(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setA(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		

		evolution.setA(1);
		AssertMore.assertEquals(1, evolution.getA() , MAX_EXACT_PERCENT_ERROR);
		evolution.setA(50);
		AssertMore.assertEquals(50, evolution.getA() , MAX_EXACT_PERCENT_ERROR);
		
	}

	public void testGetSetB1() {
		TimeEvolution evolution = new TimeEvolution();
		evolution.setB1(111);
		AssertMore.assertEquals(111, evolution.getB1() , MAX_EXACT_PERCENT_ERROR);
		try {
			evolution.getA();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getC();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setB1(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setB1(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		evolution.setB1(0);
		AssertMore.assertEquals(0, evolution.getB1() , MAX_EXACT_PERCENT_ERROR);

		evolution.setB1(1);
		AssertMore.assertEquals(1, evolution.getB1() , MAX_EXACT_PERCENT_ERROR);
		evolution.setB1(51);
		AssertMore.assertEquals(51, evolution.getB1() , MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetB2() {
		TimeEvolution evolution = new TimeEvolution();
		evolution.setB2(111);
		AssertMore.assertEquals(111, evolution.getB2() , MAX_EXACT_PERCENT_ERROR);
		try {
			evolution.getA();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getC();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setB2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setB2(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.getA();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getC();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setB2(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setB2(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		evolution.setB2(0);
		AssertMore.assertEquals(0, evolution.getB2() , MAX_EXACT_PERCENT_ERROR);
		evolution.setB2(1);
		AssertMore.assertEquals(1, evolution.getB2() , MAX_EXACT_PERCENT_ERROR);
		evolution.setB2(51);
		AssertMore.assertEquals(51, evolution.getB2() , MAX_EXACT_PERCENT_ERROR);
	}

	public void testSetC() {
		TimeEvolution evolution = new TimeEvolution();
		evolution.setC(5);
		AssertMore.assertEquals(5, evolution.getC() , MAX_EXACT_PERCENT_ERROR);
		try {
			evolution.getA();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB1();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			evolution.getB2();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		
		try {
			evolution.setC(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setC(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			evolution.setC(-0.00001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		

		evolution.setC(1);
		AssertMore.assertEquals(1, evolution.getC() , MAX_EXACT_PERCENT_ERROR);
		evolution.setC(50);
		AssertMore.assertEquals(50, evolution.getC() , MAX_EXACT_PERCENT_ERROR);
		
	}

	public void testGetTimeEvolutionFluxAndIntegralFlux() {
		TimeEvolution evolution = new TimeEvolution(0.5,1,1,1e4);
		AssertMore.assertEquals(4.5399929762485e-4,evolution.getFluxWithoutCWithoutGCR(Time.inDays(5)) , MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(4.5399929762485e-4*1e4+.11,evolution.getFluxWithCWithGCR(Time.inDays(5)) , MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(.217772308789459,evolution.getFluxWithoutCWithoutGCR(Time.inDays(1.2)) , MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.217772308789459*1e4+.11,evolution.getFluxWithCWithGCR(Time.inDays(1.2)) , MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		evolution.setA(.001);
		AssertMore.assertEquals(.36787944117145,evolution.getFluxWithoutCWithoutGCR(Time.inDays(.001)) , MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.36787944117145*1e4+.11,evolution.getFluxWithCWithGCR(Time.inDays(.001)) , MAX_CALCULATED_PERCENT_ERROR);
		
		
		evolution.setB1(4);
		evolution.setB2(2);
		evolution.setC(55555);
		AssertMore.assertEquals(3.7200759761231e-40,evolution.getFluxWithoutCWithoutGCR(Time.inDays(.01)) , MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.7200759761231e-40*55555+.11,evolution.getFluxWithCWithGCR(Time.inDays(.01)) , MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(6.6467019408958e-4,
				evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0), Time.inDays(10)), 
				MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		
		evolution.setA(.01);
		evolution.setB1(3);
		evolution.setB2(5);
		evolution.setC(5555);		
		AssertMore.assertEquals(.0023284594274484,
				evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0), Time.inDays(1)), 
				MAX_WEAKER_WEAKER_CALCULATED_PERCENT_ERROR);
		
		evolution.setA(1);
		evolution.setB1(5);
		evolution.setB2(100);
		evolution.setC(6);		
		AssertMore.assertEquals(.16145727491878,
				evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0), Time.inDays(5)), 
				MAX_CALCULATED_PERCENT_ERROR);
		

		evolution.setA(77);
		evolution.setB1(77);
		evolution.setB2(77);
		evolution.setC(77);		
		AssertMore.assertEquals(5.8313173909395e-82,
				evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0), Time.inDays(7)), 
				MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.638350174543e-92,evolution.getFluxWithoutCWithoutGCR(Time.inDays(5)) , MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.638350174543e-92*77+.11,evolution.getFluxWithCWithGCR(Time.inDays(5)) , MAX_CALCULATED_PERCENT_ERROR);
		
		AssertMore.assertEquals(3.638350174543e-15,evolution.getFluxWithoutCWithoutGCR(Time.inDays(50)) , MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.638350174543e-15*77+.11,evolution.getFluxWithCWithGCR(Time.inDays(50)) , MAX_CALCULATED_PERCENT_ERROR);
		
		

		evolution.setA(1);
		evolution.setB1(7);
		evolution.setB2(7);
		evolution.setC(7);		
		

		AssertMore.assertEquals(9.9999999e-8,evolution.getFluxWithoutCWithoutGCR(Time.inDays(.1)) , MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(9.9999999e-8*7+.11,evolution.getFluxWithCWithGCR(Time.inDays(.1)) , MAX_CALCULATED_PERCENT_ERROR);
		
		
		
		
		
		
		
		
		evolution = new TimeEvolution();
		evolution.setA(.5);
		try {
			evolution.getFluxWithoutCWithoutGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		evolution.setB1(1);
		try {
			evolution.getFluxWithoutCWithoutGCR(Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10));
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		
		evolution.setB2(1);
		
		// test getting flux
		AssertMore.assertEquals(.073262555554936,   evolution.getFluxWithoutCWithoutGCR(Time.inDays(2)),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.0011106882367801,  evolution.getFluxWithoutCWithoutGCR(Time.inDays(4.5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.7413963540483e-7, evolution.getFluxWithoutCWithoutGCR(Time.inDays(9)),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.49999997835788, evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.4346314830038e-4,  evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(7)),  MAX_CALCULATED_PERCENT_ERROR);

		
		
		evolution.setA(.3);
		evolution.setB1(2);
		evolution.setB2(1.2);
		
		AssertMore.assertEquals(1.7012058568079e-23, 	evolution.getFluxWithoutCWithoutGCR(Time.inDays(9)),  					MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.4385450841903,      	evolution.getFluxWithoutCWithoutGCR(Time.inDays(.5)), 					MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.3323350970449, 		evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), 	MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(8.1943550490753e-12,  	evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(7)),  	MAX_CALCULATED_PERCENT_ERROR);


		evolution.setA(1);
		evolution.setB1(21);
		evolution.setB2(.999);
		AssertMore.assertEquals(13209725352.455, evolution.getFluxWithoutCWithoutGCR(Time.inDays(3.6)),   MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.050343,         evolution.getFluxWithoutCWithoutGCR(Time.inDays(100.2)), MAX_CALCULATED_PERCENT_ERROR);
		
		
		AssertMore.assertEquals( 3.649483097353e16, evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(10)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( .017479624785935,  evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(1)),  MAX_CALCULATED_PERCENT_ERROR);


		
		evolution = new TimeEvolution(); // this one does decrease to background fast enough.
		evolution.setA(1);
		evolution.setB1(2);
		evolution.setB2(2);
		AssertMore.assertEquals(.44311346269104, evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.5400423403186e-11,evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
		
		
		evolution = new TimeEvolution(); // this one dosn't decrease to background fast enough.
		evolution.setA(10);
		evolution.setB1(2);
		evolution.setB2(2);
		AssertMore.assertEquals(.35940307438545, evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.22333558144185,evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
		

		evolution = new TimeEvolution(); // this one dosn't decrease to background fast enough.
		evolution.setA(2);
		evolution.setB1(2);
		evolution.setB2(2);
		AssertMore.assertEquals(.88104013827695, evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.0047969805702995,evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
		
		
		evolution = new TimeEvolution(); // this one dosn't decrease to background fast enough.
		evolution.setA(3);
		evolution.setB1(2);
		evolution.setB2(2);
		AssertMore.assertEquals(1.1494098027217, evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(0),Time.inDays(5)), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(.11876536675582,evolution.getIntegralFluxWithoutCWithoutGCR(Time.inDays(5),Time.inDays(6)),  MAX_CALCULATED_PERCENT_ERROR);
			
		
		
		
		
		
		
	}

}
