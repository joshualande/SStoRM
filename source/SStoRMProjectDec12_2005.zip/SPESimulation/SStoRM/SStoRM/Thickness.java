package SStoRM;

public enum Thickness {
	POINT_THREE,
	ONE,
	FIVE,
	TEN,
	THIRTY;
	
	public String toString() {
		switch(this) {
		case POINT_THREE:
			return "0.3";
		case ONE:
			return "1";
		case FIVE:
			return "5";
		case TEN:
			return "10";
		case THIRTY:
			return "30";
		}
		return "";	
	}
}
