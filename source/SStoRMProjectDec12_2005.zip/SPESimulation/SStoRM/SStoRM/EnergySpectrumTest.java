package SStoRM;

public class EnergySpectrumTest extends junit.framework.TestCase {

	public static double MAX_EXACT_PERCENT_ERROR=.0000000000000000000001;
	public static double MAX_CALCULATED_PERCENT_ERROR = .00001;
	public static double MAX_WEAKER_CALCULATED_PERCENT_ERROR = .00003;
	
	public void testEqualsObject() {
		AssertMore.assertEquals(
				new EnergySpectrum(1e9,0,30,50),
				new EnergySpectrum(1e9,0,30,50)
		);
		AssertMore.assertEquals(
				new EnergySpectrum(1e9,0,30),
				new EnergySpectrum(1e9,0,30)
		);
		AssertMore.assertNotEquals(
				new EnergySpectrum(1e9, 0,30),
				new EnergySpectrum(1e10,0,30)
		);
		AssertMore.assertNotEquals(
				new EnergySpectrum(1e9, 0,30),
				new EnergySpectrum(1e9, 1,30)
		);
		AssertMore.assertNotEquals(
				new EnergySpectrum(1e9, 0,30),
				new EnergySpectrum(1e9, 0,50)
		);
		
		// emin can be different
		AssertMore.assertEquals(
				new EnergySpectrum(1,2.2,30.1,80),
				new EnergySpectrum(1,2.2,30.1,50)
		);
				
		// events can't be equal until they are set
		AssertMore.assertNotEquals(new EnergySpectrum(),new EnergySpectrum());
		AssertMore.assertNotEquals(new EnergySpectrum(1,1,100),new EnergySpectrum());
	}

	public void testClone() {
		EnergySpectrum spectrum1 = new EnergySpectrum(1e9,0,30,50);
		EnergySpectrum spectrum2 = (EnergySpectrum)spectrum1.clone();
		AssertMore.assertEquals(spectrum1,spectrum2);
		
		spectrum1.setGamma(4);
		AssertMore.assertNotEquals(spectrum1,spectrum2);
		spectrum2.setGamma(4);
		AssertMore.assertEquals(spectrum1,spectrum2);
		
		AssertMore.assertEquals(spectrum1,(EnergySpectrum)spectrum1.clone());
		AssertMore.assertEquals(spectrum2,(EnergySpectrum)spectrum2.clone());
		
		spectrum1= new EnergySpectrum(1,1,50,80);
		spectrum2 = (EnergySpectrum)spectrum1.clone();
		AssertMore.assertEquals(spectrum1,spectrum2);
		spectrum1.setEmin(100);
		AssertMore.assertEquals(spectrum1,spectrum2); // emin being different should be a problem
		spectrum1.setE0(20);
		AssertMore.assertNotEquals(spectrum1,spectrum2); 
		spectrum2.setE0(20);
		AssertMore.assertEquals(spectrum1,spectrum2); 

		spectrum1 = new EnergySpectrum(1e9,0,30,50);
		spectrum1.setIntegralFluence(1E9);
		spectrum2 = (EnergySpectrum)spectrum1.clone();
		AssertMore.assertEquals(spectrum1,spectrum2);
		spectrum1.setEmin(20);
		AssertMore.assertNotEquals(spectrum1,spectrum2); 
		spectrum1.setEmin(50);
		AssertMore.assertEquals(spectrum1,spectrum2);
		spectrum1.setEmin(20);
		AssertMore.assertNotEquals(spectrum1,spectrum2); 
		spectrum2.setEmin(20);
		AssertMore.assertEquals(spectrum1,spectrum2);
		spectrum1.setEmin(80);
		spectrum2.setEmin(80);
		AssertMore.assertEquals(spectrum1,spectrum2);
		
		
		
		
	}

	public void testEnergySpectrum() {
		EnergySpectrum spectrum;
		spectrum = new EnergySpectrum(1e5,.5,90,150);
		AssertMore.assertEquals(1e5,spectrum.getK(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(.5,spectrum.getGamma(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(90,spectrum.getE0(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(150,spectrum.getEmin(),MAX_EXACT_PERCENT_ERROR);
		
		spectrum = new EnergySpectrum();
		try {
			spectrum.getK();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.getGamma();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.getE0();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		spectrum = new EnergySpectrum(5,3.33,10);
		AssertMore.assertEquals(5,spectrum.getK(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(3.33,spectrum.getGamma(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(10,spectrum.getE0(),MAX_EXACT_PERCENT_ERROR);		
		try {
			spectrum.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
	}
	
	
	public void testSetSPE() {
		EnergySpectrum spectrum = new EnergySpectrum();
		spectrum.setEnergySpectrum(1,3,10);
		AssertMore.assertEquals(1,spectrum.getK(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(3,spectrum.getGamma(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(10,spectrum.getE0(),MAX_EXACT_PERCENT_ERROR);
		try {
			spectrum.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		
		spectrum.setEnergySpectrum(100,4,15,50);
		AssertMore.assertEquals(100,spectrum.getK(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(4,spectrum.getGamma(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(15,spectrum.getE0(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(50,spectrum.getEmin(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetEmin() {
		EnergySpectrum spectrum = new EnergySpectrum();
		try {
			spectrum.getEmin();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		spectrum.setEmin(45);
		AssertMore.assertEquals(45,spectrum.getEmin(),MAX_EXACT_PERCENT_ERROR);
		

		try {
			spectrum.setEmin(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setEmin(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setEmin(0);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setEmin(9.9);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setEmin(1501);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		AssertMore.assertEquals(45,spectrum.getEmin(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetE0() {
		EnergySpectrum spectrum = new EnergySpectrum();
		try {
			spectrum.getE0();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		spectrum.setE0(45);
		AssertMore.assertEquals(45,spectrum.getE0(),MAX_EXACT_PERCENT_ERROR);
		try {
			spectrum.setE0(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			spectrum.setE0(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
			
		try {
			spectrum.setE0(9.9);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setE0(501);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		AssertMore.assertEquals(45,spectrum.getE0(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetGamma() {
		EnergySpectrum spectrum = new EnergySpectrum();
		try {
			spectrum.getGamma();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		spectrum.setGamma(2.21);
		AssertMore.assertEquals(2.21,spectrum.getGamma(),MAX_EXACT_PERCENT_ERROR);
		

		try {
			spectrum.setGamma(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setGamma(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		
		try {
			spectrum.setGamma(-.0001);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setGamma(4.126);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		AssertMore.assertEquals(2.21,spectrum.getGamma(),MAX_EXACT_PERCENT_ERROR);
	}

	public void testGetSetKandEnergySpectrumIntegralFluence() {
		EnergySpectrum spectrum = new EnergySpectrum();

		try {
			spectrum.setK(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setK(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};

		try {
			spectrum.setK(-1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setIntegralFluence(Double.NaN);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setIntegralFluence(Double.POSITIVE_INFINITY);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		try {
			spectrum.setIntegralFluence(-1);
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {};
		
		
		
		
		
		
		
		spectrum = new EnergySpectrum(1,3,50,500);
		AssertMore.assertEquals(1,spectrum.getK(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(2.9430355293715e-6,spectrum.getFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(3.631994380988e-13,spectrum.getFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.4195050212441e-11,spectrum.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		spectrum.setEmin(1000);
		AssertMore.assertEquals(9.0091168133463e-17,spectrum.getIntegralFluence(),MAX_WEAKER_CALCULATED_PERCENT_ERROR);
		spectrum.setEmin(666);
		AssertMore.assertEquals(2.2909144215819e-13,spectrum.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		spectrum.setEmin(10);
		AssertMore.assertEquals(.0035194531243864,spectrum.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		
		spectrum.setIntegralFluence(1e9);
		AssertMore.assertEquals(1e9,spectrum.getIntegralFluence(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(284135052991.89,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(836219.55609498,spectrum.getFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10319769159113,spectrum.getFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		
		spectrum.setK(284135052991.89);
		AssertMore.assertEquals(1e9,spectrum.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(284135052991.89,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(836219.55609498,spectrum.getFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.10319769159113,spectrum.getFluence(500),MAX_CALCULATED_PERCENT_ERROR);
		
		spectrum.setIntegralFluence(5);
		spectrum.setEmin(500);
		AssertMore.assertEquals(352235457090.38,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5,spectrum.getIntegralFluence(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(1036641.4649214,spectrum.getFluence(50),MAX_CALCULATED_PERCENT_ERROR);
		
		spectrum.setK(50);
		spectrum.setE0(500);
		spectrum.setEmin(10);
		AssertMore.assertEquals(50,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.24048414540948,spectrum.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.24048414540948,spectrum.getIntegralFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(0.008325829170022,spectrum.getIntegralFluence(50),MAX_WEAKER_CALCULATED_PERCENT_ERROR);

		spectrum.setIntegralFluence(30);
		spectrum.setGamma(2);
		spectrum.setE0(50);
		spectrum.setEmin(60);
		AssertMore.assertEquals(16201.024079494,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		spectrum.setEmin(50);
		AssertMore.assertEquals(10101.315724163,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		spectrum.setGamma(2.5);
		AssertMore.assertEquals(83854.728083211,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		spectrum.setE0(101);
		spectrum.setIntegralFluence(60);
		AssertMore.assertEquals(79389.538225372,spectrum.getK(),MAX_CALCULATED_PERCENT_ERROR);
		
		spectrum.setK(79389.538225372);
		AssertMore.assertEquals(79389.538225372,spectrum.getK(),MAX_EXACT_PERCENT_ERROR);
		AssertMore.assertEquals(60,spectrum.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		
			
		
		// code copied from test of SolarParticleEvent.
		EnergySpectrum event = new EnergySpectrum(1e9,0,30);
		AssertMore.assertEquals(716531310.57379 , event.getFluence(10),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2.149593931714e10, 	event.getIntegralFluence(10),			MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.1036383235144e10, event.getIntegralFluence(30),			MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(4.0600584970986e9,  event.getIntegralFluence(60),			MAX_CALCULATED_PERCENT_ERROR);
		try { 
			event.getIntegralFluence();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setEmin(10);
		AssertMore.assertEquals(2.149593931714e10, 	event.getIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30); // set emin
		AssertMore.assertEquals(1.1036383235144e10, event.getIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setK(2.2e7); // change k
		AssertMore.assertEquals(242800431.17315, event.getIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(472910664.97871, event.getIntegralFluence(10),	MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(10);// change emin
		event.setGamma(3.01); // change gamma
		AssertMore.assertEquals(61025.805350301, event.getIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		event.setE0(112); // change E0
		AssertMore.assertEquals(90782.963349881, event.getIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		// second statment to check caching mechanism.
		AssertMore.assertEquals(90782.963349881, event.getIntegralFluence(),	MAX_CALCULATED_PERCENT_ERROR);
		// when we set the energy spectrum, k should be calculated automatically.
		event.setIntegralFluence(1.02e10);
		AssertMore.assertEquals(2471829423932.3,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(2471829423932.3,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK(2471829423932.3);
		AssertMore.assertEquals(2471829423932.3,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.02e10,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK(1111.111);
		event.setEmin(30);
		event.setGamma(1.99);
		event.setE0(202.2);
		AssertMore.assertEquals(1111.111,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(24.814069093002,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(7.8710442609193,event.getIntegralFluence(66),MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(66);
		AssertMore.assertEquals(7.8710442609193,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		event.setIntegralFluence(666);
		AssertMore.assertEquals(666, event.getIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(94015.470053217, event.getK(), MAX_CALCULATED_PERCENT_ERROR);
		event.setEmin(30); // change Emin
		AssertMore.assertEquals(666, event.getIntegralFluence(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(29821.788729068, event.getK(), MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals( 290.43919751046 , event.getFluence(10), MAX_CALCULATED_PERCENT_ERROR);
		event = new EnergySpectrum(1e9,0,30);
		event.setIntegralFluence(1000);
		AssertMore.assertEquals(1000,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		try {
			event.getK(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}		
		event = new EnergySpectrum(1e9,0,30);
		try {
			event.getIntegralFluence(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event = new EnergySpectrum();
		try {
			event.getIntegralFluence(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getK(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		try {
			event.getE0(); 
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setE0(80);
		AssertMore.assertEquals(80,event.getE0(),MAX_CALCULATED_PERCENT_ERROR);
		event.setGamma(1);
		AssertMore.assertEquals(1,event.getGamma(),MAX_CALCULATED_PERCENT_ERROR);
		event.setIntegralFluence(1);
		try {
			event.getK();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setK(10);
		try {
			event.getIntegralFluence();
			AssertMore.fail("Error should have been thrown");
		} catch (Exception e) {}
		event.setEmin(22);
		AssertMore.assertEquals(22,event.getEmin(),MAX_CALCULATED_PERCENT_ERROR);
		event.setIntegralFluence(1);
		AssertMore.assertEquals(1,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1.0299079093937, event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK(1.0299079093937);
		AssertMore.assertEquals(1.0299079093937, event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(1,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		event.setK(5e9);
		AssertMore.assertEquals(4854802991.9913,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(5e9,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		event.setIntegralFluence(999);
		AssertMore.assertEquals(1028.8780014843,event.getK(),MAX_CALCULATED_PERCENT_ERROR);
		AssertMore.assertEquals(999,event.getIntegralFluence(),MAX_CALCULATED_PERCENT_ERROR);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}



}
